# Rezultate Triangulație pe Date Reale Classic BT (DLT 255)

Data executării: 2026-07-29  
Sursă date: `ubertooth-standalone/data/captures` (Capturile din 17 Iunie 2026 - Filtru Strict Classic BT `rx_*.pcap`)  
Ferestre temporale per colț (conform `Logs.md`):
- `stanga_sus`: 08:50 - 09:10
- `stanga_jos`: 08:55 - 09:15
- `dreapta_jos`: 09:00 - 09:20
- `dreapta_sus`: 09:05 - 09:25

---

## Corectură (audit 2026-07-30)

> [!WARNING] Rezultatele de poziționare per-dispozitiv de mai jos sunt RETRASE
> Câmpul „LAP" citit din pseudoheader-ul Ubertooth (22 bytes) pentru capturile `rx_*.pcap` de mai sus este marcat explicit de tshark ca **nevalidat**: `Reference LAP Valid: False`, `BR or EDR Data Present: False`, fără CRC/HEC. Nu e identitate confirmată de dispozitiv — e doar metadată radio de hop-scan, nesuficientă ca să distingă 27 dispozitive reale distincte.
>
> Consecință: cele „27 dispozitive triangulate" din tabelele de mai jos (identice ca număr pe toți cei 4 algoritmi, ceea ce ar trebui să fie deja un semnal) **nu reprezintă poziții confirmate de dispozitive individuale**. Coordonatele (x, y) per `anon_*` din tabele sunt **invalidate**.
>
> Ce rămâne valid din setul de date 17 iunie: un survey RF anonim per colț (variație de semnal/activitate pe canal Classic), fără atribuire de identitate per dispozitiv. Hărțile PNG de mai jos rămân în notă doar ca demonstrație funcțională a algoritmilor (validați separat pe date sintetice), nu ca „hărți reale" — vezi eticheta adăugată la fiecare imagine.

---

## Algoritm: `CENTROID`

**Dispozitive triangulate**: ~~27~~ RETRAS — vezi Corectură (LAP nevalidat, nu identitate confirmată)  
**Fracție potrivire**: 0.00%

### Hartă Spațială 2D (`CENTROID`) — demo algoritm, NU date reale de poziție

![Harta 2D centroid — demo algoritm pe date sintetice/neconfirmate](file:///home/vlads4r4/dev/Licenta/LicentaVault/real_map_centroid.png)

### Tabel Rezultate Poziționare (`CENTROID`)

| device_id   |       x |       y | confidence   |
|:------------|--------:|--------:|:-------------|
| anon_007cb8 | 4       | 3       | 4/4          |
| anon_08dff6 | 3.8918  | 2.88199 | 4/4          |
| anon_0a8240 | 4.01954 | 3.18206 | 4/4          |
| anon_10d89f | 3.69776 | 2.80427 | 4/4          |
| anon_157475 | 3.48905 | 2.80701 | 4/4          |
| anon_1d2e97 | 4.41896 | 1.66241 | 3/4          |
| anon_24ab4b | 3.91816 | 3.06938 | 4/4          |
| anon_2ef787 | 2.66667 | 2       | 3/4          |
| anon_3375e7 | 2.66667 | 2       | 3/4          |
| anon_392a21 | 4.10308 | 1.56578 | 3/4          |
| anon_3ac1b9 | 3.96635 | 2.98845 | 4/4          |
| anon_4df0cc | 4.23031 | 2.82727 | 4/4          |
| anon_617248 | 6.56034 | 2.52148 | 3/4          |
| anon_66b941 | 4.12375 | 3.10021 | 4/4          |
| anon_73e933 | 4.51513 | 2.98977 | 4/4          |
| anon_77aed5 | 3.72444 | 3.07614 | 4/4          |
| anon_85c1e5 | 4.25688 | 2.9728  | 4/4          |
| anon_8689bb | 4.00181 | 2.88254 | 4/4          |
| anon_86e7c4 | 3.95198 | 3.00518 | 4/4          |
| anon_8f5f30 | 4       | 3       | 4/4          |
| anon_a2b65d | 3.87948 | 2.98787 | 4/4          |
| anon_b13715 | 3.51501 | 2.94604 | 4/4          |
| anon_b4ab6b | 3.68458 | 3.08478 | 4/4          |
| anon_bc0280 | 2.66667 | 2       | 3/4          |
| anon_be5501 | 3.17456 | 3.06954 | 4/4          |
| anon_c77c74 | 4.546   | 3.03883 | 4/4          |
| anon_e31bf9 | 4.22358 | 2.83231 | 4/4          |

---

## Algoritm: `WLS`

**Dispozitive triangulate**: ~~27~~ RETRAS — vezi Corectură (LAP nevalidat, nu identitate confirmată)  
**Fracție potrivire**: 0.00%

### Hartă Spațială 2D (`WLS`) — demo algoritm, NU date reale de poziție

![Harta 2D wls — demo algoritm pe date sintetice/neconfirmate](file:///home/vlads4r4/dev/Licenta/LicentaVault/real_map_wls.png)

### Tabel Rezultate Poziționare (`WLS`)

| device_id   |       x |       y | confidence   |
|:------------|--------:|--------:|:-------------|
| anon_007cb8 | 4       | 3       | 4/4          |
| anon_08dff6 | 3.96691 | 2.82861 | 4/4          |
| anon_0a8240 | 4.00027 | 3.10451 | 4/4          |
| anon_10d89f | 3.74975 | 2.86627 | 4/4          |
| anon_157475 | 3.87168 | 2.93615 | 4/4          |
| anon_1d2e97 | 3.35179 | 3.01767 | 3/4          |
| anon_24ab4b | 3.9813  | 3.02937 | 4/4          |
| anon_2ef787 | 4       | 3       | 3/4          |
| anon_3375e7 | 4       | 3       | 3/4          |
| anon_392a21 | 3.53573 | 3.05753 | 3/4          |
| anon_3ac1b9 | 3.99915 | 2.99976 | 4/4          |
| anon_4df0cc | 4.04062 | 2.94584 | 4/4          |
| anon_617248 | 5.45954 | 3.04696 | 3/4          |
| anon_66b941 | 4.01501 | 3.00993 | 4/4          |
| anon_73e933 | 4.00907 | 2.99691 | 4/4          |
| anon_77aed5 | 3.97881 | 3.01284 | 4/4          |
| anon_85c1e5 | 4.01609 | 2.99534 | 4/4          |
| anon_8689bb | 3.99662 | 2.98341 | 4/4          |
| anon_86e7c4 | 3.99587 | 3.00119 | 4/4          |
| anon_8f5f30 | 4       | 3       | 4/4          |
| anon_a2b65d | 3.99283 | 2.9985  | 4/4          |
| anon_b13715 | 3.93836 | 2.98379 | 4/4          |
| anon_b4ab6b | 3.4489  | 3.09325 | 4/4          |
| anon_bc0280 | 4       | 3       | 3/4          |
| anon_be5501 | 3.93407 | 3.00243 | 4/4          |
| anon_c77c74 | 4.08482 | 2.97262 | 4/4          |
| anon_e31bf9 | 4.04279 | 2.94294 | 4/4          |

---

## Algoritm: `KALMAN`

**Dispozitive triangulate**: ~~27~~ RETRAS — vezi Corectură (LAP nevalidat, nu identitate confirmată)  
**Fracție potrivire**: 0.00%

### Hartă Spațială 2D (`KALMAN`) — demo algoritm, NU date reale de poziție

![Harta 2D kalman — demo algoritm pe date sintetice/neconfirmate](file:///home/vlads4r4/dev/Licenta/LicentaVault/real_map_kalman.png)

### Tabel Rezultate Poziționare (`KALMAN`)

| device_id   |       x |       y | confidence   |
|:------------|--------:|--------:|:-------------|
| anon_007cb8 | 4       | 3       | 4/4          |
| anon_08dff6 | 3.97381 | 2.84701 | 4/4          |
| anon_0a8240 | 3.9982  | 3.10779 | 4/4          |
| anon_10d89f | 3.84706 | 2.91261 | 4/4          |
| anon_157475 | 3.92527 | 2.97188 | 4/4          |
| anon_1d2e97 | 3.35179 | 3.01767 | 3/4          |
| anon_24ab4b | 3.98069 | 3.02821 | 4/4          |
| anon_2ef787 | 4       | 3       | 3/4          |
| anon_3375e7 | 4       | 3       | 3/4          |
| anon_392a21 | 3.53573 | 3.05753 | 3/4          |
| anon_3ac1b9 | 3.99891 | 2.99961 | 4/4          |
| anon_4df0cc | 4.04062 | 2.94584 | 4/4          |
| anon_617248 | 5.45954 | 3.04696 | 3/4          |
| anon_66b941 | 4.0193  | 3.01275 | 4/4          |
| anon_73e933 | 4.00902 | 2.99645 | 4/4          |
| anon_77aed5 | 3.97794 | 3.01138 | 4/4          |
| anon_85c1e5 | 4.01606 | 2.99546 | 4/4          |
| anon_8689bb | 3.99668 | 2.98337 | 4/4          |
| anon_86e7c4 | 3.99586 | 3.0012  | 4/4          |
| anon_8f5f30 | 4       | 3       | 4/4          |
| anon_a2b65d | 3.99278 | 2.99843 | 4/4          |
| anon_b13715 | 3.93922 | 2.9916  | 4/4          |
| anon_b4ab6b | 3.57262 | 3.224   | 4/4          |
| anon_bc0280 | 4       | 3       | 3/4          |
| anon_be5501 | 3.93771 | 3.0017  | 4/4          |
| anon_c77c74 | 4.08416 | 2.96794 | 4/4          |
| anon_e31bf9 | 4.04279 | 2.94294 | 4/4          |

---

## Algoritm: `HYBRID`

**Dispozitive triangulate**: ~~27~~ RETRAS — vezi Corectură (LAP nevalidat, nu identitate confirmată)  
**Fracție potrivire**: 0.00%

### Hartă Spațială 2D (`HYBRID`) — demo algoritm, NU date reale de poziție

![Harta 2D hybrid — demo algoritm pe date sintetice/neconfirmate](file:///home/vlads4r4/dev/Licenta/LicentaVault/real_map_hybrid.png)

### Tabel Rezultate Poziționare (`HYBRID`)

| device_id   |       x |       y | confidence   |
|:------------|--------:|--------:|:-------------|
| anon_007cb8 | 4       | 3       | 4/4          |
| anon_08dff6 | 3.97381 | 2.84701 | 4/4          |
| anon_0a8240 | 3.9982  | 3.10779 | 4/4          |
| anon_10d89f | 3.84706 | 2.91261 | 4/4          |
| anon_157475 | 3.92527 | 2.97188 | 4/4          |
| anon_1d2e97 | 3.35179 | 3.01767 | 3/4          |
| anon_24ab4b | 3.98069 | 3.02821 | 4/4          |
| anon_2ef787 | 4       | 3       | 3/4          |
| anon_3375e7 | 4       | 3       | 3/4          |
| anon_392a21 | 3.53573 | 3.05753 | 3/4          |
| anon_3ac1b9 | 3.99891 | 2.99961 | 4/4          |
| anon_4df0cc | 4.04062 | 2.94584 | 4/4          |
| anon_617248 | 5.45954 | 3.04696 | 3/4          |
| anon_66b941 | 4.0193  | 3.01275 | 4/4          |
| anon_73e933 | 4.00902 | 2.99645 | 4/4          |
| anon_77aed5 | 3.97794 | 3.01138 | 4/4          |
| anon_85c1e5 | 4.01606 | 2.99546 | 4/4          |
| anon_8689bb | 3.99668 | 2.98337 | 4/4          |
| anon_86e7c4 | 3.99586 | 3.0012  | 4/4          |
| anon_8f5f30 | 4       | 3       | 4/4          |
| anon_a2b65d | 3.99278 | 2.99843 | 4/4          |
| anon_b13715 | 3.93922 | 2.9916  | 4/4          |
| anon_b4ab6b | 3.57262 | 3.224   | 4/4          |
| anon_bc0280 | 4       | 3       | 3/4          |
| anon_be5501 | 3.93771 | 3.0017  | 4/4          |
| anon_c77c74 | 4.08416 | 2.96794 | 4/4          |
| anon_e31bf9 | 4.04279 | 2.94294 | 4/4          |

---

