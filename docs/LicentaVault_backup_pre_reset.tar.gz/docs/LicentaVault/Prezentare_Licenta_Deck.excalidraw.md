---

excalidraw-plugin: parsed
tags: [excalidraw, prezentare, licenta, bluetooth-triangulation]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==

# Excalidraw Data

## Text Elements

PROIECT DE LICENȚĂ 2026 | UNIVERSITATEA POLITEHNICA BUCUREȘTI ^s1_badge_txt

Sistem Pasiv de Triangulare și Poziționare Indoor pe Bluetooth Classic ^s1_title

Captură Hardware Ubertooth One la 2.4 GHz, Pipeline Decuplat & Estimare Matematică Deterministică (LDPL, WLS, EKF) ^s1_subtitle

PILONUL 1: CAPTURĂ HARDWARE 100% PASIVĂ ^s1_pil_1_hdrt

• Hardware Sniffer: Receptoare SDR Ubertooth One (2.4 GHz ISM)
• Microcontroller dedicat: LPC175x ARM Cortex-M3 + CC2400
• Zero Intruziune: Fără pairing, asociere sau aplicații pe telefon
• Extragere LAP: Lower Address Part extras direct din preambul
• Hardware Guardrails: Mod Listen-Only forțat în firmware (TX blocat) ^s1_pil_1_txt

PILONUL 2: ESTIMARE DETERMINISTICĂ EXPLICABILĂ ^s1_pil_2_hdrt

• Modelare Fizică LDPL: Inversare analitică deterministă RSSI -> Distanță
• Filtrare Rolling Max (1500 ms): Reține anvelopa superioară LOS
• Optimizare WLS: Soluție analitică (A^T W A)^-1 A^T W b în sub 0.15 ms
• Extended Kalman Filter (EKF): Urmărire cinematică lină cu inerție
• Excludere ML Opac: Fără 'black-box' neuronale sau salturi false ^s1_pil_2_txt

PILONUL 3: ARHITECTURĂ & LIVRABILE COMPLETE ^s1_pil_3_hdrt

• Decuplare pe 4 Straturi: Shell UI, Orchestrare, Math, Hardware SDR
• Sincronizare Temporală: Jitter cross-window măsurat < 14.8 ms
• Interfețe Duble: Tauri Desktop (Rust 60 FPS) + Web Streamlit
• Testare Exhaustivă: 120 / 120 teste automate PyTest + Vitest (100% PASS)
• Pipeline Producție: Validare statică riguroasă prin contracte Pydantic ^s1_pil_3_txt

(AᵀWA)⁻¹ ^s1_math_txt

120/120 ✓ ^s1_pass_txt

FLUXUL DE DATE END-TO-END: DE LA CAPTURA RADIO SDR LA INTERFAȚA DE OPERATOR ^s1_flow_lbl

1. ȚINTĂ SMARTPHONE ^s1_st_0_hdrt

• Dispozitiv activ în sală
• Emisie BR/EDR (2.4 GHz ISM)
• Pachete ID/FHS nesincronizate
• Adresă LAP în clar în header ^s1_st_0_txt

2. UBERTOOTH ONE ^s1_st_1_hdrt

• Receptor SDR CC2400 2.4 GHz
• Microcontroller ARM Cortex-M3
• Monitorizare fizică 100% pasivă
• Extragere RSSI hardware ^s1_st_1_txt

3. EXTRACTOR PCAP ^s1_st_2_hdrt

• Parsare flux PyShark / libbtbb
• Filtrare LAP țintă (0x9e8b33)
• Fereastră mobilă cross-window
• Filtru Rolling Max (anvelopă LOS) ^s1_st_2_txt

4. ESTIMATOR WLS+EKF ^s1_st_3_hdrt

• Inversare LDPL metrică (d_i)
• Ponderare inversă a varianței
• Soluție Gauss-Markov (O(1))
• Propagare cinematică 4D EKF ^s1_st_3_txt

5. OPERATOR UI ^s1_st_4_hdrt

• Tauri Desktop App (Rust IPC)
• Randare Canvas 2D la 60 FPS
• Dashboard Științific Streamlit
• Monitorizare spectru & erori ^s1_st_4_txt

2.4 GHz ISM ^s1_arr_0_lbl

USB FIFO ^s1_arr_1_lbl

RSSI LOS ^s1_arr_2_lbl

(x,y), P_k ^s1_arr_3_lbl

💡 Teză Cheie:
Poziționare 100% pasivă pe Bluetooth Classic fără cooperarea țintei,
folosind pachete de interogare BR/EDR și adrese LAP în clar! ^s1_snote_txt

Sesiune Susținere Proiect de Licență | Universitatea Politehnica București | Candidat: Vlad Sărățeanu | Iulie 2026 ^s1_foot

02 / FIZICA PROPAGĂRII RF & JUSTIFICAREA MODELULUI MATEMATIC ^s2_badge_txt

Fizica Propagării la 2.4 GHz & De ce NU Folosim Machine Learning ^s2_title

Analiza fenomenelor electromagnetice reale (Multipath, Body Shadowing) și limitele fatale ale rețelelor neuronale ^s2_subtitle

FENOMENELE FIZICE LA 2.4 GHz & SOLUȚII DETERMINISTICE ^s2_col1_hdrt

1. MULTIPATH FADING (INTERFERENȚE DISTRUCTIVE) ^s2_multi_t

• Undele radio electromagnetice ricoșează din pereții de beton, mobilier și tavan.
• Razele reflectate sosesc la receptor defazate, producând interferențe distructive.
• Consecință: Scăderi bruște de semnal (până la -78 dBm) chiar dacă ținta stă pe loc!
• Soluția Noastră: Filtrul Rolling Max (W = 1500 ms) reține anvelopa superioară LOS
  (Line-of-Sight), eliminând peste 90% din distorsiunile de reflexie. ^s2_multi_body

2. BODY SHADOWING (UMBRIREA CORPORALĂ) ^s2_shad_t

• Corpul uman conține ~70% apă, reprezentând un atenuator masiv la rezonanța de 2.4 GHz.
• Când o persoană se interpune între smartphone și o ancoră, semnalul scade cu 3–9 dB.
• Consecință: Estimatorul naiv interpretează atenuarea ca o distanțare de 3-5 metri!
• Soluția Noastră: EKF adaptează dinamic covarianța măsurătorii R_k și folosește
  inerția cinematică de viteză constantă [v_x, v_y] pentru a preveni salturile false. ^s2_shad_body

Atenuare 3-9 dB
(70% apă) ^s2_dood_conetxt

Perete Beton ^s2_dood_wallt

Rază Reflectată (Drop RSSI) ^s2_dood_reflt

DE CE NU REȚELE NEURONALE (SUPERVISED ML / FINGERPRINTING)? ^s2_col2_hdrt

1. COST PROHIBITIV DE COLECTARE DATE ^s2_ml_1_t

O grilă de 0.5m impune peste 400 de puncte de calibrare pentru o sală de 80 m²,
reprezentând peste 30 de ore de măsurători manuale pentru fiecare încăpere nouă! ^s2_ml_1_b

2. FRAGILITATE EXTREMĂ LA FACTORII DE MEDIU ^s2_ml_2_t

O ușă deschisă, o masă mutată sau apariția unor persoane în sală modifică topologia
reflexiilor și invalidează complet setul de antrenare (concept drift masiv). ^s2_ml_2_b

3. EFECTUL DE CUTIE NEAGRĂ (BLACK-BOX) ^s2_ml_3_t

Rețelele neuronale nu oferă o marjă analitică de eroare (lipsă matrice de covarianță formală)
și pot halucina salturi bruște la marginea distribuției de antrenare. ^s2_ml_3_b

4. ZERO PORTABILITATE ÎNTRE CAMERE ^s2_ml_4_t

Un model antrenat în Sala A are performanțe catastrofale în Sala B. Transfer learning-ul
eșuează din cauza dimensiunilor și a coeficienților diferiți de absorbție ai pereților. ^s2_ml_4_b

5. ABORDAREA NOASTRĂ DETERMINISTICĂ (LDPL + WLS) ^s2_ml_5_t

• Funcționează INSTANT în orice încăpere nouă prin simpla specificare a dimensiunilor
  și a exponentului de atenuare n in [2.2, 3.0] specific mediului indoor.
• Rigurozitate matematică: Furnizează matricea de covarianță formală Cov(x) la fiecare pas! ^s2_ml_5_b

⚡ Cheia Fizică:
Filtrul Rolling Max reține LOS pur prin urmărirea anvelopei superioare,
fără nicio recalibrare continuă și fără fragilitatea fingerprinting-ului RF! ^s2_snote_txt

03 / ARHITECTURĂ DE SISTEM PE 4 STRATURI ^s3_badge_txt

Arhitectura Decuplată & Pipeline-ul de Date de la L1 la L4 ^s3_title

Separarea strictă a responsabilităților, validare statică Pydantic și garanții de siguranță hardware ^s3_subtitle

STRATUL 1: SHELL UI & VIZUALIZARE OPERATOR ^s3_lay_1_hdrt

• Tauri Desktop App (Rust IPC): Randare nativă Canvas 2D la 60 FPS, latență sub 16 ms, zero dependențe Node.js la runtime
• Streamlit Scientific Web Dashboard: Tuning dinamic în timp real al parametrilor fizici (n, fereastră W, praguri RSSI)
• Arhitectură decuplată: Interfețele consumă fluxuri serializate JSON fără a interacționa direct cu driverele SDR ^s3_lay_1_txt

STRATUL 2: ORCHESTRARE & VALIDARE STARE (pipeline.py) ^s3_lay_2_hdrt

• SessionController: Mașină de stări finită (IDLE -> SCANNING -> AGGREGATING -> SOLVED) cu agregare cross-window
• SchemaEngine (Pydantic): Validare riguroasă a contractelor de date între module; eliminare automată a pachetelor trunchiate
• Hardware Guardrails: Mod Listen-Only forțat în firmware; interdicție absolută de transmisie TX sau operațiuni DFU flash ^s3_lay_2_txt

STRATUL 3: EXTRAGERE PCAP & PIPELINE MATEMATIC (positioning.py) ^s3_lay_3_hdrt

• PyShark PCAP Live Extractor: Parsare pachete BR/EDR din FIFO (140 pkt/s -> 15 epoci/s) și decodare LAP cu libbtbb
• Filtru Rolling Max & Inversare LDPL: Extragere anvelopă LOS pe fereastră mobilă de 1500 ms și conversie RSSI -> distanță
• Motor Gauss-Markov WLS + EKF: Soluție analitică O(1) deterministă în sub 0.15 ms și propagare stare cinematică 4D ^s3_lay_3_txt

STRATUL 4: HARDWARE RADIO SDR (Ubertooth One & libbtbb) ^s3_lay_4_hdrt

• Receptoare SDR 2.4 GHz: Transceiver CC2400 + MCU LPC175x ARM Cortex-M3 conectate prin magistrale USB independente
• Sniffing pasiv de pachete: Decodare preambul și extragere RSSI hardware direct din banda de bază fără asociere pe piconet
• Stabilitate hardware: Buffer circular intern FIFO pentru prevenirea overflow-ului la rate ridicate de interogare radio ^s3_lay_4_txt

GARANȚII CHEIE ALE ARHITECTURII ^s3_guar_hdrt

• Latență de calcul matematic: sub 0.15 ms per epocă
• Sincronizare cross-window: Jitter măsurat < 14.8 ms
• Garanție Zero TX: Interdicție hardware de emisie radio
• Test coverage: 120 teste automate (PyTest + Vitest)
• Decuplare completă: Module testabile izolat prin mock-uri
• Contracte stricte: Pydantic SchemaEngine la orice frontieră ^s3_guar_body

● ● ●  ubertooth-daemon (listen-only monitor) ^s3_console_dots

[SYNC] Anchor A1 CC2400: LAP=0x9e8b33 RSSI=-61dBm
[SYNC] Anchor A2 CC2400: LAP=0x9e8b33 RSSI=-52dBm
[SYNC] Anchor A3 CC2400: LAP=0x9e8b33 RSSI=-68dBm
[SYNC] Anchor A4 CC2400: LAP=0x9e8b33 RSSI=-74dBm
[WLS]  Epoch 142 -> x=8.95m, y=1.25m (0.08ms)
[GUARD] TX blocked by firmware register: OK ^s3_console_txt

🔒 Hardware Guardrail:
Firmware-ul blochează forțat orice emisie TX. Sistemul este 100% pasiv,
etic și complet indetectabil în spectrul electromagnetic! ^s3_snote_txt

04 / GEOMETRIE SPAȚIALĂ & CAPCANA CONVEX HULL ^s4_badge_txt

Harta Sălii de Laborator & De ce Eșuează Matematic Centroidul Ponderat ^s4_title

Comparație spațială directă: Capcana interiorului Convex Hull vs. Intersecția hiper-suprafețelor WLS ^s4_subtitle

HARTA GEOMETRICĂ A SĂLII DE EXPERIMENT (10.0m x 8.0m) ^s4_map_hdrt

Perimetru Convex Hull al Ancorelor ^s4_hull_lbl

A1 (0.0m, 0.0m) ^s4_anc_1_lbl

A2 (10.0m, 0.0m) ^s4_anc_2_lbl

A3 (10.0m, 8.0m) ^s4_anc_3_lbl

A4 (0.0m, 8.0m) ^s4_anc_4_lbl

ȚINTĂ REALĂ (9.0m, 1.2m) ^s4_gt_txt

Estimare WLS (8.95m, 1.25m)
Eroare: doar 0.08m! ✓ ^s4_wls_txt

Centroid Ponderat (7.0m, 2.8m)
Eroare masivă: 2.52m! ✗ ^s4_cen_txt

Tracțiune A1 ^s4_pull_a1_t

Tracțiune A4 ^s4_pull_a4_t

Legendă: 🟡 Țintă Reală (9.0m, 1.2m) | 🟢 Estimare WLS (Eroare 0.08m) | 🔴 Centroid (Eroare 2.52m - Tras spre Centru) ^s4_legend_txt

DE CE EȘUEAZĂ MATEMATIC CENTROIDUL (CAPCANA CONVEX HULL) ^s4_rc1_hdrt

x_c = Σ(w_i * a_i) / Σ(w_i),   w_i = 1 / d_i^p ^s4_rc1_form

• Teoremă Convexă: Oricare ar fi ponderile w_i > 0, poziția estimată x_c este
  strict constrânsă în interiorul poligonului convex format de ancore.
• Tracțiune spre interior: Când ținta este la 0.5m de perete lângă A2, ancorele
  îndepărtate (A1, A4) exercită forțe vectoriale continue spre centrul sălii.
• Consecință practică: Centroidul nu poate ajunge niciodată lângă perete!
  Pe date reale, generează o eroare inacceptabilă de 2.52 metri. ^s4_rc1_body

CUM REZOLVĂ WLS POZIȚIA EXACTĂ (0.08m EROARE) ^s4_rc2_hdrt

x̂_WLS = (Aᵀ W A)⁻¹ Aᵀ W b ^s4_rc2_form

• Eliminarea constrângerii: WLS rezolvă intersecția hiper-suprafețelor cercurilor
  fără nicio constrângere de convexitate.
• Ponderare optimă cu varianța: W_ii = 1 / σ_i² penalizează drastic ancorele îndepărtate.
• Izolarea ancorei apropiate: Ancora A2 primește pondere masivă, fixând poziția
  exact lângă perete la coordonatele reale.
• Rezultat: Eroarea scade de la 2.52m la doar 0.08m (reducere cu 69% pe capturi reale)! ^s4_rc2_body

⚠️ Capcana Convex Hull:
Centroidul este prizonierul matematic al poligonului ancorelor.
WLS calculează intersecția liberă și rezolvă poziționarea lângă pereți! ^s4_snote_txt

05 / FORMULARE MATEMATICĂ DETERMINISTICĂ ^s5_badge_txt

Pipeline-ul Matematic: LDPL, Liniarizare WLS & Filtru Kalman EKF ^s5_title

De la atenuarea logaritmică a puterii RF la estimarea BLUE și propagarea stării cinematice ^s5_subtitle

1. CONVERSIE METRICĂ LDPL & ROLLING MAX ^s5_c1_hdrt

Modelul de Propagare Log-Distance Path Loss: ^s5_c1_lbl1

RSSI(d) = P_tx - 10·n·log₁₀(d) + X_σ ^s5_c1_eq1

Inversarea Metrică Analitică: ^s5_c1_lbl2

d_i = 10^((P_tx - RSSI_i) / (10·n)) ^s5_c1_eq2

• P_tx = -59 dBm: Puterea de referință la d₀ = 1.0 m
• n in [2.2, 3.0]: Exponentul de atenuare a mediului
• X_σ ~ N(0, σ²): Zgomotul Gaussian de fading ^s5_c1_exp

Filtru Rolling Max (LOS Recovery): ^s5_c1_boxt

RSSI_LOS(t) = max { RSSI(τ) : τ ∈ [t - W, t] } ^s5_c1_boxeq

• Fereastră mobilă W = 1500 ms pe fiecare canal
• Extrage anvelopa superioară neafectată de fading
• Elimină peste 90% din dropurile distructive! ^s5_c1_boxb

2. OPTIMIZARE GAUSS-MARKOV (WLS) ^s5_c2_hdrt

Liniarizare prin diferențiere față de Ancora N: ^s5_c2_lbl1

A_i = 2 · [x_i - x_N,   y_i - y_N] ^s5_c2_eq1

b_i = d_N² - d_i² + (x_i²+y_i²) - (x_N²+y_N²) ^s5_c2_eq2

Ponderare Optimă cu Varianța: ^s5_c2_lbl2

W = diag(1/σ₁²,  1/σ₂²,  ...,  1/σ_{N-1}²) ^s5_c2_eq3

σ_{d_i} = (ln 10 / (10·n)) · d_i · σ_RSSI ^s5_c2_eq4

Soluția Analitică Closed-Form BLUE: ^s5_c2_boxt

x̂_WLS = (Aᵀ W A)⁻¹ Aᵀ W b ^s5_c2_boxeq1

Cov(x̂) = (Aᵀ W A)⁻¹ ^s5_c2_boxeq2

• Teorema Gauss-Markov: Estimator optim nedeplasat
• Timp de calcul: sub 0.15 ms per epocă
• Zero iterații, fără pericol de divergență numerică! ^s5_c2_boxb

3. FUZIUNE CINEMATICĂ EKF ^s5_c3_hdrt

Vectorul de Stare 4D & Tranziția Cinematică: ^s5_c3_lbl1

x_k = [x,   y,   v_x,   v_y]ᵀ ^s5_c3_eq1

F = [[1, 0, Δt, 0], [0, 1, 0, Δt], [0, 0, 1, 0], [0, 0, 0, 1]] ^s5_c3_eq2

Inovație & Corecție Adaptivă: ^s5_c3_lbl2

K_k = P_k|k-1 · Hᵀ · (H P_k|k-1 Hᵀ + R_k)⁻¹ ^s5_c3_eq3

x_k|k = x_k|k-1 + K_k · (z_k - H x_k|k-1) ^s5_c3_eq4

Adaptivitate la Umbrirea Corporală: ^s5_c3_boxt

• Când o persoană obstrucționează semnalul și varianța
  WLS crește, filtrul mărește dinamic R_k.
• Observația radio este penalizată, iar starea este
  propagată pe baza vitezei constante [v_x, v_y]!
• Rezultat: Traiectorie lină, continuă, fără salturi false. ^s5_c3_boxb

📐 BLUE (Gauss-Markov Theorem):
WLS furnizează soluția analitică optimă închisă, atingând limita
teoretică Cramér-Rao pentru triangularea radio zgomotoasă! ^s5_snote_txt

06 / VALIDARE EXPERIMENTALĂ & CONCLUZII FINALE ^s6_badge_txt

Rezultate Experimentale, Metrici de Performanță & Concluzii de Licență ^s6_title

PROIECT DE LICENȚĂ 2026 | UNIVERSITATEA POLITEHNICA BUCUREȘTI ^bXERZhsz

Captură Hardware Ubertooth One la 2.4 GHz, Pipeline Decuplat & Estimare Matematică Deterministică (LDPL, WLS, EKF) ^O2t7l5Xx

PILONUL 1: CAPTURĂ HARDWARE 100% PASIVĂ ^r2NRGnOj

• Hardware Sniffer: Receptoare SDR Ubertooth One (2.4 GHz ISM)
• Microcontroller dedicat: LPC175x ARM Cortex-M3 + CC2400
• Zero Intruziune: Fără pairing, asociere sau aplicații pe telefon
• Extragere LAP: Lower Address Part extras direct din preambul
• Hardware Guardrails: Mod Listen-Only forțat în firmware (TX blocat) ^TCFqLZfq

PILONUL 2: ESTIMARE DETERMINISTICĂ EXPLICABILĂ ^3PwQWCN8

• Modelare Fizică LDPL: Inversare analitică deterministă RSSI -> Distanță
• Filtrare Rolling Max (1500 ms): Reține anvelopa superioară LOS
• Optimizare WLS: Soluție analitică (A^T W A)^-1 A^T W b în sub 0.15 ms
• Extended Kalman Filter (EKF): Urmărire cinematică lină cu inerție
• Excludere ML Opac: Fără 'black-box' neuronale sau salturi false ^AAYM93Tu

PILONUL 3: ARHITECTURĂ & LIVRABILE COMPLETE ^ShZxkNkE

• Decuplare pe 4 Straturi: Shell UI, Orchestrare, Math, Hardware SDR
• Sincronizare Temporală: Jitter cross-window măsurat < 14.8 ms
• Interfețe Duble: Tauri Desktop (Rust 60 FPS) + Web Streamlit
• Testare Exhaustivă: 120 / 120 teste automate PyTest + Vitest (100% PASS)
• Pipeline Producție: Validare statică riguroasă prin contracte Pydantic ^TLWayB09

(AᵀWA)⁻¹ ^PnBjXJNs

120/120 ✓ ^YhwsC2xV

FLUXUL DE DATE END-TO-END: DE LA CAPTURA RADIO SDR LA INTERFAȚA DE OPERATOR ^2TWydEvq

1. ȚINTĂ SMARTPHONE ^uDdc0Wlz

• Dispozitiv activ în sală
• Emisie BR/EDR (2.4 GHz ISM)
• Pachete ID/FHS nesincronizate
• Adresă LAP în clar în header ^axfNTs9E

2. UBERTOOTH ONE ^B1Fi0Ha4

• Receptor SDR CC2400 2.4 GHz
• Microcontroller ARM Cortex-M3
• Monitorizare fizică 100% pasivă
• Extragere RSSI hardware ^tMe3OF9W

3. EXTRACTOR PCAP ^WqEKe3Cu

• Parsare flux PyShark / libbtbb
• Filtrare LAP țintă (0x9e8b33)
• Fereastră mobilă cross-window
• Filtru Rolling Max (anvelopă LOS) ^rPGctXXe

4. ESTIMATOR WLS+EKF ^1moo2PUF

• Inversare LDPL metrică (d_i)
• Ponderare inversă a varianței
• Soluție Gauss-Markov (O(1))
• Propagare cinematică 4D EKF ^h3zAPZDP

5. OPERATOR UI ^eEJR2bfu

• Tauri Desktop App (Rust IPC)
• Randare Canvas 2D la 60 FPS
• Dashboard Științific Streamlit
• Monitorizare spectru & erori ^G9DsvD67

2.4 GHz ISM ^bVHuBZkF

USB FIFO ^IEnKlu8E

RSSI LOS ^mMii5LTp

(x,y), P_k ^cI7tsQ8x

💡 Teză Cheie:
Poziționare 100% pasivă pe Bluetooth Classic fără cooperarea țintei,
folosind pachete de interogare BR/EDR și adrese LAP în clar! ^qlBznx41

Sesiune Susținere Proiect de Licență | Universitatea Politehnica București | Candidat: Vlad Sărățeanu | Iulie 2026 ^s1_foot

02 / FIZICA PROPAGĂRII RF & JUSTIFICAREA MODELULUI MATEMATIC ^AJtennkR

Analiza fenomenelor electromagnetice reale (Multipath, Body Shadowing) și limitele fatale ale rețelelor neuronale ^eTnjoZVm

FENOMENELE FIZICE LA 2.4 GHz & SOLUȚII DETERMINISTICE ^PKiIwmyD

1. MULTIPATH FADING (INTERFERENȚE DISTRUCTIVE) ^qW9nl1Hj

• Undele radio electromagnetice ricoșează din pereții de beton, mobilier și tavan.
• Razele reflectate sosesc la receptor defazate, producând interferențe distructive.
• Consecință: Scăderi bruște de semnal (până la -78 dBm) chiar dacă ținta stă pe loc!
• Soluția Noastră: Filtrul Rolling Max (W = 1500 ms) reține anvelopa superioară LOS
  (Line-of-Sight), eliminând peste 90% din distorsiunile de reflexie. ^QIkIY0IX

2. BODY SHADOWING (UMBRIREA CORPORALĂ) ^sUA8L5P0

• Corpul uman conține ~70% apă, reprezentând un atenuator masiv la rezonanța de 2.4 GHz.
• Când o persoană se interpune între smartphone și o ancoră, semnalul scade cu 3–9 dB.
• Consecință: Estimatorul naiv interpretează atenuarea ca o distanțare de 3-5 metri!
• Soluția Noastră: EKF adaptează dinamic covarianța măsurătorii R_k și folosește
  inerția cinematică de viteză constantă [v_x, v_y] pentru a preveni salturile false. ^a3KJusKI

Atenuare 3-9 dB
(70% apă) ^siNGxkHr

Perete Beton ^ZEaH1n4a

Rază Reflectată (Drop RSSI) ^zQKFfgCg

DE CE NU REȚELE NEURONALE (SUPERVISED ML / FINGERPRINTING)? ^j15qCSLM

1. COST PROHIBITIV DE COLECTARE DATE ^cILrr8Fr

O grilă de 0.5m impune peste 400 de puncte de calibrare pentru o sală de 80 m²,
reprezentând peste 30 de ore de măsurători manuale pentru fiecare încăpere nouă! ^JQnQEVZ1

2. FRAGILITATE EXTREMĂ LA FACTORII DE MEDIU ^jsjMV5IN

O ușă deschisă, o masă mutată sau apariția unor persoane în sală modifică topologia
reflexiilor și invalidează complet setul de antrenare (concept drift masiv). ^zutpBBH5

3. EFECTUL DE CUTIE NEAGRĂ (BLACK-BOX) ^pOHCazQv

Rețelele neuronale nu oferă o marjă analitică de eroare (lipsă matrice de covarianță formală)
și pot halucina salturi bruște la marginea distribuției de antrenare. ^6Krc1vUH

4. ZERO PORTABILITATE ÎNTRE CAMERE ^uI245a5N

Un model antrenat în Sala A are performanțe catastrofale în Sala B. Transfer learning-ul
eșuează din cauza dimensiunilor și a coeficienților diferiți de absorbție ai pereților. ^z3IOEIke

5. ABORDAREA NOASTRĂ DETERMINISTICĂ (LDPL + WLS) ^5lvoH6Xz

• Funcționează INSTANT în orice încăpere nouă prin simpla specificare a dimensiunilor
  și a exponentului de atenuare n in [2.2, 3.0] specific mediului indoor.
• Rigurozitate matematică: Furnizează matricea de covarianță formală Cov(x) la fiecare pas! ^mtwLQ2V7

⚡ Cheia Fizică:
Filtrul Rolling Max reține LOS pur prin urmărirea anvelopei superioare,
fără nicio recalibrare continuă și fără fragilitatea fingerprinting-ului RF! ^nITUF0ao

03 / ARHITECTURĂ DE SISTEM PE 4 STRATURI ^If8wVlUG

Separarea strictă a responsabilităților, validare statică Pydantic și garanții de siguranță hardware ^TVzmpuQI

STRATUL 1: SHELL UI & VIZUALIZARE OPERATOR ^zaA8qE7Z

• Tauri Desktop App (Rust IPC): Randare nativă Canvas 2D la 60 FPS, latență sub 16 ms, zero dependențe Node.js la runtime
• Streamlit Scientific Web Dashboard: Tuning dinamic în timp real al parametrilor fizici (n, fereastră W, praguri RSSI)
• Arhitectură decuplată: Interfețele consumă fluxuri serializate JSON fără a interacționa direct cu driverele SDR ^sXRa70zU

STRATUL 2: ORCHESTRARE & VALIDARE STARE (pipeline.py) ^OmjkGV5h

• SessionController: Mașină de stări finită (IDLE -> SCANNING -> AGGREGATING -> SOLVED) cu agregare cross-window
• SchemaEngine (Pydantic): Validare riguroasă a contractelor de date între module; eliminare automată a pachetelor trunchiate
• Hardware Guardrails: Mod Listen-Only forțat în firmware; interdicție absolută de transmisie TX sau operațiuni DFU flash ^LeHtF4rr

STRATUL 3: EXTRAGERE PCAP & PIPELINE MATEMATIC (positioning.py) ^dZHzczBZ

• PyShark PCAP Live Extractor: Parsare pachete BR/EDR din FIFO (140 pkt/s -> 15 epoci/s) și decodare LAP cu libbtbb
• Filtru Rolling Max & Inversare LDPL: Extragere anvelopă LOS pe fereastră mobilă de 1500 ms și conversie RSSI -> distanță
• Motor Gauss-Markov WLS + EKF: Soluție analitică O(1) deterministă în sub 0.15 ms și propagare stare cinematică 4D ^i27tAXs6

STRATUL 4: HARDWARE RADIO SDR (Ubertooth One & libbtbb) ^hZfuDWkf

• Receptoare SDR 2.4 GHz: Transceiver CC2400 + MCU LPC175x ARM Cortex-M3 conectate prin magistrale USB independente
• Sniffing pasiv de pachete: Decodare preambul și extragere RSSI hardware direct din banda de bază fără asociere pe piconet
• Stabilitate hardware: Buffer circular intern FIFO pentru prevenirea overflow-ului la rate ridicate de interogare radio ^IclK7uej

GARANȚII CHEIE ALE ARHITECTURII ^gkhJwurk

• Latență de calcul matematic: sub 0.15 ms per epocă
• Sincronizare cross-window: Jitter măsurat < 14.8 ms
• Garanție Zero TX: Interdicție hardware de emisie radio
• Test coverage: 120 teste automate (PyTest + Vitest)
• Decuplare completă: Module testabile izolat prin mock-uri
• Contracte stricte: Pydantic SchemaEngine la orice frontieră ^jzFW3NsE

● ● ●  ubertooth-daemon (listen-only monitor) ^5SyZUT8f

[SYNC] Anchor A1 CC2400: LAP=0x9e8b33 RSSI=-61dBm
[SYNC] Anchor A2 CC2400: LAP=0x9e8b33 RSSI=-52dBm
[SYNC] Anchor A3 CC2400: LAP=0x9e8b33 RSSI=-68dBm
[SYNC] Anchor A4 CC2400: LAP=0x9e8b33 RSSI=-74dBm
[WLS]  Epoch 142 -> x=8.95m, y=1.25m (0.08ms)
[GUARD] TX blocked by firmware register: OK ^xL4tr0Sn

🔒 Hardware Guardrail:
Firmware-ul blochează forțat orice emisie TX. Sistemul este 100% pasiv,
etic și complet indetectabil în spectrul electromagnetic! ^RE6QUFUF

04 / GEOMETRIE SPAȚIALĂ & CAPCANA CONVEX HULL ^Ukb6E2ML

Comparație spațială directă: Capcana interiorului Convex Hull vs. Intersecția hiper-suprafețelor WLS ^yyClt7PX

HARTA GEOMETRICĂ A SĂLII DE EXPERIMENT (10.0m x 8.0m) ^Dfqe5qZF

Perimetru Convex Hull al Ancorelor ^1oundIR8

A1 (0.0m, 0.0m) ^UxGMAkVq

A2 (10.0m, 0.0m) ^udfYFcnI

A3 (10.0m, 8.0m) ^XPuzLDOL

A4 (0.0m, 8.0m) ^doQDfFWv

ȚINTĂ REALĂ (9.0m, 1.2m) ^u5a37MrI

Estimare WLS (8.95m, 1.25m)
Eroare: doar 0.08m! ✓ ^qyPmdVna

Centroid Ponderat (7.0m, 2.8m)
Eroare masivă: 2.52m! ✗ ^sBqf1HjI

Tracțiune A1 ^zHzQMCqO

Tracțiune A4 ^tK6Ozpsl

Legendă: 🟡 Țintă Reală (9.0m, 1.2m) | 🟢 Estimare WLS (Eroare 0.08m) | 🔴 Centroid (Eroare 2.52m - Tras spre Centru) ^lrnXV0Xv

DE CE EȘUEAZĂ MATEMATIC CENTROIDUL (CAPCANA CONVEX HULL) ^3IX6XIWX

x_c = Σ(w_i * a_i) / Σ(w_i),   w_i = 1 / d_i^p ^qGXXHMe3

• Teoremă Convexă: Oricare ar fi ponderile w_i > 0, poziția estimată x_c este
  strict constrânsă în interiorul poligonului convex format de ancore.
• Tracțiune spre interior: Când ținta este la 0.5m de perete lângă A2, ancorele
  îndepărtate (A1, A4) exercită forțe vectoriale continue spre centrul sălii.
• Consecință practică: Centroidul nu poate ajunge niciodată lângă perete!
  Pe date reale, generează o eroare inacceptabilă de 2.52 metri. ^Nz07HLgF

CUM REZOLVĂ WLS POZIȚIA EXACTĂ (0.08m EROARE) ^xyds6Ic8

x̂_WLS = (Aᵀ W A)⁻¹ Aᵀ W b ^S58vlrdh

• Eliminarea constrângerii: WLS rezolvă intersecția hiper-suprafețelor cercurilor
  fără nicio constrângere de convexitate.
• Ponderare optimă cu varianța: W_ii = 1 / σ_i² penalizează drastic ancorele îndepărtate.
• Izolarea ancorei apropiate: Ancora A2 primește pondere masivă, fixând poziția
  exact lângă perete la coordonatele reale.
• Rezultat: Eroarea scade de la 2.52m la doar 0.08m (reducere cu 69% pe capturi reale)! ^GEdh35TV

⚠️ Capcana Convex Hull:
Centroidul este prizonierul matematic al poligonului ancorelor.
WLS calculează intersecția liberă și rezolvă poziționarea lângă pereți! ^T29mjKAA

05 / FORMULARE MATEMATICĂ DETERMINISTICĂ ^nV9DZUj0

De la atenuarea logaritmică a puterii RF la estimarea BLUE și propagarea stării cinematice ^LIgNKbf3

1. CONVERSIE METRICĂ LDPL & ROLLING MAX ^Y7xKEu3o

Modelul de Propagare Log-Distance Path Loss: ^J5XOzhSs

RSSI(d) = P_tx - 10·n·log₁₀(d) + X_σ ^w6MSxnCf

Inversarea Metrică Analitică: ^8Hwh0sDj

d_i = 10^((P_tx - RSSI_i) / (10·n)) ^tws18nE6

• P_tx = -59 dBm: Puterea de referință la d₀ = 1.0 m
• n in [2.2, 3.0]: Exponentul de atenuare a mediului
• X_σ ~ N(0, σ²): Zgomotul Gaussian de fading ^O7z0euXy

Filtru Rolling Max (LOS Recovery): ^KVlb9trb

RSSI_LOS(t) = max { RSSI(τ) : τ ∈ [t - W, t] } ^XhaoT8FX

• Fereastră mobilă W = 1500 ms pe fiecare canal
• Extrage anvelopa superioară neafectată de fading
• Elimină peste 90% din dropurile distructive! ^Fqp1quYk

2. OPTIMIZARE GAUSS-MARKOV (WLS) ^fNC0Hee2

Liniarizare prin diferențiere față de Ancora N: ^Cnrs6qu1

A_i = 2 · [x_i - x_N,   y_i - y_N] ^nJD5sI93

b_i = d_N² - d_i² + (x_i²+y_i²) - (x_N²+y_N²) ^YQubUElP

Ponderare Optimă cu Varianța: ^gcjyAcWU

W = diag(1/σ₁²,  1/σ₂²,  ...,  1/σ_{N-1}²) ^NNrBVsIj

σ_{d_i} = (ln 10 / (10·n)) · d_i · σ_RSSI ^GjKBEGbF

Soluția Analitică Closed-Form BLUE: ^mVNRsUC7

x̂_WLS = (Aᵀ W A)⁻¹ Aᵀ W b ^DJw1JCBC

Cov(x̂) = (Aᵀ W A)⁻¹ ^u4mJW3OC

• Teorema Gauss-Markov: Estimator optim nedeplasat
• Timp de calcul: sub 0.15 ms per epocă
• Zero iterații, fără pericol de divergență numerică! ^YczsvjFH

3. FUZIUNE CINEMATICĂ EKF ^wTL5j2MU

Vectorul de Stare 4D & Tranziția Cinematică: ^RZLZwpF9

x_k = [x,   y,   v_x,   v_y]ᵀ ^gVcdFc1j

F = [[1, 0, Δt, 0], [0, 1, 0, Δt], [0, 0, 1, 0], [0, 0, 0, 1]] ^NnwrVyLb

Inovație & Corecție Adaptivă: ^Lwcwhw4k

K_k = P_k|k-1 · Hᵀ · (H P_k|k-1 Hᵀ + R_k)⁻¹ ^409Au3bY

x_k|k = x_k|k-1 + K_k · (z_k - H x_k|k-1) ^K99IhPpk

Adaptivitate la Umbrirea Corporală: ^hwFmam6E

• Când o persoană obstrucționează semnalul și varianța
  WLS crește, filtrul mărește dinamic R_k.
• Observația radio este penalizată, iar starea este
  propagată pe baza vitezei constante [v_x, v_y]!
• Rezultat: Traiectorie lină, continuă, fără salturi false. ^4UPNECcW

📐 BLUE (Gauss-Markov Theorem):
WLS furnizează soluția analitică optimă închisă, atingând limita
teoretică Cramér-Rao pentru triangularea radio zgomotoasă! ^3LdQIgjp

06 / VALIDARE EXPERIMENTALĂ & CONCLUZII FINALE ^45oQDX0S

Validare pe capturi reale de laborator, performanță comparativă și susținerea în fața comisiei ^wv6KwvJF

TESTE AUTOMATE ^Hr6lQ3TQ

120 / 120 ^3mPBP2Ik

100% PASS (PyTest + Vitest) ^jxeupCne

CONFIDENȚĂ ANCORE ^yINaCYr3

4 / 4 ACTIVE ^QxioOwoq

SNR Mediu: 21.4 dB (CC2400) ^VdcwlkPN

SINCRONIZARE TEMPORALĂ ^Is3NXFqa

< 14.8 ms ^DL93sL0p

Jitter cross-window sub 1500ms ^qw9eCyNd

ACURATEȚE MEDIE ^YFQVOZtB

0.82 m LOS ^JjzeWWZJ

1.45 m NLOS (+72.2% vs Centroid) ^MQn6MSdS

BENCHMARK EXPERIMENTAL PE DATE REALE DE LABORATOR (10m x 8m) ^jP8FwxQd

Metodă de Poziționare ^jEn7V7a2

Eroare Medie ^8FGICq7A

Eroare Perimetru ^VK9I3zkS

Timp Calcul ^ugGRpu64

Verdict Comisie ^9cs06klK

Centroid Ponderat (Naiv) ^DcCKFj8I

2.95 m ^4QWMpHvH

2.52 m (Trap) ^o1KiMIgb

0.05 ms ^rh6Tam4E

❌ Eșuează sever lângă pereți ^DcUt8v2l

Trilaterație Naivă Neliniară ^LWZIJLoJ

1.65 m ^EpWRN8gp

1.40 m ^EAVD7NJK

4.20 ms ^SP1Bhcby

⚠️ Instabil la reflexii RF ^41s2QPiu

Sistemul Nostru (WLS + Rolling Max) ^Z4iFiAtY

0.82 m ^toYuXMzY

0.08 m ^EAhPT8gS

0.12 ms ^OpZpI6t6

✅ Rezistent la pereți, O(1) ^OhHEC2CB

Sistemul Nostru + EKF Cinematic ^5buIWPdD

0.68 m ^hkWNCn7C

0.09 m ^nrLe1WHE

0.15 ms ^Vz1bu95F

🏆 Soluție Optimă End-to-End ^N4LaMDUY

CELE 3 CONCLUZII CHEIE PENTRU COMISIE ^jL8UBK3h

1. CONFORMITATE ETICĂ & 100% PASIV ^pKw4Xjjz

Zero aplicații sau malware pe telefoane, fără pairing sau handshake.
Monitorizare exclusivă a headerelor publice BR/EDR și protecție hardware
cu TX dezactivat fizic la nivel de registru firmware. ^DU5flVpd

2. VALOARE ȘTIINȚIFICĂ EXPLICABILĂ ^kuei02Vr

Am demonstrat teoretic de ce centroidul naiv eșuează lângă pereți (capcana convexă)
și am formulat o rezolvare analitică BLUE prin WLS cu adaptivitate EKF
validată riguros pe date reale de laborator. ^bxEoOlwE

3. SISTEM COMPLET & FUNCȚIONAL ^TZPW3uOq

Livrabil software industrial cu interfețe duble (desktop Tauri Rust 60 FPS +
web dashboard Streamlit), pipeline asincron testat cu 120 de teste automate
și zero regresii de performanță. ^NM3lxdbh

🎓 Concluzie de Licență:
Sistemul demonstrează că se poate obține precizie sub-metrică indoor
pe Bluetooth Classic fără UWB scump și fără rețele neuronale opace! ^ZE5Fx1bJ

Sesiune Susținere Proiect de Licență | Universitatea Politehnica București | Candidat: Vlad Sărățeanu | Iulie 2026 ^eaohW6fS

Explore Radio Waves ➔ ^N6iLFRNP

Engineer the Stack ➔ ^m3O5l3cb

Translate Waves to Space ➔ ^9BaMJExt

Feed Packets to Math ➔ ^aHyiWqop

Converge on Lab Data ➔ ^VoO4JDOG

Validate Against Real World ➔ ^zcSDgIfv

## Embedded Files
file_bt_logo: [[Pasted Image 20260920101014_599.svg]]

file_antenna_tower: [[Pasted Image 20260920101014_602.svg]]

file_layers_stack: [[Pasted Image 20260920101014_602_0.svg]]

file_room_blueprint: [[Pasted Image 20260920101014_603.svg]]

file_math_sigma: [[Pasted Image 20260920101014_604.svg]]

file_trophy_seal: [[Pasted Image 20260920101014_604_0.svg]]

%%
## Drawing
```compressed-json
N4KAkARALgngDgUwgLgAQQQDwMYEMA2AlgCYBOuA7hADTgQBuCpAzoQPYB2KqATLZMzYBXUtiRoIACyhQ4zZAHoFAc0JRJQgEYA6bGwC2CgF7N6hbEcK4OCtptbErHALRY8RMpWdx8Q1TdIEfARcZgRmBShcZQUebR4Adm0AZho6IIR9BA4oZm4AbXAwUDBSiBJuCGYARgB9KDY4Ws1cUjTSyFhESsDsKI5lYPayzG4ABn4ymHHJyAoSdW5qgE4e

CaLISQRCZWkl9Y6Ia0HxVAOy5ihSNgBrBABhNnw2NokAYhWE6uweYcgW7A3ZTXIQcYiPZ6vdAfZZfH5/CAAM0I+HwAGVYEMJIIPAjLtc7gB1BaSJazKpXW4IDEwLHoHEVckg3YccJ5NDnSCNXDYNTTNDVMaciDA4RwACSxHZqHyAF1yYjyFlJZVFbgsrUxtUESCwazmNKOEJUeSwghiNwAGxfAAsAA4EuTGCx2Fw0HwNgwmKxOAA5ThiJbLZaWy3

JMZ2sY28mEZgAEQyUHN3ERBDC5M0wjBAFFglkctK5eSiBwbtwjSbPc9Acm0Kn8OnPYQwVhKrgxgihHBiLgkxaBQk7cs7SPqgBWG2Wngew6SUIAFSwUAAMs2y3W0wgigBfSYlMoVbF1FrEZRIcldU4QXr9E4I0ZoBLC/moZJj8nzYiLNBT4VbHZ7GgySWuSxx0sK+JUhCLyVDCcK/BmPJArq4JPDB7wIAkiJjoiiIIsiqI0nSUg8hogR4pSRIktwM

4XJR1KYleDIWkywgsmyZKetyvKwPswqil2kqFvKnpqsq/boGJCCatqrGgsQ+rSvuZSXtwyQbLunpmhJiTTu+nrOj6bq8E63quv6HCBu6wY2tUCSWja0ZNvGia1qg9aNocmbybmmTZLkBQiYcJbrqgFb4MWbA1hJHkIDGLYPuguCyZ6XY9n2SyDsOo4TlOtGbAuS6rqWKabjue5NhJECaAAGtmABKABakjMEYCKqRISaYFA97cMsz7cDayQftRaBj

naNopAkNprJaE48CGI7kv+uw9QKdraAk+mHGBpwQfR0FQhAcHfAhnoAshWaoZClRXNYzBwK0/n4Si6KMZUzEUQSCDEl+pLuqa9FEUxTyMp6zKSIpnGHNxfJ8eSAkSlKgUKkqCAqhIUkyTqV1Q2g4Wmggbk8EOyRDqZLqcDRFNGRZVmoFOtkzfaTmHLGCbBBlG4NnF51Xb5+YBWgRZVmu5bGhFVZRXcMWbheS6VAACvVADy4rZvc86oHG2aoMu4r3

NmvqAFhAgBAgLwYw8JaqAAD6oAAqr64oAGoNWi4rzgAgvO2ae6gisq/rPsABJO/cfsAEL2/c9v1dmgAYQPO4oIi8OzNgQi7dUrqvq5r2u6/rhsm+baxW7bDtO679Xu17Pt+wHQfZqHBuR9HscJ0n+GcFAaKEEYpzjgq3cAGLqiiL7VPL3We0QyjGRAwSIj1FNQOYBAzzs88NHACItGEJYD8Nnp6DkuDNkwGNhRLxbn8H2yrUs8TbWUuBCA09XhH3

pxXEIvNswlbYzqHDSr2NydkhwjjtOOSc05lqFW6sVUKsUmSUEzmtdACJ8C4E0EERWbBWCrypvjCW5UijKXKFVGo9Q1BDAvPAK8XVl6ekSk+ckL47T5QgJ+b8qBxyW20JOJ8tktRjinM/TY99AK8MtMKXaMwtIHTQkdD41RqgcISLvJCAkwSHVuuQDgD0no5BeoRd62JQYsQUd9X6PDOGQTuMDD6FicZ+EhhxAU5JYa8QFEKBGIIkbCVRuqdGVUsZ

ahcXqdxV9KyHG0jRN8YwxxH0OIZV01MDJmT9AGU4yxkjJGmgkfJnD2auVljzDM/M8z+UCaLEqxCYllGrDLUq5TPSMMqAAHQ4MrNWGstY6z1gbI2ZsLZlzto7F2bsPbe19v7QOHsm5h1bjHOOidxSoAAHpUJPGeeo3UuldN7pcTI/tQiEHoKgYgCBUDzlIE4ZQxonqoEAJhAhB/ZsEsIAbCBXRPPFGCNgLxUCIFQBHXwCAGhsHUKge4WCDTmBTnc/

wGcFYSC6T03O/SC5DOLqM624zK5TNrrMhuCzm7hxBW3VZSdNnbNwKeaSUB9kcEObGJM+hTmsAuVcm5dzjiPMCC8t5eCvk/IFX84gALSBAuuaC3+EKoUwtCKwbAXcci937mpThiIR5j3wBPKeUAN5z0qIvJhKSmCr3cEarejRNH73PjRO05IT5RHPqQS+BNakIDvgBdB1Qn6gTfmwD+rANVoB/n/Mo5AKBoM6d0nOfT86DKLiM0ueKK6TOrtMuucz

G5kuWe3NZNLjx0t2YyqAByOBHLZRy85lzrm3Pufy65rz3kis4L8/5gLgWyvBQChVsLlUIjnMwNBiCWmeQPAAiQuBUjkhAVzXhWVIHQLysWbBuD8FqDSfU/ApDSjkMPOgFWPAoAJHwGOGqow6HdE6grckLCBoChJiNP6+xlj+uqAksYsI5piOWpI9B05tDiKOAMcCgNvq6PeDaZYY5EkaMQoCbR110LoDugYx6gRjEKleo48xuJINUhsf9EyViqT4

fpM4uS7EDTQzKF4ievjPSIyEijUSaNL5IjRtjOSkS6O7sJm5BIhSeCThpjusj5rKYcDpgPJJPBxpwaWs5Dm4K3LIL5j5KpBZ2PBTFoJqW0UJ2Rs6Ci9A9xcBwCgCIQAwICoGDq0YgFAnn2xwaQeVkhUAq1ZKgLBvABGoAAOLByMNQf2hBEAH21ggbAXYsFQFQAAMlQNmS4hB9BPIALKgMy5a+zCYkykH0M2Vl5h7MAAplxxkVsucLhJlxonC9mAA

0sPAAlAitOHBkVZwkJZ6zdmHNOZcwKtzFr+1eZ89c/zcQbTBdC+FxWkWgjnxi3FnwvZkupfS5lgVOW2W9nKzForJWOBlewJV6rtX6uNea21zrQ81VfyWE60SOqSt6vo2Z6es956moRM6S168/u3VtYhe1rIlggWPt3M+rJ3USU9fp1kPqH4CgDZ6V+79P5htQBG+KVzEpHBtJ2bsoCJLgOylA3KsDPQjrHQZ9yctwaoPMxATBG78B4IIZJ8K+7ii

VQ+nUDLyhmhmpUvQyoGXojnmYZlG0T7Xyge4aRwUf5APwyx+BvaRG7jQfQ/owx2GJf/C0ShA30AjdYeerh0xtIQaEfI1RN9ANncMQd04p3hwIZ414Z4x6PEmP8X8Wx4WQUyhSS42ElKPvcZRORxcImEkvgIeFKkohr4JNZMsqcMcsJHJDQSMUlynMNMs68pUvyunw83zqdEyWwVpbl9aYcAiITVQomkpoKAtRnjKDYBRXsQhpQYFINcNopp3CnEK

B0MAk8Njz42BHyAzYidtjHGT9KYDl05RgaBhnRUmeacONga4O9d0C8PZQuocAUS1GPGwYg0wb1XhvHIh93BWGehfNOZJZRVduBxoNdfU1JqhOE5EOQ9cHglFYJPhTpNFkMLdYD3hEQ7RERlhUwTE3pPcJA5xsAyI5dYl6ISN0liDvpKMqhqNwY2I3EBN/cuJA84YfEQ8xQw8ZQV9uNglo8eNwk+MFIollJOgpcgINIhMJJck5o1Fs9jJOEM9ZNsk

+pwDIFi9WYDxS91MylJ1/gq9BYakUdQpE9IAmkW9tDyhp0kpLQt8KdMoIE98116d4EVxj8ypShNID0hcjxag798AH9ahJAyB2oRD0B38ddepHwlc7IVdRpUBgCANQC0B7RQIwioD3dLcTp4QkNLp5J0jiAxgEBNBcJsDKD8DCCvpiMYi7EgYzEqNvco1aC/cF8YYmDvFeFmNDhWNkZa8ONuDQleDY96j5I/chDoBgj1IOh3Ck83JVhqhLQmiyh5C

yCFjMkFDc9XtkgYESZVgYwNDF0T8yhvIcwdMhYOC69DDr4jNmluYzC19WwZ1ENUpydF0qcV1adOFD8EEXCeYr9PCQieBfR6ogsOAVYAArII29dDe9eXNAFTQ4CecmT0QAoCO0ZIFIVYQpMYL4LYsYGHWcTXd0WRFIs4aA9I+AzI86c3K6S3DDY3W3USPDGoqguogQEgyo6Aygz6GjOg6UeYrkFo4PPxNgro04no8SVUfoiJAQ+gowqoZPQaIaWyR

0DJGTJYyAeQuTJYPhZYIaeDN7NmXY0w0zaqXQ6pPTRpJnGUkwrQo09pCQRWcUZcFWX0e2ZcXhNAcORWecWOc2YOT2eqOMQkP03WdXAAUn9k9ndmdlNi6yRXwFjTtIdKdJdLdOhU9k9O9Icz9IDKDLaLGDDMVgjJdmjKex7hewFFxMjw+3Hm+2gCXGtRNQQCXkBwtTXnwHrM6nBwpMhwHjUMgBdXhwviRwuJR29XxN4Uxx2iDRDTLPx1IF/kJzuKS

jtGsOeN3xp02LgVHSP3r32MgGjXjIwXXRwW5y3UIWMn5zcIqjZiqnnHuGHgAEdlxGpER7zwSGEoTDhEpYSph4klTDgkTYj89tAQxVgyYSZwCD8xz1dki7xUjyCoIUDoQeAIKFpEDsidFEKrd7obccN6T7diJOT3dSC3d4KHFGTCK49XFGiA8eRmDczBTBJhSRY29OM+jgleMaChiE9hypiJJkhpxHIZDVSvQZMNSBwZihR+o9T1C1M9iK8DiTSa8

RSDDxYGljDm9rSDVKhAAiAmG1IGcyeTRHO1wiYDQA/jEGszYEMrjHqgdnc082818wqzmwWyMFQHFDRCy3ay6V0qy3MGuBdWuFRCYHrUcDwCgDQGXEVnuCiMwFQD9Ky2hReC6mcCy2SFQAAGpoV7gxMhQfLUBGomA2B3Kcg5zLBQQEA0Bh5bNSB7NHpCA7kBhwtQgopCAmBrlmBX5UArMiA8Bvk3lgUkxF5OB8rsxupyAzwBVlw0zIq2AKAQrPZiA

yA2RTkPNUAlxyBmBLkGrYtEtHAOAgVAh1RNBjR8rHN9LRtrkgshAnNyAUR5BUAssn89ZWVshnAfM9V3IXhPktsAA7g65EYrS61ACrecGqVATQasXsR7LiRFdOOM9nXS86gygVIywgEy0gMy2LBASy6y2y8bDzSbRy65ZywLELNyjyry/Kvys/KKbuIK4IKVK5MK3sSK6K2K+K+qRKx4DzLAVK9KrK+4HKxXMYfKwq64Eqn+cq1kKqmquqs+Rq5QZ

qwQXkdq1ATqoQbqnwNefq6VfHDIbVZlDgXSsau6Sa65aaxWWa+aqVRa5ag0VaxLDa0Ibam8bag6uAI6/QE6/AM6kbJ5a626s+BsNAJ64gF645FwD6mAL60gH6xLf69yBq/QYG0G8GyGqKaG1VUsvHWYks0eT7fVNpOs0HCQAHFeVs9s9DTsryUIVbKHAUXsiAfst1D1Hi4w2+KCicl+Kc3Hb+Oco0244nXAZYFcnfOw9chw2cJw8da4o0/c9nTnY

8nnbdTPC8sASY6/YXbw+/HgZoJ/F/NpYI68Xaj/aEhmb/OEmiHgf/OYGIuI+nMc5IcAmCiDNIzCt4HgTQO0WdIgg4yknIj+tAjArAu3HA4iUokQP+lk6xNk93Dk6gyi2jHkmioPLXDo0PJizgqPNijUPgzi/jJSRfUYiE8Yy8rSOU90cMRTaStUlY4S9UxQgUURUMZCvJEvWSw0ipbTavE45i80+vS0jSkzBc4ez2MeynNc1dOnaercz4nc1wjeq

8g8G/He3wvegIyfI+iEk+voM+z8q0S+n8gcaI13WIyMeI9HVAJI7XWC4k9+m6d4L+n+5IaB6qABjCxx6EYgZIDA4gZcsBko0iKB8ol3Wxdk8ixBwY5BmsxjdBsoTo/QyPVi8U9i/Byiwh7gEYjqV8MQihtyJJH9MYW+kSoyBhlYsS1AEcD9YCcMYUEpMvTSrTI43hpJjuwR9uheYRue0RtsCOCR2w6naR94mer4sIH468yoZIRWCgAARUJHuF9AC

e0ffKzk/x/G/MgHhOWFfR4UnDHG0EgW1LmnYeKd5KkDHLWFft1wcbQ2Omcd/rQpQ2pOtyMVNyRAZNwNqLBlIp+jgd+YQeZOvAaKiXObiZYIYoCTNMgBwdSbwYGL3Pj2lM6biXdBHDEyEpIuWNEqYYtnyTDFLnqYNKacrx4b0OhYXgtM6atJEeLr63QHtMdOdNdJ4DQGzDRCTiyxzJ1h9i5vFCdg5YNnNmzBqlqxbgjgdOLNhu6163QQgEZaTJZbZ

cFa5bjnzl5ay35Y8qTnuGFdFcLk9gleXClbb27nVQHgrJharK+w8TpcNVLvQHLuVOBzbIdegBrv/u7KWCbpboRzbrUspdRy7sU0DRx1DX7vnKbAsKOHuAGYHAnuGc3MZwUdbyjTZ3pY5yPM3V5zXpIXIY8MmYkE9k9gAE0stcl5whA3zboPyRgrRNmIBf98ldnSN89lhtBQwxwSZ+KzmQ3H6Ej6LbG37fn0jkLFNUKsjnnMKaScL3mCJwHHcfm6J

YGzGqiKDImgXfdQXUG6LoKWNMG2muCxTMYJT+C/cZTUWLZtSQxMWpNsXaZcXZjgJrQkli8djOGSWFKyXTTuiVLDMm9jMem7WdLHqn8ggnlh4+5jtrtlw0A/lDInlrACBt1Lt61TtStLh7Nq53ZUBnAAA+bWVlawT5WzfKyD/AO6AVeqJ4EsZQR63AOKirPhMYVAfQZgdrLG75XzawRgZ4R6dWrsJgdgVoezR0tEfKlWazDLPuJ5BrNENANEJ4IQb

5a5JDogfLEGz2DZLWQkeK9rDZZwaoeK7T1AXTzQVARO5gLQM4bQccVj5gUa7qbIZm1AFrAgTLA68jorEG1rDrNAe2YrGqna1AXkVkPLY7EsezOLVAN1FTxz7AXwK5fbV0yTnkWW2q1AAAckhqQmcEzEwEy7CgQBEA7WCHVq6s6oo5EDeVihjPhoPIgF8rA6wQFUg8sFQ5g7g44AQ4FTU5Q/syuXQ/O0w9QGw/WXw8I8uGI9I+NtQC8/ICo5o+bDo

5y0Y+Y/s449G4QC49U+66CG5AE8QDuSsoy7E4k6k5KyMFk8awU6U5U+6p63U+Owqy050704M6M9e9M4hos4Oqs/M7GFs7HHs8c6TBbHDrc/wA87m5RG84q18824C/0CC4FVC8yCO1Q8i5C81ti7avi8S7VqyxS8D3S/s2y6wUBDy7YAK6K5K8e46oq4IBszuWZx5mzvNeh3zt1SLsOEYSroXkbPeaB0rrde3jtXrp7OdTh1bqHIDYPjRykX9T7cn

LDZnIJyjfXxnTjDjaXQTbeKTe3KQXkr3PTblaXuzdXvPLzaUbIV+KqFv3v2SH3uf2rYkFCLvHWd4USCVz/xbaAIsf7asefogKJP2igw/qETtAQGWdrqQKpKAfQMwNwGKMZMgfImgOIrvZgYow3aXcRaou3cYNotaL3YwaFMPdhZPbSYReBa4voOybGLydiUoYZg4RtCSVvbkIqcfcjDgzHAnCJY/dpdJZafJd/YEfOLl+6dZ5uOjdwGzB15ePsJk

bKA+OcJTfGfzcF0LfpAd98Kd80dd5CNPrCM9/AKMa2cylMZ4QfrxIHZsZ2lD5JIj6jCj5j//rj8Aa8eOiJhwVAbwoXaVA0+bjexH81XYRMvmTJPPrXxia2tmixfAUvu3L4UtK+kkU9gQylJEM58JDU4GQxt7N8CmqhF+sqTKZYs6GOLNYj4hUKwYMWqmUpMPy/aj8f2ylCfqpUbyNJp+u5cwprySjDxF+UjfXo4Tkbr8je3xLflvQkBohJAjUTAD

cF9A3AF+r+Gtms3PrKFaGjbV7Ds0RIxEhoqJODCTEjB2h88+SSCgOyuZDsbmI7F/vaGj5PNkC3/Gdm8xT6QCKKy7CouAPga59LESDbkrE35LxNIAiTFASkyr7wtJS57FFi3xvrIUH+97STF3woH0xqgtkD9F8BkRN0GmmhBgToW/ZKV+G7TSfuwPUqAcZ+NpdnAq2Zavg0AfpYOAsk1gZkUs+sZ2PVENYOldY9wFWFllqzZgfYdXR7g1wqHJlkg1

Q+qLUJ9j1D6o5sRoS7BaFGt2hnQ7ob0JLIc9yyXPQujWT55usnW0mF1vzzF4Q4Je3rKXqfBl5sC68o5Adkr1AzY5g0fdbgOr3/g8CjgQWfgXrw3JCDk2ogswgvQzbm8TyObK3qiAmYqNKg84ZcISFwAwAI4P6I/rWRUEGNn0DbJtn+QAIxEHI7bBDMHy1B2Q1E6glaIr3aIvwn+tzZRGOy7aj1J29gu5o4JNzOCCKUTbPmE1Ixrsc+LghkTAN8Fw

CGM/giFkgMYoV8QhaA6vuEO4oBtL2cxI5p3xkKVNBQtkRTCzHfb0CgOI/YgALGYH5DA2hQyKCUK4G2l0AulBMBtha7XJgU82DEOQGZ6EAFOWwVEA7HFDhYVYogLYPiCejhYDskgcLMjWBpogbK+VXuJZGuDnYruAqRcPoDgAvACAtmNAAACk1A3nWmgaGcDzB/kFAVjrZis4WjUAAAHl4STQ7QIPWbn8iKyIhtu1yOMFoGCBoB5wr8FngmGYA3Bt

4INeqCPkSwyI5uisNEO1kyqmcCiqAc0SEH0Dqd8qi4KbgKjGpzgWx5yKMV7xY4KAZx+tY5N1SDR5ZrkisGACOMSxZVnYagcIIliY5Ch8yEZTsflWWxRY1sisa4MQCEDYAVOaAZ2Mhx7ACopuGnRFCV1CB1VGqIXemjyCTD+wYAPYHIPCk8Rw1+hiNdbPFieSmi+xd0S0daKCD4A7RDop0buIW5xR6O6gT0f7VRq+jZu/o2mkGKeShjwx5AfANONj

EyAQqCY5gEmLXxzU0xGYrbDmOSGHMCxulIsUwBLGfIyxFYyqjchrFvI6xDYxoE2JbEMwWOw8DsV2KyqEhex/Y9UEONm4bink441+OlnoDTjwCs4+cUmEXE3CVxf4jcd2O3E6S9xoZcMmiGPGzdTxEvf2JeOvG3jUA94jwE8mfHHZXx1wd8YdWbBfjSqP41cf+OsCWp2eM5POu9hyAF1qyXIn7Pa03gNkmyFdK1KLw9Zm4vWjdY4a6j9ay8ihgbC4

VYyuGhtbh4be4QPV6Yzpg4rwoZoINkafDsh14U3pUD+Er0zybA4EavlUYuZGAD+WEQfHCKxFwwbCeUsKAApvhLGUicwY/zsZh8EK3/DIkAg/7oVUMR0GkXSTbyfN6RQLUAZnxZFkVIBPYZgFsG8HRNORWfCAOC0HZl9+RwQ3onC2kjpNBimTf9rxW4ATQC8Wg6TKQJOmMNKBvCcAnBi1ATQMhxLWqYcVVHHFD2IUM4ZcS4aehwxzYPhovlnxz5OQ

pQMYIvhXxgBEZHQQeIvjADOA1gaM2YBjJxnK8kZBMhGTjJGk4y8ZqMufLKGXyAxWghqcfHNS2B0pIZhwZzp7GZkUBWZWU8kEEEzDzVP2xhUIFAEeD6ASsFE4gHgjhnsy6IjMiOGvmW5yzIAznRWWCGVmPTV8c/ZOPOieLj1Kp7w6qYb1qnhi9UA+YyLFFakUJt6rQbAF1KUESB4JkWMIL1IH4DTEi8GP3okRAJWNFc1zeRFYJmlkk5pZuT/p42pG

vNaRgTLwaEzAHhNPBu00IAdJcSwCTpZ00vgkwPZXTj2QosIWe1FHZTL2g4ZIVKJIHmQe+loO0H+jqaKjGmwMxSnw04IQytZXTHUcb24GLkjg0Yiqa8SNmr9RmG/LcOILt5UI7ZtQUOTgMqDOy5AbjRKIUw9nWN/Z2gsxjIlGnoI15FgwOW4P1wf0Q5dg+Pg4KjkrTI8a0xdodMZHxzmREA4iHtJTlck/cnCDOYSMCHZzx+MLQUUe1uk18UIEQsUS

3wmj54pwZc96RXO+mqIu2+eYpqIjrlZDlRjA0Ga0wpYtyG82oq4qUNKlJQWsvc5fiM2EGz1Sh1so9Pb1qB5ZJAzQUtG4xya6NbwtCVQUU0XmTghpMRL9L7KkTLyJpw7HeTARmkPNXGB8r/nczeA+M/G7/GFmfK9zQDNp/zbhYC2gFbt6CYLHkedKznID35X8ngsKILn19iGOTPAZMQEAt9Ck4YLtiAriE54khKJS2Ahg4UyUlRGC5pogrH4sCChK

stuegq4FD02wy4HBZPRX4FR8FYzYefgO34gi7SHACOCCRqjRjfQeQR2ZCXhF1sBQmcy/okQv5cIYiT4TaMpmHBF5TBeUjaFtADlwVuFo7b+o80pGHzI52FJwTHLZEbTWSHggFrHIfmF94BaDXkRdKhbqLUBX8jihk0wFuLL2b4ETIODMXkCH230pJMkMjCTh1BmQuSqmxyFMC8hzcqllP3blLK4RcrF7oAAFcQMu1kADeBAAE6+hsrSoHsoOUnLg

pudUDIbSgARSbWWeO1vz22HYtdhSUneAcJ6kCgSmvrQcm4vl7BtrhvdIqeGhKka8u5uALLL4sTYfCTZ8Ck3jGkXpZt/hlvFqSPJ34kLHoBoChfSlhHu86FCI6RP1EYWbz/yLC/qYH3YWElJpz/GaZH1sGVLBFyiX/o2WT51L1pUixpQnOaX1L5FILRRTuxL4vyRQb8lxRotwbfyRROi7AXoqb5PTyyiufiuMtKZgKkh8o7ERwkH72KuBIMtUasrO

KArOBHcrxTOl9CwqqpA8wJUPKIVVQS2kgCgMwByqYBnYsI9pGfyfBK4bQ6SgCiJg7bDgEgH6eDMkH6j/pqVfqQpdcOJFByhFjKsRe43DmLS9ENS6OQALkUXyKQK7XlbIpaWcU05SihAQELFVqKJVvSmPDKsNCRC3IkYccFAlVVfSNVHCWEEIkBlD9EVxpXIU3KNWtyaWHavURAE0kKBNJqAQAMjkZyhGhmyHUjrx1ywkKXcutY88VIJdWKWXUF7N

kPMIvVddXS+VdlDhvy9KQOURyArO6lw7upABuHTk8cDwqdE8NwAqxLV/cgJTVI7U/CzeqKpqXzmt6b1R5dQREM8AoAUKtGvPY+oSrnlf4lcoia/mrkHBsL0EM0YpfY1jXKJYM8GMcA8Vj4LT0iiIaoIiF8ab5OVV4YAXHK2k3zz5qc46YWo6UqLX5pajUeWvQEDLhiuixvhMXEL7AoERS8uZngSGTKkh7fZIbBn6g6r65Ha/VWDOQXrLspfahxY8

KhWKxH1U9a1S+sIWYqwl6AHgPOEJD/jsw9AV8vEu2W9TSVP+IAlxopVmMRMk0OyNNAWgrAZiDbfEUBlpVcLL5o7FChSIpJJqXmqak+eIvwrkaM+Miy+Rmoo3UUi+1GlJSWsuk9LP5Fa7RVWv/luRQ1uSDhA2u77gKSYwiS0MJtgWLKzC4mpBeopQVCNNlZhAdcPGXD2waoyZAZHGBmSpZfQcYZwPOBVjOAjYcYNAAMmmqpl0yLQ0bp7DjDigVYfY

mynrD9j8teWw8T2MbD9gDIVYisBqN7BVj1QJ1DXCrVVpq26w6tPsBrU1pa1tbGtnWguH7A9Jek+tLQwbcNp9G2VutE2hqFNpm1Jp5ti2lrStrnW51LWSIRdRsJXXGo118U51lur+07rxePy3MYetOG9rT1eU89UcFBVq8IVcm4erM0U3+KSINqr4fPXqkSBGpp5L9UCLU1tTt6lwTUM70PogadGYG3qekpfChg3pqIsxrXIjVBhPtkBJDaUr3mwg

ECzKiOcomAZJ86RRG4JunyIpBas1rIrlZmoUUoNwtu7UVUEJi3XTQh0q+LVkxY2kMFVhipLZZrshpbEh8mOYgPxfR0DRNsmhBQau7W1ItRUM4WZ3OHpvbHi2+SRm8KU3PqEVqmkJRIN361ASdYwfwoEQM1U7PeNOq0CTLvqM7RVjm+Uohqmm7zg5XO8kphqnYzS8iBRIooRqAHC6QBPK6+YnMl2ha2l3IotZ0tUXRay1sWxjfdMGVoAG+Gutjfkz

4pzFQwJTRYmQLVUWLTgCpKBIKHmVAyxNjc8GVJrQXQykdbYNEKjrwUqarZhOm2RICEBxhiA2AMYISHwBtQDNHq8+hNEXlhgUR4enhOAls5yju9iQVYLCHXmvZNo0aulSSLgIJ7J5F0ZPdUswy1L01ea35qRrz0Bb81lG4VYgK6XsF6NFerRRgL/lFyohg4fJOnnoZt7G1pwQcPBkVx2QOGuqjuQVucUajit1LE1VsoHX+pUAxsCbebE8p+l5wisY

OE6UUHStYyDXPAwQd9DzgiDqrUg+Qd9CUHTWz2W5WsMikMFeev2/7OuoSkg5t17rXdbXVSm8I/l0vTKSeqDZnqw9cO1XtesR23qoV84CfQb3kaY6UEyK34R+rx25sCdnuu3gx0RD0HmAywNg5Lh0Yb7iVW+kzRs3OYAUxM/qSQtluUKKkz9zOx8Ffpc3i649QiskRO081Ybp2x83CqtP82SLM10ippbmv5VS7BVMu9pXLtYJl7ADSuvOSrpAOFz2

NiRP9Oc1b2fT0tSQkTNlqFBRhctI+83RJqK1D6bdtUgdQaNjDhjLAq8C5D+LrSWdIxo1ErKwBlT1QFA2YUbaTXmzk13KnlbylZNIjqZ3KcYBQMPGDhogiurAAMZwBk5Jh8qi1QIMwFE5plfuIXFrvsd5lMBVtYEuMM0Y+Tbp2jfQTo3926OzdswvRtqiCgGNDHbKIx1yuMappTGCCMx8UHMYWNLH9QzYfCesYQCbH7auxxWPsYS6tAjjIQJLjcvk

xcGnl5zTYcIbeXkCPlwh/YXurB1foId0hqHbIZh3yHL1dw8FZG1H0zp7Y6h+FZodqlvqGpehgERiqMNYqqEJOx/C70D0n8Pe59RyErjp3ezXwkeqCjey3klLXNH9H9KsCrkCLedsEfnf/wiOAC8CWekjWLtAEhbWlQq2XSKtSPdLy9GRvpXdPz4PTUAte3AZrtlJuR7QiQWyHrr42nABKNA2EMgdN16qB9kmjphso8Wmq5+bqvWU7sGZ9zXd6Oqf

Yox/Ucm6gXJ/3cBqsNv4+TRKpJUvKFPyHhpYp+/k3TZ2x6eFQi2U1bATUP6qRyibAL41wBMrX9kA4jYFtiPBa39R0sLckYNOQsAD2DIA/nOyOyqKd1p+vQQMpzP1qmTp9VS6ZbVhh0hlR23WgfVFrLfT0m7A7PzvWEg6Txshk3PTtWVAI41QSDmMEcyk519tbSAIlHb5N1adzbFefvtEQgZVEP6Z+qGocgAzz960S/THvpUFngwRZhU8ms6hhG52

EigjNyuzW56+V+e3U0kaL0Rb5d4q9I7nNNM/ykWCWsA0lthCrBeN8Q6Ubixvojhi8v4Kcw3K7WD75zw+23QOriAOwI4DUFrSrHnDBxvMrB04xm3Iv2xKL9Uai7RfouWGrWHB5E2FIeXc8ftv2DEwIcB2JScTyU9xuIYJOw4ThRJ1BV6gV5+pYd5JsFbOSpMqHh6NUVc8pvd1cCmTOOlk+isvwz7iFUALLAgGSAqxh4ywFc4ecSXHnBoE4bffWsvP

Mixw/qfJHZA2JzEP0iuYBV4dQBmaiR1+5DbBECMeak9pZlNc/rTWqmdTou+s34Y9xgXv9zZyCykbbNYMgkcFuLd2aQu5HYiQaowZ9sKPoWO9X+SMEklDURh8L/ewiz6et0Ad/TOBsCeZRxoNApU127KrlRY4uVya1NfynTVKo0cFqXNJKrzUwD81qaaxjqzJwFTIh2u9mMyTiqnGg8JqatMbqgDnAXUnojFuVrpTauWVOro2oWj1YCyjHQsA12mo

FRGu20xrPNFKmlWmvnZZrwY65AteOzLWzk6kta7Lio4WT1k21lGm43uUrDeEC68KQJainbLXlIlnYUDptSiHPW+6iQ4SYBXEncpivZS/DqUPqXtZd6kttpbd3rmzdSKhrrjtZPGX2T6mkhSTr3qZgeTKzHoMmfA0wlBQ2+7LSKaZ1388pEpzhZYI50zTo+UClVDzp/PQhlTHK6sxAw1N1mc1DZ+IwXr1Mtm/9peo07BY7zK7+lVe5jXKtY1b8tdE

kB0DiVyQjnyr5ZYMOOEUwwKTdcC0m52pWWW6/28lpq1UfxtQrGoRNiM7pajPKMidXhOm/GYJUs3epUCdM9BrUhZm/ZOZmNYLaEXC3+oot4I4/r50li7Q2AJO3FdT6y2Er8tpK/FZ8FpW+SxemjVFvVsdmTTuVpjYIXV19mDbtpiSOiNERN1SrmF76X9JxJWxiB+pdtfbZnOGqrdxq0rYPTn5S3gE+s53YbPDNr8CF0+6m/7fQCEh7yrWCy/cCrZ2

X3mX5WgVfR/AXnzN++qcCBmrnjhVEN9KMFXLxFQUo1b5m/RhCMGJ3vz3mmK75o+aRHAL0RnPcJW1ONn8+Ba3/cWoV3Gmcrle809XpduKrUA/UdvnNDNurF6YcGKBxGG7t2LPTqB707UeIv1H+17OVEqlhqjzgWhmsZbf7A9J7Wpm2gPBwQ89hEPbK0VNMkiaWAQ3+L6w6G+ieB0C8Ad8NsS+w9xNiGUb0l0/FIfRvgP2mmNpS2SZxsRsR7d6zQF7

ZntBLtD5Nwy81KpvRmabpARWEFj6A1QaoVC4+jYdTNt9nLjhyouNE2jIVpomJacH+nkNR7vDN90K043c2P3QjPm8I6fLfvfMP7wFr+9UUVvgW/BJdyLYA41uaKuz1d5Folsbs4lQ1u+9vbITbv0x++yquYqFJ7soGtl/dp26wN7WLmyhGbXSorFaCdV5rvgOKmuKkGtAbgqAOcUQE0A956nZHWHqhLG3QmuOUASrGMEwDLBo+mgPJJMd0rDx2qos

jLvoDsAogou1wRMcmIlQUAmnFHOcqNyW4DB6OjHHjvtzgCicVYnYshxIEKfFOnk/6oQOU5gCVPSA1T2p4QHqdQBGns3ebk8ktqoB2nnT7p70/6dkdhn+IezGM80ATOQuUz6iTM7mrzOf4Sz1EMt1Wcg11nfHLZzs/e28X2DzD7g2ib4NxSheLZbh4jdB0OoD1MljKcI8tLQ6sbEjxQ1I8wVHBM7ZQBdAbLDNo75HQ8xRyiqrBc5P1BhvdCZdUYk6

neDN8nYmeZt6NT+qgtREKc5uuXI7cGlnQ47jvKJ41LjmaZLcF2Z6CCITOWyBbiMpXC7he4u1BcNPtnsrmtzI9rdAe63ezakG08XNieeHQFPGxJwPCtgbFq5Q4D03ba9P1WMHjVjgcPfJdszgzNheNlPbpeDzMdm5gO73gP4B6mbbvEO2f2Ffb6MzMRbm6vzHKCVJT7O6Uwytf5VnIrVS1lQUXZWKv1TyrkXe/q1N+ONXTZrV6dOUXBOYLFd4B8AY

idYDTXohfsxA9gyJIoDKpGA8UbteIGZECmWq33fQcSrMDfpt23brbBuNqXk92l5Pp9tiD57s+9ANUDGdsAeAise2HwI3u9TVE2pbfXvYZ376hw8QVRMBB9VMLckQViRJcOvupu8z6RWV2Lafu0l3HfmtU1481OJXv7/j1K5W+fm6usropA1/BcrVDKohyWqubA8qZJJ7QVcrtm2oyf5bh3GBuo67dIvs5JoqWFVkttspycMqvnXZ+gEw/stOWOH0

zo1nw9tYGHzDFE0uuimw3OH7yhG2DiRspT+Hkh2SwS+pZEvxHIK0l8VLxsTuZ0eEX16uRd2BuMdjJ7HYeWZfL19DgI9l4u+IWSBkgRgNMo1BqzuqjzEARKLu7PP1sTHq7PJIc3ctTg3wb4ccOGp5tSIr3YGEK9K7CvOOn3rj5+6+9fvvuoB3j9wXne/flvf7P+/U6rdo1pG63wHquzrZyMN7I7heUDK3e41wP5M/UQUOhtiGr4+9Q7t1yO9Q+evm

rZWsCfB29APOasrpLIFcGe7EBaghAAZ+8hbAtPmwhkezLgFQD0BWgTgLiYQD9F3dnjQWVSdRJyznO2AFyCrCrCY7tZqvF47kMoCeRo9wuqHG0HGFSxUfgJMrSdftZKo9cLaxX1juCjuSocKsFXqryeM4BJcnk9X70I1+a+tfiO2wTr74Hu49eR8fXqp4N5BojfqgY3k8efmiDTfz4s3+zPN8W9bu+LYN7GYi8eV0eYbWwuG0x8xcsfsXDdVG3i6P

X+tpNPHx+CS8KkI7BPZqpKMoDkdBupPOh99bJ4t4qOG8Ib73STptBk7g7Ar/k8SvHBez7DDMUV/vdIyJvr3vN1nbHfTcBHyl/C5z/K8T4qmPHHn2s7nbVcK2/PHIou1W6CfQW6NoXsJ1kcbdq69bde+u5eyHCDgYH8X8pvrqtAbEtQ9obYrbby1GksnRFj18UNy/SOoVpIUTzS9wUaGRBJmCn7Td7zU/D+vJunymYcvMMmfO9hmPG4j0SvEiMd+z

7z9JH8+3GJZnN7BBEXLB/GBb9AOL5Ldfuy3X+zV8rfSutm+R5d/V8r6Ne18LTVps1628Nt9Qf06GlvdAaKMG/HwugiaBGAQ+oPMnyHuc9b/cXjucfRwQgPj8k8bmOX087MNGPqhf1EQ69yNwks3uMOHI+7uJwBS/QeXBQqwFEo5Fws23rPka183e/fPR+XGsfjxuLawquf/znjzz5+58+Z+ojStiC9q4yv5+9XQHov2aZL9gOL2LfZLfngKN1+yr

CXxh0gRHIdhkHdXXR2yt8h7W3y0oJAA5m8wFtFoVe07RQjwgBYA57QQDiHe2F1lgfedVo9BLGKXYdMTESmxMeHCSz3h2PNG2PUMbRS3R8+PTH1xs7fYejBJHfGd2d96TV31fVpPTNhJ80VMn3Xo1HBewgAgsZYDjBTAOMGtAtPeyx085/fTwcMRTMTEtBNoUMGtB4DByHb4SmOx0CsfDAWyj9HPcdgit5pFO2isX3c/w89XBS+Q/1QLLPwrcc/B/

zz9/9QDxYpK7EB3f9QDAqx9UHISmWtcEneL0qZS4cAi2JUvcoHS8wApxVnMe1ER2790PApz4lquGLHrFGxT2DgA4AESUuB3KaKmq96oawEfFrkSzG64XaHgAW9/MNsQklxOWbjjBk5TMCcxUAeOFXhmwb5GRBsAaCS9oFJJrhetU4N63VpEAPoEWcUsIqjuRkA3SmrFYgwSQSCkglIMSxxQdIPypMgsECeRcglry2oCgvzCa9igjsXypyg/aUqD9

KaoNqCOAeoPMAmggcRaDQONoLuQOgh6F2oeg9agnx+/eF0YdcA1h1Rd/tdF03VYfDslY9JLcgKR9IdCIKBU5DWgKvUyXSFWHoywZgNDNWAtc3YD7bfSxk9goFl3k82TfgKXcSFVoFIBNQWEVRC5qXqSKRF5SxxFN5/AK2c1tApK1JI79OVyf1jAlP0v9VXXx3XYf3bP3v85fHV0ysBRJwIbcIvSJ2QsjbLaCnB1BOLy8CZROyBAp+KVvxdc0HTLx

Q9MHND1Nk2AOGULByZOfDABkZJULJk58TGVKACQxUJpkOgOmR1CGZDzC5lrgHmQRM3FTmW5leZNsG5kEQAWTmpx3WFDFkDASWT7AZZYxFblRxKAHVl9qPH1bk1ZJWQGA3FXvwIAB/SMwXckQ4hU0BnYYOCEAI4RqBuAgfZtxn9sQ+yFxC0nQ91Ix/VFmHmgJoUMCDVWfJN0uEtA7eR0D3gfeUF8KQ2dipCzApKwsD1XKwP89Zff9xZCc5ML2cDf5

SLwHNMoRn1i8//W10YdhXB0DgxPtBZXHdLfBq0gDx3MizJpQsL42QC+racMppqPL3geCeDZdSEsCA6HyxNmPd4Ph8B4YUH+VKA34LR8McDH0BCBPBgLbB9AYMPndvhTgIpsjLcn2H8vCVEIdlp/I4CtDg9BDWZ88QsVx/Am6DQKJCiwkkJlNPzeUzLClpP80rD2RGI2v86Q6X2l1AnZkKf8HA5JjZDwnDkPysovICEKQu2PkJ7CfAx9mKZVgYphx

CzfEcI79wgkrSgCYZWULyEFQpGUJkVQ2mUJl1QsAE1DSZWmXpkFERmUNCWZE0J9CwQHiONC2ZGdHfDPQG0KFlape0PFknQ80BdD0EC9iiAPMT0M1kIg30I1l/Q1uUDCuAMEP9dZ3F31ntfbW3ixV1YDgBaxfAO0C4sp5O9EkCWEcTC/DUwvfVbZ22JvUVxckLUC2gS5Z83BspXYsOhBCzUCOTsorX8zccTAgu24UawqXzrCZfP92rcFfEL0L8pVY

vzbDOQgqyfAikenQmUMLfCO+ln6CcGAhY3UiOnNyIwe1ycvXYDgkB7YNEAjg5ucUGHgH1Zb2oN2cSqOqjh4WqPqjsA3Oi1RvtR4LXD+DRj03C3gkHW+UcXNogoCUfc4WoDjwgEIpM1Lc8JnRB8HSN14A3OdxJs9LW8OUd8dRTzDDVGZ8MnlqFTEKoAY3ZB1SVArWxUcirQP8LHIAIqUyAihbe+zGBKXMORCMj5EKMgiGlHxzb1fPKKPgjobRsKQj

WQ+tzQjjXdsIgdCkNw1/8u3ev2dMv8GRFg0mFUAPFDwAscNKiqIw4FhlaItUJxllQ7UNKB0ZFiLYiOgHGLABdQ3GP1CmZI0ItD+I4gEEjKYpKFEiOZfAEFk7Q0WWki4xWSJoj5IlFkUiPQv0O9DVIsEGUiNIiIMDCPg6d3BC/FFaKhC57baMqB9APykIAxwZcHnAPg6hQMd/fH6QciNBR8E1iAKMx0nBHIWYhDUw1WxygpCwm6NAF0iBOwejyQ8C

NeiM9d+yv9JffOx/toomwKZDH/ewIBiWw9kOBiUozCMCtrNdyyg9H2ZvTWAyYclRQcxQ9vwlDO/ccKiC5WTazE5kAxOO2dFw46K+1IbFhxXD6PKH36iiArcKGi8TEaPZtvguS0JcSTYl2mjVLG9Xdth6fTUd0/XJaL0i2AgyK2UYQrgLhC5PSmwfClPHaPHxagOdFfCDond3tNcQs6IyVV5S6IHZrotN1ui41TN2LNj/Z9wrD7Yj9xpDPom/wdiA

nX6NiiAPL2Nf8ELOvgwiOw7w2Ntg476RRJCkdvlv5I48324YkY91zjiZQuUIKA6IwmIYiiYvGJxkCYlGTRlOI4gm4jzQviP5jqYoBOEi6Yo0OtDGY20Nt0pIx0LZjpZDmKGVuYwWL5iZSNSK9CAwufgTNIAMWN0iIQnS1WjDIgthptsAcUASBcgWZjtBr0V8LVipAxumrkUwz7V1ikgK2CGghwYpkMF88KeLykzY2eItjrBN/htijAleOlsoo6CK

divo2/23js492LsC1bZ/0cDAYlX3QiwPNyCUCOEf/319oYgcDUQtoZ+jfZCogiwfisvKUJy8Jw9nAqxMAagBgB2sJbFqBQQqg3q5LE6xNsT7ExxMRcQfLqMzjkXA1AY8Xg4gKxdhohHxLjBHTjwPDy4sRxoCCpU8MpM5opKDiUG4sT2Wj9IhR1ZwifZk24DWXBT3d9OTDgEhRu8A+lp9aFVm1zFxpYxiqYjBEUyGgw/CQxnjnAQHn+l9/JU3zxEQ

IUGETUCXCCT9ZHVeOpCJfWkIl1voxIwQiPYhROQiP5VCJUTfYptz5cW3TXxb5REHvRKs8IgUNxZ3LHvVg0EY6OJMTJQrvxk1PFOfneY8EpuIITibKWOITQlAQLySCk+oCsw9HSnWjdVBGRCVwHQRf0yVak8pIvUiSBpO0Amk2+2hAxAYgBtAewDpIBTzQYFLHtRfMKPMCWFMjWkTf3N2L+jPY5sIPjQPN0KiF0NJ8C0Tu3BvyXQZENw3cCtkpDxj

iKIrAzKjqTJKCn9x7EM3wSJY1JNtVHw9AHvJ8ACOCMAOATAFsgJA2f0bo3wYCmPsfVRJC2ISmF8H6gkgauQjBx2L9CMFkKEU374kgWYg/QhwNQIgovIiOK+S7GH5L+THHJCic9Ao+P2Ciz/N6KAtvPSRM3i14hFMZCkUsZP3jEot/2Sjj4ttyMFbQc+KSFIFMmHPde9XuxCCLdCAJRiLEjNkABeDcABCnZuQEAIwHsx7gf8Eqo0US42+QO0AVC+t

OUOqhlQwUBykVQ4URoMRA5aL8UaAmAJ6Ca92nbYGoAukbVGeAVjcOkDwtgX8W5Q4ZIqim8BUCOFeNRtVtDpRtjC2j2NE6WE1IAAAQmQDg00NPDToUKNOQAY09tB6wE0g8SBRvrZNJBRU0omnTTlUdyGzS9AXNNQkC02tMIBi0jgFLSt0MECnTfjatOuRa064HrT+jQY2bS3kVtPCB206E07SWuXtLuDVhPi3B88A/xI3VAkuH2CTJeUuK485eI8P

HITwmaJrihPJKHoArwohLbj1orJIRDVHP22RCqEbVEhQuU6nUiJLYCOzQAP0BQNmI7IIaFmI/LE2LMEZ4+9w/pHXBABDBQU0/0pDekqsIkSBknaTgjhknePl894lFNtTD4i00/9iYZvzVT4nbRNHN9gfRIMSVVIxLqsdk2OL9T44yoDRBP4Cqj7ER8HbgFQJvNqj6B60F6jEA9g+zHGRzsVJCiAkwJrzwR1OBAEhg14EFGvEoGZ5FXhy4XIMcB0o

O8SwRw6NEDlouJawE1o7YcUGNBnjNNGQDpM1gFky0QeTLdRVxa4GUy9qC2nMBsgEjnLh7YbTLMhdMkIHeRDM4zLwBTMuLECALMt5DthrMkgFZpHJezL7EnMkICNBy4dzKIBrkLzMfTpEZcJRdeotF3fSC4kQx3CjhH9IiTuPCuN48YkoDOUNa4tsEOikkp3zpSW4tJJ9woMzuNJ9No933C9hCHRikhepJXGYUzGFYE+SLmS4QjAiM5pPeA6UTQDH

BNATNTj8WVERJf0s7ekPCjYUz/XhSGQwCKtTgvAvxf8+ZPKzUTG7YvAjBcIyGNr9cUthm1I1ESzyJSLfYqOdtKI8dx6wsgSoC1BcOG5BoRNaFLGrQTkIp05RVM4VEt5drb1xoTqUxuKX51yLaAyjvbCDLMI4sS4AMBygqIDV8lE/MyhAhCS+Vgg4web2py/gUX1ggBtBnO14GIiACBzSc2CASBPYDnI5yIARfG3ANIXJL3pt4IDWKT9GVMzPslcZ

wHgx5s/fSIivI0JOCtfDARJT1tSSMBE89U/bPeBiAFXLGA1co7Ol9aM6GykSt4i1Muzd4psMV1lEzUEnl7Uh7P94pcluxWTzFAALGhKrL4G+yRMjLzEzSUsd1t1Aw3l1wSJ7cWLhVIQ1uM35e4j6HptKFEXMFdiVG+hD00AZwH2Z8QnjI0DgIHyLnjlELXPtAdcijLeBcIREBtAEAKwl6S0/E7Iz9YIoZIL5EUs3P+jWMm6Sty0Uy01rty/eZOEx

cRdJX5CncyphHBQwe0GTCPc71JqNTEvZLydvXNfT6yWAgbJDygld309hoxMHlLAHdBMMM1PeG+mM0g/RPPQ1ZUraEOYyjINSUwJoMmDlzb3fm0AilcoRSzzVcijOWk3PedmhTqw0twrzzs6wMtSa85FItzvYvBmtzELW3JhIJoINQdzIY//0qZCkNRFyRnXO+McUfU5GN+DR88qPQBLYGpxqjGoFuH9hVYAsiCxTYeqHFB1keqGHhtsaMUqik4Vq

PDg44P2CywVYHWEq1KtdZC5YfYOgoNhkAxArnFWolAvJQekDAqwKcC0bnwKUsQgsFYSCoMnILKC7MGoLMAx6hmQGC2NgqzQfSsh8TUTPxNziAk+rN4dkbfEw498XFrL/S2s6JKxxJHM8PJdNAdpMWj0c4PMITzkyDIySDLaDO7i+AuDOIVmAQXJoR7k1Zm5TeASA0XlE86Qh/DeAZIQUCgFFYGSFO7fJSkQ8kHjNzN1s6EFUQ1ERIGvyII6jKgjP

7DeKfzjci7KYzEI9/KAdP826W/yj43/KqY/Cvdz18cUnRJ+lX+e0A58ggr1MRjQgge3+yyU1GNXC5WAbGZ57ML0Vcx7KImmmxlg861colsFbGixDRCCUSwUsNLFXg9sa5AOx0eDTkKwmAM7AuwrsYr1uwmsQHy7EtkWMy0BV4KAGCBK0QYVdJqgd0jTIztH0izJAyNVjMkCySMnNh1itRj8JNGCtCNokaLCWuQ0aDGixoLKBoDxo7KCbEhQpsJyj

nCKaCYyusAqemlutQqNeAio9Ydmi2g4qBKnGtHrAWm6sRaMWiKpJaMqkIAKqUninSGqZbmVpWqNWg1otaXqlwBdaQagNoRqB43Go/rG9OtoFqJam2MtqIpzWpnaLakcA3afakOoBxH2j9odrAVEDp9KO6hDpQOcOlXBI6d6g4BPqbVDjo/qAGmTpU6MGghooaKADWKqEHwj8Jy0XYsTJKhVliw9SPNVh5YGoTVgFYdWPVjFZw4I1muLVS3enjMHi

6ayuRjRGHkWs9YYry64NvB7mQ4NOQbjmKMODp1G4AbXDgI5zjKbg0yQXFp2o5wXFZ1W4QadbjY5NuD+B24HuXjgO4rOI7mE5TubZ3O5xiua2uQ5OW7ju9njPrg04XuEzl05PYfTkM5jON7nM5LOazkB47ONjlB5nOc0Fc53OawBh4KOEKnh4HsfzkC47kVHl+8MeezCx5ouXHnBNKShLiEAkuSYuJ40uObmzTyeXLny5CuVkDp4CABnk1pKuS0VK

Fi0W4sFymUNFC1KhhEYTGE+kBoUGRmhVoWXB5hLoSvKdtG4rVLw3DzErQDRWLAgkBUKCXNFh8O5DglbRTAKQlfjF0UCA3RXsA9E9KYGxG16oP0RBNAxbMtDSwxCMVIkYxNmKlQqJGiRTF6JEQEYlcxFiQbLCxHIA4lSxbWB4kqxfiTiChJZIIqxmxVINWDOxbsRklzOOSUHE1AYcV3FlJTAAnE1JDSTWAkCkdRMlVOZcVAQDJXcSMkdxVIP3E8yc

yUslCnAYvPE7JG8Tao7xB8RcldMtyR2A3xHYy8kDqQKj8k/xACUtQdyh8r2RbSjgEuUyyk5R3KyFIysrRp1bitHUDKpVCsqjadbWq1XSWrXq12tZrVa12tI7TG0etM7T9gLtIbQgrfKu7TwLptWbV1g0AsjxuL/1Oaj7xIaayooc6DBgz7EmDMgwoMdy33RtLnyybhaMrjbqhuMLkLo1IkejWMGeNG089PeMASr43G9pjX8X+N5jRY2WNoKtYyu4

NjWbi2NwgKExhNDjROmOMpUG4qyqNSo2mYtWLdizosMqwat7w6ge4pyrDrDq2CrTrEWl6L+rWbhpoQS4a2Co7rbmmSo+aJ6zWqZrdoMOcoOVDkTTVrSkrNoNrf0qBtgaKavVL9yjgFwcRWKhxocSHPYzuqNGMgGMr9nFgEOcynP8TOcLnPzCucGnTQFDKHnPY2ecQaLpx6c7QPp2SBqvIZyOovnVjnGdSJf53wRAXWiTmc7nZp01pwy2jkhcKsaF

0aBYXFUtjNe8PcuMriPbD0QC8PXzkyqw3bKseL1vQrymotvUr129KsA73G9jvPNIFQzvFgAu8WvXlD2CbvXCS68rqXr1SpnvIbze8PvKyS+9T0kLgHKNOAHwZq7qp3mGqukVAPgCyPcQruqvfL6pyqhg2sXCByK+KjGDKK0SUmD7gDIKyC5gnjnyDCglYPEk1gsoIqCTucOhqDCAOoPRoDgxiuOCnqU4NgqLg7oMhzrg1OEZragan21qOAaqspod

y58L91GY32iNpmomqLqik6/uLqBU6ytBTiljG4t2j4qtOq6QrEmxLsT/YBxOzq0Qp3jzqjaftMXBB0yNO2Bo07pFjTRUa5DOr1JPWl7Q00wdAOCs0jLhXSjufNKecN0rdJ3Ty0/dKrTrkGtPwqT0p5Aqq3jQVG6p7aG9J6rWgbtMyr8kpMEcrDkGTN8x/M5gAUygs2UN2pVM1cHUzIsrTPORYs0BH0zQYJMCSymvCODMy0syzMyysg7LMhLnYPLM

czaqZzKKy3MjzLKzLYa2Bir+0StGYLkC1Ao4LPYTAuwLcC3gtQB+C4gpbgyCx6hEKxC2gskLvYA2BpRI8+lH3qOANrhMyJvR6GUAguN5FmwpwtyhSwEwELmuRnSObjQhWAdlBywCCNbGXAQgUgHOx/QhqOcSM2FoqGx2isbE6Lfi4mh6KAS/orPFfMIYs2wRinbHGLssXLEHKTsb0uG4iymDmWL7sDrEyrNi5ws1KmWZMgOK/KjMl9J/SM4uDJJ0

y4qLIDK+/BmrjalmrEaXi4yhLFMaLbg+KTuF4tG0CaBym6KPjMY0ppqvdaqGtKQLavBLwqNmhioYSzmh2qJrfmm7ElqvKlm5xaYqiLF0SzErnKMueqkVo8S1WifEuqHqh1pfavWiGpGyCkpNoqS82ladaS22npKVqJkqdoqS1kp2oVMjks9ouS06lm5XG4LBuoBS4Ogeow6COjB5xSyUu+oZSpOiBonkNOkVLM6ZUocbfCOoDjq9i3gGVY9SrbR6

FDSrVkFZdWPBzNLLyy0r34J5ZmrtLwOVrhOrROF0tZrfq3rke5+uNDk0bWULDn9KJuIMv6ASOcGsW4IylbgY5oyqXI25OONbBJr+OFMqE4TuWF0zLpODoNzK+xSWvdKnuPby+5Sy8ss+4Syn7hrKAeIHlYlUsJznB4WyqHjbKvOTsoR4ey5Hj7LrkGb3UbhynHgRw4uccoJ5kubzBJ4cmsnhy5KeJctp5AxNcvK4NypnliDYoJZtObVmw8tdJhhT

mhPKJhKYXPLZhNoWhQFhW8t1h7yx3jOayg18s2x3y65DNEYJarh/KEJP8u8xkJQCrQl3RTCV5LfGyCtwkWqgiRDFMgYiUjEkKiiRQqAXNCtmcMKzMSYk8xXFvYlSATiW4lIaXiVNqBJc2sbFra6irdraK6SVkkrgI4OYrFJVirHF2K1STaMuKrSV4rdxfioaB9JNcUMktxUStMlbGo8XG8ZK3zAm8rxeSt4knJbLKfEVK1DnckrKDSs9pvJbSr6B

/JPSoOCVW/fhIbTKo5WOULKkCpIabKljjsr7yhyrjrnKzbW1h3KxrU8qDtDrSTRutU7VjgAqgbSCqurW7XoN7tcKqe09axAJiqANEusSr8DQg1SqSDdKtYNo6v3VmqWaoMryq2jAqofbiqmbhNonjM9JXqgm+cKBKfjWetmNGqoE0/hVjAiXardKTqo0rHnO9LhM+qhExCo7qv3TjrRqqixVgaLCasva7qpxqfKWa+asBQurFJt6s6G4EvCaGaUa

wSaES56zUAjq+ayubcyMMhWsfrC6vWt/rHDhuqnkdDpIanq/B0IdEAuh2hMPqtVp+qSnd63+qKnbayBq6nUGu+aN6qGoqwYat5wRqPnZGquBvnNGsmdMat1uBdcahZ3xrlnP5rWc9uGFz1htncmp91KakhpprSPOmoo8NazkyZqb2/KgK87mzb1qxtvMrz28eao71q9TvPbiFruqS71Fr2vW72U5uvaWv68bgF72G9RvcbyVqfvMLnUb1atrGjqt

ah6t1qXtDAPWRDa/jpiCza+IOElEgiiqoqJgqYNm4Zg7IOhQnaxYJdqxJdsVKCDRT2qqCfav2oaDDg+SXjbWgijrOCXJLoNBdegm4OjrY6h6oTrPKGutJ166rpAzrWorOqLqc6o9qNoC64br3pRukytcTK6xWGrqpu2upm6ukRurDSI04dNHTCAONPHSu6ydLo6Z0vuvnSB6zNOXSAUUeqOpx6/Cs3SS0thrXwZ6mY3nqisNgGVrl6i9LXq201p0

3qe0nepuS46nzIxKj6gLIRwz6kLMvrwsjTKiyYsl0DizH6xLPOxkst+tSyEAdLKszv62zNyy6UfLMAbCs1zPcpQG3FB3LEM4ypgbWCuBvQKEGrguQaCCogtqiMG2ZAoKqCl0nEK6C7MCkLCGvFTLQHqshuSyKG6IGobpGuhu2xGGsQFQAWG4eGe6OG0iG4beG/hrx8Ks4TLB8obWRLYc+o5QsGiGsr9MdQxou7JHJJogDKrisfLHSsKLMKzFaKwK

4Gn8aui3zFoaLrMLAiw5GssQ1aEsbbDGKZcfbDUaZi9TGKwfS57h0byPFYoR4DGnvCMajaNZrMbl2yYUzIrGnMguLCyKMmFaMO76tt7DKdxtMovG9qx8bgq+3skbAmwbu+NfKQaxutIm5mghKYmjmjhKHrPasRK8OlEolpMmoQGlpeJaqlyaFaXEu6oVaNqiKbNaEpr6oymskuGoWa02kY6aSvWFtCGm+2kZLGZdalabXaC+s6avabkt6bni/pqD

p7qUOmepRSsZujpY6eOn2NAaFOlmaFSjOnCpjOtUpWaHqtZp1KSPcUFVYtmjVl2aTSg5oNYLS4Vs+rMO85odLBe65tqxXStmt24PS47C9LA+rRteacOd5qI4QyzTso5rkAmohcoypjkBbYy4Fu459O5MsE5juETkM6aullqzLYWm7nhb8y0AaRbKsFFve4Ky6gerK/uWspxbcK6prB4XOSHmh4SWqVC7K/OB2F7Lgualo05aWmLnpa8eRlsnLCeG

cuwAsShcs5bqeZcuK4eWsrkJLNywVs3Bv+khrWaJWmoTqFji7bCaE5Wq8oVaby7ZuFbHyjPoUaHSj8t1bvyvsRtEDW+0SNaAKxAeAqMJTPuwkrW3SjwkYKjoKIkEKsiWQqMa6Z2xqPWrCuYl8xZgcloCKriSIrA2kiuGDQ24SXDbWxSNqkkexBitjaWuh4sGDE265BUlJxdSWfR027ir4qlxbNsErc24SvzaTJaMqLaLJEtrd7bJJ/HskFKxySUr

a29RobbPJZtq0rvxNtt0rApTtqtLu2uOt7bzKm4ssq464drHV7K3FQnbKtFyqTRttXWA8r9tbysXaTtI4pXb+tS7WCrN2ybR3a5tPduIcD2uKsW7aDU9uIM2LC9uVabO0nTs6ygi41aM60DoyKq7jEqoeM32l40qqQaEvtqqD065AarATZqqA6wTCE22NuqyDqlRoOulFg7bh+DoG6KHFiyQ6UOzi2jr0+uauxojrRauFohQFasus1q8vtBLImuv

t2rJrfara7XrY6qdLu6l9rxbLqpjsBtN+tjrjqOOl6u46PSaOp/6M+pksE73IYTtOdROpAvE6bnMGoQGWnR52k7ZOuGvec7nT5yU7Ua353RrUKoFxxrBnPGrBdCa1AdBayazkbM6KHR/roLiHemoS7NazLoc7eRmDhc6uakGnc6rJPmrq9vOjSqa8Ratr3FrPBhFoe9ExULvC75aqLsm8Yu6YuOx4u/AtNG46lLvQD8adLtuGja3/sUlSKkYNy6r

agrrSC7a6YIdqBUeYOdqeimivWC6u7YIa69g/2saDA61rpOD2u0Oq66rgvoLeQMuhDvF7E69bpG6Eq9OqqjM64bUbHc65sa6Q5uxsYW6uxpborr3E4brrr+x7bubq9u9urHSnkGkd7q50yRoXTB667tXSx6wtMe7t057r3TK0t7qPSF6z7qXqm02yhbT16/7shHt6wat3qGUB6tB6/MiHrVolMlfrCzr6zTIdgEeghAfqEsncRfqUs8zM/qyujWV

x6/6/HoAbbMIBuJ6SszzPAbyeqBqNoqe8UDYL64WnsQbuCvAsZ6BClnuEL2emgokL6C/BvuBeenZEvHjKwXv0yla0Xqd7PjBhqpbmG+2FYay0jLHo4uG3zB4bWgZXuHQCfDtV78jCmvmOTTCq1RFku4+8LsKjImmwQB5wDgBBI2ARqGdhLw7d1XyPC5n2cASItnz6hhwX5OIjREXJDfAUtLyOAw+E4jJmlUNBDDiK7YsROfyYU8vMGSzJ12NfzmM

83KyLX/XIo4zq1HSFsgcMl1Pkwb6fJFg9PUxD1+ySUkqNgLyUposqBPYB5qu53IbIAMBsgfbilQMgboIMBogVkEtRrkI6jK4KsLLGNBV4R6FcGI4A+lsG6UOamW4uxVtCIBJZDIGZwogMrl5bAgLiWCBIQbltK43GVOEaiM2UKeQ5wpksXyT8wGKfWpggeKcyw54cFHCzUAVKZJoMpijkiwQK8LFynn8fKdmcip1etKmdxMrlTBKp1TjK4apjIHq

mVyxQZBszWEKXUF7lF9J6j8A7Xrqzde1QrY98TT7X3DxohS2BUOs6uK6yQM6qEthwMiwpvDLejuMaR4Q2wu/V7CyhD3pRceoBn7YRGXDPBepRXHHiXwRPN19lJkvU58CRNbP+TKM0ROzcNcw3BMm9c8RKSKTpI3PNS0i2RKuyy7RRJQjLct6dV10UpLX2YscwozezSi60EvcYikTSjjiUr3ICmAc23Xbxo8LvFqBApbIB6wQZm2iHwbMUfCYAJ8P

EGnxX4ufF5Il8PUOBDKgIwsHjUc5JNpcD8difttaaC/B7iZY7ED3o9AfAGPAVe18KD1z6OPIlye2EU3FSvIzZL38UZt4AQAzmZ+lzz88nCAI1TJiQFQq5wKAAIJHYujOStK8v+0C8AHWtwSj68imfuya9ZvLmSQlSvyAgDE/vK8C+M822sZVCHEjwyfs++NqLsnVxQkzapTiajB3p0POCVdZ+kH1mngDDujz6fMXPkmN8y2Z8LrZgK0CCIi+2cdn

7zGvj2zFTTpOwBlgHuapDS88yZgjLJ1IpfyRk+ROuzSZiZPJnHJsBzL8Y5gxQbtHUHDOWSgC3sOYZgIURCKsWZyApVFoCx+LzmOJ6NiML3ZlWf6yzCs5OLn3fRWBaxCAcUAoB9AGACZzaE7T0Sg18i2ZxJZU3lLmInwOaBmhFoWzw0Clslue1TjoHuZ4BcAcBeMnDUhIveiTU/2fvyfoombfzrUuvK1sI51XypmdIacBvoIYj6WAKe+dRBP0t/W+

LIj/J+op9yGjdnGHgjYToSNhRC3WGp7DYXyuqqocwOHtgCDdZANK+WY0qGRkA6hd9BaF1g0MHGF47TxH6GvsTYWOF9Vh2aeFw2DTjPtI6Y17qs06dqzBDV1nEsPgsgPxMfWIRy0LUfHQqmjHp83sMKcSIuaGy02L6bvDeA/6eEmrkven0BMpwgH3oUc2ZOP5ffUpLfnPC62ytmlswBflz1UxXMUQhbJ2Y7ml4oBnzz09D2dT8c7dPyHn6MwOYC8V

bEOcV8w5tBZnmTXVxf0UCrYcC51sUqGP4z1oIUF7yz3TOagKh83ZKfjD5p4SMKMNKl0DzaU8+exyPpkuYBnKge8kJBlgCUuqBg4JgOfmbImiGEQvF8eIAp23Q5n6g3IqIhLkCMqxmQplLHnwzzYIMBYgXIUp6MMCDUqjKiW+k2JdNSUigmdHn0i0ZInnxkyVXDn0lkGLjnIHOzSPzii/JZTm5lY+yfMB8mor3nh8ypfttcDChyywXSJOALIOLKbU

G1fQILBBpQq6hbjgTYLbW1Z6oaOCThXYGGhhgQJc5QkA8DL5aVjJg72Dot/l/liBWKsEFYahhkCFY5YoVzWEmQ4VuQpzoB4OJ0UWs45RbfS1FvYVIC66fE1Axbpo3oEYokwxb0L+POJJMWE1HiYEEn1JpeLnGXXQxsLBJmxZISBA2ZnFAbgcUBLYxgcUC0tZJs2cGWFJtYHQyGYeDAEQowH1WDBZlC+y8jckXf1PzzYoJYCNdU9Ga7nMZ6Bc2WaM

3Ge2kA5qycQWqNQ5ZJnjlhjTSYzlv2JPjXwcMBDB6ZrKNWT27YMESR2+CAtIX2Z8hYXMgp6KRA5os+0pSm6UdgF6nLghKcGnkpkafMA2AZ5BCBB0zpvapdablBwQGgDgHCwfnFEH77V6qIBa8OAbQDTH+4DacbI+puLPVp8EcIEaD/MXoDz6madlTaq0JT2iaHsAAACO9049I8aIsuetZQ5yQqoQBa12bkeADEWLDqDpxNEEuwkuN5E0A5yCzLnq

OqTIEe4QaOAGHWhypr2cBBwS5Ajh9ALsS4a4THsFQ52nJrxG5gUasG7TAu75Ca9/QEZ2nF5uY0A1GUB/5oqxdOAAF5wbXEdjKRp7bhBbsBsFtwG0yqFoOoQaYqAQBnANgERBnAXuFWhK61bDOxh1itMzbIHCSo5LHAfHJdBQQLvFUzAgf9SwA2qbQAGCXx+NZGnE14qjinKQAaaSnhp3byzWc1gbm8kjucDbeRC1vtBLWFR8tZCpW0KtesBZ1g61

wB61lKcbXT6X8UEAwgZgHbWmvTtaxGrkVMF7XwsftYrbsN4QeLF2qMWu2p8Qa8TaMZ1/KnnWwgULhI4FOVdaE4IaTdcPT1aXdYIB91w9Z6KT1/MWIBz1y9ckArAJmh5B7MO9fVpfSx9aihn1iWvzK31xtqU6qqPGoQlkByMr/XAN4DZY5QNmqYg2kyqDdTLIWgga6RUAeDfPgkNlDbQ3pADDaWmOAXTcQBFxfqDDICN1lBeBfM87DK5uUcjeCBMA

KjbTimHY6c16ngx1g3D84i6YZWpLDQuR9WV0RxN78pTlboCgQilNen9AgPJpSTkqfPMKhV9JKUdRV6xcMNS5qoD3p9pOlGcWq5v33oT3C9fIqS8ZdVe1UdJ/xbs9Al8PmVzs83XIMCgoiWwiXHtt9yCYi3bPQ+i8Zs1K2X9lpBdsna8j/IcnG8uedyYK/ReY2Z1EOJ07zMolOeSE3wbtlExSl3efKXxMwKcaLusiQCMLxGEwv5Xp7DWeljWl7EHt

hPYO0GXAxwRWA7AlV2PJVWN867ZGXMSYCiCKrPfMJmXJt41f4TTVzPO1y3txNWejyww7KhSXYg3J+3dlv7frCYowHcyLQnW1M9WHUi5dshxoQPydzk553OsYwwdDX74+bEhaKiyFnJwx3/UuVnIsI4SgpLY+xX0jjAVYQkCxWQae2CyxG08UEwaOheqADgWhY1lJWuQBFdW9KgE3bN2LdgbWt3bdirHt3Hd53eW03dz2A9204yle6ietmrOeDzpo

QxIDNFxleLjmV3Rbunjeh6am3Yk2aJMX+mPHfE9JY1beGzLFjaLZd3fWdBaxoxEfBawsA5fLoTX5unYqSQ/HhC9UBEfPBRIe8r4AdAQi9BENXbPYBYc8nHPQKgWNl7GasnRd+1YQXGMgHYyKUF4Hbl3G8zjIkI22QxKTmSigpdTmirG+mIW0vaou2Ts531MN3JMvZ3Gs4Ab9aEBoeE+ATKAAPyfAwyKzFsxwsQIC6b+4HIF03QQbqjB4bqBasyw4

cjtbDSO0PYKa9uUAEok3oUXTeKojuQQGsB7MMID02mAS/d8x/qWNvVo9sWQEkBOAFtDeRiqawD0BaqcLDCB9AR7m/WlNmEex5XwQAGQCZYDPXIDizcXWNMtll2xewF4G/WesOtGPSumvTMHTQEI0DHrks4qkI3Pmp5G5RkgSXKtHCAcLfdHIt6Xui3aqNlgS66Ua3s433aMeEaC9AF0eI4mvZHgzFbMWazeR6oautbQp6zHvar8t3Hia8BB8AeuQ

zAJMEHST4YMt9L8gegFqBrE5r1qAYAWUGlRSqQfs5LGAc7HK4quO5BWnNwajcEbQJaIJ5pL9hCWv22y2/bWwH9iSuf3X9nGkCAP9qAC/2Dqfg7/3AUAA7rQgDowBAOfqVTIgPzN6A+lQWAKyg4AEDncaKwUD65DQOnxTA7gBsD3zFbR8DyyBeAX9pzdIOCAcg7wBuUaLmSBaD+g/M3OASzaXWWDlRo6sODs+AuRuDwIF4PGvX/cEOmvYQ7gGfqAV

HEPJDzmukOX1qwHkOP1pQ/wKVD6zDUP9qDQ6/FtD0A49aDD1OCMOTDmrjYbzDscssORB6w9VrbD5rx3FHDyY/6AXDtw48O3D7w98PQXJry6bAjt5BUHQj963CPOtqrMULhLPOOF5Bt1PeG3DemQ3ZXTeoxfoCTF6Qonyg8vicFXzFsmyZdRsngPGzGUnbdqAJUJ/H8ITQgzRnlXZVfPcsfeJbOGl3iJ+hD5I/BZdH3yRF2cRB/GXAATU787O0+2/

Z5IuHm9lyXerzpdxffsnl9ymYiDL2e02SFcFgNa7zH2ZCk/MSlp5aP2XlipYPn7bAuafnT5yfMaX6XYNxpPHCuk4BQKvB6AdQDNHqTZOrYReXHYRTWpObn5l8/NJFzVp7f1SrVifeF3jswefZ84UkeblObJhfaOWbU05ZX3nJmiEHBpoFebwW153gHALQ1DhB8m2/NmeP2YCzmefiMYjoBYjsY1UNLOsYhiPtA/4+WYASDQsBLG2MAASMbPTQ6BI

kiO1OBIlkEEuSOQSFZXmNNCBYgc80ij5sYEsi+V4vfpStDaiPNlM8IndsX4MvenpOKvVoDY5upZ07Nn4MT7V/xfVHQVqTrt4fd8j7mAM9WXnt1GaF33tkXdxmSmfGYl3rJseaC9XV+M7SXEzqJxoggFTEncmlCeDC/QZobefDWCz/edP3iz+GUxitQj+IrPSgFiM+TSgQzk/jmInGTOjf4jiLrP5ZBs4pjgE9BJbOML8BPQT2z5mMuBWYqWV7O3Q

lBOHOQE1BKwTqlsYHjC6lxbd4mBV605lDZzy2QuSvdWk+XO+8BAGUBEk5fNdPNz90+Z9Ki4aU+0NA9vnTy/T3QMFOwIg7NitQz/XOvPIz2U/vODl8eafPUFw13QXVEzBf94/VmHcdy4d9XeX9QwFvwqMDT/M6NP0dos47V0Y0C8rPwLrGMguiZRUMM5aGUoHb4nLss4gumIt+NKBvCxUI8uUL0mK4j0L3iNwvOmM0Jwumz8SIIuHQ7s+IukE0i/7

P1ItBIiuhzlK6ouu5IwpeEi9lJMGyGXGc5gALZN31tOlzh09qAT4BABr5qFfi9jykkbc5ogeMpf3HjU8vSciKf+EJfH20Z+S5xnvtmfcZI75ZMBkTnVtS5CclfZU8jnVT8AzmgzLzfduWjL/JGfp+odDTDW9diNYN3rL+21sv5QsC/ojHLny92usZJC9xk3wWs+Cv6z8mLCvor7C6uu2zpmNgSWY+BISvZZJK6UjyLrC6833rzpgLnypXK+bjp8g

q7RingIq7nO2L0eTKuGTyq72jj6Wq7Fz6rj04D54Z3MVqTPAhXOJDJLjCE6uZL9Ze6vLzsM4fyLJ+JcqBBrhIyryYzl1bGvUlzS/l38iuYmzO8l/BfAVEkGIrUQU3dJzzO/J9a9zngLmy45idr+y72utQzy5xkgihiNOugr4mLJiaYzC7SvQEqK7uuYEySMev4r50MSvVTsi4yuqYyi5HPqLhvbou0c/HYk8QwswjNkQb1i9DDid+kEIBAV2QWDg

cEqyMTC2T+PN4A4ZtMPfRNoJ7IALlAq+J4TQiuIDav7ZpZcgXsb4M9xv3Pe/On2lLu86dX/7BGfUul9hM5VPV9vqGZhUbwy7V2ZRKuTAp0NGq3MvObwC9eWTT3UXZxPYNY4FQJDug682y6x/a1pbMT3dOlvdhrlLvsgAZuuQK7s9eruUjzZ3rvQbEKRKYqV3xJeUlCpPfUWU9xrOSUsTqgJz2VeabYMKFZ7HbGAe5P69OTSTwG4sX1tyk+yTEQy2

44vyrgA/eYarjc9p2qVIP3rmkb2pNO2Al9G+53YIQyfQ0uri8/Durz77ZvPftqsJjvg5uO8pvbsxO8mvk7xIhWBa1L84FAclhyC/QCYqot8ms5yy+9yo1zHYgBtr6WYFv34/a9QuoLqs6pl+oM68luQry66EjrruW9uufQ/C4evCLp69VuXr9W+SvMErW6+uA2AuewVl75bYvmyThB+Bvirof3Dy9Z+04ZP9AKiWquYbo+7FyldhG+lz2fWpORmQ

Ft4Dvval086DPzzuS7xuFLvq6jv37ufZGvHz7+5JyQdpO6TOqGH9GmhgHi+h/QYhf87WuC74055utrvm6Qf0Hhy6FuDr5B9KAT79iJ1D/4tC7wfaYj6+lvwrgNhivSHuK5kjEEyh4UjqHlSI+vtb4WNHOfFJh6tPCdjuVNuOHj3W227Tzi74eAXaG50ZYb9WLEwls3/BV3zogki8jJHkfehAZHh+8Uen7/G8juzsqM5Uv59im9Dmf7l890e3zsaE

R2RMIx6uW+8/fcgeOb6B7R3YHkixAv+bux8FvXH866cewAGC8Yi3HtB4pBAE+W6pifH6K5Ielbsh5Vv2YkJ65iwnoWIie6H7KQLmYVWJ5JOmL3m5YuSrrh7LmeHirw6kqr9c6hxV8wUw9PhlhN3737gu2akerYx6P521l0O8fvxT6p7tXVH9kUQWn5ZBbjONL00xpudLjDIJZuw1eeyj6YMOKfB0NFEiHDgg55cGeOZhovHdEH4WF8ulQ7y7QfnL

ufBmfDOMcGFvFQtO+Qu5nyZ5ZJFnoh5ASVnhW47P7bLs6CeSLqh7evNbii4OeTFi1ROfGL+J62VEn0G4tuFzhwohvbn3AEYBMnq8GyfjtsTHEvmfM+1lT3n90ADuvn+6J+fO5k/xvzQo5+7gXpTom7qewX2O9LstHsmeyKG81p65CgCKMESQuny+K7ZstNXt13jEix6svcX23XxeZQQl/LPHHsZ46AXHjoHO2qXufH75iX3GPceGX0K/wfBzwh4T

fiH+6/WfAnns7VvQnnl5oe+X3l5lIC59qItPiT4V8H9rHi584eUn6V9qAXMVEEO2PF4cA5OxHyOzlzwi305vuYMP6XvuQ70BfBSQU3pK9newX2fXixdmU+jv1Hi15rcUl5p+pvXz+1+SV88Wz1h34nGUWmh5ofwNzPWZ/O5gecXihaqWsrsYAU0hXgndLf5ziVeRDGobMFwBg4aoA4AbQFZYduV88+moYfeV57MZDVz4FYZzPdy1ERuTy4SSAtX0

p+Ohyn7t4NejUrzyZF4Fl2I/uklr+6aftHia4wWpr9RKUxt7VXa334doUDYZs80UJ3nqjQrULurH4u4zZFYdql/EI4ATeQCSP5Y5lQKPmQqboB7hQqHuUTnXuT2gkouJCTOEFlexOJt7Gy5X89+e/QAjClHSPejb68It6N7n6YEnNtraJ3vUn8q9a2BHrJ6Eecn5vw9OmrlhRavLmEp6PPZpCp5ftAX5R+NeR301+UvoP3P00e4P6150e/7vR6qZ

coqN5uXGbpIVQt9BKuRw+AL7d8jXhn3m5fiCXw65Rlo3nB/8/58Y6/xkJbzgndCWX5Z9bOU3xW87Plbzl8zedn7N/CfZbyJ/zfRzpfP1vVZle7Oey3s28ufK3m59qBWt+V8tDIE1fIbfRHkU1YUvI8eMPP+T6EDbnl/PT9vyALZS5qfLA4m+Tkhrk3NUuLPqd/g/f7xD//ul5Z9jTOtTwy+g9gIa23AJ3P8x88+Nrn15GfbH0l5QeHHkl5YjDOUN

/cvP42N4Wf43rx9luoviBKxD+ZNZ/i+NnxL+2exRDW5zf9nvN++vRz8fRE+S9mfJpOjAWZjaxEQZQHuBjZxvZfnHUHjJfAz7t25AeDmK2C1AzPJJG/f/Lbf2hw5lvk4xuAU1YGWXWvw16BeVH2p9M/x3z+8tfLPqeZtetL6ZNpv7IARzQ/5rmUT+kq5cAh4zhwhb+xevPrB3eX2cTIMHSP4Cjb0ZfSirDjBz8P0vdh675qaEaE4qTaw5ZNrn8qxe

f4STG4e7/adzp+7uPZpXh7ulc+Vx7n6UnvDwgxdxPc9zrOx9RztQ1e+pzwnwk/+JsbMr3Sriq6eB6bf79cWaFUXPVj+KZ28UnOTmIhHBak22c539JoRQ2JkgXAEVwXZ4X3veDPq8AHefZh336STXh1bNfcfmD/x/Bvqz4Q/tLpvPV867WOch3rGbEV6el32AytAVgcaHshZrj19EyvXoZ+Z+Dk6i9pNDf/K5tOrn2k4Nmf+ut+xDveTwtB/CnypO

9P1BBr+R/joH379/qd9XMtWf+HpzEA+d4P6VcyiYd/6v8bsz9sCBv+KOnfoX0Hejnwd1vIkhYMcBARf0zpF93Dsw7LQbZ6fz18W/ubza/L/93oMyJOGl055Few87bZBJxwe8nuA0QZcGOe+ltwv4pL7rWNw5wwZhPvpB9gTRxE+9jpNtPo19jzmPsQPvEUbVokUsfl19o/mTcHzskt5/kN8WnjZ82ni7cYEBN8bXNv8BlizBQ1Kh8D9lA8ylvh9L

Hif8O5AOoBkEwsWGnHBjYPQtpetmBY4E6Qo9rrAKsGiB7YPAFnYB5QhjI9RXSCwUsVg1BlYBNosVu1gAAPzIBcgG6wSgHZgagGGDVgz0A30CMAkGgsAtgEcAhbxE8JAqtRQFZ8A7Ar0GQQEiAmQoKLRX7IndcKonDFysfT9Lsfb9JhJTQpZ7NlY8fQDJPTPX7UXWywX/JbZxPE94dyduJWLak61/O06DiF8LL5U2bEqd/4S5bxYNzTT6XCWQpX3M

/LtvJr5Y3Af4n+PPK4QN2b9zGJZl5OJZR/HH5wA/r4IAm7JIAmd4qnMHZZLf2L9QLSYM3DM4QUIwRQzOn6YvQ06M/Jb67vU06jnRVbOAhi7HvY24tLSV5VQMhLLgcfB2gYeD23VWKA/eObXbGGZiYEpjDSMmBjLVM53mABZX2I1Zo3KIF3beOyxAi1b6vCAGT7Op6dfWsKOrGP7mfbIGTzE5bIAkb62fVhTXLOa5OfU4ATQWYj2uff7VAiy61A4/

7LfbBxTqChwdCDlhoFFWC1CCVgwrJNAdCK8qawblgzIZAJ4GV4FawHpCfAj2AuwH4GBwPpAAgpYQdRBFxkrbrZK/Zj4j3elYYnL4KWA0bbcfae490Pj7AZAuaE2Kv4A3ac5l7E34LwX6ZirLbY73aMSzMDgCzMbMDOwRqCKfVwrYhZ+jBA8n5t/caD+3H9AcIJQIiIOH5s7UIoAfHT7hWdH5gfKU7GfdIFjvTIENPUa4E/A4F5AlAFzvTQLWgZ+h

GPdyzF4acB2Gdm6bvAZ5EA7171Aoj5ysYbTAgP5zcoQHhjgdlAZYRo7SoRcTLVblAoHPobDHZDgbrSCT+QRZzFUSrgDca5CRgVjgAAJq3Sb+wyO/kEq2uG3DAqmReA263uOs1lY4LmV5aiAD8OSdFiwTyH+ol2B42YUGEAtmAfSTiSiOxoNQApoPRq5oJAwVoLDEsmSq2v4ntBJolBAToKpaLoJacCYNBcnoMjEqmV9B+gADBXSCDBYaRDBm4zDB

LHG5QkYNUyehzswMYI84N1DK4DYMWcyIGTBAqFTBtmHTB+SSEAWYLTi9HwMBTHyMBLH1HubHz4c+Jk4+meybOfwVJMZvXxOAn1emntiJBK21YeHgIr2OSQt+vgLK+UbncWTfw/+MMxVSoQP3OEQJu2190WBrKmWBgZwxmx0Fdm2EGSBkp0n+IL03YOwNn+ewLdWnZhyKS/xT+LeTT+xcjrU8hmz+PbiWAbIM8s2UBR2eH3QMBoLgePflHO97wnOe

V2JBhXx3uIJGYAIJCywzsDHA/LGQynvDyQwwO4AhnA5BE8T2Y4BEOYlsFhARgks80y0V4J+XmBJq2/BsEGa+zs3ABWMx6uU+2Be2P2lBQc1j+k70QBCf2G+Sf1G+zdhDWRj2HAJMAcg/fAxeh+zuB+oNL+0oSeBxuwocw8BaEQWAdI2aGWGnHW565sG60U2hoc3BQGQWWCGM4oEr+OYMRWGmlMh5kMshRKEocccCywdkL9gDkNe0TkN1gLkMG07k

M8SOAWfSSi0MBZ0xV+GizV+rEK4+U93+CeJxm2GlkVmYwB6SzQMNub3zXu5JxFWm9xgyOsx3uRgDfgcAAjgEcGDgJ81t+TezUgbIM8KKJHxC/CH3ypRmAgvexmBA7DTun4IWB00jNWYALiBy8QBe7XzvOmwMii2wJlBGjyghz50VBRwNQBJMExIjCUc+ZQIcgZnkFAVQL0hW73uBmojeWRoMqAw2iEAzyG9BSm182OxnCwxVAAO3zjfgvYAQOxTS

wwB3SOOoIG7Q3oBqOTRzeGynUcADQXsw28DQgqgFwAHYNk27WxRAgKFbQ9XgfEahz0AYYk5gTmxswCEm5QgUmwwszRPgHxUuQdyCXgsYM5Q7WAiOHkJ92EgCOhJ0PrQZ0NjAvRyuhnkgcWumXuhg/Uehr61QAL0KlQsB3eh+xi9BqNW+hx2D+h/eCsAQMIo2IMPqm4MLyCHgChhBgB8A4KDhh360RhpVGyAKMOyQ1mHRh6NESwBR3oAOMOXBSJzX

BCUNEspgO3C+vWfQGv0iStgKPBmUKx2gn2ti54JYehULqk5ew22XgKK+vgOVmtvwCBqZiCBi8gu2YQLykH4K7+0QI6u7cyFO2ECAhJeRSB4Z0g+0/wghciTn+OQKUhhwKT+BQPNcLfFVBBj2de2qjSimsQP+xfyP+e0KLuAZmoumamIh/1wvBDKVr+cAA+BlmE++YGRp2TsKahzPl10PhUR2u+TEwryVP0Vcm6hBSjmBkQKEhA0J/BPsPEh1q3WB

HX2khMAIyBckN2BsH3j+hP2s+C0OVBqiCDUHeQMuy7x1OUYGvYOu3wB/T0IBuEMMh5iTP26ACeq1C3qErlXaE9sCTg4gN9gQWHj6FWAjg01HuALWGcApuxqggv0buODn1GO8K9Ie8OhQB8PVgtAIQap8PPh1DivhN8Nl+PFg+e6vWpW8UNUWmsM3BZgO3BxcRG2PwX1hOIIvU+hW5WJ4KMKU7nqWLgKv+bgMsKZIKwQUnxthO90tALWFEA1QHoA9

sF+ur/1ZBTELSU+ITMcaGRr8GJHuWXkV6hnsOEhApyCMKwJGhlTzH+GwP7hWwNgBQ8MghI8MUhY8MT+JP1he1jFEQI4EAKW/0DWSQktgHCEYh7r2XhuoNXhYQR3e+EM3hEAHjKW02uQO00amV8FQAyGyYA9mHJhpABBIjXgeanpWuQRVFmaRADkA3zl7Au3ijBWhyu8cPSlKmWFIkkxlbQ4YkSwc4F8AoXHvWArRZ4G62Ohv4n8we2H8A8WREOdy

BOoKnD42u3FjaR3Vxh8KxW8DXE0RdU20RCg10RRWQMRGXGMRpiMRajzW5QViIFQFWBsRGlTywDiNUyTiP869mFcRkYg8RA1EhQW1gGOfiOCOW5SCRW6x6KYSPPgYB0nWVziC62wFUySMOlhgQESRZKxB8K4PkKEPi16oCK4cWsMLikCI4+esNayOJw52uINnuiCNm2RhT52ucNy+1/3E+FJ0k+ZvxvB3gPsWvhAPMJs0eSgQIWgkRF6hAFFU+AVg

gUEly9hDs1/Bcj3/BCQL9hdUKUeQuhAhEf0lBs+2mhE7ziiEcKERykJERyfwTChQO9W7gXsg/q0wB0iIHgdmkcgup10hBANR2BkNUR3nwaB1Fxt+C2wNuk52r+ZEI6BlQCEA4oDEwY4FwAY4EFeZCIYhlcKD8yQjeSjOmfoAiAdAG801BNjg1evCAEhbcK52zCJiBXcOGhLnhDO3yKkh0AJ4Rg8MSWw8Lj+giIVBi/zteqUXGgsxBeyUiO1O30mQ

oWpHDAaeTzueoLXhmKLL+pAIw8FDgveqsDmQbFkvKVkNQAAADn6DGqxw4C5C44MgFMPMajhtG7svYEawLUdaiCHO0JPYPajLIr3dODLFDgEerCZkTD45kXr1zAehClkdoUVkbx91kfx9NkWMBw/kW9L/iW82gcKtifCVC/plSDiURIAjAMkAhtNmBpVi4VlBG/86URUlrNPiFmUV8AQwHNAu2FfFTgYKD0EIwi23nyjQAdJdBUS9Ee4ZJCuEWKjJ

obwjJUfwjpUSCjZUWEgYXkh8U8DpDQ1F09soBsQtoOPFU4Z7kS/nqijISz8M2NFk2YUEAHuPEipmmiACAE14/YG6C/Wi8APONENwqCM5kNry1E6Luj/MBHAKHLch7oB40/MEr1luM4Aempj1f4KL93aCFxX4OFNHAPmBGtqDCpUC2kvxI2RzAG1RCxvVNvoUJxvkIMj7AC8BNAPdwz4FUdwNpCBRkV7tkkU1EDqGM57SlujkYQnQDqNej90d1QtW

kejisNd5v0VEBIIPWAPoX2I90SCg70UbhH0cEAWJi+i30c8gP0bmsW2j+iekf+iweoBjV6tYc2AKBjVaBBjAUFBi7kDBjEYXBjSAAhiCygNR81oBi0MRnFyVk1kgEYPdeDAns+tsYDXgmGjLpp8EdwVGj9FjGi7AcYskEWMBbgnlCCUaRCOAlbDM0ZSCZPjmjrnr4CvkQ+9HYQ79rkWp9XYfudXbjyivfgf4KlB2j47IUQcECDYxoQPMCbmkCAUX

wiw4bNCoXqOi4IZCjY4QUxFMP1BSgVgCCSF5NohInMi/ouj04aO41EfnNRzr0tk0WgjU0WJ93fGOB8APQA2AMHBLQDVBx8gD9+lkMCfeJ08fCmoEWUY78JzF1DOUWohW4X1D24f4Z/MQL5AsbbEu0SKie0UZ8p/gxlAUXj8FIcOj3Vl/lZ3gVZcRHkhO3Cqipvo+wQ1N2x50bcCdoRiimfiuiDoTAEKHIaxltHVpMGgIsIyAQ5zYFwsjStqwhWPB

stvNJJGsHfCMMRmxYAqdj/SEIVpeirArsfH1bsW/0HsVVgnsaH1/4SpiaPIGj1MU0VaVmAi0QclDoEWXFlkQbCMoXPcE0R4lsvmfN0EWmi1tgcjTflSdzfrX99AFAAKAMuBZmDwBnYLI8H3g1DmsYvJwwIyieEL/Mn4McxtVvZpL7AOwu2CBgnka2jP6CedfnmedQPjAtjUhB9I/lFiB0TFiBEfNiYIba8lQdkt0NAg4unl2xEkG+BAggujB8vti

6gQVjjISBxh4NWDDumod+WByxPYPQZ9jKnAperOD5wZmDNKurRrQf5gw6kWNEONtReMSRtIQHlsBMYv1wxKyAcgMaAhALEif9i3cnkAdRvJPkA4gHwBXwL8kfDnbimulkBHAN7i3kLRIXgJAd6oGpVrgK0ZBKiuI/vFVQRAEGI1DuUjwsmAcqWoN5nEZFlakejVHgPQArEl2J/MFOC8AO+VQgNmCkkS1M1vDrjLIHrjP0QbivYMbjE6KbiPoWmC1

aAuCPxN5J2GpthOgousGgg7i/0dkAAMS7i4NsBisAB7j/ILHjBkWXdtEcIMZQCHjwsKiQxgBHiugkWNtvDHjfAHHiu0KQBE8cnjLjM2t08YOVM8Xw0v4J+jc8WIB88Tcci8TUjj0c2Cy8RXieitXjIJHXjVYZDjGPhpiVFontEoWPcdYUuFmstYDxtnAiFDHGj8QaOd8AGYsLYVeDrYQTiivswALxjT4ffCUkkwnk81IFUk2saG9lsnlJ8CbmZfk

vasylIf5c8mnoQseKDQITJC1HjNj5IcCj9gQtjYIfkDl/lCiIHDUxZlM69FMCsAuIatdD/rtD8sVijT/sTgjCjJNLMSRD84TX8UCWgSogN0AMCfb9jttVYlcPkh6cemEPkkRkSCe1c3gICkIUrnldCX29IAbAthcbIlbznQToscTMrXqCio4eCjRvveZtSGliEUe+hVAlqD5vgIT1cQ8DDQVnD93tpEJCXnDzYdISd7hwAPYJu4xgLgAFojSin3m

DFfkg+Z8ogbE2bhUlFcAcwhoFIQRMCbZn6D/8zGDX4T3FfEfLCztf3lYxW3pNItCfbNRQd3DhUVU9DPiYSpsQksGwhC947kqcwUS4Fzlun9rQDyD9Loi8nCeWRfVuKlC/oojcPssol0QdiN4ZQsM2IABCsiHS2wCa8AAxHSpDTi2P60S2cVHS2TE22cQKBEAVuJEAFLR2oTXlBaAyPBaeAyAqJaWzSqPSTWvQDrB03m7gzYEXBq9SHqNSImo5ayR

6SdAGAyB0aoq8AGAr6IPxPBXrxDGHvh4xMmJRxxmJXSC/W8Wx06kLmWJFtFWJl+0Zhn4k2JKPHiyuxJhO0Gx8ak9WOJYGOKoZxLqcLThdQVxPswph2zSaoFUA6nHfGyIGeJpAG6GbxOUAHxJ9xXxPkWasP/xMONmR4CO1hEaLSkYBP3B/6VWR8CLxBz0wLmERJKxLQNE+OOX2RxUMOR+OOOR223ixBmhmyck1FUMMylyNX1lyDyNWyXOI7hsEE2y

22V2yYS07RFRM4RfcO+25zDMJoLzn2woEsJ8oNQEMpBtyoiLDAffE1OmeDhRRl3KM04GKBqKJXh6KN1RwxJt8gOWCQIOR4AYOWImjQ0oarXiMOKDUl61EwYmvmyYmz6IEaZmNFiqCIYumOSN+Hajxy2bUJyyfCjm2AikgBuHJySVkpy1OSpytOTfc9OTq0xZILJLOWCQD7k5ylZJ5yc+D5yExFySWtUaAwuQUJMeRrmspKr8TbxAeviygowAO7+b

wH8ii8S80wETlMYpzGhtq31JYEIFUMoJNJ9RKsJI6N4I9sNsJxwLmI9ri6ePbBP0uImwhgxLyx2Xk9JvuVHO9cX5J+UMTJyT1k+3LijyzZOrmOT1rmFSVyQ6q2eSDCO58SP2eR/ZIoJloERA2AH9hmy3CxE0OdiIcPoJUqLmxTBKlxxTASxmSySxRtiFA/fDWxk3znhOUWVeeUFMU2qOURdRQ1xwhO8JohLGA9tx2RzD1XugRMcxEAHFAaBAoAf9

XtgOV0iJseWqsi8m1IYwITcRggEQ5/E+AVsB/ePWO5R/WN5RqpPeAL5PKJYd11J40O4RfaIlRdRIVOkLwTuaCwXJzRK9WEDhYYcuPVBgRRiExuh1BAxIdsQxNQp+qJasGbGKYSBW0G4wl0GAyHdgHLG56/sF1gZoiocZ2j1u6GMbxIOXSoc4m0pp5X+xusH0p9BSMp1jD7EplNjg5lOUxIPi62cUODRgBNhxqvxAJKUL3B2IPShOv3sB8SVemvFw

xxlpyxxYn3TRmSTsx0n3rJ1CG2KxaOsibhXNmVFNS0PhTs0BzC/Q2pCjAC0CbhnKPrhPZOeR0RXUQYoMFx4HyvkwcOmxFhJnJZpOAp4lMtJ46L6gVclyeXT2tAc32XJbhLThghJ3JkQVGJcrDamRAA6mkU26m9UyY21wBY2Q0yl6o0xBo40yymU0xBQeU0qc80wGAxUxoa0nAqaFU15a1U1LEdU0BQOiPp4vPX+4WxR2KTlRoWLkKEWDCzgmQyGY

W4vVYWlWikWAONkWNw3LmhszVayK2+WaKz+Wa7UBWwKy3aeBTxW4K21gkK2hWJK156Diwmm9QByqca3Km5AEcAjGybWM1MSmc1JSmma2zWn6LzW6W19xRa04ApazRqFa1E2sr3E2da0Rp4v2bWCmzbWPRVU2C1XU2Um1AQWmzkqum1HWBm2iGkSJM2d9QYOkxyYO1mz7Etm0CRDmyjBJBz3WFWAPWtR3c2p6y82F6xC4vm2vWAW3u6UQGC2M6SfW

hxyi2Jx3bKP8BBJvzSJqyWxjK7HDA2CZVBa96yRJ+AzO4cGyqwhW2Q2qG19QZW2k4FWx7B1W3w23khEODWz4xzWxk2vMKo20NMcWZOkrQfuzjA5uzRAluyD2gNJD2Du2wK4e1d2y2ij2psBVKu2znAFXgz6MRyv2N+04A9+xruqRzA27+27B4dG/2uRzYOUqCVhdNOAOPWDuO4BzoaDB0qOTMPgOTmyQOZJNkyzRw6orR3aOuB30RD3EIOvRzFpA

xwQkFB2GOmtFGOld1vRExwXWVm2nE3vTyw7BwQknB0WOC9R4OahyLpd3SEORm1EOOxzbuexx28Bxwi2QXU1pXzlOOa9VUOONPTgJWE0OheP86uh3TEw4MeOo3GeOX1DLSbx1dxVhxVqsXQsRvxwcOUXABOgUnswrh3cO4WFBOPhwnB/hyhO2QBhOASNI2sUAocWyCTp+2x5claGbuAh3LuzgBHpndyf23d156nF0quqzVI+NH2LWmDPKuNbwo4+d

U/RHPybWd0JBoUv2SCMvwIZDJ1a2xlTEB0vRomVAJoBMgNVgcgMMGzANYBDUHYBaIE4BqgJ4BGgNd2WgKTggK2EBvPXr+31JeB2zlBBqsHBB3wPIB0IP+B+pXq0MDNIUyzThpRtBNBoR29BNnEtBMXFLBvmHLB2rVxGDoOrBjm3cAVznrB7oM1oTYMLBPoNS27YI4AnYMyOoYMXE4YP7BG9OjBUdVHB8YJsZSYJrxPeLnBfeMzBZ4x8BGjNFGXSH

IsZkIQavkPcqNkMChvlRChy2jChj1FchNEzUZd4M0ZXSEJhp0K4aF0M7p10NY4t0N9KhJSswrXjphDMKqOcB1QOn0LZhRY1+hjQH+h3MOcZwMN9q/MMPxLXiFhn6OhhosMSwYQHhhgyKlhR3RBoqMPas8sMxhSsJxh0NPUYzQErQ28NPKL8Jjgh8I/hJ8PNgZ8Ivhv8JVgt8JmZA8WyZHAFSR5UxOpvLSyRHjSMRsYJMRZiLAGqHEKRHkmKRpSLs

RrnUcRF9La8z+LIx7iK6QniMaRPiOvE6cFaRsQXaRISN0OrQHCRPSPxAfSJiRQzO3RIyN2Z3LkrQTqIagLqOW0bqLiZO2k9RtqJ9ReK12ZsdUrQ66Owxm6KGRPWHwxtGP8wB6JIxtSMM2Z6Koxl6IIxdGNvRPKAfRIVGYx1+PeJbGI4xXGy0q3GMdxk+M9pYMMvSIGIaC4GO+QkGPRo0GN9x2CEEAMmMQx8mPS2qGOxZczKNoH2NN2X2Iuxv2MJW

N2O2a3C3ux+zWBxznWextFUyZvhDHA+zMGcuuNdA+uN9AhuM7xB1G7xv3F7xAqH7xVuKHxtuJ3xY+N643LIMQvLNIAruNnxmAHnxXuM+JiMOXxYUFXxwePiAG+PDxI+N5AUePNAGJU+J8eOPx0wVPxqeN/EF+PywV+Ozxt+PsReeMqRLzOm4sdDcREaUG87+KrxymS/xzADCZpyNqAxrMiZHAAmJLdQBJVzVmJwJIWJunWNp3DUhJ6xO6G9ML4Gd

3QRJh3AharoiOJGXBOJ6JOTBmJIuJgEiNAuJJq4+JPuJRJL0yTxMmo5JNYxnxLwKlbJ90shIeqmlJspowh0GGZD0p2rEMpC2hcphK29g7lJpQZ5OIacdS5kvmyTAfQEwq4EkUa9mBSw1kgPgHxNUyhOSjB/mGXARnB/Z5yIbxwvxCmYUya8nUyimrICmpqNNTWrG3mpIQDSmS1MmmOUzWpydMKmm1MWmO1PKmq032pDa1qmPU2OZZXDUZ51Kj6QJ

OupdC2EW91KYW3WhYWEixepYUNf671IkZFcykZj1F+pvywxWANOxWuKzBW1APBphK0hpsKz9psNIz6CNI2mDG2TW/U3Rp6a3Y22NM4xHtAUx+NIE2RNMVGJNLeQYmxrWFNIbWnP2pprayU2ZdO8a3aw02zNMOoA6zZpC9THWhmy5p0615p49OmOgtNswa63s2wSNFpzmwQkEtLc2/mA82Z6zlpV6382t6zhk96xC2M2DC2GtOOOB9O1pc5F1pmoy

S2qACA2htK7E4JMTKGzjNp2WwtpGZStpCGyK2dtPQ24WEw2zYDcZv4hq2X6PdpxGya2UYNa2lGxnWgnNXgAdJGqFDlN2wdID2Vuxt2EdND20dNmQLu0j2HuzOpydJNZF+3TpCR0zpSR2zpmzjSOedM/2e6ULpax3/231jLpxRwrppRyrpzvRrpe6RgOb0PrpiB24OzdKlhGB0ZkbRxwOq9S6O3dOIOLnMGOlBxGOYxy821nKmOzB2UaMuDmOs9IW

OjdMXpn6OXp8WVXpIhx0OXjIkOwPH2OMhzIGe9NC5MW0B8R9IuOJ9KByBwSqRbXivp+h0MOd9Oqcph1eOW62fpnx1fpgYxuZdhz+OX9IMQgJ1/pwJwAZXhyAZ/jMhOgQGhO/zLhOpQmgZdpz22FXngZRtEQZrd1fAKDI7uJlWG5dd1oZFXmwZd/VwZIKAE27POreBAGIZs3VIZVNIoZPPz5+NDLUZnF3oZlaEYZEgKkBR8NkB8gK4ZSgL4ZKgO4B

NUSEZ/AO0BYjKEBjHPwAXI2PaIIPeB8jMhBijL+BXsBUZd5XCZ6pUrQ2jLNB1yAtBJYJtBxjIz+fYKrBlkAsZ5xK1aiYLsZujNbBTjJcZ+dNtBv4g8Z1yAHB3KCHBtVBHBcYPHB/jM/xM4MsgwTIdZoTN2Zx4EDp3kNiZQcHiZXqMSZ9kOocoUM4W4UPSZuzMFytvPphRMKuQJMIKZ5MLKRJTOphWtAqZz0PySjMLW5tTOCOX0IaZ+OCaZXMMBhr

TJ9p/GIFhXTJIAwsJhhYsIGZEsLiRyMOKRYzLlhZAAVhWMPOQ0zMNZpzVrZCzN3hPwLfhR8M/h6zO/hl8Ovh2zMTp6jL2ZxlUOZZXHw52iNsZZzMKZrQDyRhZR+ORSJJoDzNjBTzNzZtx2LxL+I+ZHAC+Z3iOaRfzNhO66xFpnSJBZ3SLXpUSP6R4rOGZT0Ep5VbLhZRtARZJqNdR5qL8h6LO9RvqPlZxlTxZzXFwx0sOJZhGPioxGJNEHEhfxlL

N7A56Oox+xjwF9LPvRBiCYxUZMpJbLMuOXGLb6PGJ5ZzuL5ZvnT0AwmKFZ/GPExT0NgxkrNkxqnBlZKGITx8rNrZSrLOx32Mux6rOkWWrL2a6zMtG+rMP5zmN65zePkqOBzbxlrI7xWsC7xFSPNxITOuJ3bOdZ961dZa8HdZE+M9ZbAu9ZM+P5Zc+JwOAbOpJQbP9xDrNDZ6+LDxW+KjZu+OjxcbOpJCbJPxDyBTxagDTxfvXKwGbJvxg6TvxESI

Lxb/LeZhbKSo5eMwAleNA5ZbNrxFbN2ZNbMrQ9bP/A0xKbZQJPmJCWzbZCXLE4axOhJ3klhJlLR2JkGz2J5tMOJ26VRJvIDHZljNdBqPEuJ07JuJc7OiADxOJJy3BeJcMlXZ1JPXZZ1K3ZlPWspkrX3Z9lL7ER7MSoJ7JMpCAQvZWyCvZ/PWMqt7J3ED7PIAT7ISwL7Nd6EvA/Z3KC/ZqmR/Zf7Ka8y4AA5YyJnICiOUxSIJARflMZJcOJAJClLK

AqUM1+xmMNhqOPXuJdxA5EUy6m0U0g5Ka1mpUnLg5Y00cW2U1AqM0xjo61NQ5ygC2pwNTKmYRzWm3VBw5W02OpGSNOphHMMaqVMrQ/C0EWNAJEWj1Od622DRAkizo5Mi21ZH1Mt+X1PuGP1NRWbHLm4HHKBpk2lBpPHMG0fHOJWAnMyZ/tOE5LYFE5yNPE5zG0k5bGyxpjArk5eNNUyBNME2Za1KyQGNU5ZNPU5xXSk2lNK05glRppunKAO+nPrQ

hnKTALNJM5I6zM5HNInWxmys5Y9Ou5AtJXW9nLs2gLOc5/R1c5ktKPWuHBlp3m3lpfm0uQStKC2D6yC52AD+5inDkO76zC5LbIKF+tJi5KWw247bKwGmW2S5g7PTKpQXy21tNZAmXJK2ypRy55W3y51yEK5dWyI2U+LK5bTMq57IthptPKiZdXP92odMD2zXOxWrXKd27XIj2cdK65hHJ65qdJeAsR3phGdMLGvmGSO6DN6OgfPG5BdJyOU3PyOM

3KKOJRwfx5RznWtdNb5dRye5W3PQOzADbp+3M6OXdJ6Ox3KtFp3MHpNBxHpV3P5pk9NYO93LCgj3KWO6mBe5y+OsOGxzXpn3KjB33KkOnoq68+9KB5DNXOOKx3UOZ9Mfxl9O8ZdyCeO8PJeOj9KR5cGxfpNh3R5H9J26PkmcOuPP/pnhzBOwDN86oDKCO//LCOPMGgFPuh65eYo4A9PKeQ7dyruLPK7ubPMl55V055xlSo+MxnI++DMwlDJyIZJ/

OF5iou5+VDP5+4oEP5UvMbWDDPaE4gOYZkgNYZdAPYZSvMUBPDOUBXALUBvAOEZAgJ15evIN5RtGBBMjON54oC+BpvPmE5vNhBZIt8BKzTL5BYN0ZjvIMZzvNw2lYLWJHvMcRXvMIFPvPb5LYMcZgYPSOXYM7FwfLbubvP0RXjMj5DxxZ4vjNj5iYPj5QTItxi4I3ZskoVZ+Yrm4PkKz5O2meqAUKChtIschhfLSZkUJL5+zNyZxMPyZZMKxhN0K

phfLQb5EmKb5r0OqO1gBoxrMOwxnfM5hn3RaZ5XL5h7Aohh3TP+Oo/P6Z4KAn52ApGZFWBn5e1AxhisO+sS/Ot59NnmZj8MWZG/JWZrBm35INF35WzJ2Zy/K1q+dUOpRzJRFJzMv5hiOv5lzPyR79If5INCf5kQtf5T+ILZdSM+ZDSJ/5viL/5EDMc5HSNCRwAtZAYLLK80SLaoEAuhZ2Yut5sAq6Q8AqRZZqPdRyAptRqAqxZy/JxZ6dSwxWAsJ

ZO6LoxZLMIFpGJPRtYMoxlIHIFV6LpZDGMZZUqGZZyvQ+JXSHfRQou/RzAo9ZU+PYFgmK4FEWR4ForLil/Avgx0rOQxwrNEFN0tclHAAkFKrNmQ0guuxsgrux8gsexerNBx6QtUFZrI0Fg6XbxRuJ0FNrL0FifMclA+L+4NuJMFo+LMFqnEhlXrJ9Ztgr9Z9gvhhjgtU4wbMDxB1DDZoeM3x2+LZljQW8Fi+L8FSbICFZ+OCFh2HTZc3Czx4QseZ

DiIfxkPPzZJeKLZCQqSFATPLZzkqNZmMqyFUxMdKoQryFWnUi5v6yWJ4GxWJSxihJGxN7Z8JKqFiJJS5tQtuJYUDRJYGyaFWJNaF1xLxJGXAJJXQsXZJJOXZrxP6FwZI3ZqBOB627NGFtlOlaSaEcpx7OMprlLmF2BUvZfPUImCDNIAd7N2oj7IsGFDNfZpbUQ2xUv2F3KEOFPRROFbEwwRS5n3eRyTjJR5KQJ4pJ3u84GdgRgFLBUq3ohZs2vJJ

0UFADwrb+Q4HbYp5kFAvEJKp/txVJg2Nvunb0pxer3YR+n1HJUAMmxE5NJuDVOEpDRNl24cxapP+VERIYFcm0FPhRqqPpgCSDci6L03JylO3JZiV3Jw1KkyONFaAY9XBZfQAu82xg9xnVGU5HTjRlpAAAZbQw6odbXswa4g7ajQVbQ9aWI4ZTW5QrAACF+bJY6xbh+Jb2LlY0mSwwD8tc6vpRU24QFfl2CAeJIE0Ax38uck7Qw04ACoGGQCreQIC

sLGvuIgVmFTh60Cr2mACPWgdJOhxyv38pSUMCpN02CpaUMPBKOI2RWUIXuVKWipxb1aBcVJxxIpLxxW91gy+FOYATvGBmWCBgA3oDBmA01KSUMyVwt5Jq+UdiRmk8rZyON0fuc8qFRPFMXlxhNqpIuKg+ocNNJo8LnJaTG3leRStJ1yIbR6dyAgZQNHAUCF5BZj3cJ7pNUph2I7k3M1CQvMykV3oBM6SEBFmI+GnkzMntuFBzpA6oVlm1QH2+Bcz

LhfhOX46s1rlRpC1m29zEVddUhEfhB5cjfzkmzt1PsTdCX8otweRaoM+egH10+3bzzygf2AhE/z+RNRKmha8tjOG8vGuW8tApU2VT+C80vY7ljyQ48VQhuKW/mH6F/QfVNyxA1KvlQ1L3eGFN6yh5KsxUhKJRZ7wcKKSpgAdxQjc/gMuRNcyyVypJypeSvh+4fjUVpIXggueVT0hRFH+YWMDhEWJ2Wo73MJYuOMVMqOYJmoHMVpfjYJ4FM1IVilt

J3gS6JM4lPMBj34J/VI8JGcMI+6FOyhLizxROXxwpeX1PelyWRCV3DJ2y9gSAZ4PIpNc2fB76E4QIy16xf6HFSFnmYpQAM2VnOm2V3FNGhF/jHJy8toJRpP/Jg6MAp0EMmSVyqWx/sTJg2GUcJR8rtclmggQ6cVVxWL0+VQhLUpeXgzYZ7OfhKZFDpohVdI4hRSw7AMagpO31gjUBzIUVVe03mTcp+xQU4wcB5Vdom2wAqqFVcE1FVRwyy+3FnBx

lWV/xUyN62HDg3BdwpZJ4OjZJIVPYVYVNMxCaP9yEAGwprgOxxpINxx5IJwRyBNk+NUEyCT4CMAUUPqhgwJO2kRHAeIpj74KQCV2daJ9+zcKkQ15jJMLaI4pOqSGhbCO0V2KtMCS8uqJK8rv88AIlxQFNJVIFPlR/sVZROJEkRMFJz+2sVKMiQAuFjKpqBzKsGp+yQNR0QWDaZFVGC+XRtq6QTMo6Y20RR2B7qmYwq62Y0ja4WASwEWQQO1nFmI9

nHCw/cAloVyATBVyEM2/oCuQ2gAohdNNBA4xTHKngwyGTFUSwK63Axq8Ca69FW1geY2IAVYhI2KziuOD4sTo4xWSCqUwRFU6TRgZXnqmH1l5AINEE2Y6w/WpnBZp0QFiCMv02MuctWFNvSuQRojuhXXH02uHIAl1+xqRZTliCYQF5QY1MEq0YkJFvoCXSGXCa8x6R5Ah3R6RbtGi4c/OdA5U2u0NG0rVCY2SCeXXGCKYzjKDau3FqbT/GCwV4AlX

RoqHav4OkWX+40iD7VqAAHVwhxxoTZVHVYHAnVW1A7W06oyws6ua6C6sFpy6t3xa6o2CkgC2Cm6puQ26ro4u6oOC+6utBYGxc2Lm0QV+x3PVJ1TeQFWGvVcowy4hIHvVAQqMOANmq8KwvvZb6o96n6siGfrV6lv6uR4fI2OcgGqE47U1A14Gsg1F3hg16gp6wy/RUyiGruQyGrK4qGpkK3lKDR9JIYVtwoCp+qqCp4SXAJOUmRxJquPBCaIaxvCp

TR/CqFJ8VOsKiVNwRySr7wqSvpsRSQvJR21fmvcs/+y/ixyuSrdhivAKVnv20JXFJGxSpjKVAcN+R2yzqptRKl2tStnJlyrTVk1xjhEO2GUN9AE0XTxEwqiFwyNwO2hOqJURHpKGV2KKyugoHgJeFKmVlCBmVpzW98FyMfBmSsiIiQHVWXWu9OEflu24auOgJWqjVM0nLMqYCzc3aOiWlWtSBxypM+skLOVjVJMVDWuuVs81uVLWrjhXlmVROarQ

hvyigQBiT/O58tHCQFxIBWyk4mqiFG1kypBVxChVg+gBBINwCCwNEKTR7qqaxnqsXkyhDUJg0H6gm0A7cUyxKpZVO5xG2r/Bg/wFxRhKFx+iv+RhisJV4uKHRKavJml2tcCRQOQoc0Fpms8NzVyuDyQBVMg8SFLdJ/WtcVIxK1xkgklV6zW8w9UHuAMqrPZarH5VUe3+MOZENxarAlpJcu0AcAFsSEqrmFSrE513OpI8LQj51jkgF152IcpFvKYB

d+Dd64usl1egLoVOcRRBQBK3BahWLiOiyC17JK1+nJKgJeexgJ1S3AIv2psxWCIpBSVJpOPDWDgDyhtA4+G7lFFNhVvykK1YP0gcPqniAVsGh+KKoFBiM3QQIauFBIAJ5xkavR1qwIkh42L1JeKoHhJ2qEpdWqapqapJ1LRMvYwYFDUgQU6VpRX8Cyr2KYEDyLV+kJcVnhM1xq6LW8PmSMg86wiajNFDouAFeQUtPAVHThZ4JJLUAlWH+Mhgwm4a

IHDgvoCdggNIm4CDRPh2YCCw+DSH1BHEJFy4FdgcYEvWg/WBA3F2m8rrRVGfol+MmWGzAAwDWwFWAIVgEmwAm3GrapXU6GTox8kd0DbakGLnqglRbpbMONACAAAA3L1NHaYhwBKigrXukNRAUD/BLIArSQOm4MrqAM1PADv1hSqM03qIf0pSsf1E6Kf1LqA/rj0mFREMXBjfAL6VuUDSRPhgqVCSsuNvkCRttYMPAaJv+pk5DRsa9a6A69cR1PGj

lhm9bozMOO3rSsNz9u9brBe9f3rB9UCth9UFhR9ePrRGYwap9YHBZ9fPruqIvrlasqNsamvqtgBvqt9U5Rd9ZagD9T/KM1vLLPJIJjfJOfqxMZfrfxNfrsMbfqH9blyRmXpIKGZCc6qj1NP9Vesf9X01+SgAahSiM19+iAaJSjHQwDVM1IDU9BoDQvVYDQWV4DW/BdGcgayqg2hwaGgbR6hgagjnGBsDXyM8DZ5rddZD59dYwrgCQFqEcb+kjMaF

qZ7lbqeSUfMv0HbroQiNlRSSIqyoUlqpFXsz0lelqPFllqJ4O5YclSwo1lY2j0IecwmEWtq3gI+5StagRytV+TDlT+TDSeBD8decrJcRnrGlQ7d2CRcspKKXJVoeliLYJtDkhBOAN3kpT3tQR9PtXXLRCckJEjcCr2LuIrktbMrHyhkqe5VkqBUjV8ijWHro9IUqdPpUbNtfHY83CL4E9SRADtUHCDFX+SalY09ztc1S2jfKobtQUxkvFa4KfucC

VJiOB8/kvC+nkojGdShSK9WhSvtfEaXMZarYqUKT3fMQBGoKFgLADGFPdTCrIiKPEfCj/4UgMuScSCGtiqWirNjVHrtjbHr55W18cVXGqcdVUr+0anrzjRcrLjemrvVthFDHj0bnlXMQhQPZBLtgzqcIUzqvjayr8nPAr2dRK1vJQg0sWTx1tsPaQFtPrBL2lz0eehLT5PMtwtda9jLKWzrpdVUJ/Ieya1WJybX2ZMFRCvyxwoXg0dWPushTQMAR

TbSTNVa+lfNaGimSfMijdSEkTdVYCzdS8KOFfGiuFYJ9ZiFMb3AckbhFaVChJuNrpcIkBDUDVBmAMXloVVeTvdeDZBLkjdtSEkAQwLMRnstXJe9mzirGBHr0VbwpecVortSToqsTXoqIor+T6qadr15fVqiTTLj/YtrsuQeqDpoDUwVgC6T3jXSbPjV8qxjUyaQOCJ0qnG9VoTKuBGAHSNyAH0AXgGgAeRl/j/hl8MV6hyUJusNomOIrggUA2IFA

FtQJuHZwcaK1Q+zdCL31U/gIatCZouMKNbnGqMtOq2zIXClhzRkV4gBrWbqSolyDOsULgUDeqUahKLdGYbTV6ifBUkEgM3mgRwPufAMmuAtVPRk94BvBcg5ON2JfOHmV+kaNLjsPLUnmpAMXmizDGBvWUtqJ4jouu0N+ym/SgxuadYFWKb9RADVBRpybqzbkMqSvWbPGk2ba8S2bvurZR2zW1Foyt2a4AL2b+zQRxBzeGJeQCObV6mObSuo84pzS

DURRqGVtOnrSoyoubHRsubYOKubamtqMCBnrRtzfKNdzapl9za2hDzWZBjzTANTzVsdaRk9RLzSF1ZaqH17zW1hHzYhjzES+bRvG+b5iiNwsWjZxvzavV+1oGT/zVS1vjnN5gLWqqvKUEbpkTcLdTXqqFkYfBDMRNFICSpZTVRabqoHZBrTZgjbVdgijkUkrHTdiBJtdT4sjTNrMCXNrodU+BctYUb8tX6hfdb5jtCd88A/iAwg/gcqjjUcrqtdU

rkzWnqLja0bWCfBD55stj+KNXJKdZ0SaVa9h1krv8nFR8ry9cWbHgUNqJjbytG5eMqAiX9qZjS5ag7NkbepJlSq4Z2xVjX5aNjUVrW5jq8hTtHwM7OUqVXJUqE1cNcgUSxlRKZpdM9T2YwKTcbG7OiRhwB1rEDAtAb4v0SPPgMqR8tGsXppoAVgDZab/jvdpBJP4AyDcA+dgMDIdZ4s6ra1ikbvBh22KGpv/g5Bgisibmrdq8RbFVSsdTVSEzQ0b

JyWca5QXFbideSrvVjnqJoNSqNseApd3IMbwwEMa5rSWrBlWWr1KcyaJTTaA0AJY1syGqxAqldphjIX0oUN0UUsNObNAKKagOeKbz2a6RIbQn0YbbrA4bcFUQ9hI0kbb5gUbaRb6nGDiQfPoDJkdqaQjX5qmFQFqjTViC2FZXEzTdbrhtbjsYlYCq9kXFrYQikb7TeKt/tVVBxQAlwWsAkBf4MViIdRlTKKVXDi8IZ4eEH6b4gLZBstPZog1eHqF

AqGqnydziyiVUb/nhwjdFdjqHrW/cCVc9bw4UTqifkNaFdun8cMjMojHlYrsIirjdsX1qizSyq3FWDaQONh0vigCUqxEbgxAHfUpUHh1uxFlgY4FCVYmmOBYSvdZSRkk1Krlz8TRJ+IBppOteWhnVbiMOr/IBxrXimHKp0nDkHQTobOtLFhxze+U1+t+tW0M7RamptYqFU5q9qN5IWgLMFRRZ+jPZS1RCmoQKgUJmskpn6IogO/LBKlQq0AG/UMa

CrVRAPyhG6Z5xULWBKIJdsT9Ec6BYqhQAqSTQ0VNoJU7kCzRHNsek9xgKgkaewAaNp7b3BmIsfbfdA/bc6AkSriMsqMHaaJlFQw7RHbSOg30fJHJs47d5IE7S6IyuMnaWwKnb8Kn6J3GhC46OqpktxkmA87XoBSul01jqMXa3kKXarqsx1N+myUV+tXaHanXbB0g3a++mrRgUHfhsGe3aMFQuzrkN3bTMn3beQAPbDjMelh7VnVR7STywGXd1BvB

xIANDPa6afPaSABCUowcvblamva+SWcKA0Wpi/8fQq6bQZb/NUZbI0YaqWbe1kwtUbClrdUBC9lzarVQIqbVUIq7VQ5bRFU5b6QE7wHkK0BmgLijXMYsqHflBTodSsqkbveSArMBAUdeUbe/v78SlQq5+3q61vZkO9urfirGjabbYsQNbTTJbbiciNbV/kAQ8oh/NyTRlb3QAjt64SZc3tX9lmddfLhlYrNqgIScxlZISyrRW9TybUA5HWiFptQs

rZtU+9VHVXD1HX7rNHesrrGJ38w1VPL3gHo7+/jsbWVMP9GyJ1aYFccbcdacaYrQSaWjW9aErYljRrYb5UXmlb1sbBSSjPeZ4KTlb+lcDaFrfA9vtVpaLVSVbgnbhTyrXbxlADcBJANGIKACIB0cU0qS0diEc7mo6iikjcMiTeZ7XDNARMIGrkdRGbBoe2jsnbJcF5XGbDbY/kTlSbaSnS9bCTfFb0zd6s/8BGAMAU8rXHV7xSYGGATHl479dgya

3bWyq5WOPqWhCbBuCnLr34fICE5WZSPKUL9cwZUBXnUbipFp87dYN8692TpT3KR5T/URaxdLdqrCAmiddMUNt+HEzaYEUjizLQgjzTcbCrLeOdunf4Tenfbq7LY7rEtdI6IACCQjAMPBCQMkBYlJZFdrW/8pnVXCBjdUl++CBgcFvxQRQshRAAQ8iOIZHreyTraNnRor9bds77rbs7jtacr8TYc6ynRbb3rVJTe8qb4zgRmdz3MXhMcvmbhjd47H

nSzqq9SBxlwORrdGe4A4sAhI02eYA0AJRq6yj9ytqEdx1qLhbaRl4NWqsvq1OiqMnWt5xI+aENvWhEMevPoh7uOk0bkDVAv1UwAHDWg6wHZYjPhvQ6WKqkEtDnmkzwIUMFxL+JNDb+Id9euJKho5IC2tV5C5S0KCpdOIw6LfqY3Sg6j0sUdPet2yxnJTxquGPSz9fJtkFbxIxDQHV19fPwRDTNgNjhUjFQJcTDETRsdXWDxIss6D8AAa7n+WjyTX

V+bzXVUcrXVFAbXTa1YKvwaUxE66QqC67EsF60cKg5xZuB67QFdchvXWDQ/XfpRzAPdwK7YUiQ3Qxsw3YlgI3etZo3SUM43STQKhqkEqhruJU3fpr03X0zM3U0MyuCZJc3TFx83VthC3dLBX0XchS3XWby3bt5v7f0M99YLShDbW7wkT0VbWU27AJC27AjVqaTpgyT2HQzbOHbi5MQWi7o0dEa1kbEaHAcNraLv8rMcWVjYtYIqM0fzas0Q5jSXb

ManDk8Bu8Io7qFG5ilCXE76UUnkfCkk7ije6Aiiatr0nRGr1neiaP6Py69tXxTe0YmaatfKdYrUc7ynU1rrtQ47HwM3oG2Pnrt9otlXXnvtVXUDa8ra7bNXSIT/HWRSgnfi6gVWDcOTE7wyPcEAmye5bFCYlA3wAU9stfR6NHSoqm0bydWPeoroQJk7c8vZ7qqRKCDScbaLHcdJpySmb09SJ7EPs1rxPb4VFst9b6nQPBclEtdEgAp6Gfq079oT8

rsdt0tVre0DSXWOA0QDABBVfOB0CBCaVHT5izPRvs/dRsQ4gEs68lC29EfjZ70iOqSdsrdbe4bx6k9eKiU9bVrSnebbX/LY7REY78jBPdrD5T9b6YNXIrYGsBBUvc6ubvlavCe7aJAIAB50lQAI3pG99MOJtkgGcAPYEyAnAAmlr1BcAnAE+oYzlOC6NoBdw3tG9m3om9PxXUA03srMK3vm9YpSW9MdBW97XUptfd2XCJTD0tWmN1VHDoNNiKJMt

901CpMRt1+EVOWtHlP+NuHuaWvNu+mdpqI97vkwAJwquAYwCMo6Xpo9mXryNDOz3OLhmmUfEL9QTrxRNvZPcsH5NDA5Xp49uKvjV5jqetBzrNtJKu89KkNs+qL2fo2ara9QXqDAnt1SxzTrVxSntLVcBX/xlQHyAaIBLYvoHuAPh1CmBBEBQnsCM4eHUioaZAA2Uo3hqlEoA2zgDmIstK6QjPuZ9rPvioX+s59vpJ59rTn59rzmlG6VDG4wvq7YY

vo4AEvpZ9bPpl9ttHSo8vstoivthqgvtV9IvrtAGvq19UvvZ92B1to82AN9fPoF9eSCF9J62BS563F9cnB8OqWFwtXmGSEvpIm4mAAA2G0Dgw+gHCwMAAA2VwnZQMnV+SdoFjK4vqCwpO39IPhwv6VpAholhrlKTyECAqgGOQnjRVgjDzxhDXEt9Ovo59ttG59OIzGAvPsVgRvrk6zvtF9bvs19TPu190vuL98VDl9Zfor9VfuV9zvvV9dfsL9Tf

pt98VH19bfoV9jvpV9ANmF9Vcgt9Dfqt9uvviodvqH9hvpH9zvumgFvo99+W2zA3vrKSAZVQAAfqD9loND94fqfgkfsaSMfvY4cfoT9cYCT96dBT9mgDT9MzVXt3F1eoOfrz90UNzoEyKRcTyiu98Lv62iLr1N4aIQ9oBKQ9iOJQ9GLu5JGHomNS92EdAJu+9+HoSphHvsxyVJjle9Tct0To8tUROwJ8bHVWNSTlyRBO+SjSQ/BvZLRNbyMH+eeV

8YOuX2VwrolBuJsEptXsld9XttSjXohR9jsQhX/lWA2u2zN/gXz+4XucV9Jv69letU9MXuf9UWtKxMWuaWCAdkJdyUWNgQJy0stsOtfuvSUgC3qSeAdAwvZIMJ972jNQilUD1BL+RLnvF24rpoDuPrmhNjpldnRuACrEOk9Kc2Qo7kWKYqhF69KlI1dvjsKt/jpiekAa+9l8xpOccEtAszE3cm7jB9xnuwifKUjAxTFgwGxGDA0OsjAYqSFAqGiD

UEFGtA2+TzEUCD0gyu0vcnKJY9pwE1S+AeeR3HqIDcerGxlRN6uVXoEpNXsE9dXrx90ruJNbbmmgipDttOJAnATCi1RilMU9PAeU9DgaOx6AADSgACRd3/Vb9QZoogZtnp+wIAfsy/qsyGB2TNRLC2szIBuGn10UOaHIw09aiLibupbpOakHmkWGww24i6alB0swysbfraanQcuanfEiykY2toOdBww3/6wUp9Bu/2lyhCRDBtQ5WGsYMVIiYN9G

KYN9iV6izB3DYLBkGX6VTi0rBsWFrB0+iKjTYOXBbYNQc/4XmAfYOeUkKTU29/1aqzTE6q1EF3eq6bG6x73Z7Z71oe172GFaoAv/DT27I+JU/ezwEOq/ClhIcSnUKaUk9ytskYZUVRL+RUnJOnvQ6Otj3HQUr2akwckxmmNUR3XGY6BvZ1uev3AeeoT1Su4LWtU0b6Q/P023se0m+BL26MzLgO5WpoO0+xa2s5Kylg5HTX5y9YWFylWnFyhoZ7C0

BAIgb7XUorEMY5fPDHkrgTJkgnKkCux2E/LMk4yHMnvAKnJWh04WqmIsmM5Usms5Cslc5cRi85fnK2nWOqNkloD9A0DTKO47bZ5CXLyknKlUhpj2jRRH3lU7AAJAc0DumgV1RFCMNRhrQNVaw3Kue7H1chvq12TTeVoLG0MSUq23iiZ7UXOjO5YWCMBQaH9Al6p23IUnOa8B743jG/x2FvIQMCkgqFjaoW0fQVy3nkwz0tk9WJ95CXLmexJ1dknq

GPk4r17yOMPEAaMOceoWxYQHCDkBsXx1G/in8e6K0SugwNxY3ghZh1qm+e5gPEwExT5h9D7q7ML0lyN8AShlp00+kG10+yy3LWw94uBkQNuB2v72wG4CaAS0DZgHgBE8XwODQDhKeFdviw6xIiJAFlGRgTyzTAlil9Yso10hj4BDhkcPZBjE0Y/Kok4mnq19fWUELh6x1hIZcM7ytqku5GIqtey53te3cJ2QdOZFmWwOXytp1G7EHLzYOcRBYbMC

0LAhzvwtEAFkAgzx07bAekfvUnaJ0iuwcGjBwF0jOBwDnrehAqER4LAkRlyFkRhymUR8UDURlLC0Ro3H0R30CMRhzAsRxE7Qe+PYAEm71wh+D33erh2AByI2mWlENck6AlxGm3XCfc8OCk6ANiOgj1/e+APuhlKlHbOl2QzM+IKTWyDqCJwzWOS/RJBkwRAA+r5pO2z3HQCqmxFLFVCu2NXxm0V1SgvQPFB2gOlB1/wIRixVIRhmDCuPAG8ZLcOV

MAqlBqTEiiqUvV7Yw8N4R9REIK++V3dR+Wv6l+WTHFB2d6z+U4Kmtq/y9RpVuohX5g++WkK1TLkKz132YCu0LCn3Toiy6mHIdnVmNblXLgXlXrIflVwTRVUiqtVhiq44azGjI3ojFmroahIaYapMa1qu2r1q2YIOsptURpcrrEattXVdMjXtu7tXmcXtVscftWolIdUMa6IZjqmdaTq1jWASLIDt25oJqAbjX+QXjW9ifjWCardXK9e8Xiag6gHq

qTUISGTX3yuTWAoC9WKa5TWKdVTXqax9Vaa59V5ytYXegj9UdONd3+tMrhOHP9VmazAAWa4DVgmVBo2ahu2N02DU/ISu1UHJDXtUdzWjaWqMDRkhocq5Mg6lZbRy63nW6wfnX6wFXWuUnMii6zXUS6lUqTawSV+iNkCEGokYN6+jhkGiqNt6mrhUGrvVxgHvVT6+g227Jg0sGifXsGmjlcGqg7RATP32uoIYpiQQ3o8TfUgehN2AKiQ24KzGnSGk

/Wttd/XdrZ0VKG7bkqG4IBqG8rbP6soav6r+26Guchf6qwAGGzfpGGwUrDNPfoLe8ZqWG0YMn9foP36xukBu7qhOGxA3XIVw2PB1A1dUdA18YrA04G2FBeYHGMpavGMsmtlicdaU26wWU3+weU28mpU04TFU2CmgETCm2mOZyjI1mDHKrlm85yVml6g1mifo/iBs2rUXkZmx1s2jaFC1Z1Ls0scDC1QAPs1b+nC3Dmo2mtoQi0Tmqg6o28i3zmqi

23NC0Y3NEuMMWyDawuZi0qa5TqKjPc3oDH81vILi0ugHi3jcPi3BlL5oHVIS2PeGWo3m0S1ZUB83/cyS3XM+zCvmiAZyW30oKWs132cZS1/mwqMAWtHn/eBbwRx+Y1RxiG1Q204o5kAm1dWIm07ev4rXIMm3XOCm3Zx1JUxjDPqb2y1rb2hlkGIPe0hUQO1H2kO2n22vqR2xJppUK+2x2q3F32u6AP21sYp2hjU/6jO3v2mbk52/4Y/2gu1x27po

ISEu01NEB2MjC1poxjko12nsDQOmpHZpRu399Zu2IOnA5ZDaCQ5R5tboO3u2PorB0GuuEy4OtsbgnRZxj24h2T2sh2L4jtaUOxe00O3cZ0OsTn3xmOokNIF3vO9ZCgu+KiGDH51QuzOUROzLpturtWVIggDduo11SDATjYtJS2Wuoc2XYKCogjDoLju2ZyTukunX0z1rYVcIbzu3SiLuwsbLu1EqruwzWexrd3BuyYOhuhNrhukh2Hu7SS4bE90g

0M92biZN0mSK90fqm92cwO91XiB92sVRUZ5up4Cvu+O3vukt1zrXoY/u8wB/u4qOAe+WN1u0D2NuwMSrwIaW1R3RMISsb1berQCfxvb2zeg6glIx2PHe1GqrezOV6e6SASoXICVoXv3W+zn2l+nqzt+xf2m+2v36AcX1T+ov39+z2Ct+sZPD+pX0m+sf2S5HgCT+yX1zJzn2D+pZML+lZNO+yZPm+nv2zJvv2c+uf17Jh30HJ0f3uwYX3L+nv2r+

r31RQH30zQLf07+4Ch7+1ABh+iP3Q1aP2x+zX3x+rMiX++ZrRQVP3TNM/r3+rP1FYNAC5+npOTHcj0kNDoNdB22PB0c4MQpy4Mgp4YNvM4/rjBlA01QaYMvB7YPzBk7rfWRYOfB2ePfBxLC/BvRj/ByzhbBhCQ7BkEMeizOWIB7OUwTTiPER0iPYFPiPTaASPGsGiNpkOiMKtMSMisCSOtRmlAth69kPVc6gq0xzJEAX3E6uzMAWiQFCUTJhqpYd

jFqHKYqzeaFDug2UKpJmrwned5j/OzyEQAVKNrpYLa/u5+VoK7KPvyrBWQgfKOldVySocEpPAKsqMFrDqjJ4qBVMjWY1EcjEVG0fGNSqi3ayqvlWOSTqMC67qORVFVX/x2ZWDR4cTxjEaOW1GtWpBW2q4aqaONqgjUtq+aNFBdtXLBZaNmJqjXrRmjWbR+jUtgRjXjq/aMqbNjVHR3CTzq9ThnRwCSrqy6Mbqm6MQuMTWNBCTVhiJ6PHq2TXb0+T

XtcT6PhYFi0/Rw6gPqlnhPqjqovq3TVDYd9XDFacS+tcGMF4gxBQxo5wwxlnhAaqwAga38Rgap0i2a3zr2auDVoxlzX+2lDXYx/qOpK2/rGVANMc6omM86qhyK652DK6oXVq6/dZi6rOOKJhmO4SJmOcAIg23WRvXsx1vVBcJ4md64Fa8x2g38xo3EMGrf0j6uOCsGwWMcGmfVDGbg2SxpfWo8FfUCG3CQ1uhWPb64qMqxgqNSG9SoXeTWM9TblD

b4X7joHfWPux9Q3GxhKamxnQ31TPQ3f6jjUnB7fomGh2NilUA0uxiA1uxuw1FYT2MSspTg+x2cj3QPFMxSoOOYG3w2hx5OTRpkVpXjaONSm4iMymjkZymnk2Km7Cbc9XCaqmjOPqmt9Nnph+P3DQpwCjCs2QWu+qrm2C2Nmg5wIW39pIWr9EdmtC31xzC3Nx4HhWJwgD4W9uP52oi17GEi2/x0Uazm0Fz+ivuNLm9mormoeNq0Ri2bm96zjxoTb2

MoMVscZYOOjZ4ybWCbhnmleMXmwFBXmjeNhdW82NYMS3DwCS0FlKS2ocQ+MB9Y+P2YU+NMDGePGc1S1Xx9S2AWzS3SZpLqXp9nU426G3WNbYbrtBG2TeqRo/x0Gp0xuY1KJ/TO59XGhb2721gJpTbbAfe1QJx6gwJ6Erh2+JrwlS+0x25taFuzoX3265CP2raOlp7BNv2lZwf2/BOz1QhN/2ou2kJoB3kJhkZNIqhPgOjpqQO2u2Freu2MJuB1at

Fu1IOmtOcJru3PFHu1CATB0NUfhNSoQRO2Zgh0IAaE5iJ0h1zUch1SJ38QL26h2qZWh0Z+hRO6ZpRNx1FRMgumVVfOzRMQuuyncFWpMDNPRO6uwxNdu79YmJvt3mJgd2WJ6102J0Ex2JtDMTu1BoBDad3ZiVxO4tTxNeunxO+uvxMbu54wBJ9ag7u5Gl7um46Ru3iQZtXSQv6092Ju891xJy93rBa90F4jN279VJO+x9JOkbPuBZJxLBvu4t2fu/

JNyGwpNttRs0BSAD0rrID1YZx3oNu4abge6pMZcLHPyO+pObe8b1NJwmi/FFpMHe9pNHeiw1dJs71wpgxAIp/pPzumZNbJs5Ml+g+3l+5ZPG+w5NrJqZM+5xv3DJ22iLJkWjjJ65Nd+jZMnJ33OR5gf0B52PPB5m5Pigcf3HJ6ZP1+pPMz+z2AXJmPNB56v2m++5M55/ICPJ9f3PJzf3++wP0fJkP1fJg/2KYI/1/J0/0Ap8/3Apy/oywMFM2GyF

OP+mFMtYd3M4gNlNbdY4M2x04OopvIUXBwYPVgLFNH9LbC4pyYNg0AlPHIV4PEpiSp0dMlMHBL4MFS4QZelGlMogAEPh1BlPAh/kXMp2qOspkhpRgJAqcpniPcpvsT8RwSM9aIVMdCEVNMRliMSprOUkNGVNNeOVNgKi2jYICMQLVVVNS9bMAapz9FapjHg6p4awkAb9Z4ITzpzsOX64CbxJQh2m3rg+SNhG//0Dy5uisK54Woe9SPoe4UnwKu+X

mpjKNWph6A2pzBV5Ry7yqx4LZFR3XPkp0qOeu//PW4yBWUK71NO8X1MNRqtBNR6VXBp9qOhpwVXhp5VWpdWyiKJ2NNxjeIY5dUaNJpwroTR0bh4aollTiQjVZjbNOLR3NMGJyjVrR5gAbRwdUlpkdU7RpjUVpkaZVp9O21p06NLq86ONp8zhXRr2otpndWn0+6P44STVHql6Onq0I7vRhTVXqwdORZtTUjpjTWUS7TWTpxUPAx2dNgx4zWQx0zUr

p2GMbp+GPbpiDVIx/dOoxy7P7uzWgYxwIBYxsQvw5i9OVoK9OExrnW3phXWkxpXXkxp9NUxjXUS8EU3SZj9OeDL9McAH9NbVP9PNgcg2cxoDPUG0DNb+vvUQZuDPxUZg0wZkWOdFzg2IZiWO8G6WNY1WWMYZg3PlJpWOEK3DNH60/EyG0/Xfu4jOKGj6HkZ+92UZo2O9cF/UXeM2P0Zi2P6GpjPj5ljP2xkUqOxjjPSlYlm9592MwG9nOqcb2MuG

o3AiZzw15pbw0CSPw24G/aTVFx+NY2yU1smhTPxxpTOJxlTN8m5U0ENdOOW8TOO2JerOZdfOPVOYzPFxmC0dWczOOdN/XvtauPeSWzN1xns2NxrC3g2Id14WtuOxI3+2dxrzMSdMUYUWqLlxUai1ulTrj0W0LMjxpi1bmyLNsW7lAcWilPxZheNb+5LMCWyFBpZ4S2bxu83bx8S27x/LP7x7zAyWo+M+lUrMMDYnPnx383+jNS2o8v7zWMO+Pw5h

rO5FprPPxxPqw2tdrw294yI2r+PbYVG29ZjI2AJjEbeNL210NHe3gJ8bOQJsv1B26bNn2ubP19MkbpURbOCVZbNQpkiRrZjBNP2rBPp27bN0cXbMmiXO3rYIhOclAB3HZxfr0jLktbu9ppV2g6i0Jh/EtAGB33Z/EqPZ1hNt2l7Od238TcJz7O8J77OD2v7Mj2/xmiJ+LJhJqe1g5ue0Q5qh3hUWRMfdeRM8ixRP9dYypI5j50o5sF1o5qVq/OnR

PY5gbP6JuHqdu4xMhC0xOmu8rODuqxMju2xNjF9ToUARxMhDGd0M5911up54wru1nO+tfxNBurnNBJ3d0hJ/d1hJ2XBHuyJPC56JOi52JPGSCXPqtRJPS5292y57N2PujJPPu5XMoJ3JPq53ShEGnSoZRyt0MF6t1TFkD3+YMD1VJ/vr2YC3NohK3MNJ7b1253b0zex3NEAZ3PLew6qkAXrO9J+04DJo2hDJ/POjJovP7J9PM1+6oCbJiPP556PN

CgNPMl5tZPd+8vOnJ5POewXZM4Vq5N4Vo5OEV6f3N+gvOp54vOd+0vOu+8vOV5jf2++t5N154P37+n5NR+iMD/J/ICApxP0+ukFPd5m/3gp4GiZ+/vPeYQfO1R1Ctx1JFPMZnoP4ANFOXUGfPPJm4MuxxfP+x/FPPB1fNEp38TvBmDnLB3fPUpju2H5ulOAhk/N/Cs/NhMzgvDC6Bocp7iM9Ce/MUR3lNP54SNyA4VPiR5iPiprZCSppYWVoH/P5

ZeVOX1QAvKpqVAgF3IbgFwdKQF/Sr3AXVOwFhCTwFw1M1y61Unh6oCqqrp30XJuUJa/EOkumAAwAGFBnoRWBNAxrFuFTsMt/bL2DykMDR+qBDKYKk0JBnSYTysMPc44D662hR5bOryM7Owm6+R/Z3zhqx2NEzMPGB9P4VAg+VoRsn3axKIiF4HCPzWqL2DeizAiw++X3cQxCvrQsEJl6cQDYPACOa49LsACLnUk+daMAOKhRhW0T0AZgAUOX1qWb

OmG+bI7jOAFMrkAcGOAoOTjIBcWSIK7auPQXatcbG8AHVqzBHV6DUL1U6uL4i6tYABzASwZrx3VwzWPVo47PVpgCvVrsDvVw6mfVxrBpxQ6argnzVsOgaJIu9EHXTJEM2AkAMaRsAP+Ol746RhsPG/Il32qluViK6nzAza4AGAWRWy4XqS/zLsOZepfyWe4tQARlyOY6mMMDVzE1DVkV0jV0XHjV5NWBR21LBRpyaoA6aD8UFCF1+EUO4sbvaIGJ

8CA2iL1JRtatmEDxWd4fT0s1/QDNAMFDkk/xVizIJWSzNcqrfcJWRK+I0G/HSNxKvKt9kc/COWpsPYganyZYJoBHVhYKSB1MwNVhSat/NiGkYKr4BWD36CQ9imAR74CRh4cMhWgXRGOtTomO8HWFOqgNFB8m4BRwwPwRq4362NcON2AtX2kgsPfSOYhzKcAj1BnLHU+qUNHhxa3fat1XYemKmuB977eAj2tWYKq1thy8l+hiyN1zF35vvRG4hhn0

5a28o1R1+MMlK3ZWRLCr3fkmcOPW1eU4+iasZhzS6y1q7WJWlf451r/CzEMk0Ku3o14ZcOKcuzWvcBl23Sh9p3xG8/46hkR2Ammk5xgF8gIAMcD3kRqBYeqnEeqk3zvzTIk38WYjAUeyA5LKYHaTAKxALZyOkkauR3vXKFC1wWvo+7E1G23QNjV/QMz1+pVTV8oMXLWnXWKyKOU/R9gJIEcDtKneuShveuV1+B4DqSxpewLiNcph7F+wNECmwfWA

BSkVjwBJ/pGwLWD7iX5LsoOKgbQMYAXrZAI4Nv2C357ysENvsTEN1JlkNhqAUN43HUNhhvb+qpg0N870faOF0whhF0mA3/16YrRaIh7h14FsmuEF9ENOA4+tQB0vbvC8R32WsUmu1mY3U+Q2v70eSC+1jsOwgYIGvvdva9hsM2iqfmvpERz39Vj5H55BMOHatSBQRwmYzQqWsZ1pcPTV4ZRKu2p0Pa3FLJCD9CfAHrVoows0Vh5oODa/gOWm2qt1

hkqsTK0J2M1/wgSwPvDKfB96KvE8zGNoZYdkwKzmN4NWWNn+sf0BkNo+g40Y+yCMyQkm6JqrIFuNxcNpMeeuk671YD8ZfzTonUgcISLQJR522hN/et4vGx5+fKZ6BvTb44yJ7KBfL+KKhAZs4yKXIRvdb6RvIUDjNgL6oPGN7zPSL4xfZl6LNvC6pvS77pvZ66uhbl48xR75+PdK73fJ7426wkHU1/UMJPdh7ivNa34U6oBXQJ3YJqMyOe8Ltj4E

kYFt7ZkTAQJW3jLWEDE+tQJy5f96rO5RAFNjyODV1kN8eyevlNmCOQNqm6mmGptZ6qIRuRPokINx43rzDYhgFCKOtN8sMn7Es3QBBlhCcTmqa0KGtXV2Gsubdn2Rgm6CRHE1NUfdjWguPFsw120SEt7o4ZFmCB0fMRuyR2EMG6iBGKR3WFyN2BFqRy3VohpBHVAKFUqN+usIE200SOrRtSOt2v0ganwEHPwj9J2EQsneRXKYF57WRyoi+3IDArar

8HlGiMDjhgBujh737m+5YAj0fJ1fbAoOzhvE0QNyptwRjxswN9P7HWnPXToowTYiHbG9atFuFnAq0RNqy1EQvF3YhtoHu+e2CYAILBcsG4DOwA8lS2yGZuRar45Um+i/JOZRq2zKCc4nquath0DYQHVugR6NWeRoFsmtkFu9W2bGME6WvhzKFuSUi5YsMRZ3TotfJbQMdgrVyL2Zw9asQALn2/JhhvhYRpKMN0lv4w9AB1t0SsN5ptsiNiwGIgjX

qf+8Rvf+yRuGW9lsABx4W4FrlvGql73hU9EMptoqv4onp1ae2y0aN4l1lViVtVAKVuWQU5qyt5k7guWeRuya0DqCX/CBBJwyqtgZa/N2CBat5NsOe/VuGtirUVKxMNFOpM2S1wnV5t6BsnO0GLcJD/7mB7cO/Sb+barStva16tvVhmL0/PT70XhhuvbbScqIgEtjDwbADBEp8NjQBl1B+JaE1fZlFw+uNu8u58lJt7bKFNvIOiozNvJhqevPt4lX

uN6pueNlvhymclFGPF6TjQe0AMqssMfG9puYN/CNFsX0n8NztvCN5AILJmoY0NxtucdxlvSR/tvMtiRs6YqRvIugzGct9F3ct8y3ha/Ks5wr1vc2nEMwB+LVwBp3WN1vmabtp3jbt18Lyt/dtjKVVaIUpG4RRwBbqt/qGARy9s4dkpVkwLXK3t2o0RW+o2Ed0FuuNl9ukdvBgFtnMNxwwVJagadGwxcBAJE2a1a1iuvJRwrE26lBHFV0q0Euk8n4

U0Vht9arCBwBDuAUJ34La1DsW6jQJ2QeNtXWopUWd2dvqB0bE6kg21i1yLF46yx0Wtyatz18jvEwfvhAPFx3oRoMBTw1hT06hoOBdjBvBd1nVtt9Kjsd8LD0N5tv5+ku4ddwUC8doRsMN7tuqY3ttZxITuwegmtidomvFxXcGm6o1Ws2vh1vC7F3LW7ZEKdk+t6R9RsGR0VupGh01rt5gAbt+2TU+bTvL5XTue8VDSHt5iGenHwrGdy5imdgbEuR

vsnYdnLtakvVs2d+bZ4dwtz3txxsnGp9vmtlztVNtzsVdtf4gUPPVU6x7WBWKBA5hacBU+plWAd75U/Gm3WKOsDu6Ry8PbbCVCzMc+uUu6JV1VsNuPNq7u2eJfxRt8+xcu6kM/NhNvmd57u4d3inFN0BschlMP/dkjuA926Tud/IqLOlEj51qKNrJH+YJBraHBNrcmrVoDulmotjzYDttdd/ju9d1qai9ptvi94bs/45h0g/a4VyR1lvMk//3pxJ

4UTtxbtTtiy0rd6oBJ1udsAqjbtqNoqHbdzRu7dwW06N8J294E7u2/M7vn0URBwtieBfAOQKhmsaSpO/uuAR7CCYEYwq2Nkyg4kECOfdxPWY+5PV+RtOuwRsruQt4HsqTUVIK4uRH2gZuwAdoLs61t73VACzGCt8DsFwlJ7U+ZQC94fh4PPUpLa7S7vrQTAMSPc9uoEVpI+9wBtrA4BveR8WvFd6euld2euR961viiHpWm2GrsLV3hDBgVhjIotB

sHhpPtC98kB+vdUJeXWZtBfKZ7HXPb7zN7mInfbx7LNiK4Xfdl4JfDN43fIuR3fVL67Nz647Nw57xGyW211vhWo91h5ivc24XNkj3Z93PsZPfPv7t/y7lo7msxEb060hx7te9tpJZO3Vt5d2M2i1ygPON/7bOdpnuWtsjst9r/zF4eDAdEup3U6j7IQUB8yJ9lrvJ9oftdN/17BfXpv0vNb4zNgK5T9+l4HfTx4y3Tfuz9hfurNpftXfFfubNrN7

bN/Zub99L4HN4bVjOg3s4ejPskgsoDH9vp1YqIQAUo/JBZYd1AJdgfhF98GzqrNYD+oATS4ZB0xMwZx3Uh1ilWNj+hF5NImv91NvMh9NtGvYPvVe0PtJqgHv/9oHuADu0w9sZ3sd98AdzQBWsDuWk0C9qtsI9552VAZKrmwMgr8pirAYiBvNK8HrtsRk1NmD0bi+wSwfWD8LC2DkbsQ4hXtoFjWH02zAsjtwLXGmhbu8O7Xuyd3XtwEs2GRdtaK2

Y1Tsku/bvU+CgANgNCtyt3dusne3uTmWW3wqyogaEsvtIUGPy55ZH2IgVH1Oemgkh98Bv+R8PtN9zOvqDiQg4kIqxGPHXxhxUMB998uswDwft8t8Qnp9w/uZ9ne73kGACKwfQDEAZ2A9YTgftKj04UhlhSqTTEhzfFK103bAutXHIf3MPIcAtkWsZthQeFBpQcVNlQcR9qofvtotuwaQL3U6rc5n2Fa7QDpjutdrV0SAKenXcJYwVYXf02Dw/2TG

bMB3M3iQSoOEzH+/QDb1WdSS9uVhXDgVB3m24f15twcPDrpBPDnxpoAV4dSod4efD+XtjdqHF669Asq9/U0IhxZGSd4APSdzF3s2iY2+Ezoc01wl3Lt+mvaN0eTU+dTLuHZkEmoZJvzyeGL2RF3s6Td3sDh4JYCoqvvx6wPuVekwlN0LNvQR3/u5t1zss9qPsbMHyygD3xulFUNTsnV7UGDi+WC94wdGkYfsBvQZsIXRUIDy0oAkwbB4RfGfvz9n

Afqj7KT+PNN5EXCh7ED5L6kDjftajvZtGj9EMMO/fvRarof0DyACMDuJtn9iq7ZAdw73gx1gUjoAj2gbgdaDozuu9oDB0jjVuAR0SGhLJkOC7OQeY/Iz7sjxzvZthgn9W7YdWt3YfW2qMCAPO21/nKMBQD8UcjG4gFut05u+fBAc9NuUeEvPGRuXaZ52gFUdS3TUf8yG67JvVSKL9rgQcvIgecxW767PVK7kD/l58t2Mnhdhds82wq5JPaY2jyCO

D3kHDQ9LDyl3N+3ttaxhSZN8nWbQH1TWaOb6WwDYintoCCYd7nFB3NQOvd9/ssh+QclN0oechxnvcj5nuagVnuiImaAGJHxuk+6nVPsGJyDgfztvGtV0POysOMmzFsQAdKswF8OjZVvNJ7iJIANtgLAx+x4fPDhfkFDALBdsD4eoAQADo5N9WMqy+P7RltgKsB+OG83EBvxyCPfx0rDpxP7ceAEBPQJwJ2vBzB6dTVN3h28iO7XCTWICeiPQAyn2

Q2xaPhA1aPaa/iPJHWkb7R7EdfCMlAMQvTFUzBOA16xUlcCV6P9zt/WPe492Ax9T2Cu1/3Smz18iO1EhwXp57XrUT8Dx6FG9w5ePqO1qALHDNbrx40HWh1KO4B9mOR+xg8NvsgOtvih2RbmF86XuP243lgPfHsaOk3rTE3whV8xItWOO5LWONm/WO1+42PE3hQP6HvEasKet3VGxB3yoaFhZmMHb7yLWHxnelS3ZPKJodXf2zGJGBbOAiawwF9b8

vfOPpEEV6/R493lx3xOKAyUPFB2UOw++C2F/jsOJ4dksowOSIFcYrgUzg65Th+i3MxzW370fJVZMlz7kAuVPvDdcgqpzIUFfjTasJ/jWBtoTXkoecwNe1J3J26iHp23y2oqWRP6wyc2l26b2V2wzXaJ4k2/foxOLJ8SoWJzIEqmLwOe6+sbG6I/3LYq8i+cfI8gG0U2QGz5HKCGU2ZEqJOeQ3QH823yOXbl5ZN/kKOZPbUGlUnN9ip662BvSbd4B

+pP7HhM8DJygPcZDpOXLkEUSx7g9cBxqOlnqd9RlWUBtR2s3dR1s99Rw2OUvns80vi2PNkdUAG5e2PNPXsj3fFAAWsJaAVYEYA5AOEOPTcdtIFHNPFJq7DgKMUwETTUwiwzM6Qwy/XNbfSONA6j9g7v1XNpyyPaeztP6+8R3dx6oPeR9UOaIJEGwe+lbauz+BvLcGp9wy0Ozh7AP4ChAAap2D06p1mHjU622xZ3Wbap7P604o1PUC81OER6EbDdX

hPNSAROQtQo3eW7DOeFQNOYmyE6kjdEPDI2p2s+1xczwGCAFHYY32616ayYOqsCqV5EHPpl2dPv83fe69sHG4U72Q2K60p8oO/+zGOAB6J7F6x0b0/lOOkieqCyYP9I7nWmP1XXeOnnSn2ce9E2Iu4u3T+2u38AHw0aoM7AxgDVBE5/5PHbgKYP0N6pxh2+81gLvkv0OBR0Oy+Yh9nk3IzTHqZB8GPAWxuO6ez7Ptx+UOMp7kDm+3GO1TroJWJzY

rEG79bYfs+xmh3D2B+ypPRZzw1LZ8QBpxAGlAAIf7+BjhkYv2bBVg8G77g/LgAaUAAR/u3ciYqiW+Hi/j94ddiO2ABpQAAsu9AXKQCQAfOL+OUJ+yhnAAyytqA9AMxjYy1vSamJ585xp53PPjYAvOtuEvPXBwBk5aYfPN578Ocytlnd5/n1952vOT50+Oz5+HQQF08gr52Dl70XfOumqfO5yB4PvItJHkQarPfB+rP9MVAitZweCtez1OdewI7AZ

wbPk552P9I7AHTZ7EPLe4ihpABVcnMGSOHwagGZp278W/l3X29vIGn6KkGzOzxO1p7l2lTIkDPyWPXpw8C2Ix5yO0w0DsA52oOg55U6/PQtA6cedPTxxD3ZiLc7QCq8bUW4x2Sp/dOU+38qaB3XW6B0wOabAd2SvtgBK5tVb7m6wuA6+wv0wpwv7+L6OeF6tPGR2/2BFz3M+5ne2urQ+2U6xsOwW432oG+V2KnUwGWlVEIpwJ9kNIcAOBjYtPFJ8

13hZ20PYZ+aqUe7iOou6S780TVA6seKBCQFE2854+8Zp9IG65iIO/dStdfklIQjBLlBSeyGGuJ1TOyzDTOVx0GO1xyGOII83PRq63P0p74uIW1lOCfagCQKF1q7bfn92+Lkuy6yPPlJxi3RZ4wyE4PbBfYI1BzYPyaNM0XACHGrA4wMmQKsAFXRI8FWWI0/OZZ6Mv44OMvPYJMu1Mzz1ZlznAFl66Qll4KmRI0FXRUyFXlwKgvNYgx9oQ8J3B26J

3cJzgvDTXguOSbGjFG3y3ItaQuOx0p2KFyp2qF6u32LveQgsDo5g4OZYiQ/o4PVVApggc7O/de3wNoGHFXwck7ZlpTP4p+kREp8sPwI/kG1h6a3qA23PWl5lPYx9lP/Yvsw/0LH3kUeXPbpx9rSpyYOJAJgAKroGLAAMXAFWEA0byAAAVN1RKvF2I5xMyvWV5XV8tqyvAxUZw5xAd4NkB8FpZw1x6V40EgNryvKvKgAOV7gAuV0gVZV1V5wsAKu5

V7FykCqKuPgjC7MoJd6leyy21Z2y2NZ54Ox2/N2eHboUQh/w7OJmsA4vbiHrwYSOsVL6AjAJiRg4MuBlALfXhxzkuyQ7hxkKOqsgFMBRBTKkJ/5j1ieXQsPo9Rx7653UvG56GOcVxyOXGxIuZdn4vO58SuPrQmOESOvXnlcY2UG8q8qV6MaaV8L2wLYuBIwaZq8W9OJHROzLiMUnQgUPaNSNoKuCOBMAa1yKgmvLuI7ufZgpV3MGLDhamikwBKrg

MOsNKonQTqzPSa17PBOAIviuLXFRakaFk5xSMjhxHLOJZ50EBauDWy4/cBdNkFtcNv5glJQ6DuefgBh1lQ0W/c1Q6WxkBXcf9Qh1TVRm1i9xJ4LP6uxFgAmADxBsU3YddqKnBeWtiSjQB1QkF+pkdaerRbMPKm1xRPSR0zcZLsO6RwJxwdNaOGJBKrgAQSKCAzwF7KGhelAhynuvk0tR9wtvlsSPjrGZNmuVwsJbPhnIOlGNr+P04BnZ2rCg7dGS

hOpDkpiJV2BJi14EBS15wBLq+WvdvIhwpUMiAa17V4613KuG11psO6i2vNxe2uGV5m1XcRlHe16QB+1zKXG6RDWEJGbIdgGOvPiROvZpdOuCDpGDIDuLPZMvfP6jhC1PGquu90uuvFxJuviwZ/ad14huD1zOvj13BtT1zjRz14JVL1+FgC8zevMAHevgM2AbH17BaN04um3ib/BF11RM/Dv3Sf177U/10usAN8rLIF8Fl9U0VlwN7G6oN88TYN+w

B4N35hDNzxskwChv/YKsWno2hJsN0dRcN5HUvOjyAPisRuyjqy6yN1JHMJzJHJu61Ppu/DjXl+br3l7rOTw8hQ7V8p2+bQCuxp3EOSvr6h6F/pRnR3b92wzjPLF0H51PhZpbF0HwDzjXO+fOQSSlZQSiYEa2BJ1uOGe/iuth5UOiV9HCxPcvWxoLBot8toOIe6D21gDSamu7vWYl2PPNkdOA4vbkldGz8AW6ygGjPf7xIl7TpMm2kS6vvYuHu2QS

AsULXhFL4wk/COSL/OPXRF2A3ml37PWZ1Iv2ZzIvAlwVYB+Cq9M11c7ph1iRKihouQm1ou+A9F7BPjfQjtzSdMAP+I3TSLbbm5CvIddCux4sy6DmEGp5F3IjcnisBLreHW/MWFYlh3TPq+1tPa+0V3inSzPox/NvA56mvZXZePBR0ou/GyiQNJp1WY57eOwm6DbaVxZh7dk4PGoJwbzYHeaA4CgUqI3g58+esz3h6lhVYEGR1lw1wY4IlQ44CLuZ

9WLvssxLvxQFLuRWDLv62zH75d79i44NcvIQ1cLfKcr2jV6r3/B6i6gA1EadZ71ODt1mGEl0NPPpg7qCR+K32LmiBxoPQB058QB9e16vmJ/0u+5c83GrpNAJwHZpOXbG33QN1WXZ1Hq+FEf5al5s6Vh03OmZ3Tudxwzvk1+0vFyagC8Mr3P4WxmdgCNXIjfH0qhZ7Duqw4WudPIAAgYFqAd5qA2eym+4ZlX7ansF2U33FnbFG4zYmABr3de804re

9Ra5lRb3be+xr+q4t3hq6wXxq+eXsLtRH9u6In5Nbe9imDq3fy4a3O3YFt2aNJdxEf93b4DblnA+D32WpCnDOIdAwFEfMBXu5dse9J32hKyD60//B9M5p7207r76e9m3/s8Z30i+Z3nRuLwz7FXJSyR8sgs8GXe2+GX9PvP2uYCf1K9IBOwm9JJvtTQAd5oyOTwB7qx6URrTXmRrpAFRrntFwAH1ZQqd6+q40+Py2nstHZQm73XatGGOtG8o2cWU

gOr45acjQHGKUXE1ob/NwAkB8q8byE1Xc4kAAw8CVeP0G+HdqaXHTaj6VBTcZFj6FnrjzCgISA7igF919so9eXpFS1Wx3iREt9YXcd5tpZADpEe4qcp/j3o7IgTACVbLjeu4rAA/iWLcDAJDczGfzArpfSgdoXamjTRPFhpTKY5ZUEcPyoY7fsprxwL/zAQjmzhiVkGiBACtpq0aLjZaWjq1gwbAs8UabtYMEMd7tbxAHs7CCHUA/4Hl8WQH7LPQ

HqrH2YOA+xYJ6srYJA9vV1A8Y19A8D2jwvWC7A/1CpNZOHPtekk55l7cdrYkHjzoneAVAUHjLBUHvzpQ8ug9lNRg+oAFg+EANg8Jgjg840rg8HBHg/lTMzebOAQ9JgIQ8iHl2WEHAZFWYc/CSH6oR0t/dG+kuQ9vHFjdKHpCeDpwgBqHzcYaHuDZaHlTK7r3Q/IYoFk5pIw9EsymlrlMw8VQijiWH54f3rGw8HCuw+su9lAOHk7hOHw3cVYVw/Xi

dw+a0Tw960PAA+Ht5B+HsEO6r01dqq83d41zBdwevwcmrxHzKRvRaqR7qcEF6rcrdq2CL7rbuULlff/e4yOX55AMOw30OJQPKAqE9idwr/AlpdnAPFEy2CkEj+iX5HPIGO3CCF5APu37mndHappczblpdzbrPcLb8FGrhoJc1qcZYypdbd+N8nXwr3MJ5rjMfaLwwruR45uEou0fNby/NyEtKluLZhepmc60qE2QNt/AbdjSTQkEn7QmaBkpWqnu

63Oe7/vRnX7eZ7tpeMn7MP5FKIhkwE8fzVs8fWB6BChrXk94QivcCn4q0Iz71vlYmk7zgBaBA6lrDFsBLtmeBQIJjgwQokRaDCpQaCJIDtiTgX8BtKpFvZYzkFmOckQ4ZPVZlLpadiSGPQkEwk+1zyNdX7jHVU7hmd372nd/dx/d/b5/cA71/c2t/uUBWgvcb1kMBB6podWn9eEtB8tVysQAAFZIAB4P7K6cAFBrSVEKP1Le0rXSCC3eqfMrN9rm

5/fQJzo5e7ToMAtki+I6PqGK6Qd5v1dt+s/RcR/kqTXjqcQ0tbQ0R57qeVTg1d3XWP+65423yACPvxLrPjZ8OrSHFbPl1fbPsxK7PmVc7XvZ7WMTAAHPSsvaPEm+HP0m+pJY54TxE5+yzU5+Yxg6VnPdMIXPGXCXPwBxiPTa6eh8aXiyG570P2581NRW4wXPg8BP2C5kbLy+n34J4IXkJ8d3NW4+7Lu+FPxs/d31E7277F2z3D7xJDxKn9DnhUDD

SN0Wy+5wSdgVvtmbs6ZHuQcpPw1f30Wp/qe3IZKDc0ItJiEYFDPBPwJdMwzOawAbemJDmUlZ+XRKno7ksoYkA1+ZvnUVevRZTRSwQWAQAUUzK8TXkbQnaotEu0pBoZ5/Dot1dBxmoaPmPAE5tgrYTJGF4NDLYiNDROXTJJOTNDioQtD0IGtD+ZOZy87DtDJZOZyjoYj4lZO5yrobrJtp2NZQuS9DNs5PMgQaopxc5ly2Tfh94a5wgyQEX0WYf4X7

wDCvEV89nkVqTD329pPpuTEnwnqJ+LmP5DtnxmgVtkeVBdfpgDQ9WyV4+h3hg/h7/+5q3QjpxHru/i9+3ZrZrYfO3XW78vztyUVDHt5rQEH7DaK4/oMV+wAkV9XHSplIDo9Z49n24I7iV+EnOZ91PhK7SY6V8QjzJ4KsjMBahHJ9KKXwFTOjkEa7Ay+LVJV4LXAp8CdSc5+XPrZpOHAGdgwgUFVIJGkHd9ch1D9aopQ0C5s773yQnGjAoCQb/D1c

+4n6RE6v3V6T3grpjXDS7T32Z7pPT+4ZPE15On2ZzAoPS4qB5nneV/faGXG19FniSDUBy2hRWOZGmX7/Tep2rJNYIFsODEAGhvLBVhvLpHhvYJf2aSN/kFhW9hHLDvhH0F5wn8Icn3SkbNXgQ4tXHKytXy3aWtBQVhPJvfhPZvdX3xHuqvJkYlP2S79rHdZvJ2VKM7e+ymgPqiq7xgmj3vAA+n5+/tmbkdnlPV/evKe9jXm49SnP282Hv171P/14

5nAD04Sm4f7nSQnP4yuNUCgl4G1/O8r3P1a2rzxh2rG6cBru1GBrzZ8PPQ67OrbyCpb11YQkt1furC9XgPW1kSPyB/RrtU0xrhdWMXXBbHKXSGYbeDbvz7DaIbJDaTQ3DewKN1KobA3YEbdDeEbn+c9rarXJbOLaPP0Nedvx6ukPPUzCrCTdRAm3UQlRnDF7Th7lped+lbnY1LqiErY78d447w3c/z0rb7GVd9orPHc/H3XZVKh3b2Zi3TYrJd/b

vDd83b1PkW6jg4sH6zJ/nq87zvOfZIagC53ndw6BHzeZ/HYI8uQNx6hH0wzzvCQ+YAJDXUvBqbfHINBgn4WDgnF6wQn+fSQn7oEuP29WAnn+ZJHcdWU3vmDrbed7onfMzklRtBvvks8/zD979++zJfnYIDfn885yAi8/Rqy88/Hq8//nW8+uHF89AXfyYPnqAGPnyC71T4D9gXlx/gXm1A83yC6EAHd4tnznBIamy+2Xuy4RvBDQOX8y8WXyy/OX

7+daj6D8IRarQ7XMq5ZXcq4VXSq55XND9VX+W1QAgq7qP2q8/zFD9cRJtTkv1G6LZhR/o3la7hMzG8UPQnDK49a+JIgF7phra7ywvG8aC/G7g2gm9yPYB4HXwsqKw4m5HXUm4rA1JNk3U66GZgx6U3865U3SC/tv7pDXX/nIvPPRS3Xr0v0Phm4WTh68GPl1Py2XR4s38bq591m5tAtm/s3vpUc3zXifXwGtc3VxPfXqPBsZ3m9/XRovXFAW9CFs

D/PPoW6so4W+g32iLRJMW9Avmx4QAiW7Q3pGdGmWG+im6W/OZ40oI3OW8njeW67YZG44fpi5q5nZ6F3au9F3olu13uu5qg+u9Erhu8RZiu7KfH6a73te+yz9e8H3/e+b3fe5+4ed9EAe9C4f4/S2Lb3LCP4B6tEoluXPsR/dv8R6RrXt+SPaB6Ya6R8AxruJwP3sqUf4R4KPl1aCFvR5KP/NTD5F3EqPNB5qPDB94QSBQaPTR+lhY1M4PosnaPR6

7K4zj56PZm0LE/R8qFgx/EPIx9AQYx8IOEx68k8h9/EIj4FQcx6Toix4rSyx/y2qx8SwKT/i39bu2PEqF2PDa32P0wXMPRx8hKVh/SjZx4rlFx8AnPRUcPcu/uP5oEePqPGePywC8P36PePKW/8PbT4qfHAAbPTZ5bPTt4lgp55A3DKcXEzbT7P158Ndg55k1D560fl6UefL544Ak56MT058/Pcz7nPwNXcwM7LA2+bpXPHdWAv857i3CmLCZ1Pj

FP27OB4mN65o2N7VYeD7xvmrMJl7/S2QNV6lTOEpLlH7NSrxrudKN2Beo52Fa8JAyWMKWC/WhLWh4BHhbbyu82r5AD+rJJUtvldptvLZ/tvkNaIP+LZur8NYer8z4QPiz7RrKR99vUqDvNed8DvkVZIMLDa8rZEf2ahDc4bpDdFYPDdjvrd9obQ3bLvxi5Tv9wzTvO3lxbIb/bP2d6FfA1WMXGgALv3d+LvMvdLv6D4rvhd+47nXZbf/d/tkTd4Q

Z/Xebffd/Lvmnfbf0vcG7g7+MX0rcHv/Y2Hvzg9HvK8/iARb/P7U99YOfw+AXs99N6h944AmL5eHy97+Tnw8/z6983v4E+3vmYmgng3YPvC96eQJ94AnqE/Pvl98dH198Mft96M4994mnT966QL99n9b94mnt0q6QX96nnaAFnnv999KH8G/n879QnUD43noD9XfNw+3ftx7/n0D4gXx75gXAqDgXN84QXKD6C3aD8/zwQEnnWD/olqWC2XEy6mX

uN+hQlDcOXRD9OXgVdfzqy7IfZT4kLVD9QAKq/lXnK6q8yq8Yf/K5YfGq4ufIq8q8Yq/o/tQBGfLFRLXfD7o3MKYY3vXCY3DSNY3Yj/Y3Ej9XPRx2kfFDI7X8j/y2ij4mfKj7E3w68k3I55k3lb90fksP0fc65RjRj6XXaj5XXZj9PgFj903+jO3X1Hx0P+67sfxm8cfv3H4PF67cf168X6Xj4fXvj+c3L6/9lQT883X652MYT41zxoo/EHRiA30

T5C3YG7ifqnAi3MG9HZyT5VfyG9dxGT/ntgIuyfkPU/ReG/z6BT6I3RT6rpJT/2OlPJO33JhgAlaBV3wu5qf4u5Vgku4Ej0u81gsu7+TRu9afgz9O39ww6fPe4b3vT/io/T/M47X+Gfx6JyqwR/TgIB+x5YB8moEB+mf/59gPkr4SPL1aWfqR5WfqWTWfcGw2fDQrwP+R9zZhR72frz8KckE7KPxz6oOpz9M49B6FXlz9YP7B9ufrR/ufjQTHPfB

/M3Lz76PWSdEPnz61o3z7/d0h/+fUx4UP9o2uQoL9UP6h+bXmh8wA2h9hfO68ExLwERfoCGRfwQAOPFh4xfJx/Vo2L/hf9h7AOu7+cPRL7cPpL4Zg5L9eP1vViCnx9pfCEoZfB58c1zL9RArL+fHPZ68kXL4i5Pbu1TfL9HXAr+c/wr9Ff+OY/Psz6KwHt5/Psr5mfkj87qyr42PW5+kOn+Y1flPS1fc3Cxv01D1fuN41Z9HORvNKFNfEVej6Fr+

/WVr9MTIfWKgfm1gqd5udf6o3YGbZXdf8IM1QTLZK3P/qeXcF5dM6gk6naI4hPPLZQvzN/6wXr99f7699fzYJSLAb7tvy64dvGd9DfLt/Df834Wfi35jfyz4TfAd/qjQd44AId9Yb6b/Ngmb8jvAyGjvvDbjvTbcEb476brTQFLf2LfLf/v6rftLYcfgKDzv9b98Ijb/rbdd8XfGnftkld4QZNd+bfXbe7fpzW7v/b7HfSd6Hf9shHGzd9Hfbd/b

/E74Hvhd5nf1EcAf9w4g/n+cnvcdWnv/w/XfEfsvfgQHBHmP5j9+77XviQ7jqW97IPUE73vX483fcH+vfV87vfed6vvD1U/fd9+MX79/ffHABP/82FffBd4/vxlX/fP94/nf96/nAD7HvC78g/AC5XfQC9g/e88gf4C+i/8D6ofog+6H7IPqpuqD7oPrh+mD5x1Ng+xH57LjMu5H6EPscuxD40fhcuay4Cfp1+DK7UPoKudD5sfgw+fK5qrlx+5z

7CrpcgfH7JBO1+f6jDfkNGPD6ZAKJ+WAACPoEyVa7CPrWusn5vIBxugv7cbrMcsj4XngJuyCpbfpp+Qb73niz+4676fi/i8m5HrgY+Jn6+YGABJj5QHFpu5j4brk14Vj6pPg5+9mBOfg9+J65P2i4+JNAefjZuXn6iAA5u31BObrNY/n5Tsu5uYAGfrgz+IX6+buE+/64oHoBuB1ZsvnoiYW7xfgk+UW7jmr6UEP6pfnBs6X4Q5pl++YI5PmocuX

5ZboRu1mC5bkV+vpIlfgJ+CEpVftU+Gu61PnV+Ou4NfnruTX4G7uygLT4m7rS+nX7d7l0+ve6N7n20fX5t7rS+Qn4PGGM+shr4gOEe035QHrN+3P7egJG+nt6h/igeyz5iAKs+WB67prgeWz7bfoQeu37FHnaMnnRHfpQeJ35F4rQeZ361Hjx+9R5Xfs0eN365rG0e936PPo9+3R49AWxI7z7Gbl8+jQCjHk36EYgt+gC+0x7AvgD+06TzHuC+7A

Gg/uD+KX76HlD+Ox6w/hhu8P6ovoceumRssMj+A9K2Hje+Vx4Y/m8OLX7Y/iS+VLRkvhS+bx5blMT+g350vmT+INaHnpT+HZ71Fo4BuGycvleeDP4mJkOeQgGfEs+eibIivm+eYr5c/o3SvP5XOIueHx7VAYL+Sr4qAajKYv6Jvu5WMExS/nVEOr6y/inG6maI3oa+gOL7NCa+X+arNOr+CEia/pFQSxR2vrr+jr7bYC6+Rv4HUCb+1mKOBtjsPA

C4uvaeOFKs3oietfz6wMoAvoAtYIUQEK7WGPfWvN59yrIiVsz8UAIg1jj8XlHu48oZdpLeUjx9VjRe+XbJTmY6024jXj9euZ5/Xngwk14hRqN87pjweKuSQoCRzmsApe6/7uXu944jLvC+r3LznivaagBn0rsWb8BCcMGSPRRKfnd058LjLhfGipbxZBQaZTQ/ik1Mu56VAIw0/mAegX5gXoFQAD6B4Ep+gS+KPBSBgV/+r9SVaLrACpZVZgFyov

TRgcPu6C4GriJ2H6TW7sCemsR2/jPuDv4ydtauOl631uhe/IFRDlheYrY0ThzewMwQKplgbNYQzJ7wnNZUUrciLCgtXqXY4g6yDi/YUV562h9e2K6K3usOvs4q3maBat4WgSdObfBWwGzuxkAq1gPOHdgA2obePjrhNu4qXeA8zPp6llTdgfe8z4gBKk7IFtZT4FbW3TZ+XITIESrzPDau6nrbXmrMlV7OoC7Wnu6jyMay5T4onlku1HoNXqhkkS

66xJEuGgRh1pReUjylhL72NRrCLvZ2E9ZiLgmuObZjXh3OYSCWgTcqwc53KkBAQoDJeI02V8R2aD/ua16jzqVe0J6kIhVehl7aekYu34FmLq3WGWrPhssqQEH30CBBybj3bhHWj3aQQc9uI9aThh9s33bJ1oxeM/wE6qre417LgQEuec4hzha4vvomnrlenegfoB46fPaukjDud05w7oj2WVw8AB96bk5Cto2G7FwlsAkAmAAtYNmAQgDJAOaOp1

71Vi+G8Tpkzm38ZMCokFXIy0KzDvdeJO7gQUUqbEHOLnLeWK74dnGu8EE/9omuipx5npqAqEEf+LZ8miRMwOqCsGBiIAbePO59enzux4YxrEis0jIiplmgRfLx/ja+rpApYKrArUa27FywmS4N3HAqlQDCSrFB7sDxQdgU+zSWjMlBgcC8mkCs6UEQXkTedy4W/kO25N7W/qN2fZDjtl1OSF6O/kQuNq4QBqRBLYE2mibOCJ5GRrX80YiXoOjOkg

BogP1ORkHmRl6aXWrqrCEGm0Csos34pzDFnml2Yg7DbihoM8pJTp/2KU5zgcrePi70nkuBt0i+QbU2EDjZaPBgaOjfttFGveTTQJSuYUF2BnHOwl41tmHQQQDFSsL0ytTLgJ90zgAfNAQcq4ggVNP0BoDIAMgEd0G+AAjCZ9RVZtP0lJJvQbngpyBQoM9B30GE3r8ePlL/HqTepW5W/mnsISQRGmCeT3p1gRiOmkbKQYIG3y6Izr8ucJ7/Lj1BZs

473BQAloBZYGiAmAD1FjtamO7GQeNBURBc2EGoHbCxngQSY0hn7vZBOnyOQVGuye4uQRNibkHDXk52nkEiUv9uPkEnTuskz9A5Xlz230iFIJVYrDCw9gRBEN78nqLOY3D7eF2IQGyrdIygYOSCgAAA7RwAmsH94IAAgQSAAAEEysHdiDVAtQBMHsnEANjGwarBeyAawWMA2sG6wZ90hsHGwVlQpsHmwTIUONZNTs8ocMEhomTeCkZVgSwq5q7yNr

PuHy4HbqxGL4EOnnh6S+6/eoTB1C528HaAwcA8yGMA8YB79qNB53YmQfSiekByBOl2khBumJHuG5IPIotBT14f0HqBTkFTgfLen1737t9eOp7phuaBu0EnTt16/gR22nN8wZpFTpdBuEYizgAe6ACBZvFk5liudKoBBWZRiMgE3cFNeL3B1oyjUv1wP0FQepBeZYEPLhWBSI4U3oh6VN7M2kHB6MHETgKemIbhwYp2TtaWwm2B5vZr7mu2xOI1AH

aAW74B9oHuHYbpweWiIQKzOtloh+gXWl/WrMFsUmTuJYRkhJiucV4OdnzBkY4AUouBgkF1wRre4t7okIoupp7KLiMomOT6Djtu6DZ/7pDencEQAAd4Qq5jABsgFWA76jbBN85jcPQ+NQzawWN4yASwIbFy8CGIIWrBcVAoIQDYaCH7iBgh1y4ewcrOXsGsOgCevsFAngvBGqqgnsFq+C7BDoQuoQ4M3tqGm8FG9peCIrZigb1B22wqwAkALq7FcD

VA5qpnwbbONyII+kjcBU6KBKtixbZ3wck64ZoU9o92l+6TgcLW3MFB9rOBuK6p1tXBki7eQYkgJ04yICiQ3Rpg7rzOEhgaTHWoskEFmsVehEFQIcFM5+z4IYGKkuQj0voAjZrpgVEKYGweNP5uDh4GwUKuvySscPlQwspr4uGy7gqygGywvMqe4oMyTgpIMhzK0soH4vlQrsGoAHfs0vQydOFgTB5+gptwjUAD4GM4gzJXmk4AqmSpgJgkHr5gSP

YhQGyOIV5yLiFFYG4h5GxCcHD0XiE+Ials/iGuCkEh4sqhIf6yESGCys4K0SGxsrHicSFmwQkhSSGNrqkh6SGZIZCg36w5IW2U3KD5IcrIU8GVQd4OPsEIwbVBSMHGWgheaMHNQfWB9N42rn5Oei4H9okurYF01theFvZfgRVcj+C6LlR6aJ7PhuNBM0D+ro1a7oBORkXB8eiYqrY2mEB+wpxBqe6VwQJ6poFIQZHCmlx7QTXY6EFVOmNAh0EXCi

dBj7AKkKY8FiE3juFBHTZ7ktUs67hI7rX8LWB/1JoAywBXALO2oiFpNhQiuYimNsyI1oDZKPKIfCDVWKzscZ4VLu1ewch/1tggq0GrDhoh8a4eQYhBNcE7QcLBf8HwGL6sRjzAQFA4MiCl1gF2u24ugfHOD44uvv5mf6zFCuZQYSa2JJPB3w6VAHyhoJKoDIKh+drOgCKhFUEwwd5qVCHwwZb+CyFSWLbuKkYrIcwhyF6tQTpe2kYdQbE2mF57Ie

2BOF528DVAc4BsAKl6w8AZQWihcOoYoQyimAbMoiAOtkFf1itOe8hkoS92b15lwWohrI5Uoe5B2p4LgZ8h1hLfIfohP6CfhMYhnfYAyD78QCi7gfYG+4E1tqghYnAVYIs0QGyZYHFQwACUShVggAAjwF2IaACZoagAgAAQRDKAiWA3zn4WUAA+HNuAFsHuwLUAiaHJobGCaaEZodmhqAC5oQWhRaFg5KWh5aHyoZcKfbYzwdpic8F/+jbuFW6mmk

t2nCrQnoVWzYEGobshVE7GoQchWKgPkHAA1QD3kEIAJbDUDjahiRCFztDqkChXXpNAEqRYpF1ieiScogohce58ulGast5eoW/BcEEfweIutKE6IbXBDKFdzrdqJnok+kAh72RREN1SKLYMdvJB1K4KwdAhgzgslip033CxctPGzFopCrWCj3C/WDBuptIDsgcS9mCbSiWIEvx5IYmsAwCjUOVsyaQu0rVsbtLn4Jge+oo/wNOsO55ZQefsSNQhAD

ua/6EG0kBhW5ogYd+iYGEMdLLg65o4DO7KMGEhAHBh0UoTIYhhygDIYY7SqGEFcq7SB1BkAI0AWGGgCtzSjABfHkgWgCIzISrOyqE1QX7BdCEBDsvBmvZaoS1BrCE2rlTW+qFGzpOhI04e7h2BMxrfgalqjNh1Xm3WlI50QZk2Ck6gQZEuY4HzxDYIA5IC7Hzo0EEDXiIuQ1709iaB2iFJrvSheiHCQe0aGEGxECTAYXoaQg6A7KESIjGh10HVnk

pBohKaaHChKTzaYWduqJ4xOjNOKxrxOvRBWRKMQXYu4a6EBqme8QJsqPsaLI6DXrzBDmH8wdehzmE/wXehPnpLbiyeRthwYBqcRjw76FyCy5IBYRFBVdY6XjXWWyGWjjsh5EECBKYY9wB7mETAHW7U4rEQ7bjTOgUajOgv1uhofIJjynZBj8HaEilhKiE37vxO60GaId4uXI6BoaYqQkH3oWAgJlyRLsChv1pTgLKI+pzgIeDekCHfobYhXkJwBJ

ywSqpqsOPqlURogKlQfpAtYCrAzsAg0HJwSu7s4ORY82jHYRGmwWCewOdhl2H1QNdht2H/rC9inaG3LrMh+lo0IbBeiyH1QTgWgcFyYZauLCENgTChR9YcIe5OwrbdQTwhRMH4UvcAzjJumouhjC75zjFhtMGg7jl6M0C2cB82vmFwYMHwD16LjuUaJcGcwc5B56Ffbjlhn8FEqt/ByEG8ED8hhbY2tu0qrxrrYa6kKwD2zjfQ+EFl6tYh+2FRQe

gAOv4OvpBIn4jiYnDKatCpgB26dU7jHtL0oqH2DjLOIuEddIXabtIIypLh81gklLoy337y4dDBXaGKoSTecyEqoVJhdUGLwQ1BEOFNQfJhayEjoQzeyjbw4epBlE7qYfsh+8HsXBwA0YhxgGOAzADigLkgnA69YYy6hPYJuBMC3VJMwX4scU4OLoIku2pU4WehxQ5GgUreSV4BoXShBWGuYcthpWGsoeuBkkHoQoYheqyywfzh8sGKQQLutbbcfr

6SmsEygPSubyA3zvSuvoAEAbMq5eFfJrUAvoCygFx2ReGoACXh+QBl4WDkleHV4XKuN86zKg3hMewj7t7BQOHzISbhoOE/HuDh1N4rwashGMEU1oKBGUHjoaphXUG7wWze7vglsLMwWgDjLtzgvuHjQX6u1ST2gEramoFXbGHhD24R4ZZhfzyqITTh9mEtzvHhW0ECQUzh6t4p4V/gmWgSQRLBHXrZQJOA8rqrXrnhe2H54ZXumgDcfhV4voBsHj

fOB3hsHllQViSsHhlQNeFpIWDk4BGAEZAR9eFpIcgEf+HnPgARQBEkAY0e3YjgEY0e8BGNHl2IN86wEX6C8BGAEdcuseyewRN22E7D4bQhpuFoLgwhJpr4FgphMOHKQUc2KmGRDovhRqF7weze7FzKANgAIJAwAJ7A2ACEgA1hq6E9Ydvh++7MiJ+G4FD98BqCaLxIruTOhcGVLtPKaGgy3p6h5+Ex4Z4uvEFGKmdqqV6v+CzhHnbCYNY4Bw4bbi

bYw4AnDm3Bko5EQYZodpCHftcgknADAdFw94iX0grhqN7sRvKw1hFEDBUeVBwOEdUeeuEA4eJhRuGSYVQRo+EgnkvByHq1gVPha8FIIjwAArb24QYueI5O4dOhLuF28APqpAARwM7AXuEpwcIRE4Db4XBgV16okGLexKHh4Rm4FmEUoa8hWZ7vIU5hXkG3ocnhBZ7Z6iT2hhG4pNxCl7i84TVhUKE3yhIAyWyOANEATHAKAEweesEBgvls1QA9EY

AAQQT9EagA2gDjEWqugxEsHsAAvoCGcNuAiBGFIRmwHRFWAMoA3RG9EaMRUxEjEWqu4xHaAJMRPRG1ADMRcxELEab+T6RFbuQRLU7G4YERaqGDofQR1uFYugzenrYigZwhiOFL4eKB22xBYCCQLWCUWEFgmgCertTBbsh+4fSieSCTQRNAU0ArOoohD7gLxCURCt6NLhLWGe6J4XfhS2E1ES3wqdwZrg8aZQILwsoQ22Gf4YlGAuE/4Q+O0xEHeN

uAgYolIgdQgoBIFCQhHABjeC3h6BE0kSweY3DIBISRlXjEkfXu+ABkkVpIlJHUkSXhsCEl4fSRANj/YXHs5xHUIZQRIOHXEcshyIarwXPuAp6ztvPhrBHDTizeo06OrhRBFVypaichPobRYcxOgJHlopchsqTXIbwAtyEKEe8AE2GnoQBCfV4vITCRX17lEQnhN6EuYboRJobuYf8hkDgoNr1CnOF54HWoXwC6kC0RzHbQocpBoHZqQbERSS5rtv

oAzsAAkMwA0cCU4pkR7JzQ6s88N3Z0UkKA4qT54DncpOGjYWZhyiAvXtCRFcFlEXOG8JE2kUnhdpGiIl3ss6IK4vikYDy53DthZe4KQTaeos5eigDy48EacDCgrazEAM4AsvTFYCCguYFOEQcGLhE1kXTCdZHHYA2RYQBNkS2R7KAhgdmAHZHghqI2pYGj7uWBKhTidrI2tBFBDlDh2qGKYTpe8nZPEQjh1o47wewRy+Fn1sM61QDRiPcAEcBbXl

ku3WH98Hahwt5yBA5AIGApCKraWoHk4YBG6ZGvwWoRP3aPtlaRN+GM4V8hppj5kaFGBiGOvF08RTDwGDNAw85ywd/hVZHQIV1+OQE9fnpwA+79fsgE4FFLGN0+/T5N7gUBZnAlgWcRPaG3eiPhUlgBwRPhkOG03tDh6yE6XmF287a4wdvBiBKlVk1u7FxCADaA+gDRiFS6KsBHkanB9vZRkVXC37w1fMe40sHnWoShzMFAYBbqqZGwQA+RlO7Mjn

RehXbUnnCRo14IkR+RKEEnTjNA1oD1EQXqC0C5IF+gIoRekecOrQaPjsWyXe4qwbkBvT7fVhpRVe5aUZBRTe794YJ26FEYFqKR/DgZ7Bbh9v7hEVKRkRFrdmuRDuFxEQqRGmEmoVioJbAWAKYAIJALGJwOzFH0olBo1ST8IPNAKgSOQLD6B6Ea2neRSiEnoSoRU2GGgeoRWPqOYdaR+WGIkb/BD+EwkNlomXqukZoIiOxFUk6BwFHcoTdBBeHZDC

WuTXjpZt6M9AAzHHdygKDlHuygrIBDqrCgvYDDiJJqw5bGgETmilok5iFQU5bN9MVQO4jevr7Ug6bZpKmUBsyqZI4AzoCWzpFkRoBZAFzUeGGgWo1woaTFUcFgApaZZhVR09JSoNVRRXB1UaEADVGKSE1RtYKc/q1RZ8axZqTmw7pdUTFwRWC+vpuku6aDUU8Aw1H+2mNRMGHX7EJwl2DCYTQqNBFiYcVuFBGXEeZR6hQ3EQ7uOqEwocj2/pEUTk

5RBMHI4bHBHJjfgdy4aWrUQaUksMSAQUZhiWFWMGBBY2H2zGjqUeEAQjZhBxpZYb6hl6EIQVGOElFBoZ+RWdYa+MtueP5EzoAhGeE+IDqsZRgrXpyhECH5UUFhwHYI7vr2spEpzlVeWmEVXAsa5i7n0LDRajrxYTfwCNHsKMxBT8F+RCBEp+FnnDoSFZiR4ZlhdmHZYVfhCVFvkQthDWpfkdNeGZqSEHNe4aHU6soSBKQ54biReeGgUTVuafYxEU

DRgZHsXDGgFOwgkA+GQhH/Ef2BDCimQf1htiB74UOA6Ih+rDdeYagpkUtBF7ai0RmRM4GwkczOOZFJUZJRzOEA3o78B7h9zgi2eLCGITQIuVFf4fTRcaEF4bg42BooFI7A7QiKmlIUwrBLeGKhEgAJ0fbASdGXtPcAqdG4TOnRt9bfHvQhb1FQXv4Rjy6qoSi6P1HBwVCeDN4pwSzR5C74wcvuoNGArnbwTUBPkBQAcADWWB6ettH0oky6NcKOQA

IgoFA/zIiaIeGzAo9ehpFlPCtBj5EanjNh1KH+oQrR+NGLYSlRyJHEwJUGQKHg9u9ktkAijlhCZhFGDhYRA6jOwH4+xUoYgE8gAPgpYNQKza7QoBpag8GLEXKwx9GwWqfRikTatAt4l9H6INfR9wC30WORJdEfgr4R71EXEQERX1G4LuKRpNa10U7+DN7UDo3ReMHO/i3RipGfgVioygDOwNgAxACwdtUAGRHW0dzRfdHlonTBsZHtsBqcp7gVzi

VSvFEe0ZxSXtGz0RV6jM5vIdmR4lG5kclRhWEdLsqCaUQ0MB1qxzDe8DrRbTax0cbeD470rtU4QGxt4dXhBAF48sw+gDK7KLBR1dT8MR4c+WwwAEIxwEr5bKIxxlFoUVORs8EzkTN2ISSWUThRluGLkQwRBFEwoVjOLBGs0fauzcpKkQIEvoAcABQApADOwDAAy4CooZgxxKgyINvhH4K6xBGAIGDJBt822oFswVHqqNGpYWBGF+Gy0TSe8tHzYc

vRStHB0dqs5NEv4S6YhVJDQIpRfOG60SBRroHQIfgU/DH5AFeuja6AACnAUACNtvKAMoCNrqkx4WAZMdkx+QCNrrkxWTHhYEUxjbYVMbwgsoCN4ffR4qGBivkAKTGVMRkxpTE5MW4OTTFloWUxxTFtMWcAhTFdMRI+1QDVMTCOCqHcGEKREmGV0ZhR/Dhzdpox1lFW4dPh8+4dDkbRzWHykSDR8DGaYXbwy4AUANgAPMgUADaAK6F2MdKe2DEh7m

IR19B5ejUGXIILagShx+T/hqQx09FKEd7RrkHY0XThV6F40XQxgdH34WvROkD75NXCGtHKLmT8MlHpDuWRzoGVkQkxB2EEUvkkLXj3cEJGkYKVtPFQPYBScAUMQ8HgsW7+NEbQsfdwi1DW9FOIP9EiYWPh/9Hl0UPhn1ET7tQRMmGhEYheszEREQdu2I6LMW+B9W7Rwa3RFFF28K5EnsD6QZoAzBGhtjbR2RGTQYOAHbAsTjxCqKoFwdcxdyEfmM

OS9zE8wY8xctG5YS8xAdEE0VJRf8FSpHvs6oLQKGwkS2RFXhKOB9E2IULhEAAtYBIxVdQ3ADbANwAVlCXhwcCt7iXhFWB0WKt0urH6sUZwRrHdiMYcNwB9tMgEWrF8MTqxerEGsQ5gxrEg0GaxDiQusVaxre5ZULax9rHTIcMxH/qmUYiO/aFVgSjBjCFvLiZiy5EwoYZB0DGkUdwhqzGuUTTYLWDBgOKAkgCKwBhavdHjQcCRXNgyICkAsPyVzl

yiArFT0etq5DGCUbRe02Gx4RtB1+FBMa8x0rFB0X/BygTFWAqxxp6voSpRHcGgsbwxerGBit2xlrHdiI6xNJEVYEYA1dQSXtv6XrGWsQ9hne4Tsb2xE7EVlFlQg7EmsSOx1ThjsX2xhnDXLl5qIzEhsVbu88FEsRGxdBG/UTGxykFtjsRREcGbdrAxtLFJsTOhypHlmAdsXNH2MYcxZnqh7mNAepG5UOGu3jEqIQ7Mb5Ifki5iwlFTbnHhgTECwX

UqtpFE0c0qbgSzKBsQGkI/+Cww2BYqsemO1p4gsdCepE6NYeROSzGpzuxcjqjDwJlg+gB3hh6et5jRkVihjqCTQENAbCRpEk6h5zAKBu+xVPYUMTX29F6iUX7RtDFSsSvRDDE57sqCsID5Gtre4dGs3GWe01qxMZwxwLE8oaLO6LHwsXt+PRT2wN7QFQoX7H4MY5GBHiFMcLFtGKJx/mDicRus49oxHNJxApGewXixlu7j7pWB0mHqoajBEpE2US

HBNW6uTg5RAZFqYc5RzuGcEQyxrAKsGPcAAhF4cWeRfNGkYJchHybRBmIgv6C9PBoEg+wRUW5odc4+MWm204EPMb7RD+4fIcExwFJfkdaBzTZSelvRBeoagimOhKT70eteguGWEWBamm7h0KtyiUpS0nYABoqt4oOkvdL/QavUNB6u4pOeH9RoSARAX64UtNMebaZw8pAcKsD2AEwAELFHHPQ6Fj6TAesYvRxOiqOI8WSqfpVm33iBchDQTNJ/iv

3AHJbOHNcgf9IgnATyf3IfwLcBOWT3oiFkqcAzYM0W4WCvrouC/VEZcP/yFPI0bOlxndJ10tlx9gA4YXlxdRyLitGWxXFwbKVxbxzzHlbKaYhlcXdGjQS2sXVxDXGkAE1xc9o8ipCBNz7tceFgnXEv0RwB7xy9cVN4/XGpls6MfxwDIrke/MwygMIxgDJTcWi+dwEMsvNxdyCLcbUcy3H+yioe2aQbcVAyPhG41kqhFdF9odI2QRHEsXbupLHaMX

cRmI6KzDwAI0HxsaI6zdGXsS5R17FXJMayyJ5Q0XphNEE/gDD2XlpYnm38WAb5KooGJRJSPM/2lfalwQBCXSTEALO2f7Hz0X6h9Tx1sUxxITFuYdcafnqCgPZA6eERMehCnkx5mh2xsS41bvDOp7FbwY6e3gL08eIG8hLQ0RzWItBeWnKeQdYQaO7RGqSNJEmeGga9vDUuVmGLLLbxfjE46t7OATESsV/BitERcfohDzab0TzOnfa/oCGA/vYcMS

62X6H4kZER+s4ocYNOZEESvMkuy4DEAFKsygAgkCrE+zHqxND8fKSLXqeRkfBhBi4xU8LcJGoE4YB44ZyC/CC6DrKINAj7oaqk3PGWwBfuUVH28dThT5E8QfFRbvEM4R7xqaqRcccCiSCXxF08iQAbJJEucHGxzrVhWDbs4AGkgAALO22RoYEVYKVRIlrzgFsAJa4ccK+eSxiT+Nfi/cCfojiAAPJ38qhw1VEyluFKzVAUkrpsS0xRAF0gSYCRgv

WRSoAAAJdIHpkEq3KJggpeAwDNoC9xSaxGAMMhnxQ7GNNRaN7D8aPxTAIT8ZvGU/HUARessxJ3mgvxmbL5cZeKz5rr8cd+qYLnQr0cR2ADALvxO1K98ofxyxx9kafx5/HhEsImmtDX8Q8gxoh38cVQD/EGAHyW74jPUeqqNy6Y8Ybh+LFAMYSxePH6cZGxlW7RsYwRIWG5zhHxhs5ykW7uW5FvETvcMrGvhARePN4+rrvulIbBXhxorqEzSNReAv

ExUWtB2gYaEVOSQHGpmhkYbF5WgbZ8zdhbQHNWTja9GlzuVJqO2s62mi4CcQVRRpCiXggUwPAoIcmye34jwaOWTXi6snVgolqjFA9g2l4woSQuDAlvCAZenUFbKIaG+gCpkvaRmZKIUNmSoAi5ktaGpZL2Xu8AjOQDaA6G5ZIuXs6G1ZIeXm4QuSSWgCDMTQA+XvexqZgYkD7wgV5q4MGGcZ5DboKxQ2KJ7jXxuQ6jbnPRYgkN8TIkzF7p1nuOpi

x/wdMo8K4davxQvIRI0b3xvO6tEX46goG6LhTxp9beApEJBEy+Xl/guRrxIHeSfAmtXuGuCe4UEsFiE27uLgU68V4vkTQxYXH1scxxxQmA7iJBHmH5UhfBYdFlAh82SqLWKGrx+241bvEugNFocWzRDLFjgGwAmPY1QCD6CXaFIF6aowLVJKqBxdY/oKwo99gxTr1ik9EkoSNuT27CCemeovHVsbNh84FL0RMJDWoB9hleqALPsGWeCuKBqItc76

HqCZ+h+a4pcQOoOJBIFA+mpRZqsCn+sd7+Vk6Q9wCVaCgU6yDqAowCTBTWwHOI0ImC6rCJOb4x3pQ2CIks+siJ3BRoiVeUGPGacduxOnG7sXjx+7ELkXhRS5G0CaTxXy62CTtelPEXsXiG9LEcmJEJF1Jc3t1hhSDO3F5hNXzZaEkAsKLpzA82J+7JOgDaAglCKNLeIrHqISFxVcGJUZURLmHfCexehPqNOhVhb9ZoWOGeUS5coZoJDNGV7vGBOx

IHikmB9aTegcdgkJzpgWU0KEz+YEGB8WQjkWGBBYGq0hmB0YHK/nVGkfR+pl0gOUFVwHlBaTIJQUVBo3AlQWlBnsDg0PSB5T73DH9BD0GXxsDBr0FwDFL0RTgQwZjUaABhiZXe1QD51JbBxABaUfYhN85awTrB+sFGwZmJJsG9ISmJtQAIAPeQaYlG0MPBj1Db0qhwvZFRfiWJqdQ8AJWg2CFtEAghSCHqwYQhVaG4AeghVJEqlJRBpYn3kE2JLN

TFIbhw+eBlIf7AriEP4lUhjVCRZLUhsXK+ITnmulABIaLKEbJb4i0hfMrFSq9yvnQxIT7iPSFMHn0hvoDJIfUeaSFoABkhuAnZIb14uSEsYV6EbonlPnPimIrqjPyhjHDSoQe6IqG3icchJ/JEITWhWlGpoZaYDaE5oagAeaGFofkAxaF3qvjg5aHvic4sZYk5VIRht6psWqRhIGwWuu9YFGGg1mnULAzrWLRhWWwRigxhKR7wYdeJy3DsYWdgnG

Epitxh6MJ8YeTylnKmbGEy/Yn5cLWyT2GekE/0J2G6wGdhFkifYd9hd2EvYreJH6bK4bBU3bIS4V4mmuEy4RsB6wq+gMmJzAARYanUFYldIJ7AzeGt4e3hFeH14V3hteG94T4cYYl70GWJUkkcAMgRgYqoEWDkIBGYEWXhhBFQEXgRINCV4UZJCBF9iSqRA4lDiTGkfQE2Ecd+9hFDAWJJEkmQ0DZJIr46SSsRaxF9EXsRTB5bEflsOxE+SQcRsx

HVAPMRlkmnbmWJyQCVoEyRhAAskRNK7JEUkbmJXJG0kbyRtQCbWGpJA4k2gLkWwAl1iRGkj9KDkcei7/HOSVZJ+XDGVHBRJJE9PlBRfT6FAelJ+XAaSZV+elEGURVJSFE1SdTwZYluSUVR1G4lUYtRg3jLUcXS+iIXcOtROND1Uewm84A7Ud+ie1H5pgdRSEmxTGTmaTSolD1R51FrcUhumawAwdtQo1EGJhNRj1FZglxJziyr8qZCOdFuQnnRBd

Hv9NZ0ENFqtI/RW4rcoGfRAqAX0WAmn9Hf0beJXf6aSbwx9TFSMV8msjFvSaIxj0kDiZpJSTEygI0xEj7NMT0xnTHdMekxHTGtMf0xLTHlMRI+uTHVMd9JbUmVoH8gheKQseNY8z51TvJxmLHfSY2JlaCDsdbBFrGusdaxJrGesfjJPrE2sQ4k+QFhiU7wEUmVoH2xs7EkyQOx1dRLsaOxDmDjsSTJYUlUyfeQmUl08hjJ9hyCVEpxEnGqcfWK0n

HfSSVJOVTbcZlxNTJGIvtxU6yHcX0cZBwncUMBJXFvnmVxl3GVcTVQ1XGOFndxDiQPcUBqz3H0bK9xHL7vcW1UHXFwmF1xP3Gu4ipafXEzpIDxQ3Eg8d/S+FTg8cBKkPE3AYj+O9pw8c8YkXBI8aYBKPHrcStKUDIiydTwtbJv8Q6J4/HdSRcg3/Ez8X/x2WYACWrKLaxyHGvxRiJgCZbGBTJQCcoAMAmSyHAJ1AHH8eqAZ/HOABfxqAmzkE2gmA

n6yffxj/GNtNtJ9IES/tA0mIklFjiJ1kLkNvCJ/KZCRoiJxImoifyw8gJbIC0JlCgkNNNxiP7QWqmUgsCYbtWJrnS+4lR8FLKRZFCxlkC+AJYACqaw9CRwogLugSaJ/eCteCmBFolrEmo+AYG2idmB7/GOid946UacxrPGGlrXIJXJUf6G8gxGUyD5QQ9iAYkpQaVBEhShieJJRyFqtJGJq0mPQQ84L0GgwfGJn0GQwQ9QDYmQ0JpJSsGFidbBHY

ltEPbB+YnOwagA8SEliXVJlYk0Wnd0o8HHYDlJRUnlPtjJRtAtiYKAbYnZiZRKxCGJSWFJdQAIycOJNsElIWOJstLlIcM4ZGyNkNUhs4lgHN4h84n1IbNwy4luCs0heLStIZuJwbK6HF0hsSGzcPEhiSGHiQMhJ4kFUI/xoyGXieMh8Jw3iVApfrIPiXOaT4nwbKsSQqGyoZtwJYmiybN0X4nbOEmhP4n/NOmhSsGNoc2hwEmgSe2hqADEkYoprU

n3kDBJf6FFPghJqWxISQbKqPBqcOBhu3BhilBhMGxFcLhJzGGiKQRJJQEcYSZKeGzoYTxhmGEUSZOsgmFpPpBJtEnp8kdhjEmvYSxJF2GqsOxJv2EGsg/JHX7ONH++pWCi4arhPGHq4QJJ8JxCSTrhokk7SZJJCDKySaXh3eHjsVXhzD414WDkKkk7SdApXSDaSUBsuknAEVd+YBGGSTgR0BH4EWZJRBHQEelJ+Cm2SaUe9kl2EZrQXhE6HEgpTd

5uScsRXRFTEd5JAxHDEaMRAUmTKdMRwUmhSZUp95CRSUbQ0UmxSaSRbRAJSXbBvYk0kTyR4wFpSfEp6kmcyVlJchw5SdCgeUnNkQVJI5FDKc4spUnZAfBR2lGVSchRAz4HKVBJ5Yn1SQkK+lHlSYhRFMkvKbVJg4ncPvNRn/FLUaA+C1RrUbVRQ0mbUSNJY0nvnvtRE5ZHUdYmc0kS0AtJ/VBLSVUcK0k3UetJcPSbSVNRO0khKUbQ2dG50SnRrB

hp0cDylMnnSSfRq0nXSa/R22BX0U9CTXhf0bVm04hkqXkpRtAvSZIxgjEiMXIxIEqygK3uZKlVKaQ09TEAyWDJUMklMYDJ4MnQyaKpW+IgyTDJbg5wyXyp/ykwKcjJzxhQsb0AaLE8yUyp8Sld/m5JuMnOsf2xhrHusaaxuqkVlNaxfrHkyWMMmqkDicspXSC0yUBsa7FGcAuxjMkg0MuxYOR0WHap7MkZSQgyPMmKcU14ynGScWpxJEgaqWdJSi

kVHCty1TI1HFLJuXHmssvxJ3IKyZfSSslLGGfgF3FJ0FdxVXEdIjVx93EScI9xesktcW9xIHIdOJ9xpsnfcdwBcGyWyf9x1smDcfYcXYIjcYCcY3EQ8ZNxLsnovm7Jfj4eyUtxp+o4kqipaPHhHAHJmABBySPxIclAqS94EcnUbrPxyIHz8arKS/FACfHJA8H9SQMB4Amkwtvxy3DpyUEKB/FZyYgJOcnICZfxoLjoCbfxJcnYCWXJ+AluiVXJME

w1ydiJFMZwiQSJTcnCpkiJB0ltyRwyNwxdyWa+PUozcb+IY1ADyf5AQ8nwKZeq3KBjycQKE8mtnhOUM8kw9E+Mi4QXCrixlIkwXuQJ4hjYFjWBhPH0iToxNuHtxEaJfuJRIZ6BZomryahwlokbyZmBW8kqNMGBuYG7yaekhYEuiUfJh6mnyUJKMUE+ie/CYd6FQVt4xUGpQYDS6UGQSRGJzXBRieGBMYkfyR9BiYnfQZBJLKndjBmJWYnIISApeY

mOwQWJqQyQKfEpeClvKTApG3gjwTWJ/cH7xkgpld5uSWgpuCHtiQQhWCndiZyRuCnWSXnGhCmjiU4hpCl3dC1sFCkzibaKxAA0KeOQdClLiY0hYsrh4uuJ4SGsKR0h24kcKbuJXCm9ITwpR4mDIaeJgikISGMhPGFuKSs44ilwAJIpfmaSoQKhsikyoUwAb4lGKQ9UCaGqKbWhv4maKZbB2imASS2hIEltoeFgZaEGKcEpximmKd9GE8Z/OBYp58

bkYdOCoGEEAHYpmEnhitBhzilMYRQy+ElIYR4pREleKamKGGHkSaRslEl31NRJj8l4qW5Kz2HhKTmQkSlsSTdhHElxKRFh9ww8SR0EfEnpKSpwgkna4XLhOSnpSbxpiEoFKW3hRSmd4aUpRSkVKZ0pUmnVKf/hCBF6SQ0ppkkQEcZJMBFtKb3hHSkvKV0p7dR2Se4RpmqOSY4RuSmuSZWgoymrEeMpGxFTKdsRExGzKUFJRxFhSYcpVqkcAKspJJ

FskRspc4haaTspcq4pSfspEWFliVzJhyDZSdOp/ZHmgBcprZFXKbip1PC3KZ0+9ymGUfkBFUkDfr8pximaSW/imlFfKXkB5qkRYX8p7UlzUZ1JC1HrxmVRvUmgqQNJ4KmbYJ1QUKmdps1R2laTSXCpHVGzSbpQ3rrIqX1Rl1GPUddRJGa3URtJD1E4qS1JPan1SnNwB0nJ0dCgx0kPYqdJHNHkqU/RlKkv0aqWNKkf0XSpN9GMqUgpT0k0ydqxAj

GlKR9JsjHeHLypFqn8qX9JDTF5MagAQMlSqRDJtukFMdKpkqm9MZUxsMmqSZbpCqldIEjJTXHfxqjJMLHCcam0+ukl1Nqp2rHmsd6xNJGEyR6xRqmkyaapdrHk6Srp1MmsqTOxtqlzsfaprnCOqcOxzMmuqenp7qmw6Z6pGLG8yVsevqmCyWSSwslkqcGpw4qhqbtxEakHcVGp+XExqUVxislnccrJSakVcTCB6slpqZrJtXGZqbrJHv67qa1xRs

l3QgWpUqBmycWp+WylqRQywKA2yZWpw3G9rmDx43H48t4cUPHPqU2pzm4I8b0cK3E+yfdCIRw1cF2plemByZWgwcn4aaHJdOmT8dPxw6lRyWOpi/FqHCvxdMIJyTOpHhFzqSnJO/F7pHvxmclH8Wup+gC5yfnJYErbqcXJLXE4CVkh5cldaUepXSCQiViJj6a4iQ3JF6kytK/m16koiRryHclumgyBsWnQ8YJUr6m5/qfAwQBuiDWJo8lECmRicP

STyQBpLBZX1F2quVZsiUta4YBe2HSxJjHIhBQA9AD4IowZ0Yh/EfKBkOr8iSoS2BZ3Iu3wvyTakPaYWV7j0WYID8F8UR28dzE0cdTudHFRWma2jHHKiUnhqomyCYtC6Gh8INR2yuJZ4UHxGgkh8frRGrGH6m6ClL5/AYCK5x5KpsXSWmyEGSeiX9JhiPfKBGqtoFZwJ9SBZE14EBoklIJib7SG0Z2RJqa6GY9mvwFE/oYZOL7GGR1YphlvSvmyvT

JWGcoWNhm3jHd0jhmlHNDCbhquGeORA8DkIX8eWPGkCeMxVxH8ONhRsmFaMXBpxPGYwaISYkJCng4JzAlToRwREQmVePoAYuCUgG0cIiHH0ODMpSSIOB6cQ4ELZCOBkWiiGdHhFbEGgaIJcVHGgY3x/EHvkQ2xaTAKGXLWyoIKUVYowoYZnItcC8KhQYCxeVH6iXHRRpB61pjAvMwVGZIAsyphAEGEDMiizIEqEszXgaEqi+A21o+BR8z8UKjojt

ZUGYkqCDFGLpEJNwB34H4CUWFSnurEnBm04s5xg0A4nqbE0onpCf0JiIBUEvHWiYiJ1v+xNbGAcXlhchn0MVMJRWF/IX56TCjv4Z3xT4AEMfFGH6FWIXrRiHHUGeJSjQmiBjScdtyWgPgAszDJAPOAeqFssefQxwkqEq8azVz+mpSa00DNqKPKXnET0b5xXHoU7vqBH/aUoQqJr5GS8YCZbzF4MAMZfkGoAjnc/bgsoVqCryQwmSCJcJnxMYJx0C

E+wAZS8VAHwp0IgIK1MRIAIpk7aO9hLWhc9OSJFCFacWPuEGm6cXuxNdGSkcZxK3YbEEzem5FFGduRtfzJAPoAisARwIrAKkF7MewZbhT4mYwo3BksKNNAKQCaSPV2Qhl+yFSZwciqIJVSEhkZnlSe0hl4ruMJUvHAUmyZ+0GwNizcclEyenIieSAZEtHRcTFcMZFBqXGDqNxUc4iaSECCCZkziCBpZu6wwUkZ2nGqmdSJ4hgXCjBpmqFE8XMxhh

RvgLqZZFExDm3RWKggkHZuXYBo4byJHqrWmcz48fZyBIpgHbC5RHTi38xl8fyxdwmFEUIolOEBceOB5cE+0ZaRYwkVEYLBuiGBmdC2Nag+qCYoXVJqBAtA3O5TGTHRMxncMaLOyfQWSGeWebTi5pcAU7FysGuZNw4xJiJU8SaKmYkZJAlZmcDhkGkYgiERBPEFmVkZRZlIIsBApZmJsTTxiRFciQ4kVxkdbv+BFVjoBq+AjxmJEM8ZBYSvGbfoDy

HPbk8hE4ZUhKH8pjqdGQBx3RnNGkdOaCwTmcNaMwmOkVIRYYBPoRTREhhhelqAOJBAUUuZWhkImZxM+SBhYTvcMAD8sLgA9wAlsKQAcoEsgsHo9yKn3ISZLCg3wdmEs0CdsIRE+S4pCfIR9wnKIBzB/ZkNzoOZwXHDmTIZfpnMmX0ZrJknTlCZM5nzXpdOaQi/nOChSk6CmVoJD46v5q1EOsA4oEbiLuyWRLJx/WBOkMpZwyAJ/iz6y2h+otixr1

FBsVVBH1FkCWqZNIkamUZxddEEWXaeWvHPERuRZZmNbvQZxCizMO1sbAAqwBQAbADIccIRl47eqLaZq7DXmD2w2FlaTA5GTcyumTKJ7pmCnrSZ644WkdQxglmjmcBx8hkiwRwg80Crkn0ul470dvyZqrHJcaHx0CGcRvNg+fKTII6iSBSFWayKhlkvURyh+uFwjsEawpEEsRZZuZlTMRkZMzGFmeSxJ4ahqI+ZSOFXsS+ZNNjOwIvoCQ43AIrA7C

HHkfWZtFmJEuzxZvEx7nEA59jweFGA8Bju5KIOJbGcWYoRRkyemS8JUFl/GTBZWhG8hrakCFl6ERIQsGjfMeiRG9b6JNaSCJqrCYfR7OBogACQ1Ykx4m46gWBebGpeZfo7mVJkN1nmWHdZvhQPWdVESy7PWceZGZmnmSqZ55kNWZeZ5uHTMWERZLG2UZsiyQB6XlSxUfGFGfERxRm2nBcZVxlUWfy4txnHbOogmJ6ZNpzx1Iamei0Zx0DGkSoRJA

ZtJP1eBxoQWfr278FPMbjR7vHhcamqe1n2kbLxJNGr+BKIRjwi0LyEqY6LmdGZy5mxmQRZ5V6w2QUZ2wnGROIqvoA1QA+Q97zCEc2oBJlP1syIvWLhxCwwVwKr+PA2C0FLWT2ZMrhQkWtZVbEbWW8Jm0FMmWOZVRH02bvKFjj83sdZFJo1JIUwOonVCZCh3pFtEegA7sAs+uwyTEk3INz0nXIo3m4ZMs522fcADtmvYfQULtl/WQbhtVljMTjxs5

HIwVZZENlamdQZDFHImcb2epkI2QaZ22y8xrkgzADLgGMASfGWmaHYHmKNmQFZ++hZKBkSjrysWVxRYlwRWVxZUVnKEZkJqhE5CVrZC9ES8ZIJXnpE/AbZoUaJAIYhoZkYfMXu6/hwtpbZV0H98Sx26ACzum4myAS92fZwaZnm/mZZKRnAMQj4eZmNQS1Zt5ltWdqZnTpR2VwhXVnPmdZxWKj3kBQAPTj3ADAAvoCZqBLZGdlB+E2ZN3aqgWVhbb

DgEIrZYt63CUXZK1ldvG0ZdJmlEfRxoXGJWVIJ5Mz12daBcDbiwTrePZDq4Lkg7pgXWeqxcZnkSPGIVObutFoWUuRrnFKZ6AD/2ZRIgDl0SMA5QoCgOScRxlnVWcTeAdnY8aox5W6gMYROmpk2WQcZwoH2WeuRjuGWcQkRy9nnGW+ZTixZhqchGpHqxA6A35mRzmcJ+5x42TcxP/CtWqSeBeRF5OBZxjqDvBTZF6FU2TShkrHCWZMJ9dkq0SSaAB

RrYbFx2+wGxCDuP9kpcQRZTYGbCZVeK+HDwLMwzsB1fh6ECXYOgNDMakD0WQtkLLpFUnre3OFaTDcJHFmq2SJCTDnX2bFZmZF32YqJHwn+mXTZJ05PsLqsEc66kFVYYN4VkXhZQpmgsdQ4K7Q+wDxyEULqwFx2KyAzIN45rkIVWYQJm7FIOdd6gNkikReZ31HoOdrO4DF/UVlcyQDPgTjBZ7HR2U5ZMcEVmTTY0Yjkuj9AhICNQO1BuJm2GN+Ee9

lZ2TLZWGSBBlXIIFCb+KJcybgX2SWEJdlyiT6hDJkjmUqJetkqifXBe8phoSbZ4O5DmNY4iXGc2fxxrjkKWVDehzARAQQMTBQjOaxwYzmq9OmZ/tnhOdOR6Jxq/BPZVlHg2a1ZkNntWSRB/NkToWwR+pmsCfhSWWC0gqTBaIDEAMphBTmGOEU541m8DteYYahSwUQxVzHdmcfhBkwz0aY59S5DmfFZvpkP2bXZr/jP2bZ804BqIHMQdtoCUIXOOF

lc2YM5BokPjvwOP3LS9MUKFWAZUMXg8QBhkJpe6l4vWdFB7fCTOb6A0LmwuSHiCLlbUEi5ftk1WXM5KjELOYFStIk03tr8dN424QRZqkFmccbRFnErMUvZJRkd2tbOsQl3GR0JAKGZNptCHfyAWRk6Q0B9/LHWGWG8UljRTTkJWS05SVlAmQI5xWEFWNo68NySWRYGjkCOuNhGSXF4kdoZ1Bn5Ock52vFNCSk83InYIJFhf4FnIY+ArLmxEH1u++

jnWU3MQtHaEjY2IFm5OuaRMtiwQbTh4rH04T0ZzfFP2aBxCEIlYY/hyLZ22sfYJlxVWR3Z7cHq8dqZ2MEsiSRROvG3/IrAvQIUAJgAszDb2cnxx2wNmUH4KXitQkkABsR52QShRbEFEQ85azqsIk8JQlGa2c+RXi7vCbrZorksmbdI3zmoAkOAMHic9u/ZVfhKYJpCGhmgiXyeeVmgsZRYLPpgrldhBzS5vhepzlJLDE4O8gJdaJ9iZHj7iAW+34

7IBM253OrRKe25+In0GFHsXbn1aBYOWzRjaMqyA7mCgEO5dg6MOlPu08HKMb2hqDmBUpQJB7FxOUexuRlhwWq5Dln4OXS5VnEMuWiEJ17kOejZLCAy2r1uz7FtEN0JGfzhruqez244aHhoQi60cSJRNZBV2XxBsFmvtppc4rmgmSTRhTDy4jK5Rly8hJhGkxk4kQM5YImNudqZG8HHuXg5Ip7sXCCQm+oJABTiECxHCeHOzPg76EKJ9DZk/N1idz

m1OVEU9Tka2bFRebniCSV220HJWX/BbCRLXD52DjH+9sC5sHkNucq5A6i9wU/gujII5GueMYH4YegAnHlTzvDkir5HdHi5YTlf+lu5RLnhGqHZqznh2QRZw1lBuSk5C9mvEbwhO9y9AhZC9wD3kNzk5cJ3GSM2vW6h0ZNZkDgKBAoJVci95FBSnkRdmSR5rkZkec85QXGisUK57zkiuY/ZddknTiThBapdPIqQImBO0VGZrHkIcW45GrFwfu9ZbV

DIBIF5sbLUKiE5w9mAMaPZUTkgMfORpLm8UXeZUNmbIfPZLxEsCap5+FLOwKmx4oCqeDcAJzkjWRwZjcz6ee+GyNwdsEWx59nhrrKJ5HkdGZR5eQnPMTTZnwkBmSLB/zEAiX6aB7Z1uQKZMZmLWgOocH5lvj/AIXm/jr15c5BieYr2m7kYUakZ0TlxeZPhYdlYOdUs0zCdWSp5KOGkun4AJ8KX7A5AqjkrCbh5Bnl3IqiQRvhDYQACZ9mGORm5xd

kxFKXZZ+EiCfSZAlmOeVY5fDlfCfohJlw5EeB5vgSZ/HOO2oIwecHxcHnseezgo0mdppZgnP7VTpJqv3kGusN5gOFnmZE5wNkTeVeZGqGGcdN5EDEEWTiZSHmOUYahOznpeaS6vczMADiQNwD4AIG5EtlrGp/8eHk5UkKAzOxPsJrsimCXMQ8i5PZHoc8ir7nZuZWxFHn18V0ZDrn/uTyOmoClucqCxtioWSyhmJDgFI8s/TnveWx5CJlH0f66Pa

7iyG4ayATH0eu6KmQi+X0YQzGIOaZZUXlB2Wox+E4xOUwhsnkzeQk5Y6GyOXDZRBYEOYjZzQn1AGiEWOGdbvph7QlemlZByipPueko+NkvIk4uaNEfIkkCdfEjCS7xYlFCWa05tHnTCQ6RYJmagqhG6Fn+NoA86/x8cXz5fnlDOVDZeXmKeeq5KJm1/HGA2ACXwsPAIJB2gEOOMbm2RBIhFSTZaJkOC2QokMzsHnH2QHyxi1n3OSxBpJA2eTFZLz

n8WW85WiFOeZ85u1kA3iAOeoaPeZtiaFhMeSx5gflVnrMZilnHvhv+e4i+gAscyLkWYG35kE4d+V35wPl+EckZCvloOZN5uFFkufhRFLkHGfbWBjFN0eyJDq5nGQIENoDzMFlgcADBwPQAGzn5eVaZenkp+R/hnIJ5ess6xHkVeYX5NPntGRd5pflzYTXZ4k5fObY5lKr57plRzDDVyDhEttqKufCZ/nlxmXEAcGCscLOEHybf+YGxsvlKCYPhoP

n1WTmZINnj4c1ZKznT2Ws52pkNYSl5jllPmee5NJxsANUAN8yasMoAtjFp2TRZwPxWgHv5hnldak/ASOpH+RCRe8gn+WjR53m32T6ZZfnXea75Yrn1wTyEIjm+8WeOzxripFUJsJk5WUq5AvmPYflukfr3onAA3fkQAKRuPAXkAHwFg/mUIQDZ8zltTsS5MnlQBXJ5Bxlw4Qj55nHbObHZuzmkurnKloDViPoANoC0uon5z0gbeb1uuAUAUHMQrL

qH+ZZ5x/kneQ05VDFZkcK51AVFuSJZJbliWYOAzRG1+VMoSSBUOZ46r/nyWWC5wznQ3nA5iuENcI0k5rqiBaMxKDlSeWr2JLlTear5sPkHGXbhCgU0uUoFOvlx2TvcUfn2wFAAdoD0ADwA+jGnOZQ5uPm06AYFlRDjgB2w3lrgPGWeHCTVOX+8HjHI0V88fC4mkeQFcVlWBVd5hbnOeTf5JQkAFPp2PzF+Nn6svOFSUJI58HlxmYAAMuTqpuyyTm

z72p4B4GzIBAMFYBZDBWEAIwWnAd8gMvlgaaN5ZlExeSiOY/mZGRP5DIm6MQk5c+Ga+QLZRjHkUS5ZlCDciWiEH5l6uYFYd7kVJNn55vnu/Fy5TXwmOW+5ZJ6sOQ75ouxO+QxxLvm2Bfw5LrlJWiSusGAwIF08/cooNn05b3maGR95+FkHGayxsQVbCe744IgoFNGIz0GquYxRxKiWOKBgL4CjKHIEgZ7DgFKkizr1ogd5KtlHeXAQpAU8WdGufF

n2eZd5VAWNBRX54cys+ctip7jP4VW5ySimedo6FtlsBfBxzfkrmcKZoRygIL1RzDQLHPZgvoD10H5stmDVThyFZ1H3cJ35yhZ8hSWAAoWiBcqZEgVlblIFyvlRsa8KU/mzedEREIXUsVHBHIkHBZUA6/qEgPVASzDKAKnZ1Fl4mTv5J0SohTCaB/kSiXIRuIX5+SQF5gVVeef59QVkhVf52hGV+YyhOSze+UrxySj2fKTAzjlAsaC5Lfmrmdyxf/

mZ0cu4QYULMdpaMUJKMUAFETkgBWGx0mHhBeP5CXkz2dQZjxG4OYj5tLlwMfS5NJy+wM7AcYAJAL6A0YjY+ToFj4CFeRcFpvG6xBaFYVm5+VZ5KiB2hbZ5xIXyiaSFl/kAmTQFxbks+a557DFoWZ6F7hSTgHmauAW+ueYRv9kfLN2a4YWZQTNR/A6pbEEF4GlA2aAFEPmg2RAFsGnrBfBp9xEEWTKROwVbOcsxmYWIBbX8FEaCOpIA2AA3+ut535

lmhRo6/qDiiVWFVoV5+cLR1nl1hUX5dnmNhRf5BbnOhTtZlIWuee6OBnkP+dIg3J6sMI35wIX8+e/5A6iTQNxUvgXOESamQEWWKVOFiwWhsbjxmJwKhdQJSoUrhQcZfpHUuVsJewXlmZyJNNi2QI4UszDLYOHxOPnqOY+A5YV2mZNAjMzpzNUwx+43CRT5OoFFKsFa9oUUBb92jJnPhXBZgHkiwRiQuAWfhXn8uUS5PL+F9blB+V4F0CEMvn8gU3

D/BkAc/fI8FMgEgkXY8hsGokVtbNaJxdFGWUYhZdHThWD5s4WzdtIFS4XZGTPhgnzhXvN5aXmLeft2RwUDxG0J+rlemg62VwU2zDcFiw7ZCSBZAwmhYnT5jvlUeQ32NHm0BTLx2dZuuTCQZPxVWRxFQaiLXDmavoXTGf6FbIXtWURRhvbIeSbRdvCNQDaAhACQcKXc4IUIhXEJOHlB+J16cgQ52Uqi7OEOMReF7FnWhdeFtYUemfWF3qGWBRY5jE

Uthe8Ft3lNse6ZyfkLCRvWq/i6QHhYHgWdeQPx7KqEpghI/oDGbCNpNrFhaYkK3mTNRfIcbUWxKR1FlFoMcBuxkXl1WeZZqkUh2XBFQ6HkuYhFs3n2UWmFigWbhdTx24XbbA0AJbBCADVAWWBGAHFFvlkmhZ/8yUXmhZtAJgXVhWYFeUV3hQ2FjTlNhU+FJUVNBa6FqVHg2JUJLKE70bDEQTZyQR153NldeezggPAcIMGFfgWfRRM5o4W/0aE5I3

nRhbKFiMGwRasFU9kaRYl57VkA0ShF6oVU8ZqFi/nIhL7AGbGpesoAofm+WaWFJ0T7RUdalYU4hVeF2hKVeflFTvEOeU6F10UUhfBZt/mTgF5Fojnw7IAoveSFXsyFffG1CRcOCBTR+j9FoEUyzsf6HMURhUw6b1HBBcP527nSeZNFtxHQxdqZzNHrhQvhi0WIxWsxWKiScI1AEoCWgFAAp8HFhVUwegVsTqHqhnlGBeeF+MU1hUTFZ0UFRZmeRU

XNOTYFN0WvhX/BHLo+8WAOyi6F4OtCYo68+X+FfEUBhdAhdZQRASNBmllsxeAQg9n/+f/RAsXABWNFcYXqmSLFh7GMidjsyQCxGXAFp7lbhYQ57vgqwJIAMqo5UAeRqjk5Bc9ImsWUhp+g1yINdlbYc47uMTWFfQl0RXUFxsXWBeSF1/m3RR8xKdwbzIoJ3YUI7CiQKKI+eU35Ql78RaCxgACg5FtwlgCR0DC+kJwKYg6Io3jIBK3F03ELep3FBI

E9xe948wXECcg5gsWhBf4OTVkksTeZUMXJhQRZDdGSxUwJ2vlnuTHFSNn6+THUxkVnBV6aTV6kXurFcZ4TWVb5H7EmkRLRO2rvbtV5Xs6ORfTutNnOua5FxNHuRXZ8cuJdhXSFbRCKUQDI7dlMxTUJ1tl1CdpFUDHLxazRFWInUOkuisDEAJ06vlmJRTeSPqhyBAThw4BKBJSqnO6f1sdFxAVumbeFp/k32YXFlAXNhbw5rYV2Be2Ff8GAUVbFF0

7w7OA8Ki45nD0Fn3lNRWZWLUX4IKC4wpb4FAypaPLdRdQlvUV0JcDyjCWzeNKFykWxhTBFYAX5mdD5kQXxObkZmQVqhVr5aEXOWUjFyng3AISALPocAAkADFE7Rd+ZQoYHRdiFZOEnRdFZ6CVmOa85joXYJfV51jl3xXdF+LC8Eh55HpEagqWG2VkshY3FzsWgsYDwVcg8xWOFaN62JeEMkEUgxYS5kgXCxRDFkAXzxdAF1BmjhZHFwNHRxbr522

zOMjw01QCEgDKqRwlYxZ/8yiW4xYdFloVZRQTFUt4EhZNhzwm5ufT50FmM+dtZzEWmmFSF/sTSWRNazgXwOMrsW0Av+Q7FvEWshbGZEIl8GfYlHsXo3tUlAMUKRUDFgAWZmTGFAcW8JXOF4AWzxQIlMgVq+bkZlLGiJbsFNLEyxcmxAgTtytUAJ1BwYGwZRoW2GAfF0SXQJQx6Z4VtaplF3FEX6IklEEHJJTUFqSX2RZTZ9rl1eU3xt8UueYyh9o

FcXrTFEHmaQqTAfJn89uwFb/nB+TYl5WbjOd+aLiUtJaDFVdEdJfwlYDGYOVEFs3lxsQAlc/kx2QkFKgVrtr6ANoA6ullgCy7bRarFUCAERf7qxXlqrNNB2WhK7N2wYcS5xe+x5bEGxSTFl0U62UxFAHk5JQDevezjQNR2fgSDGhQlnAUZsIAAPBuAAGP7opa9KR4Rm+pNkQ0AbWhggMgElKXUpbdp9mB0pc4ADKV0pWPFFIlQRTuxgcV48TPF15

ndJd4lsgWzeSexoUXphfEFa8VBJbJ8kQnqbEy5hvGe8NmEkGhGuaRgZRh3bpZFfZJopQLxX7Hvkp+5mNEy0WKxrvGZJSleL4WUxffFYHEZmm78DAXWxX42jkDcQpbAjMUWJczFP8UCgdpFyHH+JeFFr5kKpVE6NxkXbjCQVI7xuWqlOAUd/KilwrFqnpLRF8VcQR4uNXkM+XsljrkHJc0F7vmM2Y/FiqSlwB55Iaip4O151yWeBdYl2pmmcfNFcQ

XR8Wu2IJDLgHaALFgtYMkAAe6QpdnkLsL57sNI9pnK2r3wEqS9sOCRlPmo6jqlZAVbJZfFIwn5uVil5MWlxebFd0XFLtdsn4VbENhkdUVlJW9FgUWVJezghsCGDPr6Lck3qdCgnZZGUjaiNEwdCJqweUHfVjQCS6VEiSul6iYLaBulRgweUL45OuqTka4lknnuJWr2u7l0iaKlvSWKzMkA5PG/JTAx/yUypYkFYirypU4shvmfmYGlV26h6HeSpn

ppdqiuRjnPwcBZuqWvbNa52iVq4NfF/tE3eY15lqWuuctitzo8ZBxFjMCrYhWe9UXvRQfWs3ma8ZKlC0XocXbwcAAtYDsxNUAgkOS6qjmoaAv4XNhfoDeYqhCjAnhkbFkrJVXOesUvwcTFTwVcObsl1Nn7JQ15Njl/wb+gHbid8ZT61yI5pZYlRt5zpc8CwqZkgZqwfkI9CA9iKWBrmS7AQIIxQTJlFqLyZfs0imW1DMplPsXjxQS516VyhR4lkP

kGcR8l1llfJQk54fFepRmFS0XrxZH59sA4QPgAzsDdgFRlD3m9brEGMJoFBazc1ijd9neY3o5AECIZDDkRrlm53aU5udslXGUmpQmlTPlFCbklaa4F/C/F4dGWBoXO13bTpbmlDUXd2RAA3rpD9OdRMUpuIsDQo/SVNElKqKl5NBC4hJRzgGCAe2x3ALOswdTljB0EbgC+AEmkvnT9VD1Ml+yQ0MNM1mYKlveym7rPFF0g0XAKlFcgV3CFVFtgF6

o9FDFkq0mKVm1F1xbkbrGBEgCZZdrQw/TgMprQuWV6GRU02qCFZZdR3fQrOKVlWQQVZa8+1WWUjAKgdWUj4MoWCB4wdPS2jMIViG1lB4xhgZ1lHObdZZZAmtB9ZWGkLwxDZSdUI2V31GNlD/oTZW7GSmK/0W/6J5kTxf7F0Xng+WpFwcX7uaHF2kX0CVZl0qWBJZ+lJHrfpRPI28UTQABlEnqZNjNccuSgZXiFRpHq2e7OESwYpQtkcGWyGbglHw

VIZV8F3qy+njZoHWr2QF5hImD+RbhZIIXv+QRZNglQ5SWl7Fw3AL/AhACWwM7A3oaYBZvo1GVfhE1Whnn3mJxCAlAZRbrFyWHY5eilnGV2uRFlPGWJpXxlBiXlxetAnbDN2ersz7CYkBZ4AfmOxRUlH0VMWBQ40InG7rrAayD8sAQYJBSmlJ/0krA/+SUWBuXVBEnAxuXM9Ps0ZDbm5cawXCV8pVSJAqXgxcZlVAlTRZP5M0UJOQ0Jr6UJsYvZy0

U73JoAmADZgB5Z+AAUANoFPOW2GHzlSUWV8c1eiyVIGLyxBdljkBziecXV8Wd5PaUOhUXFDQXYpcz5wJmMMW4EEZnHQaclMohr5Hvs0c4pZeJle4FBRRqxnsDsoFcgK3ouiIlg8AlLBsMcQX7BbvMcdaCgyp+iowUwYmVKwIGOahOuddzzSt1Q7KCuIo8gYwZyvjAeiHDTqQ6J3bKTnoP0XqnNrL5wXSBD8jFuDbRWKZk+Phn1un4ZCeJcdo3lrS

Yt5frQX+mNBB3lTDQ0/g9yPeXJVghuIv4KYqMyQ+WyGnRu9SLj5QWyU+Wd0suec+Xilgvln4hL5SDyCnGr5W1g6+VKVL6UW+V60DvlvLS+GUAWB+UYTkpFruXZme7lkzHqRUmFPiUEWRsJcMViJUMlC/myxcQ5jgBGRcy5GNl1pcz45blUIvuceJ6lsZ/QNJmQZR7OUuVGfC8F99nl+UOlFqUppW5Fy2IcJIUgGkIyILeYTrgkpQzlBxnMiczlRG

VYqPOAjUCKwFS6QgAqwD5ZtaWuZTeSn5yxkRtAnwCWwDMo8SUsZcWxayVFKvnFHGUV2XGlGSWRZVklOKVhIDFlHBJpRLIVVUUUmh1SMiC5rthls6U65XKwuDjJytzQirQ9CFyBjsD3AAQYDAJHuQ4lLhEOFVMKRgyLCK4VLPoeFRwyLuVXpWN5Y9lLIZ4li4WoFWKlWVz6OvkZG4Xw2QClKPlApWlQ+ACYAMLxNaUx5YY4ceU3klt599C2QMBQBV

JqIMk4SJoBWOnlvQmZ5fzi2eX0RaMJxcX55dFlK4EQDnbaFkGG6CnCX8VW2apRNZ6VANWa5AD/BoIAS8DA0GvgLYjAalQc7NKc0jxINowJppWqyYw0VJlQXSDzUOZwd8iCapxq6nCV1BUW0WBnIEB0ObqpFvOISBonlibGY5StoLRqYGyL6qwAvuJHcOPJtmBTZfx5EAC9FRsGAxXE4l50V4jgsi5sI5S6ihMVgbRTFdIWWXRGHKJIcxUZUAsVvY

jLFV7UqxVqAOsVJcq99Da0OxVUHCOo+xVC5ocVY+UnFZn62xgsFpcVv6nXFTylSpncJW0lwdlK+VEVc8UxFY+l2OycpBEOhjHYFcYxkiWHBZuyNyS/gUo6FDkY2btFTGATWSMs/5mEEkqeN/YigtQVtvnjbnZFvaU7JTLlPDl6JQhl/GWsFQ/FxeVd8SrlMogOgCg2M1xiZa6lXRXBYYrMM0BEWV+lNJV71OKeiOW77kxgREUWaNkOd7i/JJyVUe

rU+bb5JpVemVIZCV7cOYvRJcUuhcOliuWBWEEG3M52pQtebgWYZPXFWuVWJXXlS1pDQKqVpLoXvGOAw8CYAOMl8IUS2dESfBIa1g729xp9yptCh+ijKCT2OFg0UlkS1CLd6OOA7KI/vOXxCZ5apJoVVRUbTjUVmCUMRSbFNpXmpSxFjKGLXmGALKGW2BBxmuXlJZ6VkmVysGSlgADJ+/+p08nPGNyg5BnMHCygLCVN5aAeUMJjis4B+iKyYkYyvQ

BQcB1QWgDOAPscqHAJsl0gPaBzjAOgSqCLjBlw9sCEgNVESmzX7MkEgcr2YJtMZ/L9SmVw3EBpPsylTZXzrKQZUYLtldZsnZVsoBPyzeUZDI4cfZVxfgOVCZRdNLyAlgCjlZoA45VyaXvmkqDTlSmkcqAXdPOVV3SLlcuVKP5rle0KGXBblekiq5S7lYHg+5UXpRu5YRVLBcDl8F4ElSKlRJXmZaISjkC6Rcj5+kXsXCEAbACSAISAb5IYxarF9x

lVwpnBBPnhgIUFEZkhevkRAWVpCfiFaCUhZbT5/JXhZc75HznMFSWVd0Vd2NgsXVKM+LUwlyWvRallOGXpZdeM4PR2GZD0jQzQ9G2Vc8nPjNFk/tpvjIuyBmSfjKj0r9Tv1OYcGWR/jDZkOWSATA5kBWQuZMVkpPTlZCGFpqaH1C8U4RlQ9A+MamQGJrfUOmTvjApVz9RKVd+MH9RqVVlkAEz/1DpVwDQk9KVkuKCoUfAVcFXQRXiVnPCg5Z8lQi

XKlX8aAeVUGWk5dBlUlXaVtvycCSy5Pq7degqST7k0huGuQgkMVWf5tRUMFZY5BQkVDn4uMgmDGShlPkVv2ZuBlij2gV1qNNG6iXTRglW26DoJ6N7WwCghGBkvqX6y2BnwiiQZLZWO3gYAovmGFJOAj6j2CYkVCSrGXs4JxoZmXta8Fl7YCJ4JloZ5kjaGdOR+CcWSAQlOXkEJDKiuXi6GNZJuhrX8IJClicQ0dQB70KiEU05nfKoI4baqvCGlC4

4o3AaRy1ngZdzo2hWUMUbFg0AE5dKAB04sXhpceVXsmUwxtTCXXoUlOSC4WH6s5iVXJTXlsaFelTKOiA55jsF8uDEuXN160zZgAAkgDESKTIrg304XXL9OJk4nfOZOe1UMxPgONY7L9rZOfZyQzk2OJk5OTjv21Sw+qL6VpaUbVbsgW1VtbtG5DyQMlbp46TbM+KZ6ThgC0eHq3PEZBtzi3FmfsaBZpNnS0ba5l+GCldaVDRUDWk9VGSxIWWCZyh

URRp+FwAQ/zDTlfBW3JSt29oCE1excvoCWgIQAy4BmQr6AZ4a49mfwgaiZ+VJQukDcQnNOc0BokFZGl8TluaGAaIUbQClaJcjn8KfocTiALDRVdIA/JEzVA9bsZZLlOhXpJZtZpqWHTgB5/NWTmWv8gZrhMa/Fy/imeNmuktVNxQF5frKQgEgMYnIQiIwAW1CAACnkIXmh1QOCmQQ8ipHV4QCoALHV7sEjRYHZQsVq9ukZXSWmZTD5wVUklWheYV

WRwQjFOBUjJciE61XmgCTVezI7VQZow8Tq1fj2MJDWLmpAwGVP0KdVYGUi0RGll1VfuRKC4Y440f9s91WFCXzVnTA/CcqCPwXJOBVhagSfVbTlILn05VLVbDxqTrKOY/ZDNjLMV7hKjlM2QbxvTpDVFMgw1eF8pY7/TnP2/05I1TYJwM4EDus2eo52TmTEuNXljlv2ZA541XEVMNkDJX1V7viV1ZtVezI14uTVSZiU1eT6qGTN1WiwtST0OcUS9t

Xmdl2lhIUiQt+xBqUc1dxBfaW3VaxVtpWtyCuGErn+xJYGa4Grkmo5dkDQebTRu2FpZT6RaFV82U/VUsXCFTTY+gCWWJViyQAHhQl2gDym1YpgSzqCpIOAxtlKgaqBeGRbnAe2e+yJlTLkSvD3LJ7cbaVdVhUFxBLANY92J8XRUXmV5jlYJVdFOCWlRYKIntWs4dnqnFGccRmc8Jrv4eouHRWd2SzFalGG5kTAUqDqAC8UUQCAgKnVIXl1uiFQ2j

UcJno1adXwOUaVCwW+Vfyl7SXFxDnVwqV51YIlB7nKlZHZxdXnse+lMOWApah5xNXSQHvQUrYe6nXVTE4dhmq8jZlGYa3V08ThrrRF3dWSGd+5iRCwNW3oUWXD1QGwo9WSudaAHgR/BQOEw4A0OTYVc9XB1QvVJZzBvKgOL04r1R0AyXbL1fKOkbwFPLS8czYYDgs2B9XHfIs2x9VQJKjV1k7o1RfVmNWGjlDOzY7b9l1Vc9muNWj25ELeNac0xI

5OYNvFKRJzZC72ADVapZE19wUsORSe4VrQNQKVLFVMFfA1EQSINcB5j8XH2Lnq3FW56ofk1ZUzpTk1+aXelTg5BGXFpUQ1AgTLABHA0KjRiKbQCXZF4NwOikVt/ExSIGAIGPihxsS3kRE1dwWaJcX5JIWPhQOlEjVmxQg1aomdLn4UTpXEJerswQZIGHJOQdWHNQOo1ArMAJ2qpnCyvCnVDQB9iFBV+jVgObLO90AItcnVW1AotWiAaLVmNS/68R

kZ1SEFN6X+DnY1UPkONT0lqFXKlTI5mBWDJRqFZdW08RXVgzVO8MaytdVDxIE1fobBNXR6hHGIdqX2KCXmYUIkBcWiNbE1tXmEzIPVOVVU3NI1+1nxIMLeUpUEREJo0ygC5QOFarEpcQDVuY5lNYS8pTWaTq9OLES0ekU1+3y1NUy8h9VMvI0153zNNVsoNk5tNa9cHTXY1TfV19VIIjaASTlh+Se5KHl28K/VuyBstWTVozUGuUEU44701Q684u

XFEQY6ZpGTbmLx/dU81YOlKzUytQzZbBX+xG68oaFdUnOixeALmUCFNZUSZXVh+NWb+a61YUU9jlioV7wwAIQAS9gSWMIR7CT3NYFBN3afhtxkygTyBL5lvDU1hYTZZdm1BaK1dRV55dG1xZWxtYeOuIjsnu0Fwo4MxVY47pUZtbXldZXiocngpyA1gLkAXfLoSF5ghLWcxWto47VFOJO1uLXFUO6I6LXmNQkZ/1kA5a0lQOXjReu5nuV7uUFVTj

UklVS5RaWoRRSV+wVRVRIAnrXSQNT4kQkctcvk9dXc0RiQYw6hNR8kpmGBZTwAGBAIAOhVIrUwZTdV4rUD1bzVZXZdtQ3ZilE0xYwFvzFI5QSwTIUupd/FipUPTovVgNVatcF8OrUyzLvVfTaKhAa1JTWRgLDVHjzw1TfViNVPtSjVcXxn1aDOwTzgzvZOWNWOTjDOJ4Y2gPCFQhWC2TTYN7VKJpEJH9XbxXB4KhKJCY6gkzUJnunEfLrftb+1jy

G2ReG1rwm/uZoRZqXMRaB1gjmgxPkg7EVl5biw0kGRzj65KjV+uWsJ0tWBuYx17vjOwB5Z9HVW7C61whGmeYoVmkyxOFZB8hWn3HRlkhHZ3G68b1UC3skSwZ5E+tgsZK73wXw1ofC2cNbxpIiCda9ezbUiNf+1BZX1FR21UnUj1UC1Qxlq0ZW5XHG98B5Ee4bQtV6VA6hQ1qQAMG5zeoqm66oq0nO1btmevt50iXUHUMl1qZLrtUS1r2AktZPFZL

X+wSgVVW40tSSVXhWMdeIl6TkYRQIELHXGsve1/jWctdNO0p4vtSRVR1WAUO+1WqVtJOnY/PFpVRglrbV91VaV9TySte3OXyGgdaN8qoIOQAq14Chsgsb4CojZNf+F89UatQU1RLwodVM8aHVhvF9Om9X6tZU17064dXvVP05ljmJEFY5mTsR1QM5WTla1rTVgzpfVuDyOtRzIJo6dNffVaFWIebm1UqUs5R61gzUNdT61hBXonmZFjLrcdf/VTs

6M1R51SpgRgEvoJ16fsfnk3SSidZXZ4vF/uQYVrF7BdSFGMnWK7N167fZ9tdvsy1xzQDTgezUCVbYVuGVxFQp5WnUffNgAPojKAIRS9AmGdcGaRRXaOoxCkYDyGBPAqiAKBKdapnhd7Org0tnJnDt5ZniI7IjqLljIrjbVaQauxdoSPXUQ9RYF11X+de21/zUUxas1IXUFWM8a03X1Dph8KWJOtj9VCpWdsToZoBV1TlN4zYCpBKB+CEiEgC8A+A

Dh0Gl13hXuGVr18VA69djyL/6mcEb1JvXeVSZZIPk7tSP5zCqldTQJmwVoVcl5fTXKeXpFNsLgAEFARwBJBGfRSYDE5NAAQhoKvKAQkwAMAG1QFACXNUTZUGXDAM3QIgAm4OKAbKDmiAPWVVyZ9Yn1qWQp9WygcfU+dRJCSfXj4P5AqfWZAORw1XlF9bn1mQDp9UyILWAIAC+AEADSygsxlfUl9Wn19EADKe/KDfWg8e44LfU5AKX1+gA19YKVvf

VQAP311HD/ksP1/fWpcAvsE/VsoLL0nsHPwDP1ZfVGWeUki/X6AGggsHqr9ddJRk6srKv1dKVEdUxOq/WCRPOAoGhXQNn1yfWt9WX1aMDhlKcAieBVALTQqIBaWDchcQCG6EXWPqgSIryEUfVKbAzQhNjMeqXOv6CRoUxSQVgQAMUcrNbDVQwAAxx7QLfBRZgC4Kv1Y/UWmO/4ifWmgsc5M5Ar9UgNGIA40EAQUfVIDXdBm+rYIMEAn7BiqCQAo1

WQALlMxvU9AOgFuABMcEGobg7UDUugOzB6MvXcH8AYCa0A5A0tAM5QFRgWwNGAnA18dmOAnWAwDQbMLwDzgI0Ay2CAgDMkGADHEIP1bZy8MPn1KGBuKCdQk7Xl9a7Ww/WD9bYRroAOpF/IH8CsbkLE5CDSwoG0EkDAZAlwkWD03joJwGTCANsUI0TAZHtgdwCkAJ35wOQ24VYNTAC4DXoNZ4QwDXYAIJC7UMwARlBWYDgNPWDODfAoFLimbEINTw

B2Og+8+8C7UGkgzqADVcf1EJAWEU26A/VMbJJgaNWXAPwRgQ0AoHAS4rYwIbGAeA0wEPhU3UDmWEaADAjVQLzEF4gmadkA9MDNnNkNh0hBBH5QxAC2XF4NSQTLcE4N+A1vCsaQmADSZE2sroB3QZUAvrDVku4Qr9jhAFkwfOTbgEAAA=
```
%%