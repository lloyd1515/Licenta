---
tags: [literature, localization, ble, trilateration, path-loss, kalman-filter, particle-filter, ubertooth, hardware]
status: complete
updated: 2026-07-22
authors: ["Research Specialist Subagent"]
---

# Sinteză Algoritmică: Tehnici de Triangulație și Trilaterație Pasivă BLE în Medii Zgomotoase

Această sinteză analizează în profunzime tehnicile matematice, modelele de propagare RF și algoritmii de filtrare pentru localizarea pasivă a dispozitivelor Bluetooth Low Energy (BLE) și Bluetooth Classic (BR/EDR). Documentul integrează concluziile din lucrările de cercetare aflate în vault (`BluePIL` și `Determining the error distribution of BLE beacons at antenna near and far fields`) cu rezultatele cercetării web privind algoritmii avansați (**Weighted Least Squares - WLS**, **Extended Kalman Filter - EKF**, **Particle Filter - PF** și **NLOS Attenuation Modeling**).

---

## 1. Extracte și Sinteză din Articolele Academice din Vault

### 1.1. BluePIL: A Bluetooth-based PassIve Localization Method (Rodrigues et al., IFIP/IEEE 2021)

Lucrarea prezintă sistemul **BluePIL**, prima arhitectură streaming complet pasivă concepută pentru identificarea și localizarea dispozitivelor Bluetooth în timp cvasi-real utilizând senzori **Ubertooth One** și noduri de calcul cu resurse reduse (Raspberry Pi / ASUS Tinkerboard).

#### A. Identificare Pasivă fără MAC Randomization
- **BT Classic BR/EDR**: Folosește adresa hardware directă. Adresa EUI-48 este formată din LAP (Lower Address Part - 24 biți), UAP (Upper Address Part - 8 biți) și NAP (Non-significant Address Part - 16 biți).
- **Quasi-identificator LAP**: LAP este transmis necriptat în header-ul pachetelor de acces. Probabilitatea de coliziune a LAP pentru doi producători diferiți este calculată ca:
  $$P(\text{col}) = P(sC) \cdot P(dO) \approx 5.96 \times 10^{-8}$$
  Pentru o rețea cu 10.000 de dispozitive active, probabilitatea de coliziune a LAP este de doar $0.06\%$, ceea ce transformă LAP-ul într-un identificator unic practic în spații publice.

#### B. Pipeline-ul de Date Streaming (Node-Sink Topology)
1. **Sensor (Ubertooth One)**: Capturează pachete BT necriptate și extrage RSSI + LAP.
2. **Node (ASUS Tinkerboard / RPi)**: Execută identificarea adresei și **RSSI Filtering**.
3. **Sink (Central Laptop)**: Execută **RSSI Merger**, **Localization Algorithm** (Quadlateration LM) și **Location Filtering** (Kalman).
4. **Cloud / Dashboard**: Salvează și afișează pozițiile filtrate.

#### C. Pre-filtrare Zgomot RSSI (Unidirectional Outlier + Moving Window)
- Semnalele reflectate (multipath fading) parcurg distanțe mai lungi și ajung la receptor atenuate (RSSI scăzut). Semnalul în linie directă (LOS - Line of Sight) ajunge primul și are puterea maximă.
- **Strategie de filtrare**: Aplică un **Rolling Maximum Filter** pentru a reține doar vârfurile LOS, urmat de un **Rolling Mean/Median Filter** pe o fereastră temporală mobilă $[t_c - \Delta t, t_c]$.

#### D. Sincronizare și Fusion (RSSI Merger)
- Eșantioanele provenite de la senzorii Ubertooth sunt asincrone și au rate de eșantionare variabile/rare.
- **Interpolare Liniară**: Fluxul de emisie este amânat până când există eșantioane validate în timp atât *înainte* cât și *după* momentul $t_c$ de la toate ancorele active.

#### E. Algoritmul de Quadlaterare Modificat (Levenberg-Marquardt - LM)
Spre deosebire de metodele clasice care necesită o calibrare prealabilă a fiecărui dispozitiv țintă pentru a afla puterea la 1m ($RSS_C$), BluePIL estimează **simultan** poziția $(x, y)$ și parametrul $RSS_C$.

- **Modelul Log-Distance Path Loss (LDPL)**:
  $$RSS(d) = RSS_C - 10 n \log_{10}(d) \implies d = 10^{\frac{RSS_C - RSS(d)}{10n}}$$
- **Sistemul de Ecuații Cercului de Trilaterație**:
  $$(x - x_i)^2 + (y - y_i)^2 = d_i^2 = 10^{\frac{RSS_C - RSS_i}{5n}}, \quad i = 1 \dots k$$
- **Optimizare Non-liniară LM**:
  Vectorul de parametri extins este $\mathbf{p} = [x, y, RSS_C]^T$. Funcția reziduală minimizată pentru senzorul $i$ este:
  $$f_i(\mathbf{p}) = (x - x_i)^2 + (y - y_i)^2 - 10^{\frac{RSS_C - RSS_i}{5n}}$$
- **Matricea Jacobiană $J$ ($k \times 3$)**:
  $$J = \begin{bmatrix} 2(x - x_1) & 2(y - y_1) & -\frac{\ln 10}{5n} \cdot 10^{\frac{RSS_C - RSS_1}{5n}} \\ \vdots & \vdots & \vdots \\ 2(x - x_k) & 2(y - y_k) & -\frac{\ln 10}{5n} \cdot 10^{\frac{RSS_C - RSS_k}{5n}} \end{bmatrix}$$
- **Punctul de Pornire (Initial Guess)**:
  $$\mathbf{p}_0 = \left( \frac{\sum_{i=1}^k x_i}{k}, \frac{\sum_{i=1}^k y_i}{k}, -30 \text{ dBm} \right)$$
  unde $n$ este fixat empiric în funcție de mediu (ex. $n=2$ în spațiu liber/deschis).

#### F. Filtru Kalman Cinematic (Post-Poziționare)
- **Vectorul de Stare**: $s_k = [x_k, \dot{x}_k, y_k, \dot{y}_k]^T$ (coordonate și viteze).
- **Matricea de Tranziție**:
  $$F_k = \begin{bmatrix} 1 & \Delta t_k & 0 & 0 \\ 0 & 1 & 0 & 0 \\ 0 & 0 & 1 & \Delta t_k \\ 0 & 0 & 0 & 1 \end{bmatrix}$$
- **Covarianța Zgomotului de Proces $Q_k$** (Model Wiener / Zgomot Alb Discret cu $\sigma_v^2 = 0.001$):
  $$Q_k = \begin{bmatrix} \frac{1}{4}\Delta t_k^4 & \frac{1}{2}\Delta t_k^3 & 0 & 0 \\ \frac{1}{2}\Delta t_k^3 & \Delta t_k^2 & 0 & 0 \\ 0 & 0 & \frac{1}{4}\Delta t_k^4 & \frac{1}{2}\Delta t_k^3 \\ 0 & 0 & \frac{1}{2}\Delta t_k^3 & \Delta t_k^2 \end{bmatrix} \cdot \sigma_v^2$$
- **Matricea de Observație $H_k$ și Covarianța Zgomotului de Măsurare $R_k$**:
  $$H_k = \begin{bmatrix} 1 & 0 & 0 & 0 \\ 0 & 0 & 1 & 0 \end{bmatrix}, \quad R_k = \begin{bmatrix} 0.3 & 0 \\ 0 & 0.3 \end{bmatrix}$$

#### G. Rezultate Empirice
- Acuratețe medie indoor: **1.04 m** (spațiu deschis $4.2 \times 2.9\text{ m}$).
- Acuratețe medie outdoor: **1.40 m** (spațiu $5 \times 5\text{ m}$).
- **Limitare / Risc identificat**: Supraîncălzirea senzorilor Ubertooth One la temperaturi ambiente $> 30^\circ\text{C}$ duce la scăderea ratei de eșantionare de la $1.0\text{ pachete/sec}$ la $0.38\text{ pachete/sec}$, creând timpi fără suprapunere de date între ancore.

---

### 1.2. Determining the error distribution of BLE beacons at antenna near and far fields (Novytskyi et al., CEUR/CH&CMiGIN 2025)

Studiul investighează distribuția erorilor de măsurare RSSI și rata pierderii de pachete (packet loss) pentru transmisii BLE (ESP32-S3 NimBLE) recepționate de un sniffer Ubertooth One la distanțe cuprinse între 0 și 2 metri.

#### A. Modelul Matematic al Distribuiției Erorilor (Regresie Cubică)
Prin eșantionare la fiecare 5 cm în intervalul 0–2 m, numărul de pachete eronate/pierdute $E(l)$ în funcție de distanța $l$ (metri) este aproximat prin ecuația cubică:
$$E(l) \approx 71 l^3 - 196 l^2 + 151 l + 189$$
- Indice de determinare: $R^2 \approx 0.834$ (aproximează cu acuratețe legitatea distribuției erorilor).
- Criteriul Fisher: $F \approx 28.1$.
- Criteriul Durbin-Watson: $d_{DW} \approx 0.27 < 2$ (indică o autocorelație pozitivă puternică a erorilor în spațiu).

#### B. Comportamentul în Zonele Near-Field vs. Far-Field (Frecvența 2.402 GHz)
- Lungimea de undă $\lambda \approx 0.125\text{ m}$. Granita teoretică a câmpului apropiat reactiv/Fresnel este la aprox. $1.0\text{ m}$.
- **Vârf de Eroare în Near-Field**: În centrul zonei near-field ($0.35\text{ m} - 0.40\text{ m}$), numărul de pachete pierdute / eronate înregistrează un **maxim local neașteptat** ($E \approx 246$ pachete pierdute din 1000).
- **Mecanism Fizic**: Distorsiunile sunt cauzate de tranziția frontului de undă electromagnetică și de efectele de inducție reactivă în apropierea antenei emițătoare/receptoare.
- **Far-Field (> 1.0 m)**: Semnalul devine stabil, iar atenuarea respectă modelul logaritmic standard.

#### C. Parametri Cheie de Performanță Hardware
- **Puterea de Transmisie (Tx Power)**: Creșterea puterii ESP32 de la $-20\text{ dBm}$ (sau $-24\text{ dBm}$) la $+4\text{ dBm} \dots +18\text{ dBm}$ reduce erorile medii de distanță cu până la **66%**, obținând acurateți sub $0.45\text{ m}$.
- **Interferențe și Aglomerație Umană**:
  - Interferențele RF (Wi-Fi/ZigBee) reduc rata de livrare a pachetelor BLE cu $13\% \dots 40\%$.
  - Prezența masivă a persoanelor scăde acuratețea estimării distanței cu până la **41%**.

---

## 2. Sinteză Algoritmică și Formule Matematice pentru Medii Zgomotoase

Cercetarea pe web și literatura de specialitate indică 4 piloni matematici principali pentru depășirea zgomotului RF și atenuărilor non-line-of-sight (NLOS).

### 2.1. Modelul Extins Path Loss (LDPL + WAF + HBS)
Pentru a modela atenuarea semnalului prin obstacole rigide (pereți) și corpuri umane:
$$RSSI(d) = P_{tx} - PL(d_0) - 10 n \log_{10}\left(\frac{d}{d_0}\right) - \sum_{m=1}^{K} WAF_m - AF_{\text{body}} - X_\sigma$$

| Parametru | Descriere | Valori Uzuale / Recomandate |
|---|---|---|
| $P_{tx}$ | Puterea de transmisie la antena sursă | $-24\text{ dBm} \dots +18\text{ dBm}$ (ESP32) |
| $PL(d_0)$ | Pierderea de cale la distanța de referință $d_0=1\text{m}$ | $40 \dots 45\text{ dB}$ (la 2.4 GHz) |
| $n$ | Exponentul de atenuare al mediului (Path Loss Exponent) | $2.0$ (spațiu liber), $2.7-3.5$ (birouri), $4.0-5.0$ (hale/pereți rezonanți) |
| $WAF_m$ | Wall Attenuation Factor (Atenuare perete) | $3-4\text{ dB}$ (gips-carton), $7-12\text{ dB}$ (beton/cărămidă) |
| $AF_{\text{body}}$ | Human Body Shadowing (Ecranare corp uman) | $3-9\text{ dB}$ (atenuare directă la trecere om prin rază) |
| $X_\sigma$ | Zgomot gaussian de umbrire (Shadow Fading) | $X_\sigma \sim \mathcal{N}(0, \sigma^2)$, cu $\sigma \in [2.0, 6.0]\text{ dB}$ |

---

### 2.2. Weighted Least Squares (WLS)
Când măsurătorile de la ancore au variabilități diferite, metoda Least Squares standard oferă rezultate distorsionate de ancorele zgomotoase.

#### Formulare Matematică
Prin scăderea ultimei ecuații de cerc $k$ din primele $k-1$ ecuații, se obține sistemul liniarizat $A \mathbf{x} = \mathbf{b}$:
$$A = 2 \begin{bmatrix} (x_1 - x_k) & (y_1 - y_k) \\ (x_2 - x_k) & (y_2 - y_k) \\ \vdots & \vdots \\ (x_{k-1} - x_k) & (y_{k-1} - y_k) \end{bmatrix}, \quad \mathbf{b} = \begin{bmatrix} x_1^2 - x_k^2 + y_1^2 - y_k^2 + d_k^2 - d_1^2 \\ x_2^2 - x_k^2 + y_2^2 - y_k^2 + d_k^2 - d_2^2 \\ \vdots \\ x_{k-1}^2 - x_k^2 + y_{k-1}^2 - y_k^2 + d_k^2 - d_{k-1}^2 \end{bmatrix}$$

#### Soluția WLS
$$\mathbf{x}_{\text{WLS}} = (A^T W A)^{-1} A^T W \mathbf{b}$$

#### Construcția Matricei de Ponderi $W$
Matrice diagonală unde pondearea fiecărei ancore $i$ depinde invers proporțional de dispersia semnalului (varianta $\sigma_i^2$) și de distanța estimată $d_i$:
$$W_{ii} = \frac{1}{\sigma_i^2 \cdot d_i^\gamma}$$
- $\sigma_i^2$: Variația eșantioanelor RSSI în fereastra mobilă de la ancora $i$.
- $\gamma \in [1, 2]$: Factor de penalizare pentru ancorele îndepărtate (semnal slab).

---

### 2.3. Extended Kalman Filter (EKF) cu Model de Măsurare Non-Liniar

Spre deosebire de Kalman Filter-ul liniar din BluePIL (care filtrează coordonatele *după* trilaterație), EKF-ul poate fuziona direct măsurătorile RSSI brute sau distanțele calculate, gestionând non-linearitatea directă dintre coordonate și RSSI.

#### Vectorul de Stare și Tranziția (Model Viteză Constantă)
$$\mathbf{x}_k = [x, y, v_x, v_y]^T, \quad \mathbf{x}_k = F \mathbf{x}_{k-1} + \mathbf{w}_{k-1}$$

#### Modelul de Observație Non-Liniar $h(\mathbf{x}_k)$
$$z_k = h(\mathbf{x}_k) + \mathbf{v}_k = \begin{bmatrix} d_1(\mathbf{x}_k) \\ \vdots \\ d_k(\mathbf{x}_k) \end{bmatrix} + \mathbf{v}_k = \begin{bmatrix} \sqrt{(x - x_1)^2 + (y - y_1)^2} \\ \vdots \\ \sqrt{(x - x_k)^2 + (y - y_k)^2} \end{bmatrix} + \mathbf{v}_k$$

#### Linearizarea prin Matricea Jacobiană de Observație $H_k$
$$H_k = \left. \frac{\partial h}{\partial \mathbf{x}} \right|_{\hat{\mathbf{x}}_{k|k-1}} = \begin{bmatrix} \frac{x - x_1}{d_1} & \frac{y - y_1}{d_1} & 0 & 0 \\ \frac{x - x_2}{d_2} & \frac{y - y_2}{d_2} & 0 & 0 \\ \vdots & \vdots & \vdots & \vdots \\ \frac{x - x_k}{d_k} & \frac{y - y_k}{d_k} & 0 & 0 \end{bmatrix}$$

#### Adaptare Dinamică pentru NLOS (Covariance Scaling)
În caz de obstacole temporare sau zgomot masiv la o ancoră, reziduul de inovare $y_k = z_k - h(\hat{\mathbf{x}}_{k|k-1})$ creșterea considerabil. Se scalează covarianța de măsurare $R_{i,i}$:
$$R_{i,i}^{(k)} = R_{i,i}^{(0)} \cdot \left(1 + \alpha \max\left(0, \frac{|y_i|}{\sigma_{z,i}} - 3\right)\right)^2$$

---

### 2.4. Particle Filter (PF) și Hibrid PFEKF
În medii cu fading non-gaussian (unde semnalul are distribuții bimodal-multipath cauzate de peretari metalici sau grupuri umane), filtrele de tip Particle Filter sunt superioare EKF.

- **Populație de Particule**: $\{x_k^{(i)}, w_k^{(i)}\}_{i=1}^N$ (ex. $N = 500 \dots 2000$ particule reprezentând ipoteze de poziție 2D).
- **Update de Pondere (Likelihood)**:
  $$w_k^{(i)} \propto w_{k-1}^{(i)} \cdot \exp\left( -\frac{1}{2} \sum_{j=1}^K \frac{(RSSI_{\text{obs}, j} - RSSI_{\text{exp}, j}(x_k^{(i)}))^2}{\sigma_j^2} \right)$$
- **Resampling Sistematic**: Se declanșează când numărul efectiv de particule $N_{\text{eff}} = \frac{1}{\sum (w_k^{(i)})^2} < \frac{N}{2}$, evitând degenerarea algoritmului.

---

## 3. Întrebări Critice și Ipoteze de Rezolvat pentru Mediul Nostru

### Ipoteza 1: Ancore Mobile (Senzori montați pe roboți/drone/operatori)
- **Problemă**: Dacă pozițiile ancorelor $(x_i, y_i)$ nu sunt fixe, ci variază în timp și au propriile erori de poziționare $(\sigma_{x_i}^2, \sigma_{y_i}^2)$, cum se propagă această nesiguranță în trilaterația țintei?
- **Întrebare Critică**: Trebuie să extindem vectorul de stare în EKF/PF pentru a estima simultan coordonatele ancorelor mobile și ale țintei (similar cu arhitecturile SLAM)?
- **Ipoteză de rezolvat**: Utilizarea unei matrici de covarianță extinse $P_{\text{anchor}}$ adăugată la covarianța de măsurare $R_k$:
  $$R_{i,\text{eff}} = R_i + H_{\text{anchor}, i} P_{\text{anchor}, i} H_{\text{anchor}, i}^T$$

### Ipoteza 2: Atenuări de la Pereți (NLOS) și Aglomerație Umană (Body Shadowing)
- **Problemă**: Atenuarea cauzată de o persoană care se interpune între țintă și un senzor Ubertooth este de $3 \dots 9\text{ dB}$. În ecuația LDPL, o atenuare de $6\text{ dB}$ dublează distanța estimată calculată!
- **Întrebare Critică**: Cum poate algoritmul să facă diferența între o îndepărtare reală a țintei de ancoră și o blocare temporară a semnalului de către un corp uman sau un perete de gips?
- **Ipoteză de rezolvat**: Monitorizarea derivatei temporale a RSSI ($\frac{d(RSSI)}{dt}$). O scădere bruscă de $> 6\text{ dB}$ într-un interval sub $0.5\text{ secunde}$ este clasificată drept **Body Shadowing / Obstacle NLOS** (nu deplasare fizică) și declanșează creșterea temporară a covarianței $R_{i,i}$ în EKF.

### Ipoteza 3: Fluctuațiile RSSI și Limitările Hardware Ubertooth One (Channel Hopping & Overheating)
- **Problemă**: Ubertooth One ascultă pe un singur canal BLE la un moment dat sau execută hopping. Pachetele pot fi pierdute în proporție de $13\% \dots 40\%$. Mai mult, conform Novytskyi et al. (2025) și Rodrigues et al. (2021), senzorii Ubertooth își pierd rata de eșantionare când se încălzesc (scădere de la $1.0$ la $0.38\text{ pachete/sec}$).
- **Întrebare Critică**: Cum prevenim desincronizarea fluxurilor RSSI dintre cele $k$ ancore când una dintre ele nu primește niciun pachet timp de 3–5 secunde?
- **Ipoteză de rezolvat**: Implementarea bufferului streaming BluePIL cu **Linear Interpolation Delay**. Dacă o ancoră nu transmite date în fereastra curentă, valoarea sa este estimată prin interpolare liniară dacă fereastra anterioară și cea viitoare conțin eșantioane; altfel, ancora este eliminată din matricea $A$ / $J$ pentru pasul respectiv.

### Ipoteza 4: Estimarea Dinamică a Parametrilor de Canal ($n$ și $RSS_C$) fără Calibrare Prealabilă
- **Problemă**: Dispozitivele Bluetooth au puteri de transmisie diferite (ESP32 $+18\text{ dBm}$, smartwatch $-10\text{ dBm}$, smartphone $0\text{ dBm}$). O valoare statică presupusă pentru $RSS_C$ poate genera erori de poziționare de zeci de metri.
- **Întrebare Critică**: Este algoritmul Levenberg-Marquardt din BluePIL (vector stare $[x, y, RSS_C]^T$) suficient de stabil pentru $k \ge 4$ ancore sau există stări de minim local/degenerare?
- **Ipoteză de rezolvat**: Verificarea că determinanta matricei Jacobiane $J^T J$ este strict pozitivă ($\det(J^T J) > \epsilon$). Dacă ancorele sunt coliniare sau $k < 4$, algoritmul trebuie să cadă pe un WLS cu $RSS_C$ estimat din clasificarea OUI/vendor (ex. smartphone vs beacon).

### Ipoteza 5: Efecte Near-Field (Distanțe sub 1.0 m)
- **Problemă**: Novytskyi et al. (2025) au demonstrat că în intervalul $0.35\text{ m} - 0.40\text{ m}$ există o zonă cu rată maximă de pierdere a pachetelor și variație RSSI non-monotonă.
- **Întrebare Critică**: Cum evităm erorile mari de calcul când ținta trece la doar câțiva centimetri de o ancoră Ubertooth?
- **Ipoteză de rezolvat**: Dacă o ancoră înregistrează un $RSSI > -50\text{ dBm}$ (semnalizând proximitate extremă near-field), distanța calculată nu se mai obține din ecuația logaritmică clasică, ci este plafonată sau corectată utilizând ecuația cubica de regresie $E(l)$ identificată în studiu.

---

## 4. Drumul Recomandat de Implementare (Architecture Roadmap)

1. **Etapa 1 (Filtering Layer)**:
   - Aplicați un **Rolling Max Filter** pe ferestre de $1.5 \dots 3\text{ secunde}$ la nivel de nod/senzor pentru a izola semnalul LOS.
   - Tratați eșantioanele cu varianță ridicată prin **Rolling Median Filter**.

2. **Etapa 2 (Merger & Interpolation Layer)**:
   - Sincronizați eșantioanele de la ancorele Ubertooth pe un timegrid comun.
   - Interpolăți liniar datele lipsă dacă decalajul este sub pragul de timeout ($3\text{ s}$).

3. **Etapa 3 (Initial Solver Layer - WLS / Levenberg-Marquardt)**:
   - Pentru $k \ge 4$ ancore active, aplicați **Levenberg-Marquardt** pentru a calcula coordonatele $(x, y)$ și parametrul $RSS_C$ al dispozitivului necunoscut.
   - Dacă $k = 3$, utilizați **Weighted Least Squares (WLS)** cu $RSS_C$ din clasificarea de vendor/clasa de putere.

4. **Etapa 4 (Trajectory Smoothing Layer - EKF Adaptiv)**:
   - Treceți coordonatele calculate prin **Extended Kalman Filter (EKF)** cu stare $s = [x, \dot{x}, y, \dot{y}]^T$.
   - Incorporați **Adaptive Covariance Scaling** pe matricea $R_k$ pentru a suprima instabilitățile induse de obstacole umbrite (persoane/pereți).

---

## 5. Referințe Bibliografice

1. **B. Rodrigues, C. Halter, M. Franco, E. J. Scheid, C. Killer, B. Stiller**, *"BluePIL: a Bluetooth-based PassIve Localization Method"*, IFIP/IEEE Symposium on Integrated Network Management, 2021. `LicentaVault/Referinte/PDFs/BluePIL a Bluetooth-based PassIve Localization Method.pdf`.
2. **A. Novytskyi, V. Sokolov, L. Kriuchkova, P. Skladannyi**, *"Determining the error distribution of BLE beacons at antenna near and far fields"*, CEUR Workshop Proceedings / CH&CMiGIN, 2025. `LicentaVault/Referinte/PDFs/Determining the error distribution of BLE beacons at antenna near and far fields.pdf`.
3. **R. Faragher, R. Harle**, *"Location Fingerprinting with Bluetooth Low Energy Beacons"*, IEEE JSAC, 2015.
4. **A. Mackey et al.**, *"Improving BLE Beacon Proximity Estimation Accuracy Through Bayesian Filtering"*, IEEE Internet of Things Journal, 2020.
