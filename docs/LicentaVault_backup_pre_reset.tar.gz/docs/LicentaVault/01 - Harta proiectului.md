---
tags: [structure, map]
status: current
updated: 2026-05-24
---
# 01 - Harta proiectului

## Foldere principale
| Path | Rol |
|---|---|
| `src/` | Frontend Vite/JS: dashboard, state, UI helpers, telemetry processing. |
| `src/core/` | Clase JS pentru stare și orchestrare: `HardwareStore`, `SessionController`, `SchemaEngine`, `TelemetryStreamer`, `UIFactory`. |
| `src/components/` | Componente JS imperative pentru zone ale UI: scan BLE, channel map, CVE findings. |
| `src-tauri/` | Aplicația Tauri/Rust: commands, runner, safety, discovery, config. |
| `src-tauri/resources/` | Binarele și DLL-urile Ubertooth livrate cu aplicația. |
| `dist/` | Output generat doar după un build Vite reușit; în starea verificată nu este prezent. |
| `LicentaVault/` | Mutat în root-ul workspace-ului: documentația și notele de cercetare Obsidian ale proiectului. |
| `.gitnexus/`, `.omx/`, `.omc/`, `.omg/` | Metadate tooling/agent/indexare; nu fac parte direct din runtime-ul aplicației. |

## Fișiere entry-point
| Fișier | De ce contează |
|---|---|
| `package.json` | Scripturi: `dev`, `build`, `tauri:dev`, `tauri:build`; dependențe JS. |
| `vite.config.js` | Build multi-entry pentru `index.html` și `splash.html`, port dev `1421`. |
| `index.html` | Încarcă `/src/main.js`, dashboard-ul principal. |
| `splash.html` | Încarcă `/src/splash.jsx`, ecranul de inițializare hardware. |
| `src-tauri/tauri.conf.json` | Configurează fereastra, URL inițial `splash.html`, bundle MSI și resources. |
| `src-tauri/src/main.rs` | Entry-point Rust, Tauri command registry, setup auto-polling. |

## Artefacte runtime
| Artefact | Rol |
|---|---|
| `src-tauri/resources/ubertooth-*.exe` | Tool-uri native apelate de backend. |
| `src-tauri/resources/lib*.dll` | DLL-uri necesare tool-urilor Ubertooth pe Windows. |
| `src-tauri/app.log` / `target/debug/app.log` | Loguri locale ale aplicației Rust. |
| `tauri-dev-test.log`, `demo.log` | Loguri de test/dezvoltare prezente în repo. |

## Relația dintre frontend și backend
```mermaid
flowchart LR
  subgraph Frontend[src/]
    Main[src/main.js]
    Schema[src/commands-schema.json]
    Core[src/core/*]
    Components[src/components/*]
  end

  subgraph Tauri[src-tauri/src/]
    MainRs[main.rs]
    Runner[runner.rs]
    Safety[safety.rs]
    Discovery[discovery.rs]
    Commands[commands/*]
  end

  Main --> Core
  Core --> Schema
  Core -- invoke(...) --> MainRs
  MainRs --> Safety
  MainRs --> Commands
  MainRs --> Runner
  MainRs --> Discovery
  Runner --> Resources[src-tauri/resources]
  Runner -- emit events --> Core
```
