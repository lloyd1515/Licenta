# Ce am aflat nou (Caveman Style 🍖)

> [!NOTE]
> O sinteză ultra-simplificată a realității tehnice din spatele **Ubertooth One** și cum direcționăm proiectul mai departe fără a promite lucruri imposibile hardware-ului.

---

## 1. Ce am aflat nou (Ubertooth limitat. Trist but true)

1. **Ubertooth bătrân (2011):** Nu aude muzica sau vocea pe Bluetooth Classic nou (EDR, 2-3 Mbps). E prea rapid pentru el.
2. **Ubertooth nu e pumn de fier (nu dă atacuri):** Atacurile noi ca *BrakTooth*, *SweynTooth*, *KNOB* vor pachete trimise extrem de repede, la microsecundă. Ubertooth e prea lent la trimis.
3. **Alte unelte mai bune:** Pentru atacuri reale, lumea folosește **ESP32** ieftin (pentru [[AI research/Attacks/BrakTooth|BrakTooth]]) sau **Nordic nRF52840 Dongle** (pentru [[AI research/Attacks/SweynTooth|SweynTooth]]), ori telefoane cu cip Broadcom modificate prin [[AI research/Attacks/KNOB|InternalBlue (KNOB/BIAS)]].

---

## 2. Ce putem face acum? Chestii noi pentru dashboard-ul tău

În loc să facem atacuri grele pe care Ubertooth nu le poate duce fizic, facem **Dashboard de Alertă Pasivă (Awareness)**. Ubertooth doar ascultă pasiv și pune diagnosticul în interfață:

*   **Alarmă "Tastatură / IoT vulnerabil"**
    *   Ubertooth prinde mesaje BLE. Dacă vede cod de serviciu (UUID) de tastatură sau dispozitiv medical (ex: oximetru), aprinde becul roșu în dashboard: *"Atenție! Dispozitiv sensibil în zonă care trimite date necriptate (risc [[AI research/Attacks/SweynTooth|SweynTooth]] / [[AI research/Attacks/BLESA|BLESA]])."*
*   **Alarmă "Urmărire" (Privacy)**
    *   Dacă un dispozitiv BLE nu își schimbă adresa MAC în timp (nu are randomizare), dashboard-ul zice: *"Dispozitivul poate fi urmărit la pas de oricine în clădire (lipsă randomizare MAC - vezi [[AI research/Papers/Protecting Privacy of BLE Device Users|Protecting Privacy of BLE Device Users]])."*
*   **Alarmă "Clonă" (Spoofing)**
    *   Dacă Ubertooth vede două semnale cu aceeași adresă MAC, dar cu puteri de semnal (RSSI) foarte diferite sau la intervale imposibile, dă alerta: *"Cineva clonează un dispozitiv legitim în zonă! (Posibil atac [[AI research/Attacks/BIAS|BIAS]] / [[AI research/Attacks/BLESA|BLESA]])."*
*   **Dicționar de Cipuri (OUI Mapping)**
    *   Ubertooth prinde adresa MAC (LAP/UAP). Dashboard-ul caută primii octeți (producătorul, ex. Broadcom/Cypress) și spune utilizatorului: *"Dispozitivul tău are cip Broadcom. Risc teoretic de [[AI research/Attacks/BrakTooth|BrakTooth]] sau [[AI research/Attacks/KNOB|KNOB]]."*

---

## 3. Corelații cu Canvas-ul de Cercetare
*   Toate aceste concepte sunt mapate vizual în [[AI research/Research Map.canvas|Research Map.canvas]] pentru a arăta legătura dintre logica de detecție din dashboard, atacuri și cercetările academice.
