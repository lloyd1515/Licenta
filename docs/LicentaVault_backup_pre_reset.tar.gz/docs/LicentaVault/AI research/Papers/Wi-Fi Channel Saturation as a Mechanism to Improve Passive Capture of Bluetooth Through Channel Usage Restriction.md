# Wi-Fi Channel Saturation as a Mechanism to Improve Passive Capture of Bluetooth Through Channel Usage Restriction

## 1. Contribuția principală și metodologia
Lucrarea evaluează experimental o ipoteză des întâlnită în literatura de specialitate (ex. Spill & Bittau, BlueEar): ideea că prin congestionarea activă a benzii de 2.4 GHz cu ajutorul semnalelor Wi-Fi se poate forța algoritmul Adaptive Frequency Hopping (AFH) din Bluetooth să evite acele canale, reducând setul de frecvențe active la limita minimă legală (20 de canale). Acest lucru ar simplifica din punct de vedere matematic ghicirea prin brute-force a sincronizării ceasului (`Clock 27`) de către un receptor pasiv, crescând rata de succes a sniffing-ului.

**Metodologia** a constat în:
- Crearea unui testbed experimental compus din diverse smartphone-uri Android/Windows Mobile și ținte audio (sistemul infotainment Hyundai i30, o boxă Bose Soundlink Mini și căști stereo).
- Saturația artificială a canalului 6 Wi-Fi (lățime de bandă de 20 MHz) prin copierea continuă a unui fișier ISO de dimensiuni mari la o viteză de cca. 40 Mbps de pe un smartphone dedicat (diferit de cel care rula Bluetooth).
- Utilizarea analizei spectrale (`Kismet spectools`) pentru vizualizarea și validarea mediului RF zgomotos (Busy RF) vs. liniștit (Quiet RF).
- Măsurarea ratei de captare, a numărului de pachete decodate și a timpului necesar ghicirii `Clock 27` pe parcursul a 10 rulări de câte 180 de secunde pentru fiecare scenariu.

**Rezultatele cheie:** Ipoteza a fost infirmată. Zgomotul RF crescut nu a dus la o captare mai bună a pachetelor de date. De asemenea, lucrarea dezvăluie un comportament neașteptat: dacă Bluetooth-ul este deja pornit când pornește traficul Wi-Fi intens, protocoalele concurează agresiv pe aceleași canale, Bluetooth-ul "câștigând" disputa și scăzând lățimea de bandă a Wi-Fi-ului de la 40 Mbps la doar 1-2 Mbps (un comportament ce poate fi exploatat ca atac de tip Denial of Service asupra Wi-Fi-ului).

## 2. Relația cu Ubertooth One
Dispozitivele **Ubertooth One** au reprezentat nucleul tehnic al experimentului, fiind utilizate într-o configurație cu două adaptoare fizice conectate la un laptop de analiză (OS Ubuntu 16.04):
- Un dispozitiv Ubertooth One a rulat utilitarul `ubertooth-afh` pentru a extrage harta AFH în timp real (o dată pe secundă). Pentru corelarea datelor, autorul a modificat codul sursă al bibliotecii `libubertooth` (`ubertooth_callback.c`) adăugând un sistem de timestamp precis.
- Al doilea dispozitiv Ubertooth One a rulat utilitarul `ubertooth-rx` pentru monitorizarea pasivă a piconetului, având rolul de a recupera adresele LAP/UAP, de a rula brute-force-ul pe Clock 6 și Clock 27, și de a decoda pachetele recepționate.

## 3. Evaluare sceptică / Limitările cercetării
- **Incapacitatea de a decoda traficul EDR (Enhanced Data Rate)**: Deoarece experimentul a vizat streaming audio (A2DP) - care folosește modulații EDR de 2 sau 3 Mbps ($\pi/4$-DQPSK și 8DPSK) pentru a menține calitatea sunetului - iar **Ubertooth One nu poate demoduleze hardware semnalele EDR** (fiind limitat la modulația GFSK de 1 Mbps a Basic Rate), volumul de date decodate cu succes din aer a fost extrem de mic. Ubertooth a putut capta doar 300 de pachete de control (NULL/POLL, evenimente HCI și reglaje de volum), în timp ce telefonul a transmis peste 67.000 de pachete în același interval (o captură de doar ~0.45% din trafic).
- **Metodă imprecisă de saturare a spectrului**: Saturarea canalelor Wi-Fi prin copiere de fișiere mari este dependentă de hardware și mediu, nefiind la fel de riguroasă și reproductibilă precum bruiajul controlat obținut prin generatoare de semnal RF dedicate (SDR/generatoare de zgomot).
- **Variabilitate statistică ridicată**: Timpul de ghicire a ceasului `Clock 27` a variat haotic între 4 și peste 170 de secunde în cadrul acelorași scenarii de test, indicând faptul că eșantionul de 10 rulări este insuficient pentru a stabili corelații statistice de înaltă precizie.
- **Dependență de implementarea chipset-ului**: Lipsa de cooperare a algoritmului AFH cu Wi-Fi-ul (care a provocat degradarea lățimii de bandă Wi-Fi) poate fi un comportament specific microcodului din cipurile telefoanelor OnePlus folosite (Qualcomm/Broadcom) și s-ar putea să nu se aplice la toate controllerele Bluetooth de pe piață.
