# Ubertooth - Bluetooth Monitoring and Injection

## 1. Contribuția principală și metodologia
Lucrarea reprezintă o sinteză teoretică și o analiză comparativă a soluțiilor hardware și software destinate monitorizării (sniffing) și injectării de pachete în conexiunile Bluetooth Classic și Low Energy. Aceasta explică mecanismele fundamentale de funcționare ale Bluetooth: saltul în frecvență (FHSS), structura pachetului de date la nivel de bază (Baseband) cu divizarea adresei dispozitivului (BD_ADDR) în LAP, UAP și NAP, precum și procesul de asociere (pairing) și autentificare (cheia Link Key derived from Kinit).

**Metodologia** implică:
- Evaluarea modului în care atacatorii pot intercepta traficul și pot deduce cheile de criptare.
- Analiza atacului Shaked & Wool pentru spargerea PIN-ului prin brute-force offline (folosind datele captate la pairing: `IN_RAND`, `LK_RAND`, `AU_RAND` și `SRES`).
- Studiul forțării unui nou pairing (pentru a intercepta strângerea de mână) prin injectarea unui pachet de tip `LMP not accepted` sau prin falsificarea valorii `SRES`.

## 2. Relația cu Ubertooth One
Dispozitivul **Ubertooth One** este analizat în detaliu ca o alternativă open-source accesibilă financiar (cca. 100 USD) față de analizoarele comerciale scumpe.
- Lucrarea prezintă arhitectura sa hardware: transceiver-ul wireless CC2400 (Texas Instruments), amplificatorul RF front-end CC2591, microcontrolerul ARM Cortex-M3 (LPC1756) și conexiunea USB 2.0.
- Sunt documentate instrumentele software incluse: `Specan UI` (analiză spectrală grafică), `ubertooth-util` (configurare moduri de lucru), `ubertooth-lap` (obținerea adresei LAP), `ubertooth-uap` (determinarea UAP) și utilizarea plugin-ului pentru Kismet pentru a captura pachete într-un fișier PCAP compatibil cu Wireshark.

## 3. Evaluare sceptică / Limitările cercetării
- **Limitarea critică a ratei de date (lipsa EDR)**: Autorul recunoaște explicit că transceiver-ul **CC2400 de pe Ubertooth One este limitat la o viteză maximă de 1 Mbit/s**. Din acest motiv, Ubertooth One **nu poate capta traficul ce folosește specificațiile Bluetooth 2.0+ EDR (Enhanced Data Rate)**, care funcționează la 2 sau 3 Mbit/s. Prin urmare, monitorizarea datelor din conexiunile reale moderne de Bluetooth Classic este imposibilă, dispozitivul fiind limitat doar la pachetele de bază (Basic Rate - BR).
- **Injectarea de pachete nefuncțională (la momentul cercetării)**: Deși titlul lucrării menționează "Injection", se constată că firmware-ul Ubertooth nu suporta la acel moment transmiterea pachetelor arbitrare prin interfața USB pentru injectarea în conexiunile active ale terților. Astfel, atacurile teoretice de forțare a unui nou pairing prin transmiterea de pachete `LMP not accepted` sau `SRES` nu puteau fi realizate practic cu Ubertooth One, rămânând scenarii pur ipotetice.
- **Asimetria scanării (Single-channel vs. Multi-channel)**: Spre deosebire de analizoarele comerciale (de ex. Ellisys Bluetooth Explorer 400, estimat la 20.000 USD) care monitorizează toate cele 79 de canale simultan, Ubertooth One folosește un singur receptor radio. Sincronizarea cu secvența FHSS și captarea handshake-ului depind în totalitate de captarea la timp a pachetelor pe un singur canal, ceea ce face ca rata de succes în medii zgomotoase să fie extrem de mică.
