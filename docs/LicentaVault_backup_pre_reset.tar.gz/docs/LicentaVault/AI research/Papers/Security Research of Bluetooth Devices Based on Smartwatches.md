# Security Research of Bluetooth Devices Based on Smartwatches

## 1. Contribuția principală și metodologia
Lucrarea analizează securitatea ceasurilor inteligente (smartwatch-uri) ca dispozitive IoT, axându-se pe riscurile legate de colectarea, transmiterea și stocarea datelor personale (parametri de sănătate, locație GPS, mesaje) prin intermediul conexiunilor wireless (Bluetooth/Wi-Fi/LTE).

**Metodologia** practică descrie pașii pentru realizarea unui audit de securitate (sniffing pasiv) asupra unui ceas **Amazfit Bip Watch**:
- Pregătirea mediului de lucru în Kali Linux, instalarea dependințelor hardware (biblioteca de decodare `libbtbb` și utilitarele Ubertooth) și configurarea Wireshark.
- Calibrarea dispozitivului Ubertooth One ca analizor de spectru în banda de 2.4 GHz utilizând aplicația grafică `ubertooth-specan-ui`.
- Captarea adresei fizice a dispozitivului prin scanarea și identificarea componentei LAP (Lower Address Part) a adresei MAC Bluetooth.
- Rularea sniffing-ului BLE pentru monitorizarea canalelor de publicitate (advertising) și urmărirea dinamică a tranzițiilor de canal la stabilirea conexiunilor active, direcționând pachetele captate către Wireshark pentru analiză.

## 2. Relația cu Ubertooth One
Echipamentul **Ubertooth One** reprezintă instrumentul hardware central utilizat în studiul de caz din lucrare.
- A fost folosit pentru vizualizarea spectrului electromagnetic în banda de 2.4 GHz.
- A fost utilizat pentru extragerea LAP din adresa MAC Bluetooth Classic a ceasului.
- A fost folosit pentru monitorizarea pasivă a traficului BLE, permițând captarea canalelor de publicitate și urmărirea conexiunii stabilite între ceasul Amazfit Bip și smartphone, transmițând pachetele recepționate în Wireshark.

## 3. Evaluare sceptică / Limitările cercetării
- **Abordare superficială și didactică**: Lucrarea se comportă mai degrabă ca un manual de instalare și configurare pentru Ubertooth One, prezentând doar procesul de captare a pachetelor brute (reprezentat prin capturi de ecran). Nu se realizează nicio decriptare efectivă a datelor și nu se demonstrează practic realizarea atacurilor menționate în tabele (cum ar fi atacurile de spoofing sau injectare de pachete).
- **Omiterea limitărilor hardware ale Ubertooth**: Lucrarea laudă precizia Ubertooth One, dar ignoră complet neajunsurile sale critice. Ubertooth One nu poate decoda modurile de modulație EDR (Enhanced Data Rate) folosite în Bluetooth Classic pentru transfer rapid de date (este limitat la modul de bază, BR). De asemenea, rata de pierdere a pachetelor (packet loss) în medii zgomotoase este foarte mare, ceea ce face ca urmărirea conexiunilor BLE să eșueze frecvent dacă pachetul inițial de sincronizare (`CONN_REQ`) pe canalele de advertising este pierdut.
- **Prezentare nerealistă a ușurinței de utilizare**: Autorii afirmă că un astfel de audit de securitate poate fi efectuat cu ușurință de "orice utilizator cu cunoștințe de bază despre tehnologia Bluetooth". În realitate, analiza protocoalelor wireless și interpretarea pachetelor nestandardizate sau a fluxurilor criptate în Wireshark necesită cunoștințe avansate de rețea și securitate.
