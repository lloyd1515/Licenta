## Rezumat Lucrare: Building an Autonomous Portable Device to Analyse Wireless Traffic Protocols in IoT

### 1. Contribuția principală și metodologia
- **Contribuție principală:** Autorii propun proiectarea și asamblarea unui dispozitiv portabil, autonom și ieftin, capabil să analizeze simultan mai multe protocoale wireless utilizate în mediul IoT: Wi-Fi, Bluetooth și ZigBee. Dispozitivul are scopul de a rula independent de un computer gazdă, oferind alimentare proprie (baterie de 9V) și stocare pe card SD pentru jurnalele de trafic, facilitând auditurile de securitate și inventarierea echipamentelor în spații industriale ("Industry 4.0").
- **Metodologie:**
  - **Dezvoltare hardware:** Au utilizat o placă de bază **Arduino Mega 2560** conectată la un cititor de carduri SD. Pentru Wi-Fi au integrat modulul **ESP-01** (folosind biblioteca *ArduinoPCAP* pentru crearea de fișiere analizabile în Wireshark). Pentru Bluetooth, au folosit modulul **HC-05**, iar pentru ZigBee au integrat un modul **XBee** configurat prin software-ul *XCTU*.
  - **Software și depanare:** Codul a fost scris în Arduino IDE, iar depanarea semnalelor logice s-a realizat cu un analizor logic *Saleae Logic 2*.

### 2. Relația cu Ubertooth One
- **Este folosit?** Nu, Ubertooth One nu este folosit în implementarea dispozitivului.
- **Ce hardware s-a folosit?** Pentru funcționalitatea Bluetooth, autorii folosesc un modul comercial simplu **HC-05** configurat în mod Master. Ubertooth One este citat în introducere și în tabelul comparativ ca o soluție de referință open-source existentă pe piață, fiind criticat pentru faptul că nu poate funcționa autonom (necesită conectarea la un laptop) și este limitat la un singur protocol (doar Bluetooth).

### 3. Evaluare sceptică și Limitările cercetării
- **HC-05 nu suportă sniffing pasiv (promiscuu):** Modulul HC-05 este un receptor Bluetooth comercial standard cu firmware închis, capabil doar să efectueze o scanare activă (*inquiry scan*) pentru a detecta dispozitive aflate în mod vizibil (*discoverable*). Spre deosebire de Ubertooth One, HC-05 **nu poate intercepta pachetele din aer** trimise între alte dispozitive și nu poate detecta dispozitivele aflate în mod invizibil (*non-discoverable*), limitând drastic utilitatea ca instrument de audit de securitate.
- **Imposibilitatea generării fișierelor PCAP pentru Bluetooth/ZigBee:** Autorii recunosc în secțiunea de discuții că nu există module sau biblioteci software compatibile cu Arduino Mega care să permită generarea de fișiere PCAP pentru protocoalele Bluetooth și ZigBee. Prin urmare, dispozitivul nu realizează o analiză reală de trafic pentru aceste două protocoale, ci doar o listare (inventariere) a adreselor dispozitivelor descoperite.
- **Limitările severe de memorie și procesare ale Arduino Mega:** Utilizarea unui microcontroler pe 8 biți (ATmega2560) rulând la 16 MHz cu doar 8 KB RAM este complet inadecvată pentru procesarea fluxurilor mari de pachete Wi-Fi (chiar și doar headerele PCAP). Viteza mică de scriere pe cardul SD prin interfața SPI va cauza pierderi masive de pachete (*buffer overflow* și *packet loss*) în orice mediu de rețea cu activitate normală.
