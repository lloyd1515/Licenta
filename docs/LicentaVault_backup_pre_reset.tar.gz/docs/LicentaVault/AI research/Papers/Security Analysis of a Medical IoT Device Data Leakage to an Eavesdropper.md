# Security Analysis of a Medical IoT Device: Data Leakage to an Eavesdropper

## 1. Contribuția principală și metodologia
Lucrarea analizează securitatea oximetrului de puls **Masimo MightySat Rx** și a aplicației sale mobile însoțitoare, axându-se pe scurgerea datelor de sănătate prin protocolul Bluetooth Low Energy (BLE).

**Metodologia** propusă include trei etape majore:
- **Colectarea traficului de rețea (Eavesdropping pasiv)**: Utilizarea unui receptor BLE pentru a intercepta pachetele transmise în aer între oximetru și smartphone, urmată de analiza pachetelor în Wireshark.
- **Analiză statică**: Decompilarea fișierului APK al aplicației Android folosind **jadx** și **MobSF** pentru a identifica clasele și funcțiile care gestionează conexiunea BLE (`BluetoothLEConnection` și callback-ul `onCharacteristicChanged`). De asemenea, s-a analizat fișierul de log al controlerului Bluetooth de pe telefon (`HCI snoop.log`).
- **Analiză dinamică**: Utilizarea framework-ului **Frida** pe un dispozitiv Android cu drepturi de root pentru a face hooking pe funcția `onCharacteristicChanged()` și a extrage valorile în timp real. Această analiză a demonstrat că octeții 8 și 10 dintr-un tablou specific de date corespund saturației de oxigen și ratei pulsului transmise în format necriptat.

## 2. Relația cu Ubertooth One
Dispozitivul **Ubertooth One** a fost utilizat în mod direct ca hardware principal de sniffing wireless pentru faza de colectare a traficului.
- Autorii au rulat instrumentul `ubertooth-btle` pentru a capta pachetele BLE din aer, vizând adresa MAC a oximetrului.
- Datele obținute au fost exportate în format PCAP și analizate în Wireshark pentru a corela datele brute captate prin radio cu cele obținute local prin intermediul log-ului HCI și al instrumentului Frida. S-a arătat că pachetele interceptate de Ubertooth conțin aceleași date în clar ca și log-ul intern.

## 3. Evaluare sceptică / Limitările cercetării
- **Simplitatea scenariului de securitate (lipsa criptării)**: Descoperirea se bazează pe faptul că dispozitivul medical nu implementează deloc criptarea sau securizarea canalului de comunicație BLE, trimițând datele în text clar (Cleartext). Cercetarea nu analizează cum ar fi influențat atacul dacă s-ar fi utilizat moduri securizate de asociere (Secure Connections implementat în BLE 4.2+ cu ECDH).
- **Limitările fizice ale Ubertooth One**: Ubertooth One folosește un singur transmițător/receptor radio CC2400. Captarea pachetului inițial de conexiune (`CONN_REQ`) este critică pentru a urmări salturile de frecvență (hopping). În medii reale de 2.4 GHz cu zgomot radio ridicat (Wi-Fi, alte dispozitive Bluetooth), rata de pierdere a pachetelor de către Ubertooth este mare, ceea ce face ca sniffing-ul pasiv să eșueze frecvent în practică.
- **Cerința de Root pentru investigație**: Metodologia necesită un telefon Android rootat pentru a rula Frida și pentru a accesa fișierul `HCI snoop.log`. Deși acest lucru este acceptabil pentru analiza de securitate realizată de un cercetător, nu reprezintă un vector de atac pur extern asupra utilizatorului final (atacatorul ar trebui să aibă deja controlul telefonului sau să se bazeze exclusiv pe interceptarea radio, care depinde critic de captarea handshake-ului).
