# Revisiting Adaptive Frequency Hopping Map Prediction in Bluetooth with Machine Learning Classifiers

## 1. Contribuția principală și metodologia
Lucrarea investighează posibilitatea de a prezice harta de salt în frecvență (AFH - Adaptive Frequency Hopping) folosită de dispozitivele Bluetooth Classic (BR/EDR), utilizând algoritmi de machine learning (ML) pe baza statisticilor obținute prin monitorizarea spectrului (spectrum sensing). 

**Metodologia** a constat în:
- Crearea unui mediu experimental (testbed) pentru colectarea datelor.
- Folosirea unui dispozitiv de monitorizare a spectrului (spectrogramă / indicator RSSI) pentru a calcula activitatea pe canalele Bluetooth.
- Extragerea hărților reale AFH direct din firmware-ul Broadcom al unui dispozitiv controller prin intermediul instrumentului open-source **InternalBlue**.
- Antrenarea și evaluarea a 5 clasificatori de învățare automată: Regresie Logistică (LR), Arbori de Decizie (DT), Păduri Aleatoare (RF), Support Vector Machines (SVM) și Perceptron Multistrat (MLP). Evaluarea s-a realizat pe un set de date de cca. 106.000 de eșantioane de antrenare și 20.000 de test.
- Rezultatele arată că RF și DT obțin cea mai bună performanță (o acuratețe mediană de până la 73.4%), în timp ce SVM s-a dovedit lent și ineficient în medii dinamice.

## 2. Relația cu Ubertooth One
Echipamentul **Ubertooth One** a fost utilizat în mod direct în cadrul testbed-ului ca analizor de spectru de joasă cost. În mod specific:
- A fost rulat firmware-ul standard sau modificat al Ubertooth pentru a monitoriza spectrul RF de 2.4 GHz.
- Datele de putere a semnalului (RSSI) pe fiecare dintre cele 79 de canale Bluetooth au fost colectate prin intermediul bibliotecii `libubertooth`.
- Aceste histograme de RSSI obținute prin scanare rapidă au servit drept date de intrare (features) pentru modelele de machine learning care încearcă să clasifice canalele ca fiind "bune" sau "slabe" (corespunzător clasificării AFH).

## 3. Evaluare sceptică / Limitările cercetării
- **Dependența de vendor și implementare proprietary**: Hărțile AFH sunt decise în mod dinamic de controller-ul Bluetooth (master), iar algoritmii exacți de clasificare a canalelor nu sunt standardizați de Bluetooth SIG, ci sunt proprietari (de exemplu, Broadcom utilizează un algoritm specific). Un model ML antrenat pe comportamentul unui cip Broadcom s-ar putea să nu se generalizeze pentru controllere de la alți producători (ex. Qualcomm, Intel, Realtek).
- **Proximitatea fizică a sniffer-ului**: Pentru ca statisticile RSSI colectate de Ubertooth One să se potrivească cu cele percepute de master-ul Bluetooth, sniffer-ul trebuie să fie plasat foarte aproape de acesta. Dacă există interferențe locale doar la nivelul receptorului/emițătorului țintă (de exemplu, atenuări din cauza corpului uman sau obstacolelor), Ubertooth nu le va sesiza corect, ducând la o predicție greșită a hărții AFH.
- **Dimensiunea și diversitatea setului de date**: Experimentul s-a desfășurat într-un număr limitat de scenarii de laborator. În medii reale hiper-congestionate și dinamice (de tipul conferințelor sau spațiilor publice cu sute de dispozitive Wi-Fi și Bluetooth active), performanța de 73.4% s-ar putea degrada semnificativ.
- **Latența de predicție vs. Rata de schimbare**: AFH-ul se poate adapta rapid la schimbări de spectru. Timpul necesar colectării statisticilor RSSI, rulării clasificatorului și aplicării predicției poate fi mai mare decât intervalul în care harta reală AFH este deja actualizată de dispozitive.
