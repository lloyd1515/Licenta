# BrakTooth Attacks

## Prezentare Generală
*   **Tip Protocol:** Bluetooth Classic (BR/EDR)
*   **Nivel Protocol (Layer):** Link Manager Protocol (LMP) și Baseband
*   **CVE-uri:** CVE-2021-28139 (și altele)
*   **Impact:** Denial of Service (DoS - freeze/crash), Execuție de Cod Arbitrar (ACE) pe chipuri Bluetooth Classic

## Mecanism Tehnic
BrakTooth reprezintă o colecție masivă de vulnerabilități la nivel de firmware în cipurile de Bluetooth Classic utilizate pe scară largă (Intel, Broadcom, Cypress, Qualcomm, etc.). 
Atacul constă în transmiterea de pachete LMP malformate sau trimise în momente neașteptate ale negocierii conexiunii (de exemplu, pachete de configurare a caracteristicilor trimise înainte de stabilirea conexiunii securizate). Buffer-ele interne din firmware-ul controllerului Bluetooth nu validează lungimile sau secvențele acestor mesaje, provocând Buffer Overflow sau dereferențieri de pointeri nuli. Pe anumite SoC-uri (cum ar fi Cypress CYW20735), atacatorul poate scrie date direct în memoria RAM a cipului și poate prelua controlul execuției (ACE).

## Relația cu Ubertooth One
*   **Sniffing:** **Extrem de limitat.** Bluetooth Classic folosește AFH (Adaptive Frequency Hopping) cu 1600 de salturi pe secundă pe 79 de canale. Ubertooth One are doar un receptor radio și nu poate urmări aceste salturi în timp real. De asemenea, Ubertooth nu poate decoda modulațiile EDR (Enhanced Data Rate de 2-3 Mbps), ci doar modulația de bază BR (GFSK 1 Mbps).
*   **Transmisie/Atac:** **NU este fezabil.** BrakTooth necesită trimiterea de pachete LMP nestandard (care sunt validate și blocate de firmware-ul standard al Ubertooth). CC2511-ul de pe Ubertooth este un cip dedicat în principal BLE și nu are funcționalitățile hardware necesare pentru transmisiuni active BR/EDR complexe.

## Hardware Alternativ Necesar
*   **ESP32 (în special ESP-WROVER-KIT):** Este platforma oficială folosită de cercetători pentru BrakTooth. Prin utilizarea unui firmware ESP32 modificat care ocolește validările HCI din ROM, calculatorul gazdă poate injecta pachete LMP neconforme direct în aer către dispozitivul țintă.

## Lucrări Academice Relevante (Wikilinks)
*   [[AI research/Papers/A Comprehensive Review of RFID and Bluetooth Security Practical Analysis|A Comprehensive Review of RFID and Bluetooth Security]]
*   [[AI research/Papers/Ubertooth - Bluetooth Monitoring and Injection|Ubertooth - Bluetooth Monitoring and Injection]] - Explică limitele hardware de modulație (CC2400) ale Ubertooth.
