# BIAS (Bluetooth Impersonation Attacks)

## Prezentare Generală
*   **Tip Protocol:** Bluetooth Classic (BR/EDR)
*   **Nivel Protocol (Layer):** Link Manager Protocol (LMP)
*   **CVE-uri:** CVE-2020-10135
*   **Impact:** Impersonarea unui dispozitiv anterior împerecheat (ocolirea autentificării) fără cunoașterea cheii pe termen lung (Link Key)

## Mecanism Tehnic
BIAS profită de asimetria și lipsa verificării obligatorii bidirecționale în timpul reconectării dispozitivelor prin Legacy Secure Connections (LSC). Când se reconectează, un atacator clonează adresa MAC a unui dispozitiv de încredere al victimei. Atacatorul inițiază o solicitare de inversare a rolurilor master/slave (Role Switch), asumându-și rolul de Master. În acest fel, atacatorul devine cel care inițiază procedura de provocare-răspuns (Challenge-Response) și declară succesul autentificării fără a fi validat la rândul său de către victimă. De asemenea, atacul poate forța downgrade-ul conexiunii la moduri nesecurizate.

## Relația cu Ubertooth One
*   **Sniffing:** Ubertooth One poate ajuta la extragerea adreselor MAC (LAP/UAP) din aer, însă nu poate fi folosit pentru a asista la atacul activ.
*   **Transmisie/Atac:** **NU este fezabil.** La fel ca în cazul BrakTooth și KNOB, BIAS este un atac activ la nivelul de negociere LMP al Bluetooth Classic. Ubertooth One nu are hardware-ul necesar pentru a negocia conexiuni active Classic BR/EDR sau pentru a efectua proceduri active de Role Switch.

## Hardware Alternativ Necesar
*   **InternalBlue Framework + cip Broadcom patch-uit:** Permite rularea scripturilor Python care forțează pașii de negociere LMP direct pe controllerul Bluetooth al unui smartphone Pixel sau Raspberry Pi 3/4.

## Lucrări Academice Relevante (Wikilinks)
*   [[AI research/Papers/Revisiting Adaptive Frequency Hopping Map Prediction in Bluetooth with Machine Learning Classifiers|Revisiting Adaptive Frequency Hopping Map Prediction]]
*   [[AI research/Papers/Improving compliance with bluetooth device detection|Improving compliance with bluetooth device detection]]
