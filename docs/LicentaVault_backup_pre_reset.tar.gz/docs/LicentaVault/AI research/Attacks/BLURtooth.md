# BLURtooth Attacks

## Prezentare Generală
*   **Tip Protocol:** Dual-mode Bluetooth (Classic + BLE)
*   **Nivel Protocol (Layer):** Security Manager / Cross-Transport Key Derivation (CTKD)
*   **CVE-uri:** CVE-2020-15802
*   **Impact:** Suprascrierea cheilor de împerechere legitime (downgrade sau deturnare MitM)

## Mecanism Tehnic
BLURtooth vizează funcționalitatea CTKD (Cross-Transport Key Derivation) din standardul Bluetooth (4.2 - 5.0). CTKD permite derivarea cheii de criptare pentru un transport (de ex. Classic) dintr-o împerechere de succes pe celălalt transport (de ex. BLE), reducând pașii necesari pentru utilizator.
Atacatorul, aflat în apropiere, inițiază o asociere neautentificată (de tip "Just Works") peste BLE folosind adresa MAC clonată a unui dispozitiv deja împerecheat legitim peste Bluetooth Classic. Deoarece specificațiile vechi nu protejau adecvat suprascrierea cheilor active, mecanismul CTKD generează o nouă cheie slabă peste BLE și suprascrie cheia securizată anterioară a conexiunii Classic.

## Relația cu Ubertooth One
*   **Sniffing:** Ubertooth One poate înregistra adresele MAC ale ambelor transporturi în aer și poate detecta asocierea lor, dar nu poate decoda procesul de derivare.
*   **Transmisie/Atac:** **NU este fezabil.** Deși atacul începe pe BLE (unde Ubertooth are capabilități radio), el necesită o asociere activă (Just Works) cu victima, ceea ce necesită o stivă BLE completă (TX/RX) pe care firmware-ul Ubertooth nu o pune la dispoziție.

## Hardware Alternativ Necesar
*   **Adaptor Bluetooth USB standard (e.g., CSR8510):** Permite scrierea de scripturi Python (prin Scapy/Bluepy) care inițiază asocieri active Just Works peste BLE cu adrese MAC arbitrare.

## Lucrări Academice Relevante (Wikilinks)
*   [[AI research/Papers/A Novel Secure Communication Scheme for Bluetooth Low Energy Devices|A Novel Secure Communication Scheme for BLE]]
*   [[AI research/Papers/Protecting Privacy of BLE Device Users|Protecting Privacy of BLE Device Users]]
