# KNOB (Key Negotiation Of Bluetooth)

## Prezentare Generală
*   **Tip Protocol:** Bluetooth Classic (BR/EDR)
*   **Nivel Protocol (Layer):** Link Manager Protocol (LMP)
*   **CVE-uri:** CVE-2019-9506
*   **Impact:** Reducerea entropiei cheii de criptare la 1 octet (8 biți), permițând decriptarea în timp real a traficului (MitM)

## Mecanism Tehnic
KNOB exploatează o eroare fundamentală de design în specificația standard Bluetooth Classic. Când două dispozitive stabilesc o conexiune securizată, ele folosesc mesaje LMP necriptate și nesemnate pentru a negocia dimensiunea cheii de criptare (între 1 și 16 octeți). 
Un atacator aflat în poziție Man-in-the-Middle (MitM) în aer interceptează aceste mesaje LMP de negociere și le modifică în zbor, forțând ambele dispozitive să agreeze o cheie de doar **1 octet**. O cheie de 8 biți are doar 256 de combinații posibile. Atacatorul poate decripta pachetele capturate instantaneu prin brute-force și poate injecta propriul conținut criptat legitim în sesiune.

## Relația cu Ubertooth One
*   **Sniffing:** Ubertooth One nu poate capta conexiuni active Bluetooth Classic în mod stabil din cauza AFH (Adaptive Frequency Hopping) și a utilizării modulațiilor EDR. Chiar dacă atacul KNOB este activ, Ubertooth nu va putea intercepta pachetele de date decriptate de 2-3 Mbps.
*   **Transmisie/Atac:** **NU este fezabil.** KNOB necesită un atac activ Man-in-the-Middle la nivel fizic sau de protocol (bruierea pachetului legitim și retransmiterea imediată a pachetului modificat). Ubertooth nu dispune de timpul de răspuns rapid (latență foarte mică) și nici de stiva RF Classic necesară pentru acest tip de manipulare în zbor.

## Hardware Alternativ Necesar
*   **InternalBlue Framework + Broadcom SoC:** Permite patch-uirea firmware-ului de pe telefoane (Google Pixel, Nexus) sau module ca Raspberry Pi 3/4 pentru a forța sau intercepta negocierea cheii.
*   **SDR-uri de mare viteză (USRP):** Pentru bruiaj și captare sincronizată.

## Lucrări Academice Relevante (Wikilinks)
*   [[AI research/Papers/6 . 858  Hacking Bluetooth|6 . 858  Hacking Bluetooth]] - Discută vulnerabilitatea proceselor de împerechere bazate pe PIN.
*   [[AI research/Papers/Wi-Fi Channel Saturation as a Mechanism to Improve Passive Capture of Bluetooth Through Channel Usage Restriction|Wi-Fi Channel Saturation as a Mechanism to Improve Passive Capture of Bluetooth]]
