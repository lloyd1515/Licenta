# Dashboard Mapping: Logica de Securitate și Awareness Pasiv (Ubertooth One)

> [!NOTE]  
> Acest document detaliază modul în care un dashboard de securitate ("awareness dashboard") local poate procesa datele colectate pasiv de **Ubertooth One** pentru a semnala potențiale riscuri și vulnerabilități dispozitivelor din zonă, păstrând în același timp o perspectivă realistă și sceptică asupra limitărilor hardware.

---

## 1. Ce poate colecta Ubertooth One în mod pasiv?

Pentru a afișa dispozitivele din zonă, stiva software Tauri/Rust a aplicației noastre apelează utilitarele native Ubertooth. Datele brute extrase sunt:
1.  **Adrese fizice:** 
    *   **BLE:** Adresa MAC de 48 de biți (care poate fi statică sau randomizată/privată).
    *   **Classic:** Adresele LAP (Lower Address Part - 24 biți) și UAP (Upper Address Part - 8 biți).
2.  **Mesaje de publicitate (BLE Advertising Payloads):**
    *   Numele dispozitivului (Local Name).
    *   Clasa dispozitivului (Class of Device / Appearance).
    *   Serviciile oferite (UUID-uri specifice, e.g., servicii medicale, HID/tastaturi, baterie).
    *   Date specifice de producător (Manufacturer Specific Data, utile pentru identificarea dispozitivelor Apple, Microsoft etc.).
3.  **RSSI (Received Signal Strength Indicator):** Puterea semnalului, utilă pentru estimarea proximității relative.
4.  **Activitatea spectrului (Spectrum):** Nivelul de zgomot RF pe cele 79 de canale (pentru analiză de interferențe).

---

## 2. Corelarea Datelor cu Vulnerabilitățile (Logica Dashboard-ului)

Deoarece Ubertooth One **nu poate rula exploit-uri active** (cum ar fi SweynTooth sau BrakTooth) și **nu poate intercepta direct mesaje LMP** de negociere (pentru KNOB sau BIAS), dashboard-ul trebuie să funcționeze pe principiul **amprentării pasive (passive fingerprinting)** și a asocierii statistice.

### Matricea de Corelare pentru Dispozitivele Scanate

| Date Colectate de Ubertooth | Identificare Dispozitiv | Vulnerabilități Potențiale (Awareness) | Nivel de Risc | Explicație Tehnică (Scepticism) |
| :--- | :--- | :--- | :--- | :--- |
| **BLE Adv: UUID 0x180D (Heart Rate) sau 0x180D (Oximeter)** | Dispozitiv Medical IoT | **SweynTooth / BLESA / Scurgere de date** | **CRITIC** | Multe dispozitive medicale vechi folosesc cipuri TI/Nordic vulnerabile la SweynTooth și nu folosesc criptare la nivel de aplicație (vezi [[AI research/Papers/Security Analysis of a Medical IoT Device Data Leakage to an Eavesdropper|Security Analysis of Medical IoT]]). |
| **BLE Adv: Appearance 0x03C1 (Keyboard)** | Tastatură Bluetooth Low Energy | **Eavesdropping / Packet Injection** | **RIDICAT** | Dacă tastatura folosește moduri de împerechere slabe (Just Works), Ubertooth poate asista la captarea pachetelor de pairing și spargerea lor offline (vezi [[AI research/Papers/6 . 858  Hacking Bluetooth|6.858: Hacking Bluetooth]]). |
| **Classic: LAP/UAP asociat cu OUI Broadcom/Cypress** | Laptop, Smart TV sau Smartphone vechi | **BrakTooth / KNOB / BIAS** | **MEDIU** | Cipurile BR/EDR Broadcom/Cypress din generații anterioare sunt vulnerabile structural la BrakTooth (mesaje LMP malformate) și KNOB (entropie cheie redusă). Dashboard-ul avertizează utilizatorul asupra riscului teoretic bazat pe producătorul cipului (OUI). |
| **BLE Adv: Adresă MAC statică (fără randomizare)** | Dispozitiv IoT static (Smart Home, etc.) | **Urmărire / Pierderea confidențialității** | **MEDIU** | Dispozitivele care nu folosesc adrese private randomizate (RPA) pot fi urmărite geografic de orice receptor pasiv (vezi [[AI research/Papers/Protecting Privacy of BLE Device Users|Protecting Privacy of BLE Device Users]]). |

---

## 3. Logica de Alerte pentru Dashboard (Detecție Anomalii)

Dashboard-ul poate folosi starea curentă a conexiunilor și semnalelor pentru a semnala posibile comportamente suspecte în perimetru:

### A. Alerta "Downgrade Suspect de Securitate"
*   **Scenariu:** Un dispozitiv BLE cunoscut (înregistrat anterior în baza de date cu suport LE Secure Connections și criptare activă) apare brusc în aer realizând o asociere de tip "Just Works" sau fără autentificare.
*   **Semnificație:** Posibil atac de downgrade (cum ar fi **BLURtooth** sau **BLESA**) în desfășurare.

### B. Alerta "Clonare de Adresă MAC (Spoofing)"
*   **Scenariu:** Se detectează două semnale cu aceeași adresă MAC (sau LAP/UAP), însă valorile RSSI indică locații fizice complet diferite, sau intervalele de conectare (Connection Intervals) se suprapun într-un mod imposibil fizic pentru un singur radio.
*   **Semnificație:** Atacator activ care clonează un dispozitiv legitim (esențial pentru **BIAS** și **BLESA**).

---

## 4. Limitări Critice ale Dashboard-ului (Ce trebuie explicat utilizatorului)

Pentru ca lucrarea de licență să fie riguroasă, dashboard-ul trebuie să includă o secțiune de **Disclaimer / Limitări Hardware**:
1.  **Fără Detecție Certă a Exploit-ului:** Dashboard-ul raporteaază vulnerabilitățile ca fiind **potențiale (riscuri teoretice)** pe baza tipului de dispozitiv și producătorului detectat. Nu poate confirma dacă un atac BrakTooth sau SweynTooth a avut loc cu succes doar prin sniffing pasiv.
2.  **Rate de Packet Loss:** Din cauza bruiajului pe banda de 2.4 GHz (WiFi, cuptoare cu microunde), Ubertooth One poate pierde pachetele critice de pairing. Astfel, starea de securitate a unui dispozitiv poate fi clasificată incorect ca "sigură" doar pentru că pachetele de negociere nu au fost captate.
3.  **Incapacitate EDR:** Orice trafic de date moderne pe Classic (EDR 2/3 Mbps) este invizibil pentru Ubertooth. Dispozitivele Classic vor fi mapate doar la nivel de prezență (LAP/UAP), nu și la nivel de conținut.
