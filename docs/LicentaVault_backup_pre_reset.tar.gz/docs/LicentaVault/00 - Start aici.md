---
tags: [overview, onboarding]
status: current
updated: 2026-05-24
---
# 00 - Start aici

## Într-o propoziție
`ubertooth-standalone` este o aplicație desktop Tauri care oferă o interfață “operator dashboard” pentru un dispozitiv **Ubertooth One**, rulând local binarele `ubertooth-*` și afișând rezultate live: spectru RF, BLE devices, consolă și status hardware.

## Ce problemă rezolvă
În loc să rulezi manual comenzi de terminal precum `ubertooth-specan`, `ubertooth-btle` sau `ubertooth-util`, aplicația:
- detectează hardware-ul;
- verifică handshake-ul cu `ubertooth-util -v`;
- oferă un UI cu formulare ghidate pentru comenzi;
- validează argumentele pe backend;
- pornește un singur proces hardware activ la un moment dat;
- stream-uiește stdout/stderr sau batch-uri de spectru către frontend;
- aplică reguli de siguranță pentru TX, DFU și duty-cycle.

## Cele 4 straturi mentale
```mermaid
flowchart TB
  A["Layer 1 — Shell / UI"] --> B["Layer 2 — State & schema JS"]
  B --> C["Layer 3 — Tauri commands Rust"]
  C --> D["Layer 4 — Binare Ubertooth + DLL-uri"]

  A --- A1[src/main.js, splash.jsx, styles.css]
  B --- B1[SessionController, HardwareStore, SchemaEngine, TelemetryStreamer]
  C --- C1[src-tauri/src/main.rs, runner.rs, discovery.rs, safety.rs, commands/*]
  D --- D1[src-tauri/resources/ubertooth-*.exe, lib*.dll]
```

## Ce să ții minte
- `splash.html` / `src/splash.jsx` este ecranul de pornire: așteaptă evenimentele de conexiune.
- `index.html` / `src/main.js` este dashboard-ul principal.
- `src/commands-schema.json` descrie formularele și argumentele din UI.
- `src-tauri/src/main.rs` expune comenzile Tauri și face auto-polling pentru hardware.
- `src-tauri/src/runner.rs` pornește procesele `.exe` și emite evenimente către UI.
- `src-tauri/src/safety.rs` conține guardrails: TX antenna, DFU confirm, duty-cycle.
- `src-tauri/src/commands/mod.rs` validează allowlist-ul de argumente.

## Intrări utile pentru studiu
- [[Flows/Flow general al aplicatiei]]
- [[Flows/Flow comenzi hardware]]
- [[Flows/Flow boot si handshake]]
- [[Flows/Flow telemetrie si vizualizari]]
- [[Referinte/Observatii si riscuri curente]]
- [[Referinte/Literatura Academica|Literatura Academică Ubertooth]]

> Scop acum Classic-only (pivot 2026-07-30). Notele de rezultate proprii BLE au fost retrase/reformulate.

