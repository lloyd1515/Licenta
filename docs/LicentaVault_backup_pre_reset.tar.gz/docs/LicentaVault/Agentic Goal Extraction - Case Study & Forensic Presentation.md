# Agentic Goal Extraction & Persistence Canvas — Forensic Case Study & Presentation

> **Presentation Deck**: ![[Agentic_Goal_Extraction_Presentation.excalidraw]]  
> **Source Repository**: [github.com/lloyd1515/agentic_goal_extraction](https://github.com/lloyd1515/agentic_goal_extraction.git)  
> **Target Architecture**: CQRS (Command Query Responsibility Segregation) + Human-in-the-Loop (HITL)  
> **Verification Status**: 100% Automated Test Pass Rate (227 / 227 tests passing)  
> **Author & Candidate**: Vlad Sărățeanu | Sesiune Septembrie 2026

---

## 1. Executive Summary & Problem Framing

Modern enterprise performance management relies on frequent 1:1 discussions between managers and employees. While rich in context, these discussions generate unstructured notes, action commitments, and development milestones that frequently fail to translate into trackable organizational goals.

Traditional attempts to automate goal extraction using Large Language Models (LLMs) suffer from two fatal failure modes:
1. **The Excessive Agency Vulnerability (OWASP LLM08)**: Granting an AI agent direct write access to enterprise databases invites catastrophic hallucinations, unauthorized modifications, and SQL injection via untrusted inputs.
2. **The Passive Ingestion Fallacy**: Presenting raw LLM outputs directly to production systems without mandatory human review causes employee distrust, irrelevant goal assignment, and metric drift.

The **Agentic Goal Extraction & Persistence Canvas** solves these foundational challenges by implementing a strictly decoupled **CQRS** architecture paired with an interactive **Human-in-the-Loop (HITL)** staging canvas, verified across 6 academic research dimensions.

```mermaid
flowchart LR
    A["1. Raw Transcript Ingestion"] --> B["2. MediatR Command Bus"]
    B --> C["3. Agentic Extraction Loop (Read-Only DB Tool)"]
    C --> D["4. Interactive HITL Review Canvas"]
    D --> E["5. Atomic Batch Persistence (BeginTransactionAsync)"]
    
    style A fill:#e7f5ff,stroke:#1864ab,stroke-width:2px
    style B fill:#e6fcf5,stroke:#0ca678,stroke-width:2px
    style C fill:#f3f0ff,stroke:#5f3dc4,stroke-width:2px
    style D fill:#fff4e6,stroke:#d9480f,stroke-width:2px
    style E fill:#ebfbee,stroke:#2b8a3e,stroke-width:2px
```

---

## 2. Decoupled CQRS Architecture & Physical Sandboxing

The system strictly segregates reads from writes across distinct commands, database contexts, and execution lifecycles:

### 2.1 The Extraction Command Path (`ExtractGoalsCommand`)
- **Controller Decoupling**: [`GoalsController.ExtractGoals`](file:///home/vlads4r4/dev/side-projects/Agentic__Transcribe_Goal_Todolist/implementation/backend/src/GoalExtraction.Api/Controllers/GoalsController.cs) receives the request, enforces schema validation, and dispatches an immutable `ExtractGoalsCommand` through MediatR.
- **Physical SQLite Sandboxing**: The query tool utilizes [`ReadOnlyGoalExtractionDbContext`](file:///home/vlads4r4/dev/side-projects/Agentic__Transcribe_Goal_Todolist/implementation/backend/src/GoalExtraction.Infrastructure/Persistence/ReadOnlyGoalExtractionDbContext.cs) configured with `Data Source=goals.db;Mode=ReadOnly;`.
- **Engine PRAGMA Guardrail**: An internal DbCommand interceptor executes `PRAGMA query_only = ON;` upon connection opening. Any attempted mutating SQL query (`INSERT`, `UPDATE`, `DELETE`, `DROP`) triggers an immediate `SqliteException: attempt to write a readonly database` at the C/C++ engine level.
- **Interface Segregation**: The agent is provided only with [`IReadOnlyGoalQueryRepository`](file:///home/vlads4r4/dev/side-projects/Agentic__Transcribe_Goal_Todolist/implementation/backend/src/GoalExtraction.Domain/Interfaces/IReadOnlyGoalQueryRepository.cs), which exposes solely query methods (`GetActiveGoalsByEmployeeIdAsync`).

### 2.2 The Persistence Command Path (`SaveGoalsBatchCommand`)
- **Zero AI Guarantee**: [`SaveGoalsCommandHandler`](file:///home/vlads4r4/dev/side-projects/Agentic__Transcribe_Goal_Todolist/implementation/backend/src/GoalExtraction.Application/Commands/SaveGoalsBatchCommandHandler.cs) operates completely isolated from the AI Agent, OpenAI clients, and LLM SDKs.
- **Transactional Atomicity**: Final approval triggers `BeginTransactionAsync`. All approved or human-edited goals are committed atomically. Any constraint failure triggers a total rollback (`ROLLBACK`), preventing partial or orphaned database records.
- **Idempotency Protection**: Every batch submission includes an `Idempotency-Key` (UUIDv4) header, preventing duplicate inserts from rapid double-clicks.

---

## 3. The 6 Evaluation Dimensions Grounded in Academic Literature

The testing suite was built upon empirical methodologies published in seminal NLP, agentic security, and dialogue state tracking research papers:

| Dimension | Academic Reference & Benchmark | Key Finding & Defensive Implementation |
| :--- | :--- | :--- |
| **1. Multi-Speaker Attribution** | **Purver et al. (ACL 2007)**, *Alimeeting4MUG (ICASSP 2023)* | Disentangles Directive speech acts (manager request) from Commissive speech acts (employee acceptance). Tasks declined or assigned to third parties are never extracted. |
| **2. Indirect Prompt Injection** | **InjecAgent (ACL 2024)**, *BIPIA (Microsoft 2023)*, *OWASP LLM01/08* | Hostile injections smuggled into logs (e.g., `'; DROP TABLE goals; --`) are physically blocked by `PRAGMA query_only = ON;` and type-safe parameterized queries. |
| **3. Ambiguity & SMART Commitments** | **SUTime / TimeML (Stanford NLP)**, *QMSum (NAACL 2021)* | Filters idle conversational chatter and extracts only concrete commitments with measurable metrics and normalized deictic timeframes (e.g., "by Q3 2026"). |
| **4. Dialogue State Tracking** | **MultiWOZ 2.4 (2021)**, *MeetingBank (ACL 2023)* | Agent invokes `query_existing_employee_goals` to inspect active goals, preventing duplicate record creation when progress is reported incrementally. |
| **5. Multilingual Code-Switching** | **ASCEND (HKUST 2021)**, *LinCE Benchmark* | Evaluated on spontaneous technical code-switching (Denglish, Spanglish, Franglais), preserving technical terminology without semantic corruption. |
| **6. Delimiter & Boundary Stress** | **GAIA Benchmark (2023)**, *ChatEval (2023)* | Evaluated on a 30,802-character transcript near the 32,000-character ceiling (~8k tokens), executing without memory starvation or schema divergence. |

For the complete bibliography, see [`RESOURCES_AND_REFERENCES.md`](file:///home/vlads4r4/dev/side-projects/Agentic__Transcribe_Goal_Todolist/RESOURCES_AND_REFERENCES.md).

---

## 4. The Audit Crucible: Forensic Critique & Devil's Advocate Findings

Prior to final release, the system underwent an adversarial forensic audit. The Devil's Advocate review surfaced 4 critical vulnerabilities:

### Finding 1: The Physical SQLite Read-Only Isolation Gap (Critical)
- *Flaw*: Initial versions relied solely on C# interface segregation (`IReadOnlyGoalQueryRepository`). In SQLite, sharing the default connection string allowed raw SQL injections to mutate tables.
- *Remediation*: Implemented `ReadOnlyGoalExtractionDbContext` with `Mode=ReadOnly;` and `PRAGMA query_only = ON;`.

### Finding 2: Hardcoded Secrets & Credential Leakage (High)
- *Flaw*: Static API keys and internal development URLs were present in local config files.
- *Remediation*: Sanitized repository completely, created [`.env.example`](file:///home/vlads4r4/dev/side-projects/Agentic__Transcribe_Goal_Todolist/.env.example), and updated `.gitignore` to prevent secret leakage.

### Finding 3: DTO Contract Divergence & Serialization Loss (Medium-High)
- *Flaw*: PascalCase (.NET 8) vs. camelCase (React 18) naming drift caused silent loss of the `provenance` and `metric` fields upon deserialization.
- *Remediation*: Decorated all C# DTOs with explicit `[JsonPropertyName(...)]` attributes and mirrored Zod/TypeScript types.

### Finding 4: The Free-Tier Rate Limit & Quota Trap (High)
- *Flaw*: Reliance on free-tier LLM endpoints triggered HTTP 429 cascades during concurrent load tests.
- *Remediation*: Integrated `Microsoft.Extensions.Http.Polly` with exponential backoff (1s, 2s, 4s), `CircuitBreakerAsync(5, 30s)`, and multi-tier provider cascade (Titan ➔ Gemini).

---

## 5. Multi-Tier Verification Suite (227 / 227 Tests Passing)

The solution achieves a **100% automated pass rate across 227 test scenarios**:

```
========================================================================================
TEST SUITE EXECUTION SUMMARY:
----------------------------------------------------------------------------------------
1. Backend Unit Tests (GoalExtraction.UnitTests)          :  122 / 122 PASSED  (1.84s)
2. Backend Integration Tests (GoalExtraction.Integration) :   32 /  32 PASSED  (3.12s)
3. Frontend Vitest Component Tests                        :   52 /  52 PASSED  (2.45s)
4. Comprehensive 21-Scenario Benchmark (Python Runner)    :   21 /  21 PASSED (18.20s)
----------------------------------------------------------------------------------------
TOTAL QUALITY GATE                                        :  227 / 227 PASSED (100.0%)
========================================================================================
```

### Exact Reproduction Commands:
```bash
# 1. Backend Unit Tests
dotnet test implementation/backend/tests/GoalExtraction.UnitTests

# 2. Backend Integration Tests
dotnet test implementation/backend/tests/GoalExtraction.IntegrationTests

# 3. Frontend Vitest Component Tests
cd implementation/frontend && npm test -- --run

# 4. Multi-Dimensional Edge Case Benchmark
python3 implementation/run_comprehensive_test_suite.py
```

---

## 6. Live Chrome DevTools MCP & Visual Evidence

Using the `chrome-devtools-mcp` integration, the user interface was audited end-to-end in a live Chromium instance across 7 distinct verification milestones:
1. **Initial Ingestion**: Clean responsive textarea, character counter active, 1,500-char transcript loaded.
2. **Extraction State**: Progress spinner displayed (`Analyzing transcript with AI Agent...`), read-only DB tool query logged.
3. **Review Canvas**: 3 SMART goals rendered with `AI Suggested` badges, priority dropdowns, and metric fields.
4. **Inline Card Mutation**: Direct in-place editing; badge dynamically transitions to `AI Suggested (Edited)`.
5. **Escape Revert**: Pressing `Escape` cancels edits and restores the previous value without network overhead.
6. **Batch Dispatch**: Network inspector records `POST /api/goals/batch` with `Idempotency-Key: UUIDv4`.
7. **Atomic Persistence Confirmation**: Backend responds with HTTP `201 Created`; success toast notification displayed.

---

## 7. Production Release & Artifacts

- **Remote GitHub Repository**: [https://github.com/lloyd1515/agentic_goal_extraction.git](https://github.com/lloyd1515/agentic_goal_extraction.git)
- **Production Commit**: `ffaa2f1` (`feat: agentic goal extraction & persistence canvas with CQRS and strict read-only AI sandboxing`)
- **Clean Tree**: Working tree verified clean with zero secrets or extraneous build artifacts.
- **Specification Files**:
  - [`AcceptanceCriteria.md`](file:///home/vlads4r4/dev/side-projects/Agentic__Transcribe_Goal_Todolist/AcceptanceCriteria.md) (Full Gherkin BDD specs for AC 1 to AC 6 and NFR 1 to NFR 7)
  - [`Description.md`](file:///home/vlads4r4/dev/side-projects/Agentic__Transcribe_Goal_Todolist/Description.md) (Architecture overview)
  - [`RESOURCES_AND_REFERENCES.md`](file:///home/vlads4r4/dev/side-projects/Agentic__Transcribe_Goal_Todolist/RESOURCES_AND_REFERENCES.md) (Academic bibliography)

---

## 8. Excalidraw Presentation Navigation

The accompanying presentation deck `![[Agentic_Goal_Extraction_Presentation.excalidraw]]` is organized in a **4x2 2D presentation grid**:

| Frame ID | Slide Title | Visual Focus |
| :--- | :--- | :--- |
| **01** | **Title & Executive Summary** | Architecture pillars, 5-stage end-to-end data pipeline, core thesis. |
| **02** | **The 6 Academic Dimensions** | Purver 2007 speech acts, InjecAgent 2024, MultiWOZ 2.4, ASCEND code-switching. |
| **03** | **The Audit Crucible** | Forensic critique: SQLite isolation gap, hardcoded secrets, DTO drift, quota traps. |
| **04** | **Architectural Remediation** | ReadOnlyDbContext, `PRAGMA query_only = ON;`, Polly circuit breaker, Escape revert. |
| **05** | **Multi-Tier Verification Suite** | 227 tests breakdown (122 Unit, 32 Integration, 52 Vitest, 21 Edge-case runner). |
| **06** | **Live Chrome MCP Evidence** | 7 browser proof milestones, CDP DOM inspection, network inspector payload. |
| **07** | **Production Release & Git Sync** | GitHub repository ffaa2f1, secret sanitization, .env governance, Docker readiness. |
| **08** | **Forensic Trajectory & Methodology** | 6-phase conversation lifecycle timeline + Karpathy & SOLID design principles. |

*To present: Open `Agentic_Goal_Extraction_Presentation.excalidraw.md` in Obsidian and switch to Excalidraw view.*
