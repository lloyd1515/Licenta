---
tags: [safety, constraints]
status: current
updated: 2026-05-24
---
# Siguranță și limite

## Guardrails implementate
| Guardrail | Unde | Status |
|---|---|---|
| Allowlist argumente per comandă | `src-tauri/src/commands/mod.rs` | Activ. |
| Command unknown reject | `validate_args` | Activ. |
| Value/range validation | `validate_args` | Activ pentru câmpurile UI și cazurile clare. |
| Schema parity frontend/backend | Rust tests | Activ: schema flags trebuie să existe în backend allowlist/expectations. |
| Antenna confirm pentru TX | `safety.rs` + `SessionController` | Activ backend, dar UI curent nu expune comenzile TX listate. |
| Duty-cycle TX 60s / 60min | `DutyCycleTracker` | Activ pentru tool-uri recunoscute ca TX. |
| DFU confirm explicit | frontend + backend | Activ și testat cu Tauri mock. |
| Single process active | `runner_actor_loop` | Activ în actor. |
| Cleanup după terminare naturală | `runner_actor_loop` | Activ și testat. |
| Cooldown după stop | `runner_actor_loop` | 1 secundă. |
| Tauri capability event emit blocked | `capabilities/default.json` | Activ: doar `core:event:allow-listen`, plus `core:webview:allow-webview-close`. |

## Model mental safety
```mermaid
flowchart TD
  Start[execute_command] --> Known{command known}
  Known -- no --> Reject1[reject]
  Known -- yes --> Args{flags and values valid}
  Args -- no --> Reject2[reject]
  Args -- yes --> Tx{is TX tool}
  Tx -- yes --> Antenna{antenna_ok}
  Antenna -- no --> Reject3[reject]
  Antenna -- yes --> Duty{duty under limit}
  Duty -- no --> Reject4[reject]
  Duty -- yes --> Dfu{DFU}
  Tx -- no --> Dfu
  Dfu -- yes --> Confirm{dfu_confirmed}
  Confirm -- no --> Reject5[reject]
  Confirm -- yes --> Spawn[runner start]
  Dfu -- no --> Spawn
```

## Ce nu este încă garantat
- Comportamentul fizic al device-ului sub trafic real.
- DFU real cu firmware image și recovery plan.
