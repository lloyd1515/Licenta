---
tags: [module, backend, rust, tauri]
status: current
updated: 2026-05-24
---
# Backend Tauri Rust

## Rol
Backend-ul Tauri expune comenzi pentru frontend, face detectarea hardware, validează input-ul, rulează procese Ubertooth și emite evenimente live către UI.

## Module Rust
| Modul | Rol |
|---|---|
| `main.rs` | Tauri builder, command registry, handshake, execute_command, auto-polling. |
| `runner.rs` | Path resolving, process spawn, stdout/stderr readers, actor single-job, stop/cooldown, completion cleanup, specan batch events. |
| `discovery.rs` | Windows PnP scan pentru VID `1D50`. |
| `safety.rs` | TX antenna gate, DFU confirmation, rolling duty-cycle tracker. |
| `commands/mod.rs` | Command registry, allowlist validation, value/range validation și schema parity test. |
| `commands/*.rs` | Allowlist + parser structs pentru fiecare tool. |

## Runner actor
```mermaid
stateDiagram-v2
  [*] --> Idle
  Idle --> Running: RunnerMessage Start
  Running --> Running: stdout stderr reader threads emit events
  Running --> DoneEmitted: child exits naturally and waiter emits command-done
  DoneEmitted --> Idle: RunnerMessage Finished clears current_child
  Running --> Idle: RunnerMessage Stop kills running child and cooldown
  Idle --> Running: next Start after stale probe is clear
```

## Ce este verificat
- `cargo test`: **29 teste trecute** pe 2026-05-24.
- Runner cleanup după terminare naturală.
- Kill pentru proces lung fără waiter lock contention.
- Frontend schema flags sunt validate de backend.
- Packaged debug MSI build trece.

## Limită rămasă
Nu există încă test cu Ubertooth fizic conectat.
