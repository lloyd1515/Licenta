---
tags: [module, frontend]
status: current
updated: 2026-05-24
---
# Frontend JS

## Rol
Frontend-ul este un UI Vite/JS care randă dashboard-ul, menține state-ul de interacțiune și comunică cu backend-ul Tauri prin `invoke` și `listen`.

## Entry points
| Fișier | Rol |
|---|---|
| `src/splash.jsx` | Guard screen pentru detectarea hardware-ului. |
| `src/main.js` | Dashboard principal, shell render, event binding, render loop. |
| `src/styles.css` | Tailwind theme și clase custom. |
| `src/commands-schema.json` | Schema declarativă pentru formularele de comenzi. |

## Clase core
| Clasă | Fișier | Responsabilitate |
|---|---|---|
| `SessionController` | `src/core/SessionController.js` | tab activ, comandă selectată, draft args, arm state, run/stop command. |
| `HardwareStore` | `src/core/HardwareStore.js` | devices, duty cycle, current job, active command; invocă backend. |
| `SchemaEngine` | `src/core/SchemaEngine.js` | citește schema JSON, construiește argumente, identifică comenzi dangerous/TX. |
| `TelemetryStreamer` | `src/core/TelemetryStreamer.js` | ascultă Tauri events și actualizează state pentru spectrum/BLE. |
| `UIFactory` | `src/core/UIFactory.js` | render HTML pentru câmpuri, categorii, summary, warnings. |

## Componente UI imperative
| Componentă | Rol |
|---|---|
| `ScanPanel` | gestionează lista BLE și follow target. |
| `ChannelMap` | randă 40 canale BLE și permite selectarea canalului. |

## Tab-uri principale
- `dashboard` — status, command control, console, CVE container.
- `spectrum` — spectrum line + waterfall canvas.
- `ble` — BLE discovery + listă dispozitive.
- `settings` — util version/reset și DFU.

## Tauri bridge folosit în frontend
```mermaid
flowchart LR
  HardwareStore -->|invoke detect_devices| Rust
  HardwareStore -->|invoke get_duty_cycle_status| Rust
  HardwareStore -->|invoke execute_command| Rust
  HardwareStore -->|invoke stop_command| Rust
  MainJS -->|invoke list_commands| Rust
  Splash -->|invoke retry_connection/finalize_connection| Rust
  Rust -->|listen command-output| TelemetryStreamer
  Rust -->|listen command-batch| TelemetryStreamer
  Rust -->|listen command-done| TelemetryStreamer
  Rust -->|listen connection-*| Splash
```

## Observații curente
- `SchemaEngine.isTxCommand()` include `ubertooth-tx`, `ubertooth-ego`, `ubertooth-ducky`, dar schema curentă nu expune aceste comenzi în UI. Pentru cele 8 comenzi actuale, TX gating nu se activează din UI.
