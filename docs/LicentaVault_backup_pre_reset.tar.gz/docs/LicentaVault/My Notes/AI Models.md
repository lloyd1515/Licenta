https://huggingface.co/empero-ai/Qwythos-9B-Claude-Mythos-5-1M-GGUF

https://huggingface.co/roslein/Qwen3-32B-abliterated
