---
tags: [flow, architecture]
status: current
updated: 2026-05-24
---
# Flow general al aplicației

## Flow-ul mare
```mermaid
sequenceDiagram
  participant Op as Operator
  participant Splash as src/splash.jsx
  participant MainRs as Rust main.rs
  participant Disc as discovery.rs
  participant Runner as runner.rs
  participant UI as src/main.js Dashboard
  participant Store as JS Stores
  participant Exe as ubertooth-*.exe

  MainRs->>MainRs: pornește Tauri + runner_actor_loop
  MainRs->>Splash: fereastra pornește la splash.html
  MainRs->>Disc: auto-poll detect_devices / discover_devices
  Disc-->>MainRs: device găsit sau listă goală
  MainRs->>Runner: verify_handshake => ubertooth-util -v
  Runner-->>MainRs: OK / eroare
  MainRs-->>Splash: connection-progress / success / error
  Splash->>MainRs: finalize_connection după success
  MainRs-->>Splash: navigate către index.html
  Splash-->>UI: dashboard se încarcă
  UI->>Store: renderShell + queryEls + bindEvents
  Store->>MainRs: invoke(list_commands, detect_devices, duty_cycle)
  Op->>UI: click Run / Start Specan / BLE / Scan
  UI->>Store: SessionController.runCurrentCommand
  Store->>MainRs: invoke(execute_command)
  MainRs->>Runner: start_command
  Runner->>Exe: spawn process
  Exe-->>Runner: stdout/stderr / spectrum lines
  Runner-->>Store: command-output / command-batch / command-done
  Store-->>UI: update console, metrics, spectrum, BLE list
```

## Lifecycle pe pași
1. **Tauri pornește fereastra principală** cu URL inițial `splash.html` (`src-tauri/tauri.conf.json`).
2. **Backend-ul pornește runner actor-ul** (`runner::runner_actor_loop`) și auto-polling-ul hardware (`main.rs`).
3. **Splash UI ascultă evenimentele** `connection-progress`, `connection-error`, `connection-success` (`src/splash.jsx`).
4. **Detectarea hardware** se face prin Windows PnP (`discovery.rs`) și fallback direct cu `ubertooth-util -v` (`runner.rs`).
5. La success, splash cheamă `finalize_connection`, iar backend-ul navighează către `index.html`.
6. **Dashboard-ul principal** randat în `src/main.js` creează shell-ul UI și inițializează store-urile/componentele.
7. Operatorul selectează sau declanșează o comandă.
8. Frontend-ul construiește argumente ghidate + manuale din schema JSON.
9. Backend-ul validează allowlist-ul, safety gates și pornește binarul.
10. Output-ul revine ca evenimente și actualizează UI.

## Flow-uri GitNexus relevante observate
GitNexus a indexat 42 execution flows. Exemple relevante:
- `LoadCommands → GetCommandSchema` — dropdown UI + schema command.
- `RunCurrentCommand → GetState` — execuția unei comenzi din state-ul JS.
- `Execute_command → Allowed_args_for` — validare backend înainte de spawn.
- `Execute_command → Is_tx_tool` — safety pentru tool-uri TX.
- `StartPolling → GetState` — refresh periodic device/duty-cycle.
- `SubscribeToEvents → AppendConsoleLine` — evenimente backend spre consolă UI.
- `RenderLoop → GetTurboColor` — frame-uri spectrum/waterfall.
- `Main → UbertoothDevice` și `Retry_connection → Resolve_binary_path` — boot/handshake.

## Conceptual: ce face aplicația în runtime
```mermaid
flowchart TD
  Boot[Boot Tauri] --> Splash[Splash guard]
  Splash -->|hardware ok| Dashboard[Dashboard]
  Splash -->|hardware missing/error| Retry[Retry / Exit]
  Dashboard --> Poll[Polling devices + duty]
  Dashboard --> CommandUI[Command Control]
  CommandUI --> Args[SchemaEngine + manual args]
  Args --> Safety[Backend validation + safety]
  Safety --> Runner[Runner actor]
  Runner --> Process[Ubertooth process]
  Process --> Output[stdout/stderr/specan batch]
  Output --> Telemetry[TelemetryStreamer]
  Telemetry --> Views[Console / BLE / Spectrum / Metrics]
```
