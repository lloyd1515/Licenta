---
tags: [flow, telemetry, ui]
status: current
updated: 2026-05-24
---
# Flow telemetrie și vizualizări

## Scop
Arată cum se transformă output-ul din tool-urile Ubertooth în UI: consolă, spectrum, waterfall, BLE list și metrici RSSI.

## Spectrum / `ubertooth-specan`
```mermaid
flowchart TD
  Specan[ubertooth-specan stdout] --> Parser[SpecanParser Rust]
  Parser --> Batch[command-batch data: freq,rssi pairs]
  Batch --> Telemetry[TelemetryStreamer.listen command-batch]
  Telemetry --> Runtime[processSpectrumBatch]
  Runtime --> State[spectrumData array 80]
  State --> RenderLoop[requestAnimationFrame renderLoop]
  RenderLoop --> Line[renderSpectrumFrame canvas]
  RenderLoop --> Waterfall[renderWaterfallFrame canvas]
  Runtime --> Hero[hero metric last RSSI]
```

## BLE / `ubertooth-btle`
```mermaid
flowchart TD
  BTLE[ubertooth-btle output] --> Event[command-output]
  Event --> Telemetry[TelemetryStreamer]
  Telemetry --> Processor[processCommandOutput]
  Processor -->|adv_mac regex| Devices[bleDevices]
  Processor -->|rssi regex| Metric[Hero RSSI]
  Devices --> ScanPanel[ScanPanel.updateDevices]
  ScanPanel --> List[BLE device list + Follow buttons]
  List --> Target[queueBleFollowTarget]
  Target --> Draft[select ubertooth-btle + follow + analysisTarget]
```

## Console output
- Pentru comenzi care nu sunt consumate semantic, output-ul ajunge în `appendConsoleLine()`.
- `stderr` primește clasă separată.
- `command-done` adaugă `✓ FINISHED` sau `✗ FAILED`.

## Observație despre ordering
În starea curentă, `TelemetryStreamer.start()` aplică patch-ul de state înainte de `onBleDevicesChanged()`, apoi `ScanPanel` citește `telemetry.getBleDevices()`. Acesta este flow-ul corect de urmărit când verifici lista BLE.
