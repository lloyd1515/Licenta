---
tags: [flow, boot, hardware]
status: current
updated: 2026-05-24
---
# Flow boot și handshake hardware

## Scop
Înainte să ajungi în dashboard, aplicația încearcă să confirme că există un Ubertooth One conectat și că `ubertooth-util -v` răspunde.

## Fișiere implicate
- `src-tauri/tauri.conf.json` — fereastra pornește la `splash.html`.
- `src/splash.jsx` — UI-ul de guard/loader.
- `src-tauri/src/main.rs` — `attempt_handshake`, `retry_connection`, `finalize_connection`.
- `src-tauri/src/discovery.rs` — Windows PnP scan.
- `src-tauri/src/runner.rs` — `verify_handshake`, `resolve_binary_path`.

## Secvență
```mermaid
sequenceDiagram
  participant App as Tauri main.rs
  participant Window as Main Webview
  participant Splash as splash.jsx
  participant PnP as discovery.rs
  participant Util as ubertooth-util.exe

  App->>Window: open splash.html
  Splash->>Splash: listen(connection-progress/error/success)
  App->>App: după ~1500ms, începe loop auto-poll
  App->>PnP: discover_devices()
  PnP-->>App: device list sau []
  alt device PnP găsit
    App->>Util: verify_handshake() => ubertooth-util -v
    Util-->>App: exit 0 / non-zero
    App-->>Splash: progress pnp/util + success/error
  else PnP gol
    App->>Util: fallback direct ubertooth-util -v
    Util-->>App: exit 0 / non-zero
    App-->>Splash: success dacă exit 0, altfel retry loop
  end
  Splash->>App: invoke(finalize_connection) după success
  App->>Window: navigate index.html
```

## Detalii importante
- `discover_devices()` caută în `Win32_PnPEntity` device IDs care conțin `1D50`.
- Dacă PnP nu găsește nimic, backend-ul încearcă direct `ubertooth-util -v`.
- `resolve_binary_path()` caută binarul întâi lângă exe-ul Tauri în `resources`, apoi în `src-tauri/resources` pentru dev.
- Auto-polling-ul se oprește doar la success.
- Retry-ul manual cheamă `retry_connection`.
