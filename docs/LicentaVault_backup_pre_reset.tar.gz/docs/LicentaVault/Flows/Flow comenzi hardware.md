---
tags: [flow, commands, hardware]
status: current
updated: 2026-05-24
---
# Flow comenzi hardware

## Scop
Explică drumul de la un click în UI până la pornirea unui proces `ubertooth-*.exe`.

## Secvență end-to-end
```mermaid
sequenceDiagram
  participant Op as Operator
  participant UI as src/main.js
  participant Session as SessionController
  participant Schema as SchemaEngine
  participant HW as HardwareStore
  participant Rust as execute_command(main.rs)
  participant Cmd as commands/mod.rs
  participant Safety as safety.rs
  participant Runner as runner.rs actor
  participant Proc as ubertooth-*.exe

  Op->>UI: click Run / quick action
  UI->>Session: selectCommand/updateDraft/runCurrentCommand
  Session->>Schema: buildGuidedArgs(schema, draft)
  Session->>HW: startCommand(cmd, args, antennaOk)
  HW->>Rust: invoke execute_command(commandName,args,antennaOk,dfuConfirmed)
  Rust->>Cmd: validate_args(command,args)
  Cmd-->>Rust: OK sau reject flag
  Rust->>Safety: check_antenna_confirmed
  Rust->>Safety: check_dfu_confirmed
  Rust->>Safety: duty_cycle.check dacă TX
  Rust->>Runner: start_command(tool,args)
  Runner->>Proc: spawn binary + patched PATH
  Proc-->>Runner: stdout/stderr
  Runner-->>UI: command-output / command-batch / command-done
```

## Frontend: cum se construiesc argumentele
1. `loadCommands()` cere `list_commands` din Rust.
2. Dropdown-ul este populat, dar detaliile UI vin din `src/commands-schema.json`.
3. `SessionController.selectCommand()` inițializează `commandDraft` cu default-urile din schema JSON.
4. Inputurile din UI au `data-command-field`; `syncCommandFieldFromTarget()` actualizează draft-ul.
5. `SchemaEngine.buildGuidedArgs()` transformă draft-ul în flag-uri:
   - boolean `true` => doar flag (`-v`);
   - text/number => flag + value (`-c 37`).
6. `buildManualArgs()` adaugă override-urile brute din inputul “Expert Overrides”.

## Backend: ce verifică înainte de spawn
| Verificare | Unde | Ce previne |
|---|---|---|
| Command known | `commands::allowed_args_for` | comenzi necunoscute. |
| Flag allowlist | `commands::validate_args` | flag-uri arbitrare pe tool-uri native. |
| Antenna confirm | `safety::check_antenna_confirmed` | TX fără antenă confirmată. |
| DFU confirm | `safety::check_dfu_confirmed` | firmware flashing fără confirmare. |
| Duty cycle | `DutyCycleTracker::check` | prea mult TX într-o fereastră de 60 min. |
| Single active process | `runner_actor_loop` | două procese hardware simultane. |

## Runner actor
`runner_actor_loop` ține `current_child` și primește mesaje:
- `Start` — rezolvă binarul, pornește procesul, creează thread-uri de stdout/stderr/waiter.
- `Stop` — omoară procesul curent și aplică cooldown de 1 secundă.

## Evenimente emise către frontend
| Event | Payload | Consumator |
|---|---|---|
| `command-output` | `{ jobId, line, isStderr }` | `TelemetryStreamer`, console/BLE parsing. |
| `command-batch` | `{ jobId, data: [freq,rssi,...] }` | spectrum/waterfall. |
| `command-done` | `{ jobId, tool, success, code }` | reset state + log final. |
