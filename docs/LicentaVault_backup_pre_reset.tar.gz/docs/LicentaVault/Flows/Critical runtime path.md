---
tags: [flow, runtime, critical-path]
status: current
updated: 2026-05-24
---
# Critical runtime path

Aceasta este ruta exactă pe care merită să o urmărești când vrei să înțelegi “cum rulează aplicația” de la click până la output în UI.

## Click → args → backend → process → telemetry
```mermaid
flowchart TD
  Click[Operator apasa Run sau un quick action] --> MainJS[src/main.js]
  MainJS --> Session[SessionController.runCurrentCommand]
  Session --> Schema[SchemaEngine.buildGuidedArgs]
  Session --> Hardware[HardwareStore.startCommand]
  Hardware --> Invoke[invoke execute_command]
  Invoke --> RustMain[src-tauri/src/main.rs execute_command]
  RustMain --> Validate[commands::validate_args]
  RustMain --> Safety[safety.rs guards]
  RustMain --> RunnerStart[runner::start_command]
  RunnerStart --> Actor[runner_actor_loop]
  Actor --> Binary[src-tauri/resources/ubertooth exe]
  Binary --> Events[command-output / command-batch / command-done]
  Events --> Telemetry[TelemetryStreamer.start listeners]
  Telemetry --> Runtime[telemetry-runtime.js processors]
  Runtime --> UI[Console / Spectrum / BLE / Metrics]
```

## Risk gates după fixuri
1. Runner Idle după terminare naturală — ✅ unit test.
2. Stop/kill pentru proces lung — ✅ unit test.
3. Frontend start/stop/event cleanup — ✅ Node test cu Tauri mocks.
4. Backend schema parity — ✅ Rust test.
5. Frontend build — ✅ Vite build.
6. Packaged debug build — ✅ MSI debug build.
7. Hardware real — ⚠️ cere test manual cu device conectat.

Detaliile sunt în [[Referinte/Architecture review - NO PASS]].
