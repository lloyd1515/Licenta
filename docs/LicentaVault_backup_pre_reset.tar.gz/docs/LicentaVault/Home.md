---
tags: [ubertooth, licenta, index]
status: current
updated: 2026-05-24
---
# Ubertooth Standalone — hartă Obsidian

Acest vault explică **ce avem în folder**, **cum curge aplicația**, **unde sunt piesele importante** și **ce riscuri merită urmărite**.

## Citește în ordinea asta
1. [[00 - Start aici]] — rezumatul proiectului în 5 minute.
2. [[01 - Harta proiectului]] — foldere, fișiere, artefacte și ce contează.
3. [[Flows/Flow general al aplicatiei]] — boot → splash → dashboard → comandă → telemetrie.
4. [[Flows/Flow comenzi hardware]] — cum ajunge un click din UI să pornească un `.exe` Ubertooth.
5. [[Flows/Flow telemetrie si vizualizari]] — cum se transformă output-ul în spectrum, waterfall și BLE list.
6. [[Module/Frontend JS]] și [[Module/Backend Tauri Rust]] — modulele principale.
7. [[Module/Siguranta si limite]] — confirmări, duty-cycle, DFU, TX.
8. [[Referinte/Catalog comenzi Ubertooth]] — ce comenzi suportă aplicația.
9. [[Referinte/Observatii si riscuri curente]] — probleme observate și verificări rulate.
10. [[Referinte/Obsidian rendering caveats]] — reguli ca notele să se randze curat în Obsidian.
11. [[Flows/Critical runtime path]] — traseul exact click → proces → evenimente.
12. [[Referinte/Architecture review - NO PASS]] — critica arhitecturală strictă și riscurile reale.
13. [[Referinte/Literatura Academica|Literatura Academică]] — lucrări de cercetare și studii științifice corelate cu Ubertooth.

## Harta rapidă
```mermaid
flowchart LR
  User[Operator] --> Splash[Splash / hardware guard]
  Splash --> Dashboard[Dashboard UI]
  Dashboard --> Schema[Command schema]
  Dashboard --> Tauri[Tauri invoke]
  Tauri --> Rust[Rust backend]
  Rust --> Exe[resources/ubertooth-*.exe]
  Exe --> Events[Tauri events]
  Events --> Telemetry[TelemetryStreamer]
  Telemetry --> UI[Spectrum / BLE / Console]
```

## Canvas vizual
Deschide [[Harta aplicatiei.canvas]] în Obsidian pentru o hartă vizuală cu noduri și conexiuni între notele principale.

## Verdict scurt
- **Ce este:** aplicație desktop locală pentru control și vizualizare Ubertooth One.
- **Stack:** Tauri 2 + Rust backend + Vite frontend + JS modules + Tailwind.
- **Responsabilitate centrală:** rulează tool-uri Ubertooth locale, validează argumente, aplică guardrails și stream-uiește output-ul în UI.
- **Unde începe:** `src-tauri/src/main.rs` pentru app lifecycle și `src/main.js` pentru dashboard.
- **Ce e important:** handshake hardware, schema de comenzi, runner actor, evenimente Tauri, parser specan, safety gates.
