---
tags: [commands, reference]
status: current
updated: 2026-05-24
---
# Catalog comenzi Ubertooth

Sursa principală: `src/commands-schema.json` pentru UI și `src-tauri/src/commands/mod.rs` + `commands/*.rs` pentru backend allowlists.

| Comandă | UI label | Scop | Categorii UI |
|---|---|---|---|
| `ubertooth-specan` | Spectrum analyser | Sweep 2.4GHz și telemetry waterfall. | Basic, Advanced |
| `ubertooth-btle` | BLE packet capture | Capture BLE advertisements + RSSI/device list. | Basic, Targeting, Advanced |
| `ubertooth-scan` | Bluetooth device scan | Scan/inquiry pentru activitate Bluetooth. | Basic, Advanced |
| `ubertooth-util` | Device info & channel control | Version, reset, channel/power/specan utility. | Basic, Advanced |
| `ubertooth-rx` | Raw RX capture | Raw RX traffic, channel/connection tuple. | Basic, Targeting, Advanced |
| `ubertooth-follow` | Follow a BLE connection | Track BLE conversation cu LAP/UAP/channel. | Targeting, Advanced |
| `ubertooth-afh` | Adaptive Frequency Hopping monitor | Monitor AFH pentru target connection. | Basic, Targeting, Advanced |
| `ubertooth-dfu` | Firmware update (DFU) | Firmware maintenance / flashing. | Basic, Advanced; `dangerous: true` |

## Profile ghidate în UI
- **Spectrum Sweep** → rulează `ubertooth-specan`; monitorizare RF 2.4GHz fără payload.
- **BLE Packet Capture** → rulează `ubertooth-btle`; capturează BLE advertisements, RSSI, channel, adv type și câmpuri publice precum name/company când apar.
- **Proximity Capture** → rulează tot `ubertooth-btle`, dar este prezentat ca profil blackbox pentru “tot ce e observabil în proximitatea Ubertooth”: advertising public + metadate, nu trafic complet, pairing sau conținut criptat.
- **Bluetooth Inquiry Scan** → rulează `ubertooth-scan`; inquiry pentru device-uri discoverable.

## Detalii Comenzi și Corelări Academice

### ubertooth-specan
Analizor de spectru în banda 2.4GHz. Măsoară puterea semnalului RSSI pe diverse canale fără a demodula pachetele.
- **Cercetări asociate:**
  - [[Referinte/Literatura/Revisiting Adaptive Frequency Hopping Map Prediction in Bluetooth with Machine Learning Classifiers|Revisiting Adaptive Frequency Hopping Map Prediction in Bluetooth with Machine Learning Classifiers]]
  - [[Referinte/Literatura/Revisiting Bluetooth Adaptive Frequency Hopping Prediction with a Ubertooth|Revisiting Bluetooth Adaptive Frequency Hopping Prediction with a Ubertooth]]

### ubertooth-btle
Captură de trafic Bluetooth Low Energy (BLE). Permite sniffing pasiv pe canalele de advertising (37, 38, 39) sau urmărirea conexiunilor active.
- **Cercetări asociate:**
  - [[Referinte/Literatura/Protecting Privacy of BLE Device Users|Protecting Privacy of BLE Device Users]]
  - [[Referinte/Literatura/A Robust Algorithm for Sniffing BLE Long-Lived Connections in Real-Time|A Robust Algorithm for Sniffing BLE Long-Lived Connections in Real-Time]]
  - [[Referinte/Literatura/Enabling Bluetooth Low Energy auditing through synchronized tracking of multiple connections|Enabling Bluetooth Low Energy auditing through synchronized tracking of multiple connections]]
  - [[Referinte/Literatura/A Novel Secure Communication Scheme for Bluetooth Low Energy Devices|A Novel Secure Communication Scheme for Bluetooth Low Energy Devices]]
  - [[Referinte/Literatura/Security Analysis of a Medical IoT Device Data Leakage to an Eavesdropper|Security Analysis of a Medical IoT Device: Data Leakage to an Eavesdropper]]
  - [[Referinte/Literatura/Security Research of Bluetooth Devices Based on Smartwatches|Security Research of Bluetooth Devices Based on Smartwatches]]
  - [[Referinte/Literatura/Improving compliance with bluetooth device detection|Improving compliance with bluetooth device detection]]

### ubertooth-scan
Efectuează o scanare activă de tip Inquiry pentru a descoperi dispozitive Bluetooth Classic în modul vizibil (discoverable) prin colectarea adreselor LAP (Lower Address Part) și UAP (Upper Address Part).
- **Cercetări asociate:**
  - [[Referinte/Literatura/Revisiting Urban War Nibbling Mobile Passive Discovery of Classic Bluetooth Devices Using Ubertooth One|Revisiting Urban War Nibbling: Mobile Passive Discovery of Classic Bluetooth Devices Using Ubertooth One]]
  - [[Referinte/Literatura/Analysis of a Bluetooth Traffic Dataset Obtained during University Examination Sessions|Analysis of a Bluetooth Traffic Dataset Obtained during University Examination Sessions]]
  - [[Referinte/Literatura/BlueCoDE Bluetooth coordination in dense environment for better coexistence|BlueCoDE: Bluetooth coordination in dense environment for better coexistence]]
  - [[Referinte/Literatura/BlueScan Boosting Wi-Fi Scanning Efficiency Using Bluetooth Radio|BlueScan: Boosting Wi-Fi Scanning Efficiency Using Bluetooth Radio]]

### ubertooth-rx
Sniffer general pentru Bluetooth Classic care încearcă să descopere adresele dispozitivelor active prin ascultarea traficului brut de pe un canal.
- **Cercetări asociate:**
  - [[Referinte/Literatura/Wi-Fi Channel Saturation as a Mechanism to Improve Passive Capture of Bluetooth Through Channel Usage Restriction|Wi-Fi Channel Saturation as a Mechanism to Improve Passive Capture of Bluetooth Through Channel Usage Restriction]]
  - [[Referinte/Literatura/BluePIL a Bluetooth-based PassIve Localization Method|BluePIL: a Bluetooth-based PassIve Localization Method]]
  - [[Referinte/Literatura/Estimation of Vehicular Traffic State Through Data Obtained from Devices with Various Technologies|Estimation of Vehicular Traffic State Through Data Obtained from Devices with Various Technologies]]
  - [[Referinte/Literatura/Building an Autonomous Portable Device to Analyse Wireless Traffic Protocols in IoT|Building an Autonomous Portable Device to Analyse Wireless Traffic Protocols in IoT]]

### ubertooth-follow
Urmărește o conexiune Bluetooth active (Classic sau BLE) pe baza adreselor LAP/UAP descoperite, sincronizându-se cu hop-urile de frecvență ale target-ului.
- **Cercetări asociate:**
  - [[Referinte/Literatura/A Robust Algorithm for Sniffing BLE Long-Lived Connections in Real-Time|A Robust Algorithm for Sniffing BLE Long-Lived Connections in Real-Time]]
  - [[Referinte/Literatura/Enabling Bluetooth Low Energy auditing through synchronized tracking of multiple connections|Enabling Bluetooth Low Energy auditing through synchronized tracking of multiple connections]]

### ubertooth-afh
Analizează harta de sărituri în frecvență (AFH - Adaptive Frequency Hopping) folosită de o conexiune Bluetooth Classic activă, raportând canalele blocate sau folosite.
- **Cercetări asociate:**
  - [[Referinte/Literatura/Revisiting Bluetooth Adaptive Frequency Hopping Prediction with a Ubertooth|Revisiting Bluetooth Adaptive Frequency Hopping Prediction with a Ubertooth]]
  - [[Referinte/Literatura/Revisiting Adaptive Frequency Hopping Map Prediction in Bluetooth with Machine Learning Classifiers|Revisiting Adaptive Frequency Hopping Map Prediction in Bluetooth with Machine Learning Classifiers]]

### ubertooth-util
Utilitar general pentru interogarea versiunii de firmware, resetarea dispozitivului, modificarea frecvenței curente sau controlul puterii de emisie a cipului RF CC2400.
- **Cercetări asociate:**
  - [[Referinte/Literatura/6 . 858  Hacking Bluetooth|6 . 858 : Hacking Bluetooth]]
  - [[Referinte/Literatura/Cryptanalysis and Attacks on Bluetooth|Cryptanalysis and Attacks on Bluetooth]]
  - [[Referinte/Literatura/Ubertooth - Bluetooth Monitoring and Injection|Ubertooth - Bluetooth Monitoring and Injection]]
  - [[Referinte/Literatura/AirChat Ad hoc network monitoring with drones|AirChat: Ad hoc network monitoring with drones]]
  - [[Referinte/Literatura/Architecture for Inspecting Bluetooth Traffic in Software-Defined Networks|Architecture for Inspecting Bluetooth Traffic in Software-Defined Networks]]

## Cum se adaugă o comandă nouă
1. Adaugă intrare în `src/commands-schema.json` pentru UI.
2. Adaugă allowlist în `src-tauri/src/commands/<cmd>.rs` sau modul nou.
3. Expune în `allowed_args_for()` și `known_commands()`.
4. Dacă produce output semantic, adaugă parser în Rust și procesare în `telemetry-runtime.js`.
5. Adaugă teste Rust pentru allowlist/parser/safety.
