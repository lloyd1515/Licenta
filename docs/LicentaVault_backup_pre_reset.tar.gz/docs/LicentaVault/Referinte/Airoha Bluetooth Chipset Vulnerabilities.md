---
title: Airoha Bluetooth Chipset Vulnerabilities & RACE Protocol
date: 2026-07-31
tags:
  - security
  - bluetooth
  - vulnerability-research
  - airoha
---

# Vulnerabilități Airoha Bluetooth Chipset & Protocolul RACE

Sinteză tehnică a vulnerabilităților identificate în cipuri Bluetooth Airoha (MediaTek) și utilitarul de audit aferent.

> [!info] Rezumat Executiv
> Cercetătorii de securitate (ERNW) au identificat vulnerabilități majore în modul de implementare a protocolului proprietar **RACE (Remote Access Control Engine)** pe cipurile Airoha, utilizate de producători premium (Dell, Sony, JBL, Bose, etc.).

---

## 1. Vulnerabilități și CVE-uri Asociate

Protocolul **RACE** (folosit pentru diagnosticare și actualizări de firmware) expune interfețe neautentificate pe BLE, Bluetooth Classic și USB:

- **CVE-2025-20700 (CVSS 8.8):** Autentificare GATT lipsă pe Bluetooth Low Energy (BLE).
- **CVE-2025-20701 (CVSS 8.8):** Autentificare BR/EDR lipsă pe Bluetooth Classic.
- **CVE-2025-20702 (CVSS 9.6):** Control insuficient al accesului în protocolul RACE, permițând executare de cod la distanță (RCE) și acces arbitrar la memorie.

---

## 2. Unelte de Audit și Remediere (Surse de Încredere)

### Utilitar de Cercetare & Testare
- **[auracast-research/race-toolkit (GitHub)](https://github.com/auracast-research/race-toolkit)**
  - Utilitar CLI Python open-source creat pentru inspecția pachetelor RACE, dump-ul memoriei RAM/Flash și verificarea rezistenței dispozitivelor Airoha la CVE-urile de mai sus.

### Buletine de Securitate și Remedieri Oficiale
- **[Dell Security Advisory DSA-2025-303](https://www.dell.com/support/kbdoc/en-us/000349491/dsa-2025-303)**
  - Ghid și patch-uri furnizate de Dell pentru remedierea vulnerabilităților Airoha SDK în căștile din seria WL (WL7024, WL5024, WL3024).
- **[Airoha Official Technology Site](https://www.airoha.com/)**
  - Site-ul oficial al producătorului de microcontrollere.

---

## 3. Articole și Note Terțe

- Articol explicativ pe Medium: *Vulnerabilități în cipuri Bluetooth audio / Airoha*.
- Analize tehnice pe bloguri de securitate (ex. WebAsha / ERNW blog).
