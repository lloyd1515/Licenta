---
tags: [sources, evidence]
status: current
updated: 2026-05-24
---
# Surse inspectate

## Fișiere principale citite
- `package.json`
- `vite.config.js`
- `index.html`
- `splash.html`
- `src/splash.jsx`
- `src/main.js`
- `src/commands-schema.json`
- `src/core/HardwareStore.js`
- `src/core/SchemaEngine.js`
- `src/core/SessionController.js`
- `src/core/TelemetryStreamer.js`
- `src/core/UIFactory.js`
- `src/components/ChannelMap.js`
- `src/components/ScanPanel.js`
- `src/telemetry-runtime.js`
- `src/danger-ui.js`
- `src/spectrum-ui.js`
- `src/discovery-ui.js`
- `src/runtime-ui.js`
- `src/styles.css`
- `src-tauri/Cargo.toml`
- `src-tauri/tauri.conf.json`
- `src-tauri/capabilities/default.json`
- `src-tauri/src/main.rs`
- `src-tauri/src/runner.rs`
- `src-tauri/src/discovery.rs`
- `src-tauri/src/safety.rs`
- `src-tauri/src/commands/mod.rs`
- `src-tauri/src/commands/*.rs`

## Tool evidence
- GitNexus repo list: `ubertooth-standalone`, 513 symbols, 42 processes, indexed 2026-04-28.
- GitNexus processes query: examples include `RunCurrentCommand → GetState`, `Execute_command → Allowed_args_for`, `SubscribeToEvents → AppendConsoleLine`.
- `cargo test`: 23 tests passed.
- `npm run build`: failed before app bundle due Vite CLI syntax error.
