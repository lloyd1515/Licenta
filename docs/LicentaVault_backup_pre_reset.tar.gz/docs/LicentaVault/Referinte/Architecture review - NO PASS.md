---
tags: [architecture, review, risks, tauri, subprocess]
status: current
updated: 2026-05-24
verdict: LOCAL_SOFTWARE_PASS_HARDWARE_UNTESTED
---
# Architecture review — local software PASS, hardware untested

Aceasta este judecata strictă asupra arhitecturii aplicației, nu asupra formatării Obsidian.

## Verdict curent
**LOCAL SOFTWARE PASS** pentru riscurile identificate în research-ul arhitectural: lifecycle runner, stop/kill, DFU explicit, backend validation, capability scope, frontend build, audit și packaged debug build.

Nu declar **hardware PASS**, pentru că nu am rulat aplicația cu un Ubertooth fizic conectat.

## Fixuri aplicate pe 2026-05-24
| Zonă | Status | Ce s-a schimbat / verificat |
|---|---|---|
| Runner idle după terminare naturală | ✅ fix + test | `RunnerMessage::Finished` golește `current_child`; testul `test_poll_child_status_clears_finished_child` trece. |
| Stop/kill fără blocaj pe `wait()` | ✅ fix + test | waiter-ul folosește `try_wait()` polling; testul `test_running_child_can_be_killed_without_waiter_lock_contention` trece. |
| DFU confirm explicit | ✅ fix + frontend test | modal result este propagat explicit până la `execute_command`; test Node confirmă payload-ul. |
| Frontend Run/Stop event flow | ✅ test mock Tauri | test Node acoperă start → stop request → `command-done` → state clear. |
| Backend value/range validation | ✅ fix + schema parity test | `validate_args()` validează valori/range-uri; schema frontend este verificată contra backend allowlist/expectations. |
| Schema parity pentru `analysisTarget` | ✅ fix | flag-ul `-a`/`--analysis-target` pentru `ubertooth-btle` este acceptat și tipat ca text în backend. |
| Tauri capabilities | ✅ strâns + packaged build | capability default permite doar `core:event:allow-listen` și `core:webview:allow-webview-close`. |
| Frontend build | ✅ pass | `npm run build` trece. |
| Packaged debug MSI | ✅ pass | `npx tauri build --debug --bundles msi` produce MSI. |
| Dependency audit | ✅ pass | `npm audit --audit-level=moderate` raportează 0 vulnerabilities. |

## Ce este solid acum
- Rust rămâne granița privilegiată pentru hardware control.
- Execuția folosește `std::process::Command(...).args(...)`, fără shell string interpolation.
- Backend-ul validează flag-uri, valori lipsă, range-uri clare și schema parity pentru câmpurile UI.
- DFU nu mai este auto-confirmat din numele comenzii.
- Runner-ul revine la Idle după completion natural și poate omorî un proces lung fără lock contention.
- Capability-ul default nu mai include `core:default`, `core:event:default`, `core:window:default`, `core:app:default` sau `core:resources:default`.
- Build-ul frontend și MSI debug se generează local.

## Ce rămâne în afara verificării locale
- Test hardware real cu Ubertooth conectat.
- Test instalare MSI pe o mașină curată.
- Test cu firmware flashing real; acesta nu trebuie automatizat fără hardware/lab control.

## Surse oficiale folosite
- Tauri capabilities: https://v2.tauri.app/security/capabilities/
- Tauri core permissions / event permissions: https://v2.tauri.app/reference/acl/core-permissions/
- Tauri resources bundling: https://v2.tauri.app/develop/resources/
- Tauri sidecars: https://v2.tauri.app/develop/sidecar/
- Tauri shell plugin: https://v2.tauri.app/plugin/shell/
