---
tags: [obsidian, rendering, reference]
status: current
updated: 2026-05-24
---
# Obsidian rendering caveats

Această notă explică regulile practice pentru ca vault-ul să se vadă curat în Obsidian.

## Reguli de folosit în notele de arhitectură
- Preferă note `.md`, wikilinks de tip `[[Home]]`, tabele Markdown și Mermaid simplu.
- Evită etichete Mermaid care încep cu `1.`, `2.`, etc. În Obsidian/Mermaid pot fi interpretate ca listă Markdown și pot produce `Unsupported markdown: list`.
- Dacă ai nevoie de numerotare în Mermaid, folosește `Layer 1 — ...` sau caractere precum `①`, nu `1. ...` la începutul labelului.
- HTML static simplu poate fi randat în note Markdown, dar trebuie tratat ca fallback punctual, nu ca format principal de documentație.
- Nu te baza pe Markdown în interiorul elementelor HTML. De exemplu, wikilink-uri sau bold Markdown într-un `<div>` pot rămâne text brut.
- Nu pune fișiere `.html` standalone ca documentație principală în vault. Obsidian lucrează nativ cu `.md`, `.canvas`, imagini, PDF-uri și alte formate acceptate; HTML standalone poate apărea ca fișier, dar nu este formatul normal de notițe.

## Surse verificate
- Obsidian Help — HTML content: https://help.obsidian.md/Editing+and+formatting/HTML+content
- Obsidian accepted file formats: https://www.mintlify.com/obsidianmd/obsidian-help/files/accepted-formats
- Obsidian Forum — exemplu bug Mermaid `Unsupported markdown: list`: https://forum.obsidian.md/t/bug-render-mermaid-unsupported-markdown-list/112325
