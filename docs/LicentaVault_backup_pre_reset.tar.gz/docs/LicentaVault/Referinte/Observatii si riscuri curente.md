---
tags: [risks, verification, current-state]
status: current
updated: 2026-05-24
---
# Observații și riscuri curente

Această notă separă ce este demonstrat local de ce cere hardware real.

## Verificări rulate
| Comandă | Rezultat | Observații |
|---|---|---|
| `cargo test` în `src-tauri` | ✅ 29 passed | Include commands, safety, specan parser, runner completion cleanup, runner kill și schema parity. |
| `npm test` | ✅ 4 passed | Testează DFU explicit, non-DFU no auto-confirm, stop-before-new-start și command-done state cleanup. |
| `npm run build` | ✅ pass | Vite build produce `dist/`. |
| `npx tauri build --debug --bundles msi` | ✅ pass | Produce `src-tauri/target/debug/bundle/msi/Ubertooth Standalone_0.1.0_x64_en-US.msi`. |
| `npm audit --audit-level=moderate` | ✅ pass | 0 vulnerabilities după `npm audit fix`. |
| JSON parse `src-tauri/capabilities/default.json` | ✅ pass | Capabilities file este JSON valid. |
| `rustfmt --check` pe fișiere atinse | ✅ pass | `runner.rs`, `commands/mod.rs`, `commands/btle.rs`. |
| Obsidian link/Mermaid check | ✅ pass | 16 markdown files, fără Mermaid numbered-list labels. |
| `git status` | ❌ nu este repo git aici | Folderul curent nu are `.git`, deci GitNexus detect_changes nu poate folosi `git diff`. |

## Riscuri rezolvate
- Build frontend blocat de Vite/node_modules: rezolvat prin `npm ci`; build trece.
- Vulnerability moderate PostCSS: rezolvat prin `npm audit fix`; audit trece.
- DFU confirm auto-true: rezolvat; testat în frontend mock.
- Runner stale busy / stop lock contention: rezolvat; testat în Rust.
- Capabilities prea largi: reduse la event listen + webview close.
- Backend/schema mismatch pentru `ubertooth-btle -a`: rezolvat și acoperit prin schema parity test.

## Riscuri care nu pot fi eliminate fără hardware/lab
- Comportament real cu Ubertooth conectat.
- Instalare MSI pe mașină curată și verificare că driverele/DLL-urile sunt corecte.
- DFU real, care trebuie făcut manual/controlat, nu automatizat orb.

## Status architecture review
Pentru software local: **PASS**. Pentru hardware operațional complet: **pending hardware validation**.

Vezi [[Referinte/Architecture review - NO PASS]].
