# BLESA (Bluetooth Low Energy Spoofing Attack)

## Prezentare Generală
*   **Tip Protocol:** Bluetooth Low Energy (BLE)
*   **Nivel Protocol (Layer):** Link Layer / Faza de Reconectare
*   **CVE-uri:** CVE-2020-9770
*   **Impact:** Injectare de date false (Data Spoofing), ocolirea autentificării la reconectare

## Mecanism Tehnic
BLESA exploatează o slăbiciune în specificația oficială BLE referitoare la reconectarea rapidă a dispozitivelor deja împerecheate (bonded). Când o conexiune BLE este pierdută temporar (de exemplu, din cauza distanței sau a bruiajului) și apoi restabilită, protocolul permite reluarea transmisiilor fără a forța o re-autentificare criptografică mutuală. 
Dacă stiva de Bluetooth a sistemului de operare (cum ar fi BlueZ pe Linux, Fluoride pe Android sau stack-ul iOS) nu implementează verificări suplimentare, atacatorul poate clona adresa MAC a serverului legitim (de exemplu, un senzor medical sau o brățară fitness) și poate trimite date false către client în momentul în care acesta încearcă să se reconecteze.

## Relația cu Ubertooth One
*   **Sniffing:** Ubertooth One poate fi utilizat pentru a identifica adresele MAC active și UUID-urile serviciilor expuse, însă nu poate fi folosit pentru a intercepta stabilirea cheilor de criptare moderne (LE Secure Connections bazate pe ECDH).
*   **Transmisie/Atac:** **Inutil.** Atacul BLESA este un atac activ care necesită ca atacatorul să transmită pachete de spoofing active și să se conecteze la client. Ubertooth nu poate stabili conexiuni active ca un controller BLE standard. Pentru acest atac, un adaptor Bluetooth standard (dongle USB) controlat prin scripturi Python (folosind librării ca Scapy sau PyBluez) este mult mai eficient și mai simplu de utilizat.

## Hardware Alternativ Necesar
*   **Adaptor BLE standard (USB Dongle):** Pentru spoofing activ la nivel de sistem de operare.
*   **SDR (HackRF One / USRP):** Utilizat pentru a efectua "bruiaj selectiv" (selective jamming) pe canalele de publicitate/date pentru a forța deconectarea forțată a dispozitivului legitim, declanșând faza de reconectare necesară atacului.

## Lucrări Academice Relevante (Wikilinks)
*   [[AI research/Papers/A Robust Algorithm for Sniffing BLE Long-Lived Connections in Real-Time|A Robust Algorithm for Sniffing BLE Long-Lived Connections in Real-Time]]
*   [[AI research/Papers/Improving compliance with bluetooth device detection|Improving compliance with bluetooth device detection]]
