# Hartă de Acoperire RF — Bluetooth Classic (17 iunie 2026)

Rezultatul spațial VALID din sesiunea din 17 iunie: o hartă de acoperire RF anonimă, ancorată pe cele 4 colțuri ale sălii (poziții cunoscute). NU sunt poziții de dispozitiv — capturile Classic nu conțin identitate validă (LAP nevalidat, `BR or EDR Data Present: False`). Aceasta este o hartă de **intensitate de semnal**, nu de dispozitive.

RSSI mediu per colț: Stânga-Sus −59,9 · Stânga-Jos −61,7 · Dreapta-Jos −61,7 · Dreapta-Sus −60,4 dBm. Câmp aproape uniform (~−60 dBm) → acoperire simetrică, fără atenuare direcțională majoră.

![Hartă acoperire RF Classic — RSSI mediu interpolat biliniar între 4 colțuri](classic_coverage_heatmap.png)

> [!NOTE] Caveat de metodă
> Interpolare biliniară din doar 4 puncte de măsură — rezoluție grosieră. Generată de `Email_Profesor/classic_rf_survey.py`.
