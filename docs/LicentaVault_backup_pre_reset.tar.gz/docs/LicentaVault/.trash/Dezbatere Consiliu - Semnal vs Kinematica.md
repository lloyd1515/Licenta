---
tags: [architecture, debate, rf-signal, pre-filtering, wls, kalman-filter, positioning, kinematics, consensus]
status: consensus
date: 2026-07-22
authors: ["Agent A - Specialist Semnal RF și Pre-Filtrare", "Agent B - Specialist Kinematică și Optimizare"]
---

# Dezbatere Consiliu: Semnal RF & Pre-Filtrare vs. Modelare Cinematică (Consens Hibrid)

---

## Part 1: Perspectiva Agentului A (Specialist Semnal RF și Pre-Filtrare)

### 1. Analiza Critică a Limitărilor Algoritmului Curent (`positioning.py`)

#### 1.1. Restricția Geometrică a Centroidului (Convex Hull Property)
- **Cod Sursă Relevant:** [positioning.py](file:///home/vlads4r4/dev/Licenta/positioning.py#L59-L63)
```python
weights = {label: 1.0 / max(distance, EPSILON) for label, distance in valid.items()}
total_weight = sum(weights.values())
x = sum(weights[label] * corner_coords[label][0] for label in valid) / total_weight
y = sum(weights[label] * corner_coords[label][1] for label in valid) / total_weight
```
- **Deficiență Matematică:** Poziția $(x, y)$ estimată este o combinație convexă strictă a coordonatelor ancorelor ($\sum w_i = 1, w_i \ge 0$). Punctul rezultat este **matematic blocat în interiorul poligonului convex (Convex Hull)** definit de ancore.
- **Impact în Aplicație:** Dispozitivele aflate lângă un perete exterior sau în colțurile camerei sunt trase agresiv spre centrul camerei. Algoritmul nu poate poziționa niciodată un obiect pe perete sau în afara razei ancorelor.

#### 1.2. Absența Ponderării pe Varianță ($\sigma^2$) și Stabilitate RF
- **Deficiență Fizică:** Ponderile curent folosite ($w_i = \frac{1}{\max(d_i, \epsilon)}$) se bazează exclusiv pe distanța estimată. În medii indoor, reflexiile multipath și umbrirea de corp uman (Body Shadowing) provoacă scăderi temporare masive de RSSI, crescând dispersia eșantioanelor.
- **Impact:** Algoritmul acordă aceeași importanță unei ancore cu semnal ultra-stabil ($\sigma^2 = 0.5\text{ dB}^2$) și unei ancore cu semnal puternic fluctuant ($\sigma^2 = 25\text{ dB}^2$), dacă mediile distanțelor lor sunt egale.

#### 1.3. Ne-tratarea Zonei Near-Field ($d < 1.0\text{ m}$)
- **Cod Sursă Relevant:** `positioning.py` folosește `EPSILON = 0.1` doar pentru protecție la împărțirea cu zero.
- **Deficiență RF:** Conform studiului *Novytskyi et al. (2025)* (citat în [LicentaVault/Intrebari si Tehnici de Triangulare BLE.md](file:///home/vlads4r4/dev/Licenta/LicentaVault/Intrebari%20si%20Tehnici%20de%20Triangulare%20BLE.md)), propagarea electromagnetică în zona de câmp apropiat reactiv/Fresnel ($d < 1.0\text{ m}$) nu mai respectă modelul logaritmic standard (LDPL). La distanțe de $0.35\text{ m} - 0.40\text{ m}$, numărul de pachete eronate/pierdute atinge un **maxim local neașteptat** ($E(l) \approx 71 l^3 - 196 l^2 + 151 l + 189$).

---

## Part 2: Perspectiva Agentului B (Specialist Kinematică și Optimizare)

### 2. Rezolvarea Ancorelor Mobile & Modificările Levenberg-Marquardt + EKF

#### 2.1. Ancore Mobile (User Walking with Sniffer)
- Utilizatorul s-a deplasat manual cu sniffer-ul de la un colț la altul conform [Logs.md](file:///home/vlads4r4/dev/Licenta/LicentaVault/My%20Notes/Logs.md) (08:50 - 09:25). Coordonatele ancorelor au incertitudini spațiotemporale $(\sigma_{x_i}^2, \sigma_{y_i}^2)$.
- **Tratare:** Se extinde matricea de covarianță a zgomotului de măsurare $R_k$:
  $$R_{i,\text{eff}} = R_{0,i} + \sigma_{\text{anchor}, i}^2$$

#### 2.2. Quadlaterarea Levenberg-Marquardt ($[x, y, RSS_C]^T$)
- Pentru dispozitive unde puterea la 1m ($RSS_C$) este necunoscută, rezolvăm sistemul non-liniar BluePIL minimizând reziduul:
  $$f_i(x, y, RSS_C) = (x - x_i)^2 + (y - y_i)^2 - 10^{\frac{RSS_C - RSS_i}{5n}}$$
  cu Jacobianul $J$ calculat analitic.

#### 2.3. Extended Kalman Filter (EKF Adaptiv)
- Netezește traiectoria cu vectorul de stare $\mathbf{x}_k = [x, y, v_x, v_y]^T$.
- În caz de atenuare bruscă (Body Shadowing), scalează dinamic $R_k$ împiedicând săriturile nerealiste ale vitezei.

---

## Part 3: Arhitectura de Consens Hibridă (Consensus Pipeline)

Ambele tabere au convenit asupra unui pipeline pe 4 etape hibride:

```mermaid
flowchart LR
    A[Raw RSSI Capture] --> B[1. Rolling Max Filter\n(LOS Extraction)]
    B --> C[2. Weighted Least Squares\nWLS Solver (W_i = 1/sigma^2)]
    C --> D[3. Levenberg-Marquardt\n([x, y, RSS_C] Optimization)]
    D --> E[4. Adaptive Extended\nKalman Filter (EKF)]
    E --> F[Clean 2D Coordinates\n(x, y) + Bounds]
```

1. **Variant 1 (WLS Solver)**: Ponderare pe inversul varianței $\sigma^2$, elimină restricția Convex Hull.
2. **Variant 2 (Kalman / EKF Kinematic)**: Filtru cinematic pe stare $[x, y, v_x, v_y]^T$ cu scaling adaptiv.
3. **Variant 3 (Hybrid WLS + LM + EKF)**: Lanț complet: Pre-filtrare LOS -> Soluție inițială WLS/LM -> Netezire EKF.
