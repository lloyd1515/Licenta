# SweynTooth Attacks

## Prezentare Generală
*   **Tip Protocol:** Bluetooth Low Energy (BLE)
*   **Nivel Protocol (Layer):** Link Layer (LL)
*   **CVE-uri:** CVE-2020-10061, CVE-2020-10069, CVE-2020-13593 (și altele)
*   **Impact:** Denial of Service (DoS - cipul îngheață sau se restartează), Security Bypass (ocolirea permisiunilor de citire/scriere GATT)

## Mecanism Tehnic
SweynTooth reprezintă o familie de vulnerabilități identificate în stivele de protocol BLE proprietare utilizate de marii producători de cipuri (Texas Instruments, NXP, Cypress, Dialog Semiconductor, Telink, STMicroelectronics). 
Atacul presupune transmiterea de pachete Link Layer neconforme (de exemplu, pachete de conexiune cu lungimi invalide sau parametri de sincronizare în afara limitelor acceptate) în timpul negocierii conexiunii BLE. Deoarece firmware-ul controllerului BLE nu este programat să valideze sau să gestioneze aceste cazuri de eroare în mod securizat, cipul intră într-o stare de blocaj complet (deadlock) sau suferă un crash hardware dur, necesitând resetarea fizică a alimentării.

## Relația cu Ubertooth One
*   **Sniffing:** Ubertooth One poate intercepta pachetele de publicitate (Advertising) și poate monitoriza fluxul de conexiune dacă este sincronizat pe același canal (37, 38 sau 39). Totuși, din cauza limitărilor de viteză ale microcontrolerului LPC1756, Ubertooth One prezintă o rată mare de packet loss în medii RF aglomerate și poate rata pachetele cheie.
*   **Transmisie/Atac:** **NU este fezabil.** SweynTooth necesită transmisie activă (TX) cu temporizări extrem de precise (la nivel de microsecunde) pentru a injecta pachetele Link Layer malformate exact în stările corecte de tranziție. Cipul radio CC2511 de pe Ubertooth One nu oferă acces la nivel atât de jos al Link Layer-ului în firmware-ul implicit pentru a permite modificări arbitrare ale pachetelor fizice transmise.

## Hardware Alternativ Necesar
*   **Nordic nRF52840 Dongle:** Este hardware-ul de referință utilizat de echipa ASSET pentru rularea exploit-urilor SweynTooth. Oferă suport complet pentru scrierea de firmware custom care manipulează Link Layer-ul la nivel de registru. Costă în jur de 10-15 USD.

## Lucrări Academice Relevante (Wikilinks)
*   [[AI research/Papers/Protecting Privacy of BLE Device Users|Protecting Privacy of BLE Device Users]] - Discută atacurile pasive pe BLE.
*   [[AI research/Papers/Security Analysis of a Medical IoT Device Data Leakage to an Eavesdropper|Security Analysis of a Medical IoT Device]] - Exemplu practic de dispozitiv medical vulnerabil din lipsa criptării BLE.
