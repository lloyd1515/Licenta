Cum intrii in sala:
Colt sala stanga sus 8:50 9:10
Colt sala stanga jos 8:55 9:15
Colt sala dreapta jos 9:00 9:20
Colt sala dreapta sus 9:05 9:25