---
tags: [experiment, scan, ubertooth, capture]
date: 2026-06-17
---

# Scan Session - 2026-06-17

Sesiune de scanare și monitorizare pasivă a traficului Bluetooth (BLE și Classic BT) folosind hardware-ul **Ubertooth One** pe data de 17 iunie 2026.

Această sesiune continuă experimentele documentate în [[My Notes/Alternate Scan Session|Sesiunea din 28 mai 2026]].

---

## 1. Sumar Capturi

- **Total fișiere PCAP identificate:** 11
- **Fișiere BLE:** 8
- **Fișiere Classic Bluetooth (RX):** 2
- **Fișiere goale / antet doar (24 bytes):** 1
- **Total Pachete BLE Capturate:** 335.053
- **Total Pachete Classic BT Capturate:** 727

### Detalii Fișiere PCAP
| Nume Fișier | Tip | Dimensiune | Pachete | Durată (s) | Data Începerii (Local) |
| --- | --- | --- | --- | --- | --- |
| `btle_ch37_20260617_074723.pcap` | BLE | 4.80 MB | 86.018 | 301.6 | 2026-06-17 07:47:25.162 |
| `btle_ch37_20260617_075535.pcap` | Empty | 0.0 KB | 0 | 0 | N/A |
| `btle_ch37_20260617_075606.pcap` | BLE | 202.5 KB | 3.525 | 286.3 | 2026-06-17 07:56:07.021 |
| `btle_ch37_20260617_081341.pcap` | BLE | 4.31 MB | 74.992 | 245.6 | 2026-06-17 08:13:42.047 |
| `btle_ch37_20260617_082605.pcap` | BLE | 1.68 MB | 29.020 | 284.8 | 2026-06-17 08:26:06.273 |
| `btle_ch38_20260617_071411.pcap` | BLE | 41.3 KB | 678 | 14.1 | 2026-06-17 07:14:11.373 |
| `btle_ch38_20260617_080635.pcap` | BLE | 2.73 MB | 48.752 | 151.4 | 2026-06-17 08:06:36.305 |
| `btle_ch38_20260617_083208.pcap` | BLE | 3.70 MB | 65.812 | 214.3 | 2026-06-17 08:32:09.292 |
| `btle_ch39_20260617_081803.pcap` | BLE | 1.52 MB | 26.256 | 88.9 | 2026-06-17 08:18:04.105 |
| `rx_20260617_080121.pcap` | Classic | 14.5 KB | 390 | 280.8 | 2026-06-17 08:01:30.730 |
| `rx_20260617_082056.pcap` | Classic | 12.5 KB | 337 | 288.1 | 2026-06-17 08:21:04.430 |

---

## 2. Analiză Detaliată Bluetooth Low Energy (BLE)

### Canale BLE folosite la Captură
| Canal | Pachete | Procent |
| --- | --- | --- |
| Canal 0 | 193.467 | 57.7% |
| Canal 12 | 115.242 | 34.4% |
| Canal 39 | 26.256 | 7.8% |
| Altele (zgomot/erori) | < 100 | < 0.1% |

### Tipuri de PDU (Protocol Data Unit) BLE
| Tip PDU | Pachete | Procent | Detalii Tip |
| --- | --- | --- | --- |
| `0x00` | 212.801 | 63.5% | `ADV_IND` (Advertising generic, conectabil) |
| `0x02` | 40.130 | 12.0% | `ADV_NONCONN_IND` (Neconectabil) |
| `0x03` | 39.090 | 11.7% | `SCAN_REQ` (Scan Request de la master) |
| `0x04` | 23.553 | 7.0% | `SCAN_RSP` (Scan Response) |
| `0x06` | 9.233 | 2.8% | `ADV_SCAN_IND` (Scannable, neconectabil) |
| `0x07` | 3.799 | 1.1% | `CONNECT_IND` (Indicație de conectare) |
| `0x01` | 2.467 | 0.7% | `ADV_DIRECT_IND` (Conectabil direct) |
| Altele | < 2.500 | ~0.7% | Management/Control |

### Top 15 Dispozitive BLE Capturate
| Rang | Adresă MAC | Pachete | RSSI Mediu | RSSI Min/Max | Tipuri PDU frecvente | Canale observate |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | `0c:7e:24:35:bd:31` | 8.363 | -67.4 dBm | -85/0 | 0x00(6520), 0x03(1138), 0x04(691) | ch0(4636), ch12(3203), ch39(524) |
| 2 | `44:db:d2:6c:17:93` | 7.263 | -59.4 dBm | -86/0 | 0x00(5678), 0x03(901), 0x04(681) | ch0(4090), ch12(2670), ch39(503) |
| 3 | `55:46:38:2c:35:54` | 7.075 | -52.9 dBm | -82/0 | 0x00(5436), 0x03(904), 0x04(710) | ch12(5190), ch0(1885) |
| 4 | `00:cc:3f:e7:5c:36` | 4.332 | -76.2 dBm | -86/-36 | 0x00(3672), 0x04(413), 0x03(200) | ch0(3168), ch39(1102), ch12(62) |
| 5 | `6f:1d:aa:60:31:84` | 3.172 | -60.9 dBm | -83/0 | 0x00(2445), 0x03(381), 0x04(343) | ch0(1910), ch12(1002), ch39(260) |
| 6 | `59:89:eb:5f:25:96` | 2.928 | -66.6 dBm | -81/0 | 0x00(2230), 0x03(386), 0x04(307) | ch0(1700), ch12(991), ch39(237) |
| 7 | `40:06:34:d3:5d:57` | 2.786 | -56.1 dBm | -81/0 | 0x00(2022), 0x03(423), 0x04(341) | ch0(2491), ch12(246), ch39(49) |
| 8 | `b8:f2:55:00:8c:cd` | 2.413 | -76.6 dBm | -87/-44 | 0x00(2069), 0x03(150), 0x04(150) | ch0(2140), ch39(207), ch12(66) |
| 9 | `4a:02:3f:54:f5:fb` | 2.337 | -56.9 dBm | -80/0 | 0x00(1848), 0x03(267), 0x04(221) | ch12(1167), ch0(926), ch39(244) |
| 10 | `51:cf:f6:56:42:f6` | 2.273 | -63.9 dBm | -81/0 | 0x00(1780), 0x03(299), 0x04(188) | ch0(1179), ch12(765), ch39(329) |
| 11 | `44:f2:c0:81:e3:a0` | 2.129 | -65.6 dBm | -81/-28 | 0x00(1657), 0x03(277), 0x04(195) | ch12(1007), ch0(905), ch39(217) |
| 12 | `f8:19:30:fd:fa:9d` | 2.113 | -68.4 dBm | -83/-28 | 0x00(1757), 0x03(229), 0x04(125) | ch0(1336), ch12(637), ch39(140) |
| 13 | `46:2e:19:73:b3:3c` | 2.035 | -64.8 dBm | -80/-41 | 0x00(1515), 0x03(300), 0x04(214) | ch0(994), ch12(746), ch39(295) |
| 14 | `6e:09:b6:8c:37:75` | 1.984 | -63.3 dBm | -80/-38 | 0x00(1558), 0x03(243), 0x04(182) | ch0(1025), ch12(584), ch39(375) |
| 15 | `00:cc:3f:e5:26:6e` | 1.888 | -75.9 dBm | -87/-36 | 0x00(1628), 0x03(171), 0x04(54) | ch39(905), ch0(795), ch12(188) |

---

## 3. Analiză Detaliată Classic Bluetooth (BR/EDR)

Total adrese LAP unice identificate: 21

> [!CAUTION] Corectură (audit 2026-07-30)
> Aceste 21 de valori LAP sunt extrase dintr-un câmp pe care tshark însuși îl marchează **nevalidat** pentru aceste capturi (`Reference LAP Valid: False`, `BR or EDR Data Present: False`, fără CRC/HEC). Deci „21 LAP unice" NU înseamnă confirmat 21 dispozitive Classic BT distincte — e doar numărul de valori unice observate într-un câmp de metadată radio nevalidat. A nu se folosi ca bază pentru triangulare per-dispozitiv (vezi [[Rezultate Triangulare Date Reale]] pentru retragerea rezultatelor derivate din acest set).

### Top LAPs detectate
| Rang | LAP (Lower Address Part) | Pachete | RSSI Mediu | RSSI Min/Max | Canale observate |
| --- | --- | --- | --- | --- | --- |
| 1 | `0x0086e7c4` | 353 | -62.7 dBm | -81/0 | ch62(21), ch74(17), ch68(16) |
| 2 | `0x008689bb` | 94 | -63.4 dBm | -74/-21 | ch69(9), ch63(9), ch53(8) |
| 3 | `0x00a2b65d` | 51 | -58.7 dBm | -74/-49 | ch5(3), ch61(3), ch60(3) |
| 4 | `0x00e31bf9` | 45 | -75.4 dBm | -81/-50 | ch7(4), ch3(4), ch54(3) |
| 5 | `0x0039b3e8` | 38 | -63.0 dBm | -74/-56 | ch74(6), ch21(5), ch70(5) |
| 6 | `0x00c77c74` | 31 | -68.7 dBm | -79/-44 | ch61(4), ch4(3), ch19(3) |
| 7 | `0x0073e933` | 26 | -51.8 dBm | -66/-41 | ch10(4), ch9(2), ch59(2) |
| 8 | `0x0024ab4b` | 22 | -63.6 dBm | -73/-57 | ch4(6), ch50(2), ch69(2) |
| 9 | `0x00b13715` | 15 | -63.1 dBm | -74/-54 | ch19(3), ch22(3), ch4(2) |
| 10 | `0x0077aed5` | 11 | -58.4 dBm | -69/-44 | ch62(2), ch73(2), ch1(1) |

---

## 4. Observații și Concluzii

> [!NOTE]
> Monitorizarea s-a realizat prin intermediul scripturilor [[scan_ch37.ps1]], [[scan_ch38.ps1]] și [[scan_ch39.ps1]] rulate în ciclu alternant, corelat cu repornirea și curățarea bufferelor dispozitivului prin `ubertooth-util -r`.

- **Densitatea Traficului**: S-a observat o activitate extrem de intensă pe canalele BLE, cu peste 335k pachete capturate în total, indicând prezența multor dispozitive mobile (beacon-uri Apple/Google și telefoane) în vecinătatea antenei.
- **Canale Utilizate**: Cel mai mare trafic a fost înregistrat pe canalul virtual 0 (reprezentând ch37 în spec-ul Ubertooth) urmat de canalul 12 (ch38) și canalul 39.
- **Classic Bluetooth (LAP tracking)**: Valoarea LAP `0x0086e7c4` a apărut cel mai frecvent asociată cu trafic BR/EDR — dar fiind un câmp nevalidat de tshark (vezi corectura din secțiunea 3), nu se poate confirma că provine de la un singur dispozitiv fizic; e o observație de frecvență pe metadată radio, nu o identificare de dispozitiv.

---

## Legături Utile

- [[00 - Start aici]]
- [[01 - Harta proiectului]]
- [[Referinte/Catalog comenzi Ubertooth]]
- [[Referinte/Observatii si riscuri curente]]
