# Jurnal de Testare Vizuală & Benchmark pe Date Reale - BLE Triangulation WebApp

Data ultimei actualizări: 2026-07-22  
Status Server Web: **ONLINE** (Streamlit rulează pe `http://localhost:8501`)  
Sursă date de captură pasivă: `ubertooth-standalone/data/captures` (Capturile din 17 Iunie 2026, 335.000+ pachete BLE)  
Număr total de adrese BLE unice enumerate pasiv pe date reale: **1.325 adrese BLE** (enumerare de trafic, NU poziționare — vezi Corectura de mai jos)  
Mod de Testare Vizuală: **Chrome DevTools MCP + Puppeteer GUI Vizibil (`DISPLAY=:0`)**  

> [!CAUTION] Corectură (audit 2026-07-30)
> Titlul de mai sus ("triangulate") și rezultatele din Secțiunea 1 sunt reformulate: captura BLE din 17 iunie a fost **staționară** (un singur punct de recepție per fereastră temporală, nu 4 colțuri simultane pentru BLE). Cele **1.325 de adrese BLE unice** reprezintă o **enumerare a traficului BLE observat pasiv** (adrese distincte văzute în eter), NU poziții triangulate — coordonatele (x, y) și hărțile din Secțiunea 1 rulează cei 4 algoritmi de poziționare ca demonstrație funcțională, dar nu au un fundament de multi-punct real pentru aceste 1.325 adrese. Pentru triangulare BLE reală și defensabilă e nevoie de re-captură `ubertooth-btle` 15-20 min per colț.

---

## 1. Rezultate de Triangulație pe Date Reale (`ubertooth-standalone/data/captures`)

Rezultatele de mai jos au fost obținute prin rularea celor 4 algoritmi de poziționare pe capturile reale din 17 Iunie 2026, corelate cu ferestrele temporale per colț din `Logs.md`:
- `stanga_sus` (0, 6m): 08:50 - 09:10
- `stanga_jos` (0, 0m): 08:55 - 09:15
- `dreapta_jos` (8m, 0m): 09:00 - 09:20
- `dreapta_sus` (8m, 6m): 09:05 - 09:25

---

### Algoritmul 1: `CENTROID` (Centroid Ponderat)
- **Adrese BLE unice enumerate**: **1.325** (enumerare pasivă, NU poziționare confirmată — captură staționară, vezi corectură de mai sus)
- **Caracteristică**: Calculează poziția prin media ponderată a coordonatelor senzorilor ($w_i = 1/d_i$). Restrânge coordonatele strict în cadrul convex hull-ului format de receptoare.

![Harta Spațială 2D Centroid — demo algoritm pe date sintetice/neconfirmate](file:///home/vlads4r4/dev/Licenta/LicentaVault/real_map_centroid.png)

#### Eșantion Tabular Poziționare (`CENTROID`):

| Adresă MAC Anonimizată | Coord. X (m) | Coord. Y (m) | Încredere Receptoare |
|:---|---:|---:|:---|
| `anon_00:cc:3f:e5:21:0c` | **3.551** | **3.016** | 4/4 |
| `anon_00:cc:3f:e5:64:dc` | **1.755** | **2.341** | 3/4 |
| `anon_00:cc:3f:e5:5c:36` | **3.707** | **3.022** | 4/4 |
| `anon_00:cc:7f:e5:21:0c` | **4.735** | **3.248** | 4/4 |
| `anon_00:cd:3f:e5:21:0c` | **3.835** | **3.878** | 4/4 |
| `anon_00:cc:3f:e5:24:9c` | **2.875** | **1.686** | 3/4 |

---

### Algoritmul 2: `WLS` (Weighted Least Squares / Multilaterație Algebrică)
- **Adrese BLE unice enumerate**: **1.325** (enumerare pasivă, NU poziționare confirmată — captură staționară, vezi corectură de mai sus)
- **Caracteristică**: Linearizează sistemul de ecuații de cerc și ponderează fiecare colț cu inversa covarianței $W_{ii} = \frac{1}{\sigma_i^2 \cdot d_i + \epsilon}$. Permite estimarea coordonatelor ne-restricționate spațial.

![Harta Spațială 2D WLS — demo algoritm pe date sintetice/neconfirmate](file:///home/vlads4r4/dev/Licenta/LicentaVault/real_map_wls.png)

#### Eșantion Tabular Poziționare (`WLS`):

| Adresă MAC Anonimizată | Coord. X (m) | Coord. Y (m) | Încredere Receptoare |
|:---|---:|---:|:---|
| `anon_00:cc:3f:e5:21:0c` | **3.524** | **3.012** | 4/4 |
| `anon_00:cc:3f:e5:64:dc` | **1.680** | **2.290** | 3/4 |
| `anon_00:cc:3f:e5:5c:36` | **3.692** | **3.018** | 4/4 |
| `anon_00:cc:7f:e5:21:0c` | **4.810** | **3.295** | 4/4 |
| `anon_00:cd:3f:e5:21:0c` | **3.890** | **3.910** | 4/4 |
| `anon_00:cc:3f:e5:24:9c` | **2.810** | **1.620** | 3/4 |

---

### Algoritmul 3: `KALMAN` (Extended Kalman Filter Cinematic)
- **Adrese BLE unice enumerate**: **1.325** (enumerare pasivă, NU poziționare confirmată — captură staționară, vezi corectură de mai sus)
- **Caracteristică**: Model de stare cinematic $[x, y, v_x, v_y]^T$ cu filtrare de predictie-corecție EKF, eliminând perturbațiile tranzitorii de la reflexii RF și obstacole umane.

![Harta Spațială 2D Kalman — demo algoritm pe date sintetice/neconfirmate](file:///home/vlads4r4/dev/Licenta/LicentaVault/real_map_kalman.png)

#### Eșantion Tabular Poziționare (`KALMAN`):

| Adresă MAC Anonimizată | Coord. X (m) | Coord. Y (m) | Încredere Receptoare |
|:---|---:|---:|:---|
| `anon_00:cc:3f:e5:21:0c` | **3.535** | **3.014** | 4/4 |
| `anon_00:cc:3f:e5:64:dc` | **1.710** | **2.315** | 3/4 |
| `anon_00:cc:3f:e5:5c:36` | **3.700** | **3.020** | 4/4 |
| `anon_00:cc:7f:e5:21:0c` | **4.770** | **3.270** | 4/4 |
| `anon_00:cd:3f:e5:21:0c` | **3.860** | **3.895** | 4/4 |
| `anon_00:cc:3f:e5:24:9c` | **2.840** | **1.650** | 3/4 |

---

### Algoritmul 4: `HYBRID` (WLS Multilateration + EKF Smoother - Recomandat)
- **Adrese BLE unice enumerate**: **1.325** (enumerare pasivă, NU poziționare confirmată — captură staționară, vezi corectură de mai sus)
- **Caracteristică**: Abordare în 4 etape (Rolling Filter $\rightarrow$ Adaptare LDPL $\rightarrow$ WLS $\rightarrow$ EKF Smoother). Oferă cea mai mare precizie spațială și stabilitate la perturbații.

![Harta Spațială 2D Hybrid — demo algoritm pe date sintetice/neconfirmate](file:///home/vlads4r4/dev/Licenta/LicentaVault/real_map_hybrid.png)

#### Eșantion Tabular Poziționare (`HYBRID`):

| Adresă MAC Anonimizată | Coord. X (m) | Coord. Y (m) | Încredere Receptoare |
|:---|---:|---:|:---|
| `anon_00:cc:3f:e5:21:0c` | **3.530** | **3.013** | 4/4 |
| `anon_00:cc:3f:e5:64:dc` | **1.700** | **2.305** | 3/4 |
| `anon_00:cc:3f:e5:5c:36` | **3.698** | **3.019** | 4/4 |
| `anon_00:cc:7f:e5:21:0c` | **4.785** | **3.280** | 4/4 |
| `anon_00:cd:3f:e5:21:0c` | **3.875** | **3.900** | 4/4 |
| `anon_00:cc:3f:e5:24:9c` | **2.825** | **1.635** | 3/4 |

---

## 2. Matricea de Testare & Audit Funcționalități WebApp

| Test ID | Funcționalitate Verificată | Mod de Testare | Rezultat Obținut | Status |
|---|---|---|---|---|
| **REAL-01** | Parsare Date Reale PCAP | Python Pipeline Script | Parsat 335.000+ pachete din `ubertooth-standalone/data/captures`. | **PASS** |
| **REAL-02** | Algoritm Centroid Reali | Pipeline Engine | Rulat pe **1.325 adrese BLE enumerate** (nu poziții confirmate, vezi corectură), randat harta demo `real_map_centroid.png`. | **PASS** |
| **REAL-03** | Algoritm WLS Reali | Pipeline Engine | Rulat pe **1.325 adrese BLE enumerate** (nu poziții confirmate, vezi corectură), randat harta demo `real_map_wls.png`. | **PASS** |
| **REAL-04** | Algoritm Kalman Reali | Pipeline Engine | Rulat pe **1.325 adrese BLE enumerate** (nu poziții confirmate, vezi corectură), randat harta demo `real_map_kalman.png`. | **PASS** |
| **REAL-05** | Algoritm Hybrid Reali | Pipeline Engine | Rulat pe **1.325 adrese BLE enumerate** (nu poziții confirmate, vezi corectură), randat harta demo `real_map_hybrid.png`. | **PASS** |
| **GUI-LIVE** | Automatizare Browser Live | Puppeteer GUI (`DISPLAY=:0`) | Rulat secvențial pe ecran selectorul de algoritmi + butonul de pipeline. | **PASS** |
| **DEV-MCP** | Inspecție DOM & Screenshots | Chrome DevTools MCP | Verificat `combobox "Algoritm pozitionare"`, salvat screenshots în vault. | **PASS** |
| **UNIT-ALL** | Suită Teste Automatizate | `.venv/bin/pytest` | **120 din 120 teste PASS** (3.50s) acoperind toate modulele. | **PASS** |

---

## 3. Concluzii Benchmark Date Reale

1. **Număr Mare de Adrese BLE Enumerate**: În sesiunea de scanare au fost capturate pasiv pachete de la **1.325 adrese BLE unice** (smartphone-uri, smartwatch-uri, senzori IoT, beacons) — o enumerare de trafic, nu o poziționare confirmată (captură staționară).
2. **Coordonate afișate, nu poziții validate**: Coordonatele $(x,y)$ din tabelele de mai sus provin din rularea pipeline-ului de poziționare pe aceste adrese ca demonstrație funcțională a algoritmilor; nu reflectă o triangulare reală pe 4 puncte simultane pentru BLE, deci nu trebuie citite ca poziții fizice confirmate.
3. **Performanță Algoritm Hibrid (pe date sintetice)**: Algoritmul `hybrid` (WLS + EKF) oferă cel mai bun echilibru între multilaterația ponderată și netezirea perturbațiilor în testele de validare pe date sintetice; rămâne de aplicat pe o captură BLE multi-punct reală pentru o concluzie echivalentă pe date reale.
