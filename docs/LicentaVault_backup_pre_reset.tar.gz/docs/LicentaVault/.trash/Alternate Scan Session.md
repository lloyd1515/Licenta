---
tags: [experiment, scan, ubertooth, capture]
date: 2026-05-28
---

# Alternate Scan Session

## Intent

Captură pasivă dual-mode BLE/Classic BT folosind `alternate_scan.ps1`. Alternează între Classic BT (`ubertooth-rx`) și BLE (`ubertooth-btle`) la intervale de 5 minute, total 60 minute (6 cicluri).

## Script

`alternate_scan.ps1` — params:
- `-TotalMinutes` (default 60)
- `-IntervalMinutes` (default 5)
- `-BleChannel` (default 37)

### Cum se lansează (OBLIGATORIU din sesiune interactivă PowerShell)

```powershell
$logFile = "D:\...\data\captures\scan_log.txt"
Start-Process powershell.exe -ArgumentList "-File",".\alternate_scan.ps1","-TotalMinutes","60","-IntervalMinutes","5","-BleChannel","37" -WindowStyle Hidden -RedirectStandardOutput $logFile
```

> **NU** lansa din Bash sau terminal non-interactiv — ubertooth-btle nu poate accesa USB din acel context (libusb WinUSB restriction).

## Fix-uri aplicate pe parcurs

| Problemă | Cauza | Fix |
|----------|-------|-----|
| PCAP 0 bytes | `fopen("w")` în loc de `"wb"` | Patch pcap.c + recompilat DLL |
| `pcap_create_file` returna -1 | `pcap_stubs.c` suprascria toate funcțiile pcap | Eliminat stubs, adăugat `pcap.c` în CMakeLists |
| DLL not found la lansare | MSYS2 runtime DLLs lipseau | Copiat `libwinpthread-1.dll`, `libgcc_s_seh-1.dll`, `libstdc++-6.dll` în build dir |
| USB timeout (-7) | Force-kill fără cleanup | `ubertooth-util -r` între cicluri + sleep 8s |
| BLE eșua din Bash | libusb nu poate deschide device din sesiune non-interactivă | Lansare via `Start-Process` din PowerShell interactiv |
| `Start-Process -NoNewWindow` → PCAP eșua | `CREATE_NO_NEW_WINDOW` incompatibil cu libusb | Înlocuit cu `Start-Job { & $bin ... }` |

## Rezultate sesiune 28 mai 2026

### BLE (6 cicluri × 5 min, canal 37)

| Ciclu | Bytes |
|-------|-------|
| 1 | 1,214,396 |
| 2 | 904,285 |
| 3 | 889,470 |
| 4 | 717,492 |
| 5 | 992,286 |
| 6 | 827,858 |

**Analiză agregată BLE:**
- Pachete totale: **117,057**
- MAC-uri unice: **20,777**
- RSSI mediu: **-69.4 dBm** · range: -93 / 0 dBm
- PDU: 46% ADV_IND · 17% ADV_NONCONN_IND · 14% BLE5 extended (UNK_13) · 8% SCAN_REQ · 6% SCAN_RSP
- CONNECT_IND: **181** conexiuni inițiate
- Top producători (Manufacturer Specific 0xFF): Apple (14,991) · Samsung (13,908) · Microsoft (2,456)

### Classic BT (6 cicluri × 5 min)

| Ciclu | Bytes |
|-------|-------|
| 1 | 22,254 |
| 2 | 936 |
| 3 | 898 |
| 4 | 2,190 |
| 5 | 404 |
| 6 | 898 |

**Analiză agregată Classic BT:**
- Pachete totale: **795**
- LAP-uri unice: **47**
- RSSI mediu: **-62.7 dBm** · range: -83 / -30 dBm
- Canale RF active: **76** (hopping 2402–2480 MHz)
- LAP dominant: `0x4B2CA5` — 577 pachete (73%) = un dispozitiv activ nearby

## Key Flags

| Tool | Flag | Meaning |
|------|------|---------|
| `ubertooth-btle` | `-f` | Follow connections mode |
| `ubertooth-btle` | `-n` | Ads only (fără follow) |
| `ubertooth-btle` | `-A37` | Canal advertising 37/38/39 |
| `ubertooth-btle` | `-q<file>` | Save PCAP (fără spațiu) |
| `ubertooth-rx` | `-q<file>` | Save Classic BT PCAP |
| `ubertooth-util` | `-r` | Reset firmware USB |
| `ubertooth-util` | `-v` | Verificare versiune/conectivitate |

## Observații

- BLE5 extended advertising (tip 0x0D = UNK_13) = 14% din trafic — iPhone/Android moderne
- Classic BT rar în medii moderne; când apare, e concentrat (căști, periferice)
- Advertising data = **necriptat** prin spec → analizabil complet
- Payload conexiuni = **criptat** (LE Secure Connections pe dispozitive post-2016)

## Related

- [[Catalog comenzi Ubertooth]]
- [[Idei viitoare - exploits decryption si limite Bluetooth]]
- [[Observatii si riscuri curente]]
