---
tags: [licenta, prezentare, arhitectura, q-and-a, profesor, streamlit, classic-bt]
status: complete
date: 2026-07-22
---

# Ghid de Sustinere Licență: Classic Bluetooth Triangulation WebApp

> [!IMPORTANT]
> Document oficial de pregătire pentru comisia de licență. Conține răspunsul la întrebarea critică despre Machine Learning, arhitectura sistemului și răspunsuri directe la întrebările profesorilor.
>
> Scop acum Classic-only (pivot 2026-07-30). Webapp-ul de triangulare este repoziționat pe Bluetooth Classic (BR/EDR); algoritmii de poziționare (LDPL, WLS, EKF, Hybrid) rămân identici, doar sursa de pachete/identificator se schimbă (LAP/UAP în loc de MAC advertising BLE).

---

## 1. Întrebarea Cheie: "Avem un Machine Learning la mijloc?"

### 💡 Răspunsul scurt pentru comisie:
**"Nu folosim un model de Machine Learning supravegheat (cum ar fi o rețea neuronală sau Random Forest), ci un pipeline avansat de Teorie a Estimării, Procesare Statistică de Semnal și Algoritmi de Filtrare Adaptivă (Log-Distance Path Loss, Weighted Least Squares și Filtru Kalman Extins - EKF)."**

### 🧠 Cum explici asta din punct de vedere academic în prezentare:
1. **De ce NU Rețele Neuronale / Supervised ML?**
   - Modelele de ML supravegheat pentru poziționare RF (ex. Fingerprinting cu Deep Learning) necesită o fază lungă și costisitoare de **calibrare offline** (măsurarea RSSI în sute de puncte grilă din sală).
   - Dacă se schimbă poziția unei mese sau a unui perete, modelul de ML își pierde acuratețea și trebuie re-antrenat complet.
2. **Ce folosim în schimb? (Deterministic & Adaptive Estimation)**:
   - **Modelul Fizic Log-Distance Path Loss (LDPL)**: Calculează atenuarea propagării undelor electromagnetice la 2.4 GHz în medii indoor.
   - **Weighted Least Squares (WLS)**: Rezolvă ecuațiile algebrice de trilaterație eliminând restricția de convex hull și penalizând ancorele cu varianță ridicată.
   - **Extended Kalman Filter (EKF)**: Model bayesian de procesare secvențială/cinematică a stării $\mathbf{x}_k = [x, y, v_x, v_y]^T$ cu ajustare adaptivă a matricei de covarianță a zgomotului de măsurare ($R_k$ scaling).
   - **Potrivire de Identitate Unsupervised (`match_devices`)**: Gruparea temporală și spațială a adreselor MAC anonimizate.

---

## 2. Puncte Forte de Evidențiat în Prezentare

- **Sistem Pasiv Fără Intervenție pe Dispozitive**: Nu necesită instalarea de aplicații pe telefoanele/dispozitivele studenților.
- **Robustete la Medii Zgomotoase**: Suprimă atenuările cauzate de ecranarea corpului uman (Body Shadowing $3-9\text{ dB}$) și reflexii multipath.
- **Interfață Interactivă Streamlit**: Permite comisiei să modifice live dimensiunile camerei, ferestrele de timp și algoritmul de poziționare (`centroid`, `wls`, `kalman`, `hybrid`).

---

## 3. Q&A: Ce te poate întreba un profesor și cum răspunzi

### Q1: "Cum ați calculat distanța din RSSI?"
> **Răspuns**: "Am folosit ecuația Log-Distance Path Loss: $RSSI(d) = P_{tx} - 10 n \log_{10}(d)$. Cunoscând puterea de transmisie la 1m ($P_{tx} \approx -59\text{ dBm}$) și exponentul de pierdere al mediului ($n \approx 2.5-3.0$), inversăm ecuația pentru a obține $d = 10^{\frac{P_{tx} - RSSI}{10n}}$."

### Q2: "Ce se întâmplă dacă semnalul reflectă din pereți (Multipath Fading)?"
> **Răspuns**: "Reflexiile măresc calea parcursă de undă și atenuează semnalul. Pentru a elimina semnalele reflectate, aplicăm un **Rolling Max Filter** pe ferestre temporale mobile care izolează componenta Line-of-Sight (LOS - semnalul direct cel mai puternic), urmat de filtrarea varianței în WLS."

### Q3: "De ce nu ați folosit o simplă medie a pozițiilor (Centroid)?"
> **Răspuns**: "Centroidul ponderat are o limitare matematică fundamentală: poziția calculată este o combinație convexă strictă a ancorelor, deci nu poate plasa niciun obiect lângă perete sau în afara poligonului format de senzori. Algoritmul WLS pe care l-am implementat rezolvă sistemul liniarizat de ecuații de cerc și permite determinarea coordonatelor oriunde în spațiul 2D."

### Q4: "Cum gestionați faptul că senzorul s-a mutat manual în colțurile camerei la ore diferite?"
> **Răspuns**: "Aplicația noastră permite definirea ferestrelor temporale de captură $T_{\text{start}} \dots T_{\text{sfarsit}}$ per colț (conform jurnalului de scanare). Modul `cross_window` sincronizează pachetele pe baza adreselor MAC comune receptionate în intervalele temporale suprapuse."

---

## 4. Structura Folderului de Prezentare din Vault

- [[00 - Ghid Sustinere Licenta WebApp]] (Acest fișier)
- [[01 - Arhitectura si Fluxul de Date]] (Arhitectura software, componentele pipeline-ului, interfața Streamlit)
- [[02 - Algoritmica de Triangulare si Filtrare]] (Formule matematice: LDPL, WLS, EKF, Hybrid)
