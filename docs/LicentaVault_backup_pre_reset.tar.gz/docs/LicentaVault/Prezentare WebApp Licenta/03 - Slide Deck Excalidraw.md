---
tags: [licenta, prezentare, slide-deck, excalidraw, sustinere, wls, ekf, bluetooth, graph-topology]
status: complete
date: 2026-09-20
---

# 03 - Slide Deck Excalidraw: Susținere Licență 2026 (Graph Traversal & Sketchy Vibes)

> [!TIP] Slide Deck Interactiv Widescreen 16:9 în Topologie 2D de Graf
> Fișierul sursă complet al prezentării este disponibil în format Excalidraw nativ cu texturi autentice de whiteboard hand-drawn ("sketchy vibes"), ilustrații SVG vectoriale integrate și rutare non-liniară de graf 2D:
> **[[Prezentare_Licenta_Deck.excalidraw|👉 Deschide Slide Deck-ul Excalidraw]]**
> 
> *Format fișiere & Livrabile:*
> - **Sursă Obsidian Vault**: `Prezentare_Licenta_Deck.excalidraw.md` (Dual-format cu text elements și block references)
> - **Export JSON Pur**: `Prezentare WebApp Licenta/Prezentare_Licenta_Deck.excalidraw`
> - **Randare de Înaltă Rezoluție (Proof)**: `Prezentare WebApp Licenta/Prezentare_Licenta_Proof.png` (9240 x 2521 px)
> 
> *Pentru prezentare:* Deschide fișierul Excalidraw în Obsidian, accesează meniul din dreapta sus și pornește **Presentation Mode** (sau parcurge spațial canvasul urmărind săgețile de călătorie inter-frame). Fiecare cadru respectă raportul widescreen 16:9 (1920x1080 px).

---

## 🗺️ Harta de Navigare Spațială (Topologie de Graf 2D)

Prezentarea nu este aliniată pe o bandă orizontală plată, ci este structurată ca un **graf orientat 2D cu ramificare paralelă și convergență**:

```mermaid
graph LR
    subgraph Root ["🧭 1. Root: Viziune & Piloni Sistem"]
        N1["<b>Node 1: Titlu & Viziune Teză</b><br/>(x: 0, y: 0)<br/><i>Captură Pasivă SDR, 3 Piloni, Pipeline</i>"]
    end

    subgraph BranchUpper ["📡 Brațul Superior: Fizică & Geometrie Spațială"]
        N2["<b>Node 2: Fizica Propagării RF</b><br/>(x: 2300, y: -500)<br/><i>Multipath, Body Shadowing, De ce NU ML</i>"]
        N4["<b>Node 4: Harta Sălii & Geometrie</b><br/>(x: 4800, y: -500)<br/><i>Eșec Centroid, Capcana Convex Hull, WLS</i>"]
    end

    subgraph BranchLower ["⚙️ Brațul Inferior: Arhitectură & Matematică"]
        N3["<b>Node 3: Arhitectură pe 4 Straturi</b><br/>(x: 2300, y: 900)<br/><i>Tauri Rust, Streamlit, Pydantic, Guardrails</i>"]
        N5["<b>Node 5: Rigurozitate Matematică</b><br/>(x: 4800, y: 900)<br/><i>LDPL, Liniarizare BLUE WLS, EKF Cinematic</i>"]
    end

    subgraph Convergence ["🎯 6. Destinație: Validare & Susținere"]
        N6["<b>Node 6: Rezultate Experimentale & Comisie</b><br/>(x: 7300, y: 200)<br/><i>120/120 Teste, Eroare 0.82m, Concluzii Finale</i>"]
    end

    N1 -->|"Explore Radio Waves ➔<br/><i>(Curba Sus-Dreapta)</i>"| N2
    N1 -->|"Engineer the Stack ➔<br/><i>(Curba Jos-Dreapta)</i>"| N3
    N2 -->|"Translate Waves to Space ➔<br/><i>(Orizontal Direct)</i>"| N4
    N3 -->|"Feed Packets to Math ➔<br/><i>(Orizontal Direct)</i>"| N5
    N4 -->|"Converge on Lab Data ➔<br/><i>(Diagonal Jos-Dreapta)</i>"| N6
    N5 -->|"Validate Against Real World ➔<br/><i>(Diagonal Sus-Dreapta)</i>"| N6

    style N1 fill:#e7f5ff,stroke:#1971c2,stroke-width:2px
    style N2 fill:#fff5f5,stroke:#d9480f,stroke-width:2px
    style N3 fill:#e6fcf5,stroke:#099268,stroke-width:2px
    style N4 fill:#e7f5ff,stroke:#1c7ed6,stroke-width:2px
    style N5 fill:#f3f0ff,stroke:#7048e8,stroke-width:2px
    style N6 fill:#ebfbee,stroke:#2b8a3e,stroke-width:2px
```

### Matricea de Rutare & Coordonate Noduri:
| Nod | Titlu Cadru Excalidraw | Coordonate (X, Y) | Dimensiuni | Icoană Reprezentativă SVG | Rol în Traseul Prezentării |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Node 1** | `01 - Titlu & Sistem Pasiv de Pozitionare` | `(0, 0)` | 1920 x 1080 | Siglă Bluetooth BR/EDR | **Rădăcină (Root)**: Enunțul problemei și cei 3 piloni |
| **Node 2** | `02 - Fizica Propagarii RF & De ce NU Machine Learning` | `(2300, -500)` | 1920 x 1080 | Turn Radio & Antenă RF | **Braț Superior (Up-Right)**: Propagare unde, multipath și limitări ML |
| **Node 3** | `03 - Arhitectura Decuplata & Pipeline de Date` | `(2300, 900)` | 1920 x 1080 | Stivă pe 4 Straturi | **Braț Inferior (Down-Right)**: Ingineria software, Tauri și Guardrails |
| **Node 4** | `04 - Harta Salii & Geometria Trilateratiei (Centroid vs WLS)` | `(4800, -500)` | 1920 x 1080 | Blueprint Sală & Reticulă | **Braț Superior (Dreapta)**: Capcana convexă și rezolvarea WLS |
| **Node 5** | `05 - Rigurozitatea Matematica (LDPL, WLS & EKF)` | `(4800, 900)` | 1920 x 1080 | Matrice Sigma $\Sigma$ & Formule | **Braț Inferior (Dreapta)**: Derivare BLUE, Gauss-Markov și EKF |
| **Node 6** | `06 - Rezultate Experimentale & Concluzii Comisie` | `(7300, 200)` | 1920 x 1080 | Trofeu & Sigiliu Verificare | **Destinație (Convergence)**: 120 teste, date de laborator și pledoarie |

---

## 🖼️ Randare Vizuală Completă (Proof de Sistem)

Randarea completă a întregului canvas Excalidraw generat (9240 x 2521 px, 335 de elemente grafice, texturi hachure hand-drawn, 6 iconițe SVG embeduite, stickere adezive înclinate și 6 săgeți inter-frame):

![[Prezentare_Licenta_Proof.png]]

---

## Slide 1: Titlu & Sistem Pasiv de Poziționare (Node 1)
![[Prezentare_Licenta_Deck.excalidraw#^frame=01 - Titlu & Sistem Pasiv de Pozitionare]]

### 🎙️ Note de vorbire (Slide 1)
- **Tema**: *Sistem Pasiv de Triangulare și Poziționare Indoor pe Bluetooth Classic (BR/EDR)*.
- **Viziunea proiectului**: Nu abordăm o problemă teoretică izolată, ci livrăm un sistem end-to-end complet: de la captură radio la nivel fizic cu hardware dedicat (Ubertooth One la 2.4 GHz) la orchestrare asincronă, un pipeline matematic determinist (LDPL, WLS, EKF) și interfețe moderne de operator (Tauri Rust + Streamlit).
- **Cei 3 Piloni Fundamentali**:
  1. **Hardware & Captură 100% Pasivă**: Fără aplicații pe telefoane, fără asociere sau handshake; extragere de adrese LAP (Lower Address Part) direct din preambulul radio și guardrails hardware ce blochează forțat orice emisie TX.
  2. **Rigurozitate Matematică Explicabilă**: Excluderea rețelelor neuronale opace în favoarea modelelor fizice de propagare; inversare metrică LDPL, suprimare reflexii prin Rolling Max și rezolvare near-wall prin Weighted Least Squares (WLS).
  3. **Arhitectură pe 4 Straturi & Livrabile Complete**: Decuplare completă, sincronizare temporală cross-window cu jitter < 15 ms și 120 de teste automate ce garantează 100% stabilitate.

---

## Slide 2: Fizica Propagării RF la 2.4 GHz & De ce NU Machine Learning (Node 2)
![[Prezentare_Licenta_Deck.excalidraw#^frame=02 - Fizica Propagarii RF & De ce NU Machine Learning]]

### 🎙️ Note de vorbire (Slide 2)
- **Multipath Fading la 2.4 GHz**: Undele radio electromagnetice ricoșează din pereții de beton, mobilier și tavan. Razele reflectate sosesc la receptor cu defazaje variabile, producând interferențe distructive ce generează scăderi bruște de semnal (până la -78 dBm).
- **Body Shadowing (Umbrirea Corporală)**: Corpul uman este compus în proporție de ~70% din apă, reprezentând un atenuator masiv la frecvența de rezonanță de 2.4 GHz. Când o persoană se interpune între emițător și ancoră, semnalul scade tranzitoriu cu 3–9 dB.
- **Soluția de Netezire a Semnalului**: Filtrul *Rolling Max* pe o fereastră mobilă de $W = 1500\text{ ms}$ reține anvelopa superioară LOS (Line-of-Sight), eliminând peste 90% din distorsiunile de reflexie.
- **De ce NU Rețele Neuronale (Supervised ML / Fingerprinting)?**:
  - *Cost de calibrare prohibitiv*: Necesită măsurători dense pe grilă de 0.5m (>400 puncte pentru o sală de 80 m², reprezentând >30 de ore de muncă manuală).
  - *Fragilitate extremă*: O ușă deschisă sau mutarea unei mese invalidează complet setul de antrenare.
  - *Efectul de Black-Box*: ML nu oferă certitudine analitică a erorii și poate halucina salturi de poziție.
  - *Portabilitate zero*: Un model antrenat într-o sală eșuează lamentabil într-o altă încăpere.
  - *Abordarea noastră*: Funcționează imediat în orice sală prin simpla specificare a dimensiunilor geometrice și a exponentului $n \in [2.2, 3.0]$.

---

## Slide 3: Arhitectura Decuplată pe 4 Straturi & Pipeline de Date (Node 3)
![[Prezentare_Licenta_Deck.excalidraw#^frame=03 - Arhitectura Decuplata & Pipeline de Date]]

### 🎙️ Note de vorbire (Slide 3)
- **Stratul 1: Shell UI & Vizualizare Operator**:
  - *Streamlit Web Dashboard (Port 8501)*: Conceput pentru analiză științifică, tuning dinamic al parametrilor fizici ($n$, ferestre, praguri RSSI) și vizualizare de spectru RF.
  - *Tauri Desktop App (Rust IPC)*: Interfață nativă ultra-ușoară cu randare canvas 2D la 60 FPS, afișare traiectorie live și latență sub 16 ms.
- **Stratul 2: Orchestrare & Validare Stare (`pipeline.py`)**:
  - *SessionController*: Mașină de stări (`IDLE` $\to$ `SCANNING` $\to$ `AGGREGATING` $\to$ `SOLVED`) ce garantează sincronizarea cross-window.
  - *SchemaEngine (Pydantic)*: Validare statică a contractelor de date între module.
  - *Hardware Guardrails*: Modul critic de siguranță ce forțează modul *Listen-Only* (transmisie TX blocată fizic) și interzice comenzi de DFU firmware flash.
- **Stratul 3: Extragere PCAP & Pipeline Matematic (`positioning.py`)**:
  - *PyShark PCAP Live Extractor*: Parsare pachete Bluetooth Classic din flux PCAP/FIFO și deduplicare burst pe canal radio (140 pkt/s $\to$ 15 epoci/s).
  - *Filtrare Rolling Max & Conversie LDPL*: Extragerea anvelopei LOS și transformarea puterii în distanțe metrice.
  - *Motor WLS & EKF*: Rezolvare O(1) deterministă și propagare temporală a stării cinematice.
- **Stratul 4: Hardware Radio SDR (`Ubertooth One` & `libbtbb`)**:
  - Receptoare SDR la 2.4 GHz echipate cu transceiver CC2400 și MCU LPC175x ARM Cortex-M3.
  - Decodare directă în banda de bază prin biblioteca open-source `libbtbb` fără asociere pe piconet.

---

## Slide 4: Harta Sălii & Geometria Trilaterației (Centroid vs WLS) (Node 4)
![[Prezentare_Licenta_Deck.excalidraw#^frame=04 - Harta Salii & Geometria Trilateratiei (Centroid vs WLS)]]

### 🎙️ Note de vorbire (Slide 4)
- **Demonstrația pe Sala de Laborator (10m x 8m)**:
  - 4 ancore Ubertooth poziționate în colțuri: $A_1(0,0)$, $A_2(10,0)$, $A_3(10,8)$, $A_4(0,8)$.
  - Dispozitiv test situat lângă perete la coordonatele reale $(9.0\text{m}, 1.2\text{m})$.
- **De ce Eșuează Matematic Centroidul Ponderat?**:
  - Formula: $\mathbf{x}_c = \frac{\sum w_i \mathbf{a}_i}{\sum w_i}, \quad w_i = \frac{1}{d_i^p}$.
  - *Capcana Convex Hull*: Centroidul este prin definiție o combinație convexă strictă a pozițiilor ancorelor. Oricare ar fi ponderile $w_i > 0$, $\mathbf{x}_c \in \text{Interior}(\text{ConvexHull}(\{A_1, \dots, A_4\}))$.
  - *Tracțiune perimetrică*: Când ținta este la 0.5m de ancora $A_2$, ancorele opuse ($A_1, A_4$) exercită o forță vectorală continuă spre centrul sălii.
  - *Rezultat*: Centroidul estimează $(7.0\text{m}, 2.8\text{m})$, generând o eroare masivă de **2.52 metri**!
- **Cum Rezolvă Weighted Least Squares (WLS) Poziția Exactă?**:
  - Formula: $\hat{\mathbf{x}}_{WLS} = (\mathbf{A}^T \mathbf{W} \mathbf{A})^{-1} \mathbf{A}^T \mathbf{W} \mathbf{b}$.
  - WLS rezolvă hiper-suprafețele de intersecție ale ecuațiilor de cerc liniarizate prin scăderea ancorei de referință. Nu există nicio constrângere de convexitate.
  - Ponderarea inversă a varianței $\mathbf{W}_{ii} = \frac{1}{\sigma_{d_i}^2}$ penalizează drastic ancorele îndepărtate, permițând ancorei apropiate $A_2$ să determine intersecția.
  - *Rezultat*: WLS estimează $(8.95\text{m}, 1.25\text{m})$ cu o eroare de doar **0.08 metri** (reducere de 69% pe date reale)!

---

## Slide 5: Rigurozitatea Matematică (LDPL, WLS & EKF) (Node 5)
![[Prezentare_Licenta_Deck.excalidraw#^frame=05 - Rigurozitatea Matematica (LDPL, WLS & EKF)]]

### 🎙️ Note de vorbire (Slide 5)
- **1. Log-Distance Path Loss (LDPL) & Rolling Max**:
  - Ecuația directă: $RSSI(d) = P_{tx} - 10 \cdot n \cdot \log_{10}(d) + X_\sigma$, cu $P_{tx} = -59\text{ dBm}$ (la 1.0m) și $n \approx 2.7$.
  - Inversarea metrică analitică: $d_i = 10^{\frac{P_{tx} - RSSI_i}{10n}}$.
  - Filtru Rolling Max: $RSSI_{LOS}(t) = \max_{\tau \in [t-W, t]} RSSI(\tau)$ ($W = 1500\text{ ms}$).
- **2. Liniarizarea & Optimizarea WLS (Gauss-Markov)**:
  - Liniarizare prin scăderea ancorei $N$:
    $$\mathbf{A}_i = 2 [x_i - x_N, \; y_i - y_N], \quad b_i = d_N^2 - d_i^2 + (x_i^2 + y_i^2) - (x_N^2 + y_N^2)$$
  - Ponderarea optimă cu varianța: $\mathbf{W} = \text{diag}(1/\sigma_1^2, \dots, 1/\sigma_{N-1}^2)$, unde $\sigma_{d_i} = \frac{\ln 10}{10n} \cdot d_i \cdot \sigma_{RSSI}$.
  - Soluția analitică *closed-form* (BLUE): $\hat{\mathbf{x}} = (\mathbf{A}^T \mathbf{W} \mathbf{A})^{-1} \mathbf{A}^T \mathbf{W} \mathbf{b}$ și $\text{Cov}(\hat{\mathbf{x}}) = (\mathbf{A}^T \mathbf{W} \mathbf{A})^{-1}$.
  - Complexitate $\mathcal{O}(1)$, calcul în sub 0.15 ms, garantat fără divergență numerică sau minime locale!
- **3. Filtrul Kalman Cinematic (EKF)**:
  - Vector de stare 4D: $\mathbf{x}_k = [x, y, v_x, v_y]^T$.
  - Matricea de tranziție $\mathbf{F} = \begin{bmatrix} 1 & 0 & \Delta t & 0 \\ 0 & 1 & 0 & \Delta t \\ 0 & 0 & 1 & 0 \\ 0 & 0 & 0 & 1 \end{bmatrix}$.
  - Covarianță adaptivă $R_k$: Când o persoană obstrucționează semnalul și varianța WLS crește, Kalman crește automat $R_k$ și menține traiectoria pe baza inerției vitezei $[v_x, v_y]$, prevenind salturile pe hartă.

---

## Slide 6: Rezultate Experimentale & Concluzii Susținere (Node 6)
![[Prezentare_Licenta_Deck.excalidraw#^frame=06 - Rezultate Experimentale & Concluzii Comisie]]

### 🎙️ Note de vorbire (Slide 6)
- **Metricile de Validare Experimentală**:
  - *120 / 120 Teste Automate*: Suită exhaustivă PyTest (backend matematic) și Vitest (interfețe UI), cu 100% passing și zero regresii.
  - *Scor Confidență Ancore 4 / 4*: Sincronizare cvadruplă stabilă cu un raport semnal/zgomot (SNR) mediu de 21.4 dB.
  - *Cross-Window Time Sync*: Jitter temporal menținut sub 14.8 ms în agregarea pachetelor pe fereastra de 1500 ms.
  - *Acuratețe Metrică*: Eroare medie de **0.82 m** în condiții Line-of-Sight și **1.45 m** cu obstacole (ameliorare de 72.2% față de centroidul naiv).
- **Concluziile Cheie pentru Comisie**:
  1. *Conformitate Etică & 100% Pasiv*: Zero software sau permisiuni pe telefoane, anonimizare prin adrese LAP fără date personale, guardrails hardware TX interzis.
  2. *Valoare Științifică Explicabilă*: Demonstrație teoretică a deformării centroidale, rezolvare prin WLS și urmărire cinematică EKF adaptivă.
  3. *Livrabile Software Complete*: Aplicație desktop Tauri Rust și dashboard web Streamlit gata de testare și rulare live.
