---
tags: [licenta, arhitectura, dataflow, python, streamlit, modules]
status: complete
date: 2026-07-22
---

# Arhitectura Software și Fluxul de Date - Classic Bluetooth Triangulation WebApp

> [!NOTE]
> Document tehnic explicativ privind structura pe straturi (Layered Architecture), modulele Python și fluxul de date de la fișierele `.pcap` până la randarea 2D pe Web UI.
>
> Scop acum Classic-only (pivot 2026-07-30): pipeline-ul extrage pachete Bluetooth Classic (BR/EDR), nu BLE.

---

## 1. Diagrama Arhitecturii pe Straturi

```mermaid
graph TD
    UI[Layer 1: Streamlit Web UI - app.py] --> Orch[Layer 2: Pipeline Orchestrator - pipeline.py]
    Orch --> Extr[Layer 3a: PCAP Extractor - pcap_extractor.py]
    Orch --> Match[Layer 3b: Identity Matching - identity.py]
    Orch --> Audit[Layer 3c: Observability Audit - coverage_audit.py]
    Orch --> Pos[Layer 3d: Positioning Engine - positioning.py]
    Orch --> Render[Layer 4: Spatial & Data Rendering - render_output.py]

    Extr --> PCAP[(Store: Raw PCAP Files)]
    Pos --> Alg1[Centroid Solver]
    Pos --> Alg2[Weighted Least Squares WLS]
    Pos --> Alg3[Kinematic EKF Solver]
    Pos --> Alg4[Hybrid WLS + EKF]
```

---

## 2. Descrierea Modulelor din Proiect

### Module Core

1. **`app.py` (Interfața Web UI Streamlit)**
   - Punct de intrare pentru utilizator/profesor.
   - Permite configurarea interactivă a lungimii/lățimii camerei, modului de potrivire identitate (`cross_window` / `per_window`), ferestrelor temporale per colț și algoritmului de poziționare (`centroid`, `wls`, `kalman`, `hybrid`).

2. **`pipeline.py` (Orchestratorul Principal)**
   - Funcția centrală: `run_triangulation_pipeline(pcap_dir, corner_schedule, room_config, method=...)`.
   - Coordonează în cascadă: Extracție PCAP $\rightarrow$ Potrivire Adrese MAC $\rightarrow$ Audit Observabilitate $\rightarrow$ Triangulație Spațială.

3. **`pcap_extractor.py` (Modulul de Extracție Pachete)**
   - Folosește biblioteca `PyShark` (wrapper peste `tshark`/Wireshark).
   - Parsează fișierele `.pcap` și extrage doar pachetele Bluetooth Classic (BR/EDR) recepționate în ferestrele $[T_{\text{start}}, T_{\text{sfarsit}}]$ specifice fiecărui colț.

4. **`positioning.py` (Engine-ul de Poziționare Spațială)**
   - Modul pur matematic, complet decuplat de UI.
   - Conține algoritmii: `estimate_position_centroid`, `estimate_position_wls`, `estimate_position_kalman` și `estimate_position_hybrid`.

5. **`render_output.py` (Modulul de Randare)**
   - Generează tabelul de date Pandas (`render_position_table`) și graficul spațial 2D Matplotlib (`render_position_map`) afișat în Streamlit.

---

## 3. Fluxul de Date Pas cu Pas (Step-by-Step Data Flow)

```mermaid
sequenceDiagram
    autonumber
    actor User as Utilizator / Profesor
    participant App as app.py (Streamlit)
    participant Pipe as pipeline.py
    participant Extr as pcap_extractor.py
    participant Pos as positioning.py
    participant Rend as render_output.py

    User->>App: Apasă "Rulează pipeline-ul" (Selectează WLS/Hybrid)
    App->>Pipe: run_triangulation_pipeline(pcap_dir, schedule, room_config, method)
    Pipe->>Extr: extract_windowed_packets(pcap_dir, schedule)
    Extr-->>Pipe: DataFrame (pachete Classic BT extrase per colț)
    Pipe->>Pipe: match_devices() (grupare MAC & potrivire ferestre)
    Pipe->>Pos: estimate_position(distances, coords, method, variances)
    Pos-->>Pipe: Coordonate (x, y) + Confidence "4/4"
    Pipe-->>App: PipelineResult(results_df, matching_fraction, ...)
    App->>Rend: render_position_table() & render_position_map()
    Rend-->>App: Figură Matplotlib 2D & Tabel Pandas
    App-->>User: Afișează vizual pe ecran
```

---

## 4. Ce Trebuia Să Știi Despre Fișiere și Organizare

- **Cod Sursă**: Tot codul este acoperit de **120 de teste automatizate** în `tests/` cu 100% verde (`pytest`).
- **Separare Clară de Responsabilități (SOLID)**:
  - Modulul `positioning.py` nu știe de Streamlit sau de fișiere `.pcap` (este o funcție pură matematică).
  - Modulul `app.py` nu conține algoritmi de poziționare sau parsare (este doar un strat subțire de UI).
- **Legături Utile**:
  - [[00 - Ghid Sustinere Licenta WebApp]]
  - [[02 - Algoritmica de Triangulare si Filtrare]]
