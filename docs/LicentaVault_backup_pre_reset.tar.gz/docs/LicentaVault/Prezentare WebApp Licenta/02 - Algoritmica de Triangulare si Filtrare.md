---
tags: [licenta, algoritmi, matematica, ldpl, wls, kalman, positioning]
status: complete
date: 2026-07-22
---

# Algoritmica de Triangulație și Filtrare - Classic Bluetooth Triangulation WebApp

> [!NOTE]
> Document matematic comprehensiv ce detaliază cele 4 metode de poziționare din aplicație și fundamentele fizico-matematice folosite.
>
> Scop acum Classic-only (pivot 2026-07-30). Formulele de mai jos sunt generice (RSSI → distanță → poziție) și se aplică neschimbat pe RSSI Bluetooth Classic (BR/EDR).

---

## 1. Modelul Log-Distance Path Loss (LDPL)

Transpunerea indicelui de putere al semnalului receptat ($RSSI$ în dBm) în distanță estimată $d$ (metri):

$$RSSI(d) = P_{tx} - 10 n \log_{10}(d)$$

Inversând formula:

$$d = 10^{\frac{P_{tx} - RSSI}{10n}}$$

- $P_{tx}$: Puterea semnalului la distanța de referință de $1\text{ m}$ (implicit $-59\text{ dBm}$).
- $n$: Exponentul de pierdere a semnalului în mediu (Path Loss Exponent, uzual $n \in [2.5, 3.0]$ în birouri/săli).

---

## 2. Cei 4 Algoritm de Poziționare din WebApp

Aplicația noastră oferă 4 opțiuni selectabile interactiv în `app.py`:

| Algoritm | Simbol în UI | Principiu de Calcul | Avantaje | Limite |
|---|---|---|---|---|
| **Weighted Centroid** | `centroid` | Medie ponderată $w_i = \frac{1}{\max(d_i, \epsilon)}$ | Calcul rapid, simplu | Blocat în Convex Hull, bias spre centru |
| **Weighted Least Squares** | `wls` | Liniarizare matriceală $A \mathbf{x} = \mathbf{b}$, ponderi $W_{ii} = \frac{1}{\sigma_i^2 \cdot d_i + \epsilon}$ | Poziționare liberă 2D, rezistent la zgomot | Necesită $\ge 3$ ancore ne-coliniare |
| **Kinematic EKF** | `kalman` | Filtru Kalman cu vector stare $[x, y, v_x, v_y]^T$ | Netezește traiectoria, elimină salturi | Sensibil la starea inițială |
| **Hybrid WLS + EKF** | `hybrid` | Soluție inițială WLS $\rightarrow$ Netezire EKF | **Cel mai precis & robust** | Complexitate uşor crescută |

---

## 3. Detalii Matematice pe Algoritm

### A. Weighted Centroid (`centroid`)
$$\mathbf{x} = \frac{\sum_{i=1}^k w_i \mathbf{x}_i}{\sum_{i=1}^k w_i}, \quad \text{unde } w_i = \frac{1}{\max(d_i, \epsilon)}$$

### B. Weighted Least Squares (`wls`)
Liniarizăm ecuațiile cercurilor de trilaterație prin scăderea ultimei ancore $k$:
$$A = 2 \begin{bmatrix} (x_1 - x_k) & (y_1 - y_k) \\ (x_2 - x_k) & (y_2 - y_k) \\ \vdots & \vdots \\ (x_{k-1} - x_k) & (y_{k-1} - y_k) \end{bmatrix}, \quad \mathbf{b} = \begin{bmatrix} x_1^2 - x_k^2 + y_1^2 - y_k^2 + d_k^2 - d_1^2 \\ x_2^2 - x_k^2 + y_2^2 - y_k^2 + d_k^2 - d_2^2 \\ \vdots \\ x_{k-1}^2 - x_k^2 + y_{k-1}^2 - y_k^2 + d_k^2 - d_{k-1}^2 \end{bmatrix}$$

Soluția algebrică ponderată pe varianță ($\sigma_i^2$):
$$\mathbf{x}_{\text{WLS}} = (A^T W A)^{-1} A^T W \mathbf{b}, \quad \text{cu } W_{ii} = \frac{1}{\sigma_i^2 \cdot d_i + \epsilon}$$

### C. Kinematic Extended Kalman Filter (`kalman`)
Vectorul de stare cinematic:
$$\mathbf{x}_k = [x, y, v_x, v_y]^T$$
Predicția cinematică:
$$\mathbf{x}_{k|k-1} = F \mathbf{x}_{k-1}, \quad F = \begin{bmatrix} 1 & 0 & \Delta t & 0 \\ 0 & 1 & 0 & \Delta t \\ 0 & 0 & 1 & 0 \\ 0 & 0 & 0 & 1 \end{bmatrix}$$

Corecția cu pondere adaptivă pe reziduul de inovație împiedică săriturile nerealiste cauzate de umbrirea de corp uman (Body Shadowing).

---

## 4. Legături Utile

- [[00 - Ghid Sustinere Licenta WebApp]]
- [[01 - Arhitectura si Fluxul de Date]]
