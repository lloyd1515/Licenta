#!/usr/bin/env python3
"""
Complete Generator for Licenta Excalidraw Presentation Deck
Dual-Format Obsidian Markdown + Pure Excalidraw JSON
Non-Linear 2D Graph Traversal Layout with Authentic Sketchy Whiteboard Aesthetics.
"""

import json
import base64
import random
import sys
from pathlib import Path

random.seed(42)

# --- SVG ASSETS (Representative Icons) ---
SVGS = {
    "file_bt_logo": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100" height="100">
  <rect width="100" height="100" rx="22" fill="#1971c2" />
  <circle cx="50" cy="50" r="42" fill="none" stroke="#e7f5ff" stroke-width="2" stroke-dasharray="4 3" />
  <path d="M50 16 L50 84 M50 16 L74 36 L34 60 M50 84 L74 64 L34 40" 
        stroke="#ffffff" stroke-width="6.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
  <circle cx="50" cy="50" r="3" fill="#ffffff"/>
</svg>''',

    "file_antenna_tower": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100" height="100">
  <rect width="100" height="100" rx="22" fill="#d9480f" />
  <path d="M42 85 L48 30 M58 85 L52 30 M45 45 L55 45 M43 65 L57 65 M50 30 L50 15" 
        stroke="#ffffff" stroke-width="3" stroke-linecap="round"/>
  <circle cx="50" cy="15" r="5" fill="#ffe066"/>
  <path d="M38 12 A 16 16 0 0 0 38 22" stroke="#ffffff" stroke-width="3" stroke-linecap="round" fill="none"/>
  <path d="M30 6 A 26 26 0 0 0 30 28" stroke="#ffe066" stroke-width="3" stroke-linecap="round" fill="none"/>
  <path d="M62 12 A 16 16 0 0 1 62 22" stroke="#ffffff" stroke-width="3" stroke-linecap="round" fill="none"/>
  <path d="M70 6 A 26 26 0 0 1 70 28" stroke="#ffe066" stroke-width="3" stroke-linecap="round" fill="none"/>
</svg>''',

    "file_layers_stack": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100" height="100">
  <rect width="100" height="100" rx="22" fill="#099268" />
  <path d="M50 18 L78 28 L50 38 L22 28 Z" fill="#63e6be" stroke="#ffffff" stroke-width="2"/>
  <path d="M50 35 L78 45 L50 55 L22 45 Z" fill="#20c997" stroke="#ffffff" stroke-width="2"/>
  <path d="M50 52 L78 62 L50 72 L22 62 Z" fill="#0ca678" stroke="#ffffff" stroke-width="2"/>
  <path d="M50 69 L78 79 L50 89 L22 79 Z" fill="#087f5b" stroke="#ffffff" stroke-width="2"/>
</svg>''',

    "file_room_blueprint": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100" height="100">
  <rect width="100" height="100" rx="22" fill="#1864ab" />
  <path d="M20 20 L80 20 L80 80 L20 80 Z" fill="none" stroke="#74c0fc" stroke-width="2" stroke-dasharray="3 3"/>
  <circle cx="20" cy="20" r="5" fill="#38d9a9"/>
  <circle cx="80" cy="20" r="5" fill="#38d9a9"/>
  <circle cx="80" cy="80" r="5" fill="#38d9a9"/>
  <circle cx="20" cy="80" r="5" fill="#38d9a9"/>
  <circle cx="70" cy="35" r="10" fill="none" stroke="#ff6b6b" stroke-width="3"/>
  <line x1="70" y1="20" x2="70" y2="50" stroke="#ff6b6b" stroke-width="2"/>
  <line x1="55" y1="35" x2="85" y2="35" stroke="#ff6b6b" stroke-width="2"/>
  <circle cx="70" cy="35" r="3" fill="#ffe066"/>
</svg>''',

    "file_math_sigma": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100" height="100">
  <rect width="100" height="100" rx="22" fill="#5f3dc4" />
  <path d="M22 22 L14 22 L14 78 L22 78" fill="none" stroke="#d0bfff" stroke-width="3.5" stroke-linecap="round"/>
  <path d="M78 22 L86 22 L86 78 L78 78" fill="none" stroke="#d0bfff" stroke-width="3.5" stroke-linecap="round"/>
  <path d="M68 30 L34 30 L52 50 L34 70 L68 70" fill="none" stroke="#ffd43b" stroke-width="5.5" stroke-linecap="round" stroke-linejoin="round"/>
  <circle cx="68" cy="48" r="4" fill="#69db7c"/>
</svg>''',

    "file_trophy_seal": '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100" height="100">
  <rect width="100" height="100" rx="22" fill="#2b8a3e" />
  <path d="M35 25 L65 25 L65 48 C65 58 58 64 50 64 C42 64 35 58 35 48 Z" fill="#fcc419" stroke="#fab005" stroke-width="2"/>
  <path d="M35 32 L26 32 C23 32 23 44 28 46 L35 46" fill="none" stroke="#fcc419" stroke-width="3" stroke-linecap="round"/>
  <path d="M65 32 L74 32 C77 32 77 44 72 46 L65 46" fill="none" stroke="#fcc419" stroke-width="3" stroke-linecap="round"/>
  <path d="M47 64 L45 74 L36 78 L64 78 L55 74 L53 64 Z" fill="#fab005"/>
  <circle cx="50" cy="44" r="10" fill="#ffffff"/>
  <path d="M45 44 L48 48 L56 40" fill="none" stroke="#2b8a3e" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
</svg>'''
}


class ExcalidrawBuilder:
    def __init__(self):
        self.elements = []
        self.files = {}
        self.text_block_refs = []
        self._init_files()

    def _init_files(self):
        for fid, svg_content in SVGS.items():
            b64 = base64.b64encode(svg_content.encode("utf-8")).decode("ascii")
            self.files[fid] = {
                "id": fid,
                "mimeType": "image/svg+xml",
                "dataURL": f"data:image/svg+xml;base64,{b64}",
                "created": 1710000000000
            }

    def _base_element(self, el_id, el_type, x, y, w, h, angle=0.0):
        return {
            "id": el_id,
            "type": el_type,
            "x": round(x, 2),
            "y": round(y, 2),
            "width": round(w, 2),
            "height": round(h, 2),
            "angle": round(angle, 4),
            "strokeColor": "#1e1e1e",
            "backgroundColor": "transparent",
            "fillStyle": "solid",
            "strokeWidth": 2,
            "strokeStyle": "solid",
            "roughness": 1,
            "opacity": 100,
            "groupIds": [],
            "frameId": None,
            "roundness": None,
            "seed": random.randint(1000, 999999),
            "version": 1,
            "versionNonce": random.randint(1000, 999999),
            "isDeleted": False,
            "boundElements": None,
            "link": None,
            "locked": False
        }

    def add_rect(self, el_id, x, y, w, h, stroke_color="#1e1e1e", bg_color="transparent",
                 fill_style="solid", roughness=1, stroke_width=2, stroke_style="solid",
                 roundness=None, frame_id=None, angle=0.0):
        el = self._base_element(el_id, "rectangle", x, y, w, h, angle)
        el["strokeColor"] = stroke_color
        el["backgroundColor"] = bg_color
        el["fillStyle"] = fill_style
        el["roughness"] = roughness
        el["strokeWidth"] = stroke_width
        el["strokeStyle"] = stroke_style
        el["frameId"] = frame_id
        if roundness:
            el["roundness"] = roundness if isinstance(roundness, dict) else {"type": 3}
        self.elements.append(el)
        return el

    def add_text(self, el_id, x, y, text_str, font_size=20, font_family=1,
                 stroke_color="#1e1e1e", text_align="left", frame_id=None, angle=0.0):
        lines = text_str.split("\n")
        max_line_len = max(len(l) for l in lines) if lines else 1
        char_w = font_size * (0.6 if font_family == 1 else 0.65)
        line_h = font_size * 1.3
        w = max(40, max_line_len * char_w)
        h = max(25, len(lines) * line_h)

        el = self._base_element(el_id, "text", x, y, w, h, angle)
        el["text"] = text_str
        el["originalText"] = text_str
        el["fontSize"] = font_size
        el["fontFamily"] = font_family  # 1 = Virgil (sketchy), 3 = Cascadia (mono)
        el["textAlign"] = text_align
        el["verticalAlign"] = "top"
        el["strokeColor"] = stroke_color
        el["frameId"] = frame_id
        el["baseline"] = int(font_size * 0.9)
        el["containerId"] = None
        el["lineHeight"] = 1.25

        self.elements.append(el)
        self.text_block_refs.append((text_str, el_id))
        return el

    def add_line(self, el_id, x, y, points, stroke_color="#1e1e1e", stroke_width=2,
                 stroke_style="solid", roughness=1, frame_id=None, start_arrow=None,
                 end_arrow=None, angle=0.0):
        xs = [p[0] for p in points]
        ys = [p[1] for p in points]
        w = max(xs) - min(xs) if xs else 10
        h = max(ys) - min(ys) if ys else 10
        el_type = "arrow" if (start_arrow or end_arrow) else "line"

        el = self._base_element(el_id, el_type, x, y, w, h, angle)
        el["points"] = points
        el["strokeColor"] = stroke_color
        el["strokeWidth"] = stroke_width
        el["strokeStyle"] = stroke_style
        el["roughness"] = roughness
        el["frameId"] = frame_id
        el["startArrowhead"] = start_arrow
        el["endArrowhead"] = end_arrow
        el["elbowed"] = False
        el["lastCommittedPoint"] = None
        el["startBinding"] = None
        el["endBinding"] = None
        self.elements.append(el)
        return el

    def add_ellipse(self, el_id, x, y, w, h, stroke_color="#1e1e1e", bg_color="transparent",
                    fill_style="solid", roughness=1, stroke_width=2, stroke_style="solid",
                    frame_id=None, angle=0.0):
        el = self._base_element(el_id, "ellipse", x, y, w, h, angle)
        el["strokeColor"] = stroke_color
        el["backgroundColor"] = bg_color
        el["fillStyle"] = fill_style
        el["roughness"] = roughness
        el["strokeWidth"] = stroke_width
        el["strokeStyle"] = stroke_style
        el["frameId"] = frame_id
        self.elements.append(el)
        return el

    def add_image(self, el_id, x, y, w, h, file_id, frame_id=None, angle=0.0):
        el = self._base_element(el_id, "image", x, y, w, h, angle)
        el["strokeColor"] = "transparent"
        el["backgroundColor"] = "transparent"
        el["fileId"] = file_id
        el["status"] = "saved"
        el["scale"] = [1, 1]
        el["frameId"] = frame_id
        self.elements.append(el)
        return el

    def add_sticky_note(self, prefix, x, y, w, h, text_str, bg_color="#fff9db",
                        stroke_color="#f59f00", angle=0.015, frame_id=None):
        self.add_rect(
            f"{prefix}_body", x, y, w, h,
            stroke_color=stroke_color, bg_color=bg_color,
            fill_style="solid", roughness=1, stroke_width=2,
            roundness={"type": 3}, frame_id=frame_id, angle=angle
        )
        tape_w, tape_h = 70, 20
        tape_x = x + (w - tape_w) / 2
        tape_y = y - 8
        self.add_rect(
            f"{prefix}_tape", tape_x, tape_y, tape_w, tape_h,
            stroke_color="#ced4da", bg_color="#ced4da",
            fill_style="solid", roughness=1, stroke_width=1,
            frame_id=frame_id, angle=angle
        )
        self.add_text(
            f"{prefix}_txt", x + 16, y + 22, text_str,
            font_size=16, font_family=1, stroke_color="#212529",
            frame_id=frame_id, angle=angle
        )

    def add_frame(self, frame_id, name, x, y, w=1920, h=1080):
        el = self._base_element(frame_id, "frame", x, y, w, h, angle=0.0)
        el["name"] = name
        el["strokeColor"] = "#adb5bd"
        el["backgroundColor"] = "transparent"
        el["strokeWidth"] = 1
        el["roughness"] = 0
        self.elements.append(el)
        return el


def build_deck():
    b = ExcalidrawBuilder()

    # =========================================================================
    # SLIDE 1: Titlu & Sistem Pasiv de Pozitionare (Node 1: x: 0, y: 0)
    # =========================================================================
    fx, fy, fid = 0, 0, "frame_01"

    # Top Header Bar
    b.add_rect("s1_top_bar", fx, fy, 1920, 10, stroke_color="#1971c2", bg_color="#1971c2",
               fill_style="solid", roughness=0, stroke_width=1, frame_id=fid)
    
    # Institution Badge
    b.add_rect("s1_badge", fx + 70, fy + 35, 620, 36, stroke_color="#1971c2", bg_color="#e7f5ff",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_text("s1_badge_txt", fx + 90, fy + 43, "PROIECT DE LICENȚĂ 2026 | UNIVERSITATEA POLITEHNICA BUCUREȘTI",
               font_size=15, font_family=1, stroke_color="#1971c2", frame_id=fid)

    # Title & Subtitle
    b.add_text("s1_title", fx + 70, fy + 82, "Sistem Pasiv de Triangulare și Poziționare Indoor pe Bluetooth Classic",
               font_size=32, font_family=1, stroke_color="#111827", frame_id=fid)
    b.add_text("s1_subtitle", fx + 70, fy + 128,
               "Captură Hardware Ubertooth One la 2.4 GHz, Pipeline Decuplat & Estimare Matematică Deterministică (LDPL, WLS, EKF)",
               font_size=18, font_family=1, stroke_color="#495057", frame_id=fid)

    # Slide 1 Representative Image: Bluetooth Logo
    b.add_image("s1_img_bt", fx + 1740, fy + 35, 100, 100, "file_bt_logo", frame_id=fid)

    # 3 Fundamental Pillar Cards
    pillars = [
        ("s1_pil_1", fx + 70, fy + 175, 580, 360, "#1971c2", "#d0ebff",
         "PILONUL 1: CAPTURĂ HARDWARE 100% PASIVĂ",
         "• Hardware Sniffer: Receptoare SDR Ubertooth One (2.4 GHz ISM)\n"
         "• Microcontroller dedicat: LPC175x ARM Cortex-M3 + CC2400\n"
         "• Zero Intruziune: Fără pairing, asociere sau aplicații pe telefon\n"
         "• Extragere LAP: Lower Address Part extras direct din preambul\n"
         "• Hardware Guardrails: Mod Listen-Only forțat în firmware (TX blocat)"),

        ("s1_pil_2", fx + 670, fy + 175, 580, 360, "#2b8a3e", "#d3f9d8",
         "PILONUL 2: ESTIMARE DETERMINISTICĂ EXPLICABILĂ",
         "• Modelare Fizică LDPL: Inversare analitică deterministă RSSI -> Distanță\n"
         "• Filtrare Rolling Max (1500 ms): Reține anvelopa superioară LOS\n"
         "• Optimizare WLS: Soluție analitică (A^T W A)^-1 A^T W b în sub 0.15 ms\n"
         "• Extended Kalman Filter (EKF): Urmărire cinematică lină cu inerție\n"
         "• Excludere ML Opac: Fără 'black-box' neuronale sau salturi false"),

        ("s1_pil_3", fx + 1270, fy + 175, 580, 360, "#7048e8", "#eebefa",
         "PILONUL 3: ARHITECTURĂ & LIVRABILE COMPLETE",
         "• Decuplare pe 4 Straturi: Shell UI, Orchestrare, Math, Hardware SDR\n"
         "• Sincronizare Temporală: Jitter cross-window măsurat < 14.8 ms\n"
         "• Interfețe Duble: Tauri Desktop (Rust 60 FPS) + Web Streamlit\n"
         "• Testare Exhaustivă: 120 / 120 teste automate PyTest + Vitest (100% PASS)\n"
         "• Pipeline Producție: Validare statică riguroasă prin contracte Pydantic")
    ]

    for p_id, px, py, pw, ph, strk, hdr_bg, hdr_t, body_t in pillars:
        # Card Body
        b.add_rect(f"{p_id}_body", px, py + 48, pw, ph - 48, stroke_color=strk, bg_color="#f8f9fa",
                   fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
        # Card Header
        b.add_rect(f"{p_id}_hdr", px, py, pw, 48, stroke_color=strk, bg_color=hdr_bg,
                   fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
        b.add_text(f"{p_id}_hdrt", px + 18, py + 14, hdr_t, font_size=16, font_family=1, stroke_color=strk, frame_id=fid)
        # Card Text
        b.add_text(f"{p_id}_txt", px + 18, py + 62, body_t, font_size=16, font_family=1, stroke_color="#212529", frame_id=fid)

    # Doodles on Slide 1: Radiating waves on Pillar 1
    b.add_line("s1_wave_1", fx + 530, fy + 440, [[0, 0], [15, -20], [25, 0], [35, -20]],
               stroke_color="#1971c2", stroke_width=2, stroke_style="dashed", roughness=2, frame_id=fid)
    b.add_ellipse("s1_arc_1", fx + 540, fy + 450, 40, 40, stroke_color="#1971c2", stroke_style="dashed", roughness=2, frame_id=fid)
    b.add_ellipse("s1_arc_2", fx + 530, fy + 440, 60, 60, stroke_color="#1971c2", stroke_style="dashed", roughness=2, frame_id=fid)
    # Cascadia formula badge on Pillar 2
    b.add_rect("s1_math_badge", fx + 1090, fy + 460, 130, 40, stroke_color="#2b8a3e", bg_color="#d3f9d8",
               fill_style="solid", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_text("s1_math_txt", fx + 1100, fy + 470, "(AᵀWA)⁻¹", font_size=15, font_family=3, stroke_color="#2b8a3e", frame_id=fid)
    # 120/120 badge on Pillar 3
    b.add_rect("s1_pass_badge", fx + 1690, fy + 460, 130, 40, stroke_color="#7048e8", bg_color="#eebefa",
               fill_style="solid", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_text("s1_pass_txt", fx + 1700, fy + 470, "120/120 ✓", font_size=15, font_family=1, stroke_color="#7048e8", frame_id=fid)

    # Lower Section: End-to-End Workflow Title Bar
    b.add_rect("s1_flow_bar", fx + 70, fy + 565, 1780, 42, stroke_color="#495057", bg_color="#f1f3f5",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_text("s1_flow_lbl", fx + 90, fy + 575,
               "FLUXUL DE DATE END-TO-END: DE LA CAPTURA RADIO SDR LA INTERFAȚA DE OPERATOR",
               font_size=16, font_family=1, stroke_color="#212529", frame_id=fid)

    # 5 Connected Pipeline Boxes
    stages = [
        ("s1_st_0", fx + 70, fy + 625, 300, 240, "#1971c2", "#d0ebff", "1. ȚINTĂ SMARTPHONE",
         "• Dispozitiv activ în sală\n• Emisie BR/EDR (2.4 GHz ISM)\n• Pachete ID/FHS nesincronizate\n• Adresă LAP în clar în header"),
        ("s1_st_1", fx + 440, fy + 625, 300, 240, "#099268", "#c3fae8", "2. UBERTOOTH ONE",
         "• Receptor SDR CC2400 2.4 GHz\n• Microcontroller ARM Cortex-M3\n• Monitorizare fizică 100% pasivă\n• Extragere RSSI hardware"),
        ("s1_st_2", fx + 810, fy + 625, 300, 240, "#e8590c", "#ffe8cc", "3. EXTRACTOR PCAP",
         "• Parsare flux PyShark / libbtbb\n• Filtrare LAP țintă (0x9e8b33)\n• Fereastră mobilă cross-window\n• Filtru Rolling Max (anvelopă LOS)"),
        ("s1_st_3", fx + 1180, fy + 625, 300, 240, "#7048e8", "#eebefa", "4. ESTIMATOR WLS+EKF",
         "• Inversare LDPL metrică (d_i)\n• Ponderare inversă a varianței\n• Soluție Gauss-Markov (O(1))\n• Propagare cinematică 4D EKF"),
        ("s1_st_4", fx + 1550, fy + 625, 300, 240, "#2b8a3e", "#d3f9d8", "5. OPERATOR UI",
         "• Tauri Desktop App (Rust IPC)\n• Randare Canvas 2D la 60 FPS\n• Dashboard Științific Streamlit\n• Monitorizare spectru & erori")
    ]

    for s_id, sx, sy, sw, sh, strk, hdr_bg, hdr_t, body_t in stages:
        b.add_rect(f"{s_id}_body", sx, sy + 44, sw, sh - 44, stroke_color=strk, bg_color="#f8f9fa",
                   fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
        b.add_rect(f"{s_id}_hdr", sx, sy, sw, 44, stroke_color=strk, bg_color=hdr_bg,
                   fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
        b.add_text(f"{s_id}_hdrt", sx + 14, sy + 12, hdr_t, font_size=15, font_family=1, stroke_color=strk, frame_id=fid)
        b.add_text(f"{s_id}_txt", sx + 14, sy + 56, body_t, font_size=15, font_family=1, stroke_color="#212529", frame_id=fid)

    # Connecting Arrows between stages
    flow_arrows = [
        ("s1_arr_0", fx + 372, fy + 740, [[0, 0], [64, 0]], "2.4 GHz ISM", "#1971c2"),
        ("s1_arr_1", fx + 742, fy + 740, [[0, 0], [64, 0]], "USB FIFO", "#099268"),
        ("s1_arr_2", fx + 1112, fy + 740, [[0, 0], [64, 0]], "RSSI LOS", "#e8590c"),
        ("s1_arr_3", fx + 1482, fy + 740, [[0, 0], [64, 0]], "(x,y), P_k", "#7048e8")
    ]
    for a_id, ax, ay, pts, lbl, clr in flow_arrows:
        b.add_line(a_id, ax, ay, pts, stroke_color=clr, stroke_width=2, roughness=1, end_arrow="arrow", frame_id=fid)
        b.add_text(f"{a_id}_lbl", ax + 4, ay - 24, lbl, font_size=12, font_family=1, stroke_color=clr, frame_id=fid)

    # Sticky Note Slide 1
    b.add_sticky_note(
        "s1_snote", fx + 1420, fy + 885, 430, 130,
        "💡 Teză Cheie:\nPoziționare 100% pasivă pe Bluetooth Classic fără cooperarea țintei,\nfolosind pachete de interogare BR/EDR și adrese LAP în clar!",
        bg_color="#fff9db", stroke_color="#f59f00", angle=-0.018, frame_id=fid
    )

    # Defense Footer Slide 1
    b.add_text("s1_foot", fx + 70, fy + 1025,
               "Sesiune Susținere Proiect de Licență | Universitatea Politehnica București | Candidat: Vlad Sărățeanu | Iulie 2026",
               font_size=16, font_family=1, stroke_color="#868e96", frame_id=fid)

    # Push Frame 1 (Array Ordering Law: frame after all its children!)
    b.add_frame(fid, "01 - Titlu & Sistem Pasiv de Pozitionare", fx, fy, 1920, 1080)

    # =========================================================================
    # SLIDE 2: Fizica Propagarii RF & De ce NU Machine Learning (Node 2: x: 2300, y: -500)
    # =========================================================================
    fx, fy, fid = 2300, -500, "frame_02"

    b.add_rect("s2_top_bar", fx, fy, 1920, 10, stroke_color="#d9480f", bg_color="#d9480f",
               fill_style="solid", roughness=0, stroke_width=1, frame_id=fid)
    b.add_rect("s2_badge", fx + 70, fy + 35, 660, 36, stroke_color="#d9480f", bg_color="#fff4e6",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_text("s2_badge_txt", fx + 90, fy + 43, "02 / FIZICA PROPAGĂRII RF & JUSTIFICAREA MODELULUI MATEMATIC",
               font_size=15, font_family=1, stroke_color="#d9480f", frame_id=fid)

    b.add_text("s2_title", fx + 70, fy + 82, "Fizica Propagării la 2.4 GHz & De ce NU Folosim Machine Learning",
               font_size=32, font_family=1, stroke_color="#111827", frame_id=fid)
    b.add_text("s2_subtitle", fx + 70, fy + 128,
               "Analiza fenomenelor electromagnetice reale (Multipath, Body Shadowing) și limitele fatale ale rețelelor neuronale",
               font_size=18, font_family=1, stroke_color="#495057", frame_id=fid)

    b.add_image("s2_img_tower", fx + 1740, fy + 35, 100, 100, "file_antenna_tower", frame_id=fid)

    # Left Column: RF Physics Realities (x: 70, w: 860, h: 790)
    b.add_rect("s2_col1_bg", fx + 70, fy + 180, 860, 780, stroke_color="#e03131", bg_color="#fff5f5",
               fill_style="cross-hatch", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_rect("s2_col1_hdr", fx + 70, fy + 180, 860, 48, stroke_color="#e03131", bg_color="#ffc9c9",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_text("s2_col1_hdrt", fx + 90, fy + 194, "FENOMENELE FIZICE LA 2.4 GHz & SOLUȚII DETERMINISTICE",
               font_size=16, font_family=1, stroke_color="#c92a2a", frame_id=fid)

    # Box 1: Multipath Fading
    b.add_rect("s2_multi_box", fx + 90, fy + 245, 820, 210, stroke_color="#e03131", bg_color="#ffffff",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_text("s2_multi_t", fx + 110, fy + 260, "1. MULTIPATH FADING (INTERFERENȚE DISTRUCTIVE)",
               font_size=17, font_family=1, stroke_color="#c92a2a", frame_id=fid)
    b.add_text("s2_multi_body", fx + 110, fy + 295,
               "• Undele radio electromagnetice ricoșează din pereții de beton, mobilier și tavan.\n"
               "• Razele reflectate sosesc la receptor defazate, producând interferențe distructive.\n"
               "• Consecință: Scăderi bruște de semnal (până la -78 dBm) chiar dacă ținta stă pe loc!\n"
               "• Soluția Noastră: Filtrul Rolling Max (W = 1500 ms) reține anvelopa superioară LOS\n"
               "  (Line-of-Sight), eliminând peste 90% din distorsiunile de reflexie.",
               font_size=15, font_family=1, stroke_color="#212529", frame_id=fid)

    # Box 2: Body Shadowing
    b.add_rect("s2_shad_box", fx + 90, fy + 475, 820, 210, stroke_color="#d9480f", bg_color="#ffffff",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_text("s2_shad_t", fx + 110, fy + 490, "2. BODY SHADOWING (UMBRIREA CORPORALĂ)",
               font_size=17, font_family=1, stroke_color="#d9480f", frame_id=fid)
    b.add_text("s2_shad_body", fx + 110, fy + 525,
               "• Corpul uman conține ~70% apă, reprezentând un atenuator masiv la rezonanța de 2.4 GHz.\n"
               "• Când o persoană se interpune între smartphone și o ancoră, semnalul scade cu 3–9 dB.\n"
               "• Consecință: Estimatorul naiv interpretează atenuarea ca o distanțare de 3-5 metri!\n"
               "• Soluția Noastră: EKF adaptează dinamic covarianța măsurătorii R_k și folosește\n"
               "  inerția cinematică de viteză constantă [v_x, v_y] pentru a preveni salturile false.",
               font_size=15, font_family=1, stroke_color="#212529", frame_id=fid)

    # Doodle Graphic: Antenna + Stick figure human with absorption cone + Wall bounce
    # Stick figure at (fx + 220, fy + 760)
    b.add_ellipse("s2_dood_head", fx + 210, fy + 720, 32, 32, stroke_color="#212529", bg_color="#ffd8a8",
                  fill_style="hachure", roughness=1, frame_id=fid)
    b.add_line("s2_dood_spine", fx + 226, fy + 752, [[0, 0], [0, 48]], stroke_color="#212529", stroke_width=3, frame_id=fid)
    b.add_line("s2_dood_arms", fx + 206, fy + 770, [[0, 0], [20, -10], [40, 0]], stroke_color="#212529", stroke_width=3, frame_id=fid)
    b.add_line("s2_dood_legs", fx + 226, fy + 800, [[0, 0], [-18, 45], [0, 0], [18, 45]], stroke_color="#212529", stroke_width=3, frame_id=fid)
    # Absorption shadow cone
    b.add_line("s2_dood_cone1", fx + 236, fy + 760, [[0, 0], [140, -35]], stroke_color="#e03131", stroke_width=2, stroke_style="dashed", frame_id=fid)
    b.add_line("s2_dood_cone2", fx + 236, fy + 780, [[0, 0], [140, 35]], stroke_color="#e03131", stroke_width=2, stroke_style="dashed", frame_id=fid)
    b.add_text("s2_dood_conetxt", fx + 270, fy + 765, "Atenuare 3-9 dB\n(70% apă)", font_size=13, font_family=1, stroke_color="#c92a2a", frame_id=fid)

    # Antenna doodle on left
    b.add_line("s2_dood_mast", fx + 130, fy + 820, [[0, 0], [0, -90]], stroke_color="#495057", stroke_width=3, frame_id=fid)
    b.add_line("s2_dood_mcross1", fx + 115, fy + 780, [[0, 0], [30, 0]], stroke_color="#495057", stroke_width=2, frame_id=fid)
    b.add_line("s2_dood_mcross2", fx + 120, fy + 750, [[0, 0], [20, 0]], stroke_color="#495057", stroke_width=2, frame_id=fid)
    b.add_line("s2_dood_wave1", fx + 140, fy + 740, [[0, 0], [20, -15], [35, 0]], stroke_color="#e8590c", stroke_width=2, roughness=2, frame_id=fid)
    b.add_line("s2_dood_wave2", fx + 145, fy + 730, [[0, 0], [30, -25], [55, 0]], stroke_color="#e8590c", stroke_width=2, roughness=2, frame_id=fid)

    # Concrete Wall Doodle on bottom right of left column
    b.add_rect("s2_dood_wall", fx + 680, fy + 720, 30, 160, stroke_color="#495057", bg_color="#ced4da",
               fill_style="cross-hatch", roughness=1, stroke_width=2, frame_id=fid)
    b.add_text("s2_dood_wallt", fx + 720, fy + 740, "Perete Beton", font_size=14, font_family=1, stroke_color="#495057", frame_id=fid)
    b.add_line("s2_dood_refl1", fx + 540, fy + 760, [[0, 0], [140, 20]], stroke_color="#1971c2", stroke_width=2, frame_id=fid)
    b.add_line("s2_dood_refl2", fx + 680, fy + 780, [[0, 0], [-130, 40]], stroke_color="#e03131", stroke_width=2, stroke_style="dashed", end_arrow="arrow", frame_id=fid)
    b.add_text("s2_dood_reflt", fx + 560, fy + 820, "Rază Reflectată (Drop RSSI)", font_size=13, font_family=1, stroke_color="#c92a2a", frame_id=fid)

    # Right Column: Why NOT Machine Learning (x: 970, w: 880, h: 780)
    b.add_rect("s2_col2_bg", fx + 970, fy + 180, 880, 780, stroke_color="#343a40", bg_color="#f8f9fa",
               fill_style="cross-hatch", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_rect("s2_col2_hdr", fx + 970, fy + 180, 880, 48, stroke_color="#343a40", bg_color="#e9ecef",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_text("s2_col2_hdrt", fx + 990, fy + 194, "DE CE NU REȚELE NEURONALE (SUPERVISED ML / FINGERPRINTING)?",
               font_size=16, font_family=1, stroke_color="#212529", frame_id=fid)

    ml_cards = [
        ("s2_ml_1", fy + 245, 115, "#e03131", "#fff5f5", "1. COST PROHIBITIV DE COLECTARE DATE",
         "O grilă de 0.5m impune peste 400 de puncte de calibrare pentru o sală de 80 m²,\nreprezentând peste 30 de ore de măsurători manuale pentru fiecare încăpere nouă!"),
        ("s2_ml_2", fy + 375, 115, "#e03131", "#fff5f5", "2. FRAGILITATE EXTREMĂ LA FACTORII DE MEDIU",
         "O ușă deschisă, o masă mutată sau apariția unor persoane în sală modifică topologia\nreflexiilor și invalidează complet setul de antrenare (concept drift masiv)."),
        ("s2_ml_3", fy + 505, 115, "#e03131", "#fff5f5", "3. EFECTUL DE CUTIE NEAGRĂ (BLACK-BOX)",
         "Rețelele neuronale nu oferă o marjă analitică de eroare (lipsă matrice de covarianță formală)\nși pot halucina salturi bruște la marginea distribuției de antrenare."),
        ("s2_ml_4", fy + 635, 115, "#e03131", "#fff5f5", "4. ZERO PORTABILITATE ÎNTRE CAMERE",
         "Un model antrenat în Sala A are performanțe catastrofale în Sala B. Transfer learning-ul\neșuează din cauza dimensiunilor și a coeficienților diferiți de absorbție ai pereților."),
        ("s2_ml_5", fy + 765, 165, "#2b8a3e", "#ebfbee", "5. ABORDAREA NOASTRĂ DETERMINISTICĂ (LDPL + WLS)",
         "• Funcționează INSTANT în orice încăpere nouă prin simpla specificare a dimensiunilor\n  și a exponentului de atenuare n in [2.2, 3.0] specific mediului indoor.\n• Rigurozitate matematică: Furnizează matricea de covarianță formală Cov(x) la fiecare pas!")
    ]

    for c_id, cy, ch, strk, bg_c, hdr_t, body_t in ml_cards:
        b.add_rect(c_id, fx + 990, cy, 840, ch, stroke_color=strk, bg_color=bg_c,
                   fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
        b.add_text(f"{c_id}_t", fx + 1010, cy + 12, hdr_t, font_size=15, font_family=1, stroke_color=strk, frame_id=fid)
        b.add_text(f"{c_id}_b", fx + 1010, cy + 42, body_t, font_size=14, font_family=1, stroke_color="#212529", frame_id=fid)

    # Sticky Note Slide 2
    b.add_sticky_note(
        "s2_snote", fx + 1420, fy + 885, 430, 130,
        "⚡ Cheia Fizică:\nFiltrul Rolling Max reține LOS pur prin urmărirea anvelopei superioare,\nfără nicio recalibrare continuă și fără fragilitatea fingerprinting-ului RF!",
        bg_color="#ebfbee", stroke_color="#2b8a3e", angle=0.02, frame_id=fid
    )

    # Push Frame 2
    b.add_frame(fid, "02 - Fizica Propagarii RF & De ce NU Machine Learning", fx, fy, 1920, 1080)

    # =========================================================================
    # SLIDE 3: Arhitectura Decuplata & Pipeline de Date (Node 3: x: 2300, y: 900)
    # =========================================================================
    fx, fy, fid = 2300, 900, "frame_03"

    b.add_rect("s3_top_bar", fx, fy, 1920, 10, stroke_color="#099268", bg_color="#099268",
               fill_style="solid", roughness=0, stroke_width=1, frame_id=fid)
    b.add_rect("s3_badge", fx + 70, fy + 35, 600, 36, stroke_color="#099268", bg_color="#e6fcf5",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_text("s3_badge_txt", fx + 90, fy + 43, "03 / ARHITECTURĂ DE SISTEM PE 4 STRATURI",
               font_size=15, font_family=1, stroke_color="#099268", frame_id=fid)

    b.add_text("s3_title", fx + 70, fy + 82, "Arhitectura Decuplată & Pipeline-ul de Date de la L1 la L4",
               font_size=32, font_family=1, stroke_color="#111827", frame_id=fid)
    b.add_text("s3_subtitle", fx + 70, fy + 128,
               "Separarea strictă a responsabilităților, validare statică Pydantic și garanții de siguranță hardware",
               font_size=18, font_family=1, stroke_color="#495057", frame_id=fid)

    b.add_image("s3_img_layers", fx + 1740, fy + 35, 100, 100, "file_layers_stack", frame_id=fid)

    # Left Section: 4 Decoupled Stack Layers (x: 70, w: 1140, h: 790)
    layers = [
        ("s3_lay_1", fy + 180, 175, "#1971c2", "#d0ebff", "STRATUL 1: SHELL UI & VIZUALIZARE OPERATOR",
         "• Tauri Desktop App (Rust IPC): Randare nativă Canvas 2D la 60 FPS, latență sub 16 ms, zero dependențe Node.js la runtime\n"
         "• Streamlit Scientific Web Dashboard: Tuning dinamic în timp real al parametrilor fizici (n, fereastră W, praguri RSSI)\n"
         "• Arhitectură decuplată: Interfețele consumă fluxuri serializate JSON fără a interacționa direct cu driverele SDR"),

        ("s3_lay_2", fy + 375, 175, "#099268", "#c3fae8", "STRATUL 2: ORCHESTRARE & VALIDARE STARE (pipeline.py)",
         "• SessionController: Mașină de stări finită (IDLE -> SCANNING -> AGGREGATING -> SOLVED) cu agregare cross-window\n"
         "• SchemaEngine (Pydantic): Validare riguroasă a contractelor de date între module; eliminare automată a pachetelor trunchiate\n"
         "• Hardware Guardrails: Mod Listen-Only forțat în firmware; interdicție absolută de transmisie TX sau operațiuni DFU flash"),

        ("s3_lay_3", fy + 570, 175, "#7048e8", "#eebefa", "STRATUL 3: EXTRAGERE PCAP & PIPELINE MATEMATIC (positioning.py)",
         "• PyShark PCAP Live Extractor: Parsare pachete BR/EDR din FIFO (140 pkt/s -> 15 epoci/s) și decodare LAP cu libbtbb\n"
         "• Filtru Rolling Max & Inversare LDPL: Extragere anvelopă LOS pe fereastră mobilă de 1500 ms și conversie RSSI -> distanță\n"
         "• Motor Gauss-Markov WLS + EKF: Soluție analitică O(1) deterministă în sub 0.15 ms și propagare stare cinematică 4D"),

        ("s3_lay_4", fy + 765, 175, "#e8590c", "#ffe8cc", "STRATUL 4: HARDWARE RADIO SDR (Ubertooth One & libbtbb)",
         "• Receptoare SDR 2.4 GHz: Transceiver CC2400 + MCU LPC175x ARM Cortex-M3 conectate prin magistrale USB independente\n"
         "• Sniffing pasiv de pachete: Decodare preambul și extragere RSSI hardware direct din banda de bază fără asociere pe piconet\n"
         "• Stabilitate hardware: Buffer circular intern FIFO pentru prevenirea overflow-ului la rate ridicate de interogare radio")
    ]

    for l_id, ly, lh, strk, hdr_bg, hdr_t, body_t in layers:
        b.add_rect(f"{l_id}_body", fx + 70, ly + 44, 1140, lh - 44, stroke_color=strk, bg_color="#f8f9fa",
                   fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
        b.add_rect(f"{l_id}_hdr", fx + 70, ly, 1140, 44, stroke_color=strk, bg_color=hdr_bg,
                   fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
        b.add_text(f"{l_id}_hdrt", fx + 90, ly + 12, hdr_t, font_size=16, font_family=1, stroke_color=strk, frame_id=fid)
        b.add_text(f"{l_id}_txt", fx + 90, ly + 56, body_t, font_size=15, font_family=1, stroke_color="#212529", frame_id=fid)

    # Right Section: System Guarantees & Hardware Console (x: 1250, w: 600, h: 780)
    b.add_rect("s3_guar_bg", fx + 1250, fy + 180, 600, 360, stroke_color="#343a40", bg_color="#f8f9fa",
               fill_style="cross-hatch", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_rect("s3_guar_hdr", fx + 1250, fy + 180, 600, 48, stroke_color="#343a40", bg_color="#e9ecef",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_text("s3_guar_hdrt", fx + 1270, fy + 194, "GARANȚII CHEIE ALE ARHITECTURII",
               font_size=16, font_family=1, stroke_color="#212529", frame_id=fid)
    b.add_text("s3_guar_body", fx + 1270, fy + 245,
               "• Latență de calcul matematic: sub 0.15 ms per epocă\n"
               "• Sincronizare cross-window: Jitter măsurat < 14.8 ms\n"
               "• Garanție Zero TX: Interdicție hardware de emisie radio\n"
               "• Test coverage: 120 teste automate (PyTest + Vitest)\n"
               "• Decuplare completă: Module testabile izolat prin mock-uri\n"
               "• Contracte stricte: Pydantic SchemaEngine la orice frontieră",
               font_size=15, font_family=1, stroke_color="#212529", frame_id=fid)

    # Hardware Console Card
    b.add_rect("s3_console_bg", fx + 1250, fy + 565, 600, 260, stroke_color="#212529", bg_color="#212529",
               fill_style="solid", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_rect("s3_console_bar", fx + 1250, fy + 565, 600, 32, stroke_color="#343a40", bg_color="#343a40",
               fill_style="solid", roughness=0, stroke_width=1, roundness={"type": 3}, frame_id=fid)
    b.add_text("s3_console_dots", fx + 1265, fy + 572, "● ● ●  ubertooth-daemon (listen-only monitor)",
               font_size=13, font_family=3, stroke_color="#adb5bd", frame_id=fid)

    console_log = (
        "[SYNC] Anchor A1 CC2400: LAP=0x9e8b33 RSSI=-61dBm\n"
        "[SYNC] Anchor A2 CC2400: LAP=0x9e8b33 RSSI=-52dBm\n"
        "[SYNC] Anchor A3 CC2400: LAP=0x9e8b33 RSSI=-68dBm\n"
        "[SYNC] Anchor A4 CC2400: LAP=0x9e8b33 RSSI=-74dBm\n"
        "[WLS]  Epoch 142 -> x=8.95m, y=1.25m (0.08ms)\n"
        "[GUARD] TX blocked by firmware register: OK"
    )
    b.add_text("s3_console_txt", fx + 1265, fy + 610, console_log,
               font_size=14, font_family=3, stroke_color="#51cf66", frame_id=fid)

    # Sticky Note Slide 3
    b.add_sticky_note(
        "s3_snote", fx + 1420, fy + 885, 430, 130,
        "🔒 Hardware Guardrail:\nFirmware-ul blochează forțat orice emisie TX. Sistemul este 100% pasiv,\netic și complet indetectabil în spectrul electromagnetic!",
        bg_color="#f3f0ff", stroke_color="#7048e8", angle=-0.015, frame_id=fid
    )

    # Push Frame 3
    b.add_frame(fid, "03 - Arhitectura Decuplata & Pipeline de Date", fx, fy, 1920, 1080)

    # =========================================================================
    # SLIDE 4: Harta Salii & Geometria Trilateratiei (Node 4: x: 4800, y: -500)
    # =========================================================================
    fx, fy, fid = 4800, -500, "frame_04"

    b.add_rect("s4_top_bar", fx, fy, 1920, 10, stroke_color="#1c7ed6", bg_color="#1c7ed6",
               fill_style="solid", roughness=0, stroke_width=1, frame_id=fid)
    b.add_rect("s4_badge", fx + 70, fy + 35, 620, 36, stroke_color="#1c7ed6", bg_color="#e7f5ff",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_text("s4_badge_txt", fx + 90, fy + 43, "04 / GEOMETRIE SPAȚIALĂ & CAPCANA CONVEX HULL",
               font_size=15, font_family=1, stroke_color="#1c7ed6", frame_id=fid)

    b.add_text("s4_title", fx + 70, fy + 82, "Harta Sălii de Laborator & De ce Eșuează Matematic Centroidul Ponderat",
               font_size=32, font_family=1, stroke_color="#111827", frame_id=fid)
    b.add_text("s4_subtitle", fx + 70, fy + 128,
               "Comparație spațială directă: Capcana interiorului Convex Hull vs. Intersecția hiper-suprafețelor WLS",
               font_size=18, font_family=1, stroke_color="#495057", frame_id=fid)

    b.add_image("s4_img_room", fx + 1740, fy + 35, 100, 100, "file_room_blueprint", frame_id=fid)

    # Left Section: 2D Lab Map Canvas (10m x 8m)
    # Canvas box: (fx + 70, fy + 180, w: 980, h: 780)
    b.add_rect("s4_map_canvas", fx + 70, fy + 180, 980, 780, stroke_color="#1c7ed6", bg_color="#f8f9fa",
               fill_style="cross-hatch", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_rect("s4_map_hdr", fx + 70, fy + 180, 980, 48, stroke_color="#1c7ed6", bg_color="#d0ebff",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_text("s4_map_hdrt", fx + 90, fy + 194, "HARTA GEOMETRICĂ A SĂLII DE EXPERIMENT (10.0m x 8.0m)",
               font_size=16, font_family=1, stroke_color="#1864ab", frame_id=fid)

    # Room Perimeter Box (x: 170 to 890 -> 720 px, y: 260 to 760 -> 500 px)
    # Scale: 720 px = 10m -> 72 px/m; 500 px = 8m -> 62.5 px/m
    rx0, ry0, rw, rh = fx + 170, fy + 260, 720, 500
    b.add_rect("s4_room_bound", rx0, ry0, rw, rh, stroke_color="#343a40", bg_color="#ffffff",
               fill_style="solid", roughness=1, stroke_width=3, frame_id=fid)

    # Dashed Convex Hull line connecting corners
    b.add_line("s4_hull_line", rx0, ry0, [[0, 0], [rw, 0], [rw, rh], [0, rh], [0, 0]],
               stroke_color="#adb5bd", stroke_width=2, stroke_style="dashed", roughness=1, frame_id=fid)
    b.add_text("s4_hull_lbl", rx0 + 260, ry0 + 15, "Perimetru Convex Hull al Ancorelor",
               font_size=14, font_family=1, stroke_color="#adb5bd", frame_id=fid)

    # Corner Anchors with Sketchy Pins & Labels
    anchors = [
        ("s4_anc_1", rx0, ry0 + rh, "A1 (0.0m, 0.0m)", -40, 20),
        ("s4_anc_2", rx0 + rw, ry0 + rh, "A2 (10.0m, 0.0m)", -120, 20),
        ("s4_anc_3", rx0 + rw, ry0, "A3 (10.0m, 8.0m)", -120, -35),
        ("s4_anc_4", rx0, ry0, "A4 (0.0m, 8.0m)", -40, -35)
    ]
    for a_id, ax, ay, albl, ox, oy in anchors:
        b.add_ellipse(f"{a_id}_dot", ax - 12, ay - 12, 24, 24, stroke_color="#087f5b", bg_color="#38d9a9",
                      fill_style="hachure", roughness=1, stroke_width=2, frame_id=fid)
        b.add_text(f"{a_id}_lbl", ax + ox, ay + oy, albl, font_size=14, font_family=3, stroke_color="#087f5b", frame_id=fid)

    # Target Ground Truth: (9.0m, 1.2m)
    # x = rx0 + 9.0 * 72 = rx0 + 648
    # y = ry0 + rh - 1.2 * 62.5 = ry0 + 500 - 75 = ry0 + 425
    gt_x = rx0 + 648
    gt_y = ry0 + 425
    b.add_ellipse("s4_gt_dot", gt_x - 14, gt_y - 14, 28, 28, stroke_color="#f59f00", bg_color="#ffe066",
                  fill_style="solid", roughness=1, stroke_width=2, frame_id=fid)
    b.add_line("s4_gt_cross1", gt_x - 20, gt_y, [[0, 0], [40, 0]], stroke_color="#f59f00", stroke_width=2, frame_id=fid)
    b.add_line("s4_gt_cross2", gt_x, gt_y - 20, [[0, 0], [0, 40]], stroke_color="#f59f00", stroke_width=2, frame_id=fid)
    b.add_text("s4_gt_txt", gt_x - 210, gt_y - 30, "ȚINTĂ REALĂ (9.0m, 1.2m)", font_size=15, font_family=1, stroke_color="#e67700", frame_id=fid)

    # WLS Estimate: (8.95m, 1.25m) -> (rx0 + 644, ry0 + 422)
    wls_x = rx0 + 644
    wls_y = ry0 + 422
    b.add_ellipse("s4_wls_dot", wls_x - 10, wls_y - 10, 20, 20, stroke_color="#2b8a3e", bg_color="#51cf66",
                  fill_style="solid", roughness=1, stroke_width=2, frame_id=fid)
    b.add_text("s4_wls_txt", wls_x - 280, gt_y + 15, "Estimare WLS (8.95m, 1.25m)\nEroare: doar 0.08m! ✓",
               font_size=14, font_family=1, stroke_color="#2b8a3e", frame_id=fid)

    # Centroid Estimate: (7.0m, 2.8m) -> (rx0 + 504, ry0 + 325)
    cen_x = rx0 + 504
    cen_y = ry0 + 325
    b.add_line("s4_cen_x1", cen_x - 14, cen_y - 14, [[0, 0], [28, 28]], stroke_color="#e03131", stroke_width=4, frame_id=fid)
    b.add_line("s4_cen_x2", cen_x + 14, cen_y - 14, [[0, 0], [-28, 28]], stroke_color="#e03131", stroke_width=4, frame_id=fid)
    b.add_text("s4_cen_txt", cen_x - 240, cen_y - 45, "Centroid Ponderat (7.0m, 2.8m)\nEroare masivă: 2.52m! ✗",
               font_size=14, font_family=1, stroke_color="#c92a2a", frame_id=fid)

    # Inward Pulling Vector Arrows from Centroid toward A1 and A4
    b.add_line("s4_pull_a1", cen_x, cen_y, [[0, 0], [-280, 120]],
               stroke_color="#e03131", stroke_width=2, stroke_style="dashed", roughness=2, end_arrow="arrow", frame_id=fid)
    b.add_text("s4_pull_a1_t", cen_x - 220, cen_y + 80, "Tracțiune A1", font_size=13, font_family=1, stroke_color="#c92a2a", frame_id=fid)

    b.add_line("s4_pull_a4", cen_x, cen_y, [[0, 0], [-280, -140]],
               stroke_color="#e03131", stroke_width=2, stroke_style="dashed", roughness=2, end_arrow="arrow", frame_id=fid)
    b.add_text("s4_pull_a4_t", cen_x - 220, cen_y - 120, "Tracțiune A4", font_size=13, font_family=1, stroke_color="#c92a2a", frame_id=fid)

    # Map Legend Bar at bottom of map
    b.add_rect("s4_legend_bg", fx + 90, fy + 885, 940, 55, stroke_color="#adb5bd", bg_color="#ffffff",
               fill_style="solid", roughness=1, stroke_width=1, roundness={"type": 3}, frame_id=fid)
    b.add_text("s4_legend_txt", fx + 110, fy + 900,
               "Legendă: 🟡 Țintă Reală (9.0m, 1.2m) | 🟢 Estimare WLS (Eroare 0.08m) | 🔴 Centroid (Eroare 2.52m - Tras spre Centru)",
               font_size=15, font_family=1, stroke_color="#212529", frame_id=fid)

    # Right Section: Analytical Breakdown (x: 1080, w: 770, h: 780)
    b.add_rect("s4_right_card1", fx + 1080, fy + 180, 770, 360, stroke_color="#e03131", bg_color="#fff5f5",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_rect("s4_rc1_hdr", fx + 1080, fy + 180, 770, 48, stroke_color="#e03131", bg_color="#ffc9c9",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_text("s4_rc1_hdrt", fx + 1100, fy + 194, "DE CE EȘUEAZĂ MATEMATIC CENTROIDUL (CAPCANA CONVEX HULL)",
               font_size=16, font_family=1, stroke_color="#c92a2a", frame_id=fid)

    b.add_text("s4_rc1_form", fx + 1100, fy + 245, "x_c = Σ(w_i * a_i) / Σ(w_i),   w_i = 1 / d_i^p",
               font_size=17, font_family=3, stroke_color="#c92a2a", frame_id=fid)
    b.add_text("s4_rc1_body", fx + 1100, fy + 285,
               "• Teoremă Convexă: Oricare ar fi ponderile w_i > 0, poziția estimată x_c este\n"
               "  strict constrânsă în interiorul poligonului convex format de ancore.\n"
               "• Tracțiune spre interior: Când ținta este la 0.5m de perete lângă A2, ancorele\n"
               "  îndepărtate (A1, A4) exercită forțe vectoriale continue spre centrul sălii.\n"
               "• Consecință practică: Centroidul nu poate ajunge niciodată lângă perete!\n"
               "  Pe date reale, generează o eroare inacceptabilă de 2.52 metri.",
               font_size=15, font_family=1, stroke_color="#212529", frame_id=fid)

    # Card 2: How WLS Solves It
    b.add_rect("s4_right_card2", fx + 1080, fy + 560, 770, 310, stroke_color="#2b8a3e", bg_color="#ebfbee",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_rect("s4_rc2_hdr", fx + 1080, fy + 560, 770, 48, stroke_color="#2b8a3e", bg_color="#d3f9d8",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_text("s4_rc2_hdrt", fx + 1100, fy + 574, "CUM REZOLVĂ WLS POZIȚIA EXACTĂ (0.08m EROARE)",
               font_size=16, font_family=1, stroke_color="#2b8a3e", frame_id=fid)

    b.add_text("s4_rc2_form", fx + 1100, fy + 625, "x̂_WLS = (Aᵀ W A)⁻¹ Aᵀ W b",
               font_size=18, font_family=3, stroke_color="#2b8a3e", frame_id=fid)
    b.add_text("s4_rc2_body", fx + 1100, fy + 665,
               "• Eliminarea constrângerii: WLS rezolvă intersecția hiper-suprafețelor cercurilor\n"
               "  fără nicio constrângere de convexitate.\n"
               "• Ponderare optimă cu varianța: W_ii = 1 / σ_i² penalizează drastic ancorele îndepărtate.\n"
               "• Izolarea ancorei apropiate: Ancora A2 primește pondere masivă, fixând poziția\n"
               "  exact lângă perete la coordonatele reale.\n"
               "• Rezultat: Eroarea scade de la 2.52m la doar 0.08m (reducere cu 69% pe capturi reale)!",
               font_size=15, font_family=1, stroke_color="#212529", frame_id=fid)

    # Sticky Note Slide 4
    b.add_sticky_note(
        "s4_snote", fx + 1420, fy + 885, 430, 130,
        "⚠️ Capcana Convex Hull:\nCentroidul este prizonierul matematic al poligonului ancorelor.\nWLS calculează intersecția liberă și rezolvă poziționarea lângă pereți!",
        bg_color="#fff4e6", stroke_color="#d9480f", angle=0.022, frame_id=fid
    )

    # Push Frame 4
    b.add_frame(fid, "04 - Harta Salii & Geometria Trilateratiei (Centroid vs WLS)", fx, fy, 1920, 1080)

    # =========================================================================
    # SLIDE 5: Rigurozitatea Matematica (Node 5: x: 4800, y: 900)
    # =========================================================================
    fx, fy, fid = 4800, 900, "frame_05"

    b.add_rect("s5_top_bar", fx, fy, 1920, 10, stroke_color="#5f3dc4", bg_color="#5f3dc4",
               fill_style="solid", roughness=0, stroke_width=1, frame_id=fid)
    b.add_rect("s5_badge", fx + 70, fy + 35, 600, 36, stroke_color="#5f3dc4", bg_color="#f3f0ff",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_text("s5_badge_txt", fx + 90, fy + 43, "05 / FORMULARE MATEMATICĂ DETERMINISTICĂ",
               font_size=15, font_family=1, stroke_color="#5f3dc4", frame_id=fid)

    b.add_text("s5_title", fx + 70, fy + 82, "Pipeline-ul Matematic: LDPL, Liniarizare WLS & Filtru Kalman EKF",
               font_size=32, font_family=1, stroke_color="#111827", frame_id=fid)
    b.add_text("s5_subtitle", fx + 70, fy + 128,
               "De la atenuarea logaritmică a puterii RF la estimarea BLUE și propagarea stării cinematice",
               font_size=18, font_family=1, stroke_color="#495057", frame_id=fid)

    b.add_image("s5_img_sigma", fx + 1740, fy + 35, 100, 100, "file_math_sigma", frame_id=fid)

    # 3 Sequential Math Columns (x: 70, 670, 1270; w: 580, h: 780)
    # Column 1: LDPL & Rolling Max
    b.add_rect("s5_c1_body", fx + 70, fy + 180, 580, 780, stroke_color="#1971c2", bg_color="#f8f9fa",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_rect("s5_c1_hdr", fx + 70, fy + 180, 580, 48, stroke_color="#1971c2", bg_color="#d0ebff",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_text("s5_c1_hdrt", fx + 90, fy + 194, "1. CONVERSIE METRICĂ LDPL & ROLLING MAX",
               font_size=16, font_family=1, stroke_color="#1971c2", frame_id=fid)

    b.add_text("s5_c1_lbl1", fx + 90, fy + 245, "Modelul de Propagare Log-Distance Path Loss:",
               font_size=15, font_family=1, stroke_color="#495057", frame_id=fid)
    b.add_text("s5_c1_eq1", fx + 90, fy + 275, "RSSI(d) = P_tx - 10·n·log₁₀(d) + X_σ",
               font_size=18, font_family=3, stroke_color="#1971c2", frame_id=fid)

    b.add_text("s5_c1_lbl2", fx + 90, fy + 325, "Inversarea Metrică Analitică:",
               font_size=15, font_family=1, stroke_color="#495057", frame_id=fid)
    b.add_text("s5_c1_eq2", fx + 90, fy + 355, "d_i = 10^((P_tx - RSSI_i) / (10·n))",
               font_size=18, font_family=3, stroke_color="#1971c2", frame_id=fid)

    b.add_text("s5_c1_exp", fx + 90, fy + 405,
               "• P_tx = -59 dBm: Puterea de referință la d₀ = 1.0 m\n"
               "• n in [2.2, 3.0]: Exponentul de atenuare a mediului\n"
               "• X_σ ~ N(0, σ²): Zgomotul Gaussian de fading",
               font_size=15, font_family=1, stroke_color="#212529", frame_id=fid)

    b.add_rect("s5_c1_box", fx + 90, fy + 525, 540, 240, stroke_color="#1971c2", bg_color="#e7f5ff",
               fill_style="solid", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_text("s5_c1_boxt", fx + 110, fy + 540, "Filtru Rolling Max (LOS Recovery):",
               font_size=16, font_family=1, stroke_color="#1864ab", frame_id=fid)
    b.add_text("s5_c1_boxeq", fx + 110, fy + 575, "RSSI_LOS(t) = max { RSSI(τ) : τ ∈ [t - W, t] }",
               font_size=16, font_family=3, stroke_color="#1864ab", frame_id=fid)
    b.add_text("s5_c1_boxb", fx + 110, fy + 625,
               "• Fereastră mobilă W = 1500 ms pe fiecare canal\n"
               "• Extrage anvelopa superioară neafectată de fading\n"
               "• Elimină peste 90% din dropurile distructive!",
               font_size=15, font_family=1, stroke_color="#212529", frame_id=fid)

    # Column 2: WLS Gauss-Markov
    b.add_rect("s5_c2_body", fx + 670, fy + 180, 580, 780, stroke_color="#7048e8", bg_color="#f8f9fa",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_rect("s5_c2_hdr", fx + 670, fy + 180, 580, 48, stroke_color="#7048e8", bg_color="#eebefa",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_text("s5_c2_hdrt", fx + 690, fy + 194, "2. OPTIMIZARE GAUSS-MARKOV (WLS)",
               font_size=16, font_family=1, stroke_color="#7048e8", frame_id=fid)

    b.add_text("s5_c2_lbl1", fx + 690, fy + 245, "Liniarizare prin diferențiere față de Ancora N:",
               font_size=15, font_family=1, stroke_color="#495057", frame_id=fid)
    b.add_text("s5_c2_eq1", fx + 690, fy + 275, "A_i = 2 · [x_i - x_N,   y_i - y_N]",
               font_size=17, font_family=3, stroke_color="#7048e8", frame_id=fid)
    b.add_text("s5_c2_eq2", fx + 690, fy + 315, "b_i = d_N² - d_i² + (x_i²+y_i²) - (x_N²+y_N²)",
               font_size=17, font_family=3, stroke_color="#7048e8", frame_id=fid)

    b.add_text("s5_c2_lbl2", fx + 690, fy + 365, "Ponderare Optimă cu Varianța:",
               font_size=15, font_family=1, stroke_color="#495057", frame_id=fid)
    b.add_text("s5_c2_eq3", fx + 690, fy + 395, "W = diag(1/σ₁²,  1/σ₂²,  ...,  1/σ_{N-1}²)",
               font_size=16, font_family=3, stroke_color="#7048e8", frame_id=fid)
    b.add_text("s5_c2_eq4", fx + 690, fy + 435, "σ_{d_i} = (ln 10 / (10·n)) · d_i · σ_RSSI",
               font_size=16, font_family=3, stroke_color="#7048e8", frame_id=fid)

    b.add_rect("s5_c2_box", fx + 690, fy + 525, 540, 240, stroke_color="#7048e8", bg_color="#f3f0ff",
               fill_style="solid", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_text("s5_c2_boxt", fx + 710, fy + 540, "Soluția Analitică Closed-Form BLUE:",
               font_size=16, font_family=1, stroke_color="#5f3dc4", frame_id=fid)
    b.add_text("s5_c2_boxeq1", fx + 710, fy + 575, "x̂_WLS = (Aᵀ W A)⁻¹ Aᵀ W b",
               font_size=18, font_family=3, stroke_color="#5f3dc4", frame_id=fid)
    b.add_text("s5_c2_boxeq2", fx + 710, fy + 615, "Cov(x̂) = (Aᵀ W A)⁻¹",
               font_size=17, font_family=3, stroke_color="#5f3dc4", frame_id=fid)
    b.add_text("s5_c2_boxb", fx + 710, fy + 665,
               "• Teorema Gauss-Markov: Estimator optim nedeplasat\n"
               "• Timp de calcul: sub 0.15 ms per epocă\n"
               "• Zero iterații, fără pericol de divergență numerică!",
               font_size=15, font_family=1, stroke_color="#212529", frame_id=fid)

    # Column 3: EKF Cinematic Filter
    b.add_rect("s5_c3_body", fx + 1270, fy + 180, 580, 780, stroke_color="#099268", bg_color="#f8f9fa",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_rect("s5_c3_hdr", fx + 1270, fy + 180, 580, 48, stroke_color="#099268", bg_color="#c3fae8",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_text("s5_c3_hdrt", fx + 1290, fy + 194, "3. FUZIUNE CINEMATICĂ EKF",
               font_size=16, font_family=1, stroke_color="#099268", frame_id=fid)

    b.add_text("s5_c3_lbl1", fx + 1290, fy + 245, "Vectorul de Stare 4D & Tranziția Cinematică:",
               font_size=15, font_family=1, stroke_color="#495057", frame_id=fid)
    b.add_text("s5_c3_eq1", fx + 1290, fy + 275, "x_k = [x,   y,   v_x,   v_y]ᵀ",
               font_size=17, font_family=3, stroke_color="#099268", frame_id=fid)
    b.add_text("s5_c3_eq2", fx + 1290, fy + 315, "F = [[1, 0, Δt, 0], [0, 1, 0, Δt], [0, 0, 1, 0], [0, 0, 0, 1]]",
               font_size=14, font_family=3, stroke_color="#099268", frame_id=fid)

    b.add_text("s5_c3_lbl2", fx + 1290, fy + 365, "Inovație & Corecție Adaptivă:",
               font_size=15, font_family=1, stroke_color="#495057", frame_id=fid)
    b.add_text("s5_c3_eq3", fx + 1290, fy + 395, "K_k = P_k|k-1 · Hᵀ · (H P_k|k-1 Hᵀ + R_k)⁻¹",
               font_size=15, font_family=3, stroke_color="#099268", frame_id=fid)
    b.add_text("s5_c3_eq4", fx + 1290, fy + 435, "x_k|k = x_k|k-1 + K_k · (z_k - H x_k|k-1)",
               font_size=15, font_family=3, stroke_color="#099268", frame_id=fid)

    b.add_rect("s5_c3_box", fx + 1290, fy + 525, 540, 240, stroke_color="#099268", bg_color="#e6fcf5",
               fill_style="solid", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_text("s5_c3_boxt", fx + 1310, fy + 540, "Adaptivitate la Umbrirea Corporală:",
               font_size=16, font_family=1, stroke_color="#087f5b", frame_id=fid)
    b.add_text("s5_c3_boxb", fx + 1310, fy + 580,
               "• Când o persoană obstrucționează semnalul și varianța\n"
               "  WLS crește, filtrul mărește dinamic R_k.\n"
               "• Observația radio este penalizată, iar starea este\n"
               "  propagată pe baza vitezei constante [v_x, v_y]!\n"
               "• Rezultat: Traiectorie lină, continuă, fără salturi false.",
               font_size=15, font_family=1, stroke_color="#212529", frame_id=fid)

    # Sticky Note Slide 5
    b.add_sticky_note(
        "s5_snote", fx + 1420, fy + 885, 430, 130,
        "📐 BLUE (Gauss-Markov Theorem):\nWLS furnizează soluția analitică optimă închisă, atingând limita\nteoretică Cramér-Rao pentru triangularea radio zgomotoasă!",
        bg_color="#fff9db", stroke_color="#f59f00", angle=-0.02, frame_id=fid
    )

    # Push Frame 5
    b.add_frame(fid, "05 - Rigurozitatea Matematica (LDPL, WLS & EKF)", fx, fy, 1920, 1080)

    # =========================================================================
    # SLIDE 6: Rezultate Experimentale & Concluzii Comisie (Convergence Node: x: 7300, y: 200)
    # =========================================================================
    fx, fy, fid = 7300, 200, "frame_06"

    b.add_rect("s6_top_bar", fx, fy, 1920, 10, stroke_color="#2b8a3e", bg_color="#2b8a3e",
               fill_style="solid", roughness=0, stroke_width=1, frame_id=fid)
    b.add_rect("s6_badge", fx + 70, fy + 35, 620, 36, stroke_color="#2b8a3e", bg_color="#ebfbee",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_text("s6_badge_txt", fx + 90, fy + 43, "06 / VALIDARE EXPERIMENTALĂ & CONCLUZII FINALE",
               font_size=15, font_family=1, stroke_color="#2b8a3e", frame_id=fid)

    b.add_text("s6_title", fx + 70, fy + 82, "Rezultate Experimentale, Metrici de Performanță & Concluzii de Licență",
               font_size=32, font_family=1, stroke_color="#111827", frame_id=fid)
    b.add_text("s6_subtitle", fx + 70, fy + 128,
               "Validare pe capturi reale de laborator, performanță comparativă și susținerea în fața comisiei",
               font_size=18, font_family=1, stroke_color="#495057", frame_id=fid)

    b.add_image("s6_img_trophy", fx + 1740, fy + 35, 100, 100, "file_trophy_seal", frame_id=fid)

    # 4 Metric KPI Cards across top row (x: 70, 520, 970, 1420; w: 430, h: 150)
    kpis = [
        ("s6_kpi_1", fx + 70, fy + 180, 430, 150, "#2b8a3e", "#ebfbee",
         "TESTE AUTOMATE", "120 / 120", "100% PASS (PyTest + Vitest)"),
        ("s6_kpi_2", fx + 520, fy + 180, 430, 150, "#1971c2", "#e7f5ff",
         "CONFIDENȚĂ ANCORE", "4 / 4 ACTIVE", "SNR Mediu: 21.4 dB (CC2400)"),
        ("s6_kpi_3", fx + 970, fy + 180, 430, 150, "#7048e8", "#f3f0ff",
         "SINCRONIZARE TEMPORALĂ", "< 14.8 ms", "Jitter cross-window sub 1500ms"),
        ("s6_kpi_4", fx + 1420, fy + 180, 430, 150, "#e8590c", "#fff4e6",
         "ACURATEȚE MEDIE", "0.82 m LOS", "1.45 m NLOS (+72.2% vs Centroid)")
    ]

    for k_id, kx, ky, kw, kh, strk, bg_c, title_t, val_t, sub_t in kpis:
        b.add_rect(k_id, kx, ky, kw, kh, stroke_color=strk, bg_color=bg_c,
                   fill_style="cross-hatch", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
        b.add_text(f"{k_id}_t", kx + 20, ky + 16, title_t, font_size=15, font_family=1, stroke_color=strk, frame_id=fid)
        b.add_text(f"{k_id}_v", kx + 20, ky + 48, val_t, font_size=36, font_family=1, stroke_color="#111827", frame_id=fid)
        b.add_text(f"{k_id}_s", kx + 20, ky + 105, sub_t, font_size=15, font_family=1, stroke_color="#495057", frame_id=fid)

    # Comparative Results Table Container (x: 70, y: 360, w: 1060, h: 480)
    b.add_rect("s6_tab_bg", fx + 70, fy + 360, 1060, 480, stroke_color="#343a40", bg_color="#f8f9fa",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_rect("s6_tab_hdr", fx + 70, fy + 360, 1060, 48, stroke_color="#343a40", bg_color="#e9ecef",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_text("s6_tab_hdrt", fx + 90, fy + 374, "BENCHMARK EXPERIMENTAL PE DATE REALE DE LABORATOR (10m x 8m)",
               font_size=16, font_family=1, stroke_color="#212529", frame_id=fid)

    table_rows = [
        ("s6_tr_0", fy + 425, 40, "#ced4da", "#f1f3f5",
         "Metodă de Poziționare", "Eroare Medie", "Eroare Perimetru", "Timp Calcul", "Verdict Comisie"),
        ("s6_tr_1", fy + 480, 70, "#e03131", "#fff5f5",
         "Centroid Ponderat (Naiv)", "2.95 m", "2.52 m (Trap)", "0.05 ms", "❌ Eșuează sever lângă pereți"),
        ("s6_tr_2", fy + 565, 70, "#e8590c", "#fff4e6",
         "Trilaterație Naivă Neliniară", "1.65 m", "1.40 m", "4.20 ms", "⚠️ Instabil la reflexii RF"),
        ("s6_tr_3", fy + 650, 70, "#2b8a3e", "#ebfbee",
         "Sistemul Nostru (WLS + Rolling Max)", "0.82 m", "0.08 m", "0.12 ms", "✅ Rezistent la pereți, O(1)"),
        ("s6_tr_4", fy + 735, 85, "#099268", "#c3fae8",
         "Sistemul Nostru + EKF Cinematic", "0.68 m", "0.09 m", "0.15 ms", "🏆 Soluție Optimă End-to-End")
    ]

    for r_id, ry, rh, strk, bg_c, c1, c2, c3, c4, c5 in table_rows:
        b.add_rect(r_id, fx + 90, ry, 1020, rh, stroke_color=strk, bg_color=bg_c,
                   fill_style="solid", roughness=1, stroke_width=1, roundness={"type": 3}, frame_id=fid)
        b.add_text(f"{r_id}_c1", fx + 105, ry + 12, c1, font_size=15, font_family=1, stroke_color="#111827", frame_id=fid)
        b.add_text(f"{r_id}_c2", fx + 420, ry + 12, c2, font_size=15, font_family=3 if "m" in c2 else 1, stroke_color="#111827", frame_id=fid)
        b.add_text(f"{r_id}_c3", fx + 560, ry + 12, c3, font_size=15, font_family=3 if "m" in c3 else 1, stroke_color="#111827", frame_id=fid)
        b.add_text(f"{r_id}_c4", fx + 720, ry + 12, c4, font_size=15, font_family=3 if "ms" in c4 else 1, stroke_color="#111827", frame_id=fid)
        b.add_text(f"{r_id}_c5", fx + 840, ry + 12, c5, font_size=14, font_family=1, stroke_color=strk, frame_id=fid)

    # Right Section: The 3 Final Defense Pillars (x: 1160, y: 360, w: 690, h: 480)
    b.add_rect("s6_def_bg", fx + 1160, fy + 360, 690, 480, stroke_color="#099268", bg_color="#e6fcf5",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_rect("s6_def_hdr", fx + 1160, fy + 360, 690, 48, stroke_color="#099268", bg_color="#c3fae8",
               fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3}, frame_id=fid)
    b.add_text("s6_def_hdrt", fx + 1180, fy + 374, "CELE 3 CONCLUZII CHEIE PENTRU COMISIE",
               font_size=16, font_family=1, stroke_color="#099268", frame_id=fid)

    def_items = [
        ("s6_di_1", fy + 425, 125, "#1971c2", "#d0ebff", "1. CONFORMITATE ETICĂ & 100% PASIV",
         "Zero aplicații sau malware pe telefoane, fără pairing sau handshake.\n"
         "Monitorizare exclusivă a headerelor publice BR/EDR și protecție hardware\n"
         "cu TX dezactivat fizic la nivel de registru firmware."),
        ("s6_di_2", fy + 560, 125, "#7048e8", "#eebefa", "2. VALOARE ȘTIINȚIFICĂ EXPLICABILĂ",
         "Am demonstrat teoretic de ce centroidul naiv eșuează lângă pereți (capcana convexă)\n"
         "și am formulat o rezolvare analitică BLUE prin WLS cu adaptivitate EKF\n"
         "validată riguros pe date reale de laborator."),
        ("s6_di_3", fy + 695, 130, "#2b8a3e", "#d3f9d8", "3. SISTEM COMPLET & FUNCȚIONAL",
         "Livrabil software industrial cu interfețe duble (desktop Tauri Rust 60 FPS +\n"
         "web dashboard Streamlit), pipeline asincron testat cu 120 de teste automate\n"
         "și zero regresii de performanță.")
    ]

    for d_id, dy, dh, strk, hdr_c, dt, db in def_items:
        b.add_rect(d_id, fx + 1180, dy, 650, dh, stroke_color=strk, bg_color="#ffffff",
                   fill_style="solid", roughness=1, stroke_width=1, roundness={"type": 3}, frame_id=fid)
        b.add_text(f"{d_id}_t", fx + 1195, dy + 12, dt, font_size=15, font_family=1, stroke_color=strk, frame_id=fid)
        b.add_text(f"{d_id}_b", fx + 1195, dy + 42, db, font_size=14, font_family=1, stroke_color="#212529", frame_id=fid)

    # Sticky Note Slide 6
    b.add_sticky_note(
        "s6_snote", fx + 1420, fy + 885, 430, 130,
        "🎓 Concluzie de Licență:\nSistemul demonstrează că se poate obține precizie sub-metrică indoor\npe Bluetooth Classic fără UWB scump și fără rețele neuronale opace!",
        bg_color="#ebfbee", stroke_color="#2b8a3e", angle=0.018, frame_id=fid
    )

    # Defense Sign-off Footer Slide 6
    b.add_text("s6_sign_txt", fx + 70, fy + 1025,
               "Sesiune Susținere Proiect de Licență | Universitatea Politehnica București | Candidat: Vlad Sărățeanu | Iulie 2026",
               font_size=18, font_family=1, stroke_color="#111827", frame_id=fid)

    # Push Frame 6
    b.add_frame(fid, "06 - Rezultate Experimentale & Concluzii Comisie", fx, fy, 1920, 1080)

    # =========================================================================
    # 6 INTER-FRAME JOURNEY ARROWS (Non-Linear Directed Graph Traversal)
    # Connected across canvas with frameId=None
    # =========================================================================
    journey_edges = [
        # Edge 1 -> 2: Node 1 (0, 0) -> Node 2 (2300, -500) : "Explore Radio Waves ➔"
        {
            "id": "j_edge_1_2",
            "start": (1930, 260),
            "points": [[0, 0], [175, -200], [350, -340]],
            "label": "Explore Radio Waves ➔",
            "card_pos": (1970, 50),
            "color": "#1971c2",
            "bg": "#e7f5ff",
            "angle": -0.15
        },
        # Edge 1 -> 3: Node 1 (0, 0) -> Node 3 (2300, 900) : "Engineer the Stack ➔"
        {
            "id": "j_edge_1_3",
            "start": (1930, 820),
            "points": [[0, 0], [175, 200], [350, 340]],
            "label": "Engineer the Stack ➔",
            "card_pos": (1970, 1020),
            "color": "#099268",
            "bg": "#e6fcf5",
            "angle": 0.15
        },
        # Edge 2 -> 4: Node 2 (2300, -500) -> Node 4 (4800, -500) : "Translate Waves to Space ➔"
        {
            "id": "j_edge_2_4",
            "start": (4230, 40),
            "points": [[0, 0], [275, 0], [550, 0]],
            "label": "Translate Waves to Space ➔",
            "card_pos": (4360, 0),
            "color": "#e8590c",
            "bg": "#fff4e6",
            "angle": 0.0
        },
        # Edge 3 -> 5: Node 3 (2300, 900) -> Node 5 (4800, 900) : "Feed Packets to Math ➔"
        {
            "id": "j_edge_3_5",
            "start": (4230, 1440),
            "points": [[0, 0], [275, 0], [550, 0]],
            "label": "Feed Packets to Math ➔",
            "card_pos": (4370, 1400),
            "color": "#7048e8",
            "bg": "#f3f0ff",
            "angle": 0.0
        },
        # Edge 4 -> 6: Node 4 (4800, -500) -> Node 6 (7300, 200) : "Converge on Lab Data ➔"
        {
            "id": "j_edge_4_6",
            "start": (6730, 200),
            "points": [[0, 0], [275, 140], [550, 280]],
            "label": "Converge on Lab Data ➔",
            "card_pos": (6850, 300),
            "color": "#2f9e44",
            "bg": "#ebfbee",
            "angle": 0.12
        },
        # Edge 5 -> 6: Node 5 (4800, 900) -> Node 6 (7300, 200) : "Validate Against Real World ➔"
        {
            "id": "j_edge_5_6",
            "start": (6730, 1260),
            "points": [[0, 0], [275, -140], [550, -280]],
            "label": "Validate Against Real World ➔",
            "card_pos": (6850, 1100),
            "color": "#f08c00",
            "bg": "#fff9db",
            "angle": -0.12
        }
    ]

    for edge in journey_edges:
        eid = edge["id"]
        sx, sy = edge["start"]
        pts = edge["points"]
        clr = edge["color"]
        bg_c = edge["bg"]
        lbl = edge["label"]
        cx, cy = edge["card_pos"]
        ang = edge["angle"]

        # Prominent Hand-Drawn Journey Arrow
        b.add_line(f"{eid}_arr", sx, sy, pts, stroke_color=clr, stroke_width=4,
                   stroke_style="solid", roughness=2, end_arrow="arrow", frame_id=None)

        # Route Label Card
        card_w, card_h = 280, 50
        b.add_rect(f"{eid}_card", cx, cy, card_w, card_h, stroke_color=clr, bg_color=bg_c,
                   fill_style="hachure", roughness=1, stroke_width=2, roundness={"type": 3},
                   frame_id=None, angle=ang)
        b.add_text(f"{eid}_txt", cx + 18, cy + 14, lbl, font_size=18, font_family=1,
                   stroke_color=clr, frame_id=None, angle=ang)

    return b


def generate_dual_format(builder):
    excalidraw_data = {
        "type": "excalidraw",
        "version": 2,
        "source": "https://excalidraw.com",
        "elements": builder.elements,
        "appState": {
            "gridSize": 20,
            "viewBackgroundColor": "#ffffff"
        },
        "files": builder.files
    }

    # Format Text Elements Section for Obsidian markdown sync
    text_section_lines = []
    for text_str, el_id in builder.text_block_refs:
        # In Obsidian Excalidraw, text block references are written with ^id at the end
        lines = text_str.split("\n")
        for i, line in enumerate(lines):
            if i == len(lines) - 1:
                text_section_lines.append(f"{line} ^{el_id}")
            else:
                text_section_lines.append(line)
        text_section_lines.append("")

    text_section = "\n".join(text_section_lines)
    json_str = json.dumps(excalidraw_data, indent=2, ensure_ascii=False)

    md_content = f"""---

excalidraw-plugin: parsed
tags: [excalidraw, prezentare, licenta, bluetooth-triangulation]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==

# Excalidraw Data

## Text Elements

{text_section}
## Drawing
```json
{json_str}
```
%%
"""

    return excalidraw_data, md_content


def main():
    print("Building presentation deck...")
    builder = build_deck()
    ex_data, md_content = generate_dual_format(builder)

    # Output paths
    vault_deck_md = Path("/home/vlads4r4/dev/Licenta/LicentaVault/Prezentare_Licenta_Deck.excalidraw.md")
    webapp_deck_json = Path("/home/vlads4r4/dev/Licenta/LicentaVault/Prezentare WebApp Licenta/Prezentare_Licenta_Deck.excalidraw")

    print(f"Writing Markdown to: {vault_deck_md}")
    vault_deck_md.write_text(md_content, encoding="utf-8")

    print(f"Writing Pure JSON to: {webapp_deck_json}")
    webapp_deck_json.write_text(json.dumps(ex_data, indent=2, ensure_ascii=False), encoding="utf-8")

    # Verify counts
    frames = [e for e in builder.elements if e.get("type") == "frame"]
    images = [e for e in builder.elements if e.get("type") == "image"]
    arrows = [e for e in builder.elements if e.get("type") == "arrow"]
    texts = [e for e in builder.elements if e.get("type") == "text"]

    print(f"Build Complete!")
    print(f"Total elements: {len(builder.elements)}")
    print(f"Frames: {len(frames)}")
    print(f"Images: {len(images)}")
    print(f"Arrows/Lines: {len(arrows)}")
    print(f"Texts: {len(texts)}")
    print(f"Embedded Files: {len(builder.files)}")


if __name__ == "__main__":
    main()
