import React from "react";
import { Composition } from "remotion";
import { MainScene } from "./compositions/MainScene";
import { TOTAL_FRAMES } from "./physics/timeline";

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="MainScene"
        component={MainScene}
        durationInFrames={TOTAL_FRAMES} // 3000 frames (100 seconds @ 30 fps)
        fps={30}
        width={1920}
        height={1080}
      />
    </>
  );
};
