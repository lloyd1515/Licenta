import React, { useMemo } from "react";
import { useCurrentFrame } from "remotion";
import { getTimelineState } from "../physics/timeline";
import { ThreeDScene } from "../components/ThreeDScene";
import { TwoDOverlay } from "../components/TwoDOverlay";

export const MainScene: React.FC = () => {
  const frame = useCurrentFrame();

  // Pure deterministic state lookup for the current frame
  const timeline = useMemo(() => getTimelineState(frame), [frame]);

  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        position: "relative",
        backgroundColor: "#070b14",
        overflow: "hidden",
      }}
    >
      {/* 3D Scene Layer */}
      <ThreeDScene timeline={timeline} />

      {/* 2D HUD, Typography & Card Overlay Layer */}
      <TwoDOverlay timeline={timeline} />
    </div>
  );
};
