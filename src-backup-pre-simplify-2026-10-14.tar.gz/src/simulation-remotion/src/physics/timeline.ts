import * as THREE from "three";

export type ActId = 1 | 2 | 3 | 4 | 5;

export interface LinkMetrics {
  name: string;
  attenuationDb: number;
  fresnelZone: number;
}

export interface TimelineState {
  frame: number;
  act: ActId;
  actProgress: number; // 0 to 1 within current act
  camera: {
    pos: [number, number, number];
    target: [number, number, number];
  };
  cctv: {
    opacity: number;
    coneOpacity: number;
    showBanSign: boolean;
  };
  hardware: {
    esp32Opacity: number;
    ubertoothOpacity: number;
    harpStringsOpacity: number;
    fresnelShellOpacity: number;
  };
  human: {
    visible: boolean;
    pos: [number, number, number];
    rotX: number;
    isFallen: boolean;
    waterGlowColor: string;
  };
  telemetry: {
    posX: number;
    posZ: number;
    velocity: number;
    dopplerHz: number;
    stateLabel: string;
    links: LinkMetrics[];
    fallAlarm: boolean;
  };
  overlay: {
    title: string;
    subtitle: string;
    badgeText?: string;
    badgeColor?: string;
    showSummaryCards: boolean;
  };
}

export const TOTAL_FRAMES = 3000; // 100 sec @ 30 FPS

// Smooth helper
function clamp01(v: number): number {
  return Math.max(0, Math.min(1, v));
}

function smoothstep(min: number, max: number, value: number): number {
  const x = clamp01((value - min) / (max - min));
  return x * x * (3 - 2 * x);
}

export function getTimelineState(frame: number): TimelineState {
  // Act 1: 0 - 450 (Dilema Intimitatii)
  if (frame < 450) {
    const p = frame / 450;
    // Camera moves from close-up on CCTV to wider view as room fades to grid
    const camX = THREE.MathUtils.lerp(0.3, 3.6, smoothstep(0.25, 0.85, p));
    const camY = THREE.MathUtils.lerp(2.1, 3.8, smoothstep(0.25, 0.85, p));
    const camZ = THREE.MathUtils.lerp(1.7, 3.9, smoothstep(0.25, 0.85, p));

    const tgtX = THREE.MathUtils.lerp(0.0, 0.0, smoothstep(0.25, 0.85, p));
    const tgtY = THREE.MathUtils.lerp(2.1, 0.7, smoothstep(0.25, 0.85, p));
    const tgtZ = THREE.MathUtils.lerp(-1.0, 0.0, smoothstep(0.25, 0.85, p));

    const cctvOpacity = frame < 200 ? 1 : 1 - smoothstep(200, 270, frame);
    const coneOpacity = frame < 180 ? 0.35 : (1 - smoothstep(180, 240, frame)) * 0.35;
    const showBanSign = frame >= 140 && frame < 280;

    let title = "CĂDEREA: PERICOLUL TĂCUT AL VÂRSTNICILOR";
    let subtitle = "70% din accidente au loc acolo unde sunt singuri: în dormitor sau baie.";
    let badgeText = undefined;
    let badgeColor = undefined;

    if (frame >= 140 && frame < 280) {
      title = "CAMERELE VIDEO? O ÎNCĂLCARE A INTIMITĂȚII.";
      subtitle = "Nimeni nu acceptă camere în baie sau dormitor. Pacienții le refuză.";
      badgeText = "CAMERA = REFUZATĂ";
      badgeColor = "#ff2a55";
    } else if (frame >= 280) {
      title = "SENZORI PURTABILI? UITAȚI PE NOPTIERĂ.";
      subtitle = "Brățările de urgență nu sunt purtate noaptea. Există o cale 100% invizibilă.";
      badgeText = "SOLUȚIE INVIZIBILĂ";
      badgeColor = "#00f0ff";
    }

    return {
      frame,
      act: 1,
      actProgress: p,
      camera: { pos: [camX, camY, camZ], target: [tgtX, tgtY, tgtZ] },
      cctv: { opacity: cctvOpacity, coneOpacity, showBanSign },
      hardware: { esp32Opacity: 0, ubertoothOpacity: 0, harpStringsOpacity: 0, fresnelShellOpacity: 0 },
      human: { visible: false, pos: [0, 0, 0], rotX: 0, isFallen: false, waterGlowColor: "#00f0ff" },
      telemetry: {
        posX: 0,
        posZ: 0,
        velocity: 0,
        dopplerHz: 0,
        stateLabel: "CAMERA GOALĂ",
        links: [
          { name: "Link 1-2", attenuationDb: 0, fresnelZone: 0 },
          { name: "Link 2-3", attenuationDb: 0, fresnelZone: 0 },
          { name: "Link 3-1", attenuationDb: 0, fresnelZone: 0 },
        ],
        fallAlarm: false,
      },
      overlay: { title, subtitle, badgeText, badgeColor, showSummaryCards: false },
    };
  }

  // Act 2: 450 - 1050 (Harpa Radio cu 52 de Corzi)
  if (frame < 1050) {
    const p = (frame - 450) / 600;
    // Gentle continuous motion around the 3 ESP32 nodes
    const camX = 3.6 + Math.sin(p * Math.PI) * 0.25;
    const camY = 3.8 - Math.sin(p * Math.PI) * 0.15;
    const camZ = 3.9 - Math.sin(p * Math.PI * 0.5) * 0.2;

    const esp32Opacity = smoothstep(450, 520, frame);
    const ubertoothOpacity = smoothstep(500, 580, frame);
    const harpStringsOpacity = smoothstep(580, 720, frame);

    let title = "HARDWARE DE SUB 50€: TREI NODURI WI-FI";
    let subtitle = "Plăcuțe comerciale ESP32 conectate într-o rețea triunghiulară sincronă.";
    let badgeText = "3x ESP32 • < 50€";
    let badgeColor = "#00ff88";

    if (frame >= 650 && frame < 850) {
      title = "WI-FI NU E O SINGURĂ UNDĂ: E O HARPĂ RADIO";
      subtitle = "52 de subpurtătoare OFDM se întind în spațiu ca 52 de filamente invizibile.";
      badgeText = "52 SUBPURTĂTOARE OFDM";
      badgeColor = "#00f0ff";
    } else if (frame >= 850) {
      title = "CÂND CAMERA E GOALĂ, CORZILE STAU NEMIȘCATE";
      subtitle = "Nivelul de referință este stabil la 0 dB. Ce se întâmplă când intră un om?";
      badgeText = "STARE: REFERINȚĂ CALMĂ";
      badgeColor = "#ffb700";
    }

    return {
      frame,
      act: 2,
      actProgress: p,
      camera: { pos: [camX, camY, camZ], target: [0, 0.7, 0] },
      cctv: { opacity: 0, coneOpacity: 0, showBanSign: false },
      hardware: { esp32Opacity, ubertoothOpacity, harpStringsOpacity, fresnelShellOpacity: 0 },
      human: { visible: false, pos: [0, 0, 0], rotX: 0, isFallen: false, waterGlowColor: "#00f0ff" },
      telemetry: {
        posX: 0,
        posZ: 0,
        velocity: 0,
        dopplerHz: 0,
        stateLabel: "CAMERA GOALĂ (0 dB)",
        links: [
          { name: "Link 1-2", attenuationDb: 0.1, fresnelZone: 0 },
          { name: "Link 2-3", attenuationDb: 0.0, fresnelZone: 0 },
          { name: "Link 3-1", attenuationDb: -0.1, fresnelZone: 0 },
        ],
        fallAlarm: false,
      },
      overlay: { title, subtitle, badgeText, badgeColor, showSummaryCards: false },
    };
  }

  // Act 3: 1050 - 1800 (Zone Fresnel & Mersul 2D)
  if (frame < 1800) {
    const p = (frame - 1050) / 750;
    // Human enters and walks across room
    const humanT = smoothstep(1100, 1750, frame);
    const hX = 2.0 - 2.2 * Math.sin(humanT * Math.PI * 0.5);
    const hZ = 2.0 - 2.4 * humanT;
    const hY = 0.9 + Math.sin(frame * 0.3) * 0.04;

    // Camera tracks slightly
    const camX = 3.6 - humanT * 0.4;
    const camY = 3.8;
    const camZ = 3.9 - humanT * 0.3;

    const fresnelShellOpacity = smoothstep(1150, 1300, frame) * 0.4;

    // Synthetic CSI attenuation as human intersects Link 3-1 then Link 1-2
    const dLink12 = Math.hypot(hX - -2.0, hZ - 0.0);
    const dLink31 = Math.hypot(hX - 0.0, hZ - 0.0);
    const atten12 = Number((-14.5 * Math.exp(-(dLink12 * dLink12) / 0.8)).toFixed(1));
    const atten31 = Number((-17.2 * Math.exp(-(dLink31 * dLink31) / 0.6)).toFixed(1));

    let title = "CORPUL UMAN: 70% APĂ, OBSTACOL RADIO MASIV";
    let subtitle = "Unda directă se reflectă și se refractă la fiecare pas.";
    let badgeText = "PERSOANĂ ÎN MIȘCARE";
    let badgeColor = "#00f0ff";

    if (frame >= 1300 && frame < 1550) {
      title = "ZONA FRESNEL: TUNELUL INVIZIBIL DE SENSIBILITATE";
      subtitle = "Pășirea în elipsă produce oscilații sinusoidale deterministe pe 52 de frecvențe.";
      badgeText = "DIFRACȚIE FRESNEL (15-20 dB)";
      badgeColor = "#ffaa00";
    } else if (frame >= 1550) {
      title = "LOCALIZARE 2D PUR GEOMETRICĂ: COORDONATE (X, Z)";
      subtitle = "Intersecția celor 3 elipse dă poziția exactă a pasului, fără camere.";
      badgeText = "TRAIECTORIE ACTIVĂ";
      badgeColor = "#00ff88";
    }

    return {
      frame,
      act: 3,
      actProgress: p,
      camera: { pos: [camX, camY, camZ], target: [hX * 0.5, 0.7, hZ * 0.5] },
      cctv: { opacity: 0, coneOpacity: 0, showBanSign: false },
      hardware: { esp32Opacity: 1, ubertoothOpacity: 1, harpStringsOpacity: 1, fresnelShellOpacity },
      human: { visible: true, pos: [hX, hY, hZ], rotX: 0, isFallen: false, waterGlowColor: "#00f0ff" },
      telemetry: {
        posX: Number(hX.toFixed(2)),
        posZ: Number(hZ.toFixed(2)),
        velocity: 0.95,
        dopplerHz: 15.4,
        stateLabel: "MERS NORMAL",
        links: [
          { name: "Link 1-2", attenuationDb: atten12, fresnelZone: 0.8 },
          { name: "Link 2-3", attenuationDb: 1.2, fresnelZone: 2.1 },
          { name: "Link 3-1", attenuationDb: atten31, fresnelZone: 0.4 },
        ],
        fallAlarm: false,
      },
      overlay: { title, subtitle, badgeText, badgeColor, showSummaryCards: false },
    };
  }

  // Act 4: 1800 - 2550 (Caderea Violenta & Alarma)
  if (frame < 2550) {
    const p = (frame - 1800) / 750;
    const fallStart = 1920;
    const fallEnd = 1935; // 15 frames = 500ms rapid fall
    const isPastImpact = frame >= fallEnd;

    let hY = 0.9;
    let rotX = 0;
    let velocity = 0.8;
    let dopplerHz = 14.0;
    let isFallen = false;

    if (frame >= fallStart && frame < fallEnd) {
      const fallT = (frame - fallStart) / (fallEnd - fallStart);
      hY = 0.9 - 0.72 * (fallT * fallT);
      rotX = (Math.PI / 2) * fallT;
      velocity = 2.8; // Vertical downward velocity
      dopplerHz = 48.5; // High Doppler peak
      isFallen = true;
    } else if (frame >= fallEnd) {
      hY = 0.18;
      rotX = Math.PI / 2;
      velocity = 0.0;
      dopplerHz = 0.4;
      isFallen = true;
    }

    const fallAlarm = frame >= fallEnd + 15; // Alarm active 0.5s after impact
    const camY = isPastImpact ? 3.0 : 3.8;
    const camZ = isPastImpact ? 3.2 : 3.9;

    let title = "O CĂDERE DUREAZĂ SUB 400 MS: VÂRF DOPPLER > 45 HZ";
    let subtitle = "Gravitația prăbușește corpul spre podea. Semnătură fizică inconfundabilă.";
    let badgeText = "IMPACT ACCELERAT";
    let badgeColor = "#ff5500";

    if (frame >= 1950 && frame < 2250) {
      title = "COLAPS SIMULTAN PE TOATE CELE 3 LEGĂTURI";
      subtitle = "Mersul atinge o legătură pe rând. Căderea la sol taie baza întregului spațiu radio.";
      badgeText = "COLAPS SIMULTAN CSI (-18 dB)";
      badgeColor = "#ff0033";
    } else if (frame >= 2250) {
      title = "ALERTĂ DE SALVARE TRANSMISĂ ÎN TIMP REAL";
      subtitle = "Impact violent confirmat + 3 secunde de imobilitate la sol = 0 alarme false.";
      badgeText = "NOTIFICARE URGENȚĂ";
      badgeColor = "#ff0033";
    }

    return {
      frame,
      act: 4,
      actProgress: p,
      camera: { pos: [3.2, camY, camZ], target: [0, 0.3, 0] },
      cctv: { opacity: 0, coneOpacity: 0, showBanSign: false },
      hardware: { esp32Opacity: 1, ubertoothOpacity: 1, harpStringsOpacity: 1, fresnelShellOpacity: 0.5 },
      human: { visible: true, pos: [0.1, hY, 0.0], rotX, isFallen, waterGlowColor: fallAlarm ? "#ff0033" : "#ff5500" },
      telemetry: {
        posX: 0.1,
        posZ: 0.0,
        velocity,
        dopplerHz,
        stateLabel: fallAlarm ? "🚨 CĂDERE LA SOL" : isFallen ? "IMPACT CĂDERE" : "CLĂTINARE",
        links: [
          { name: "Link 1-2", attenuationDb: isFallen ? -18.2 : -4.5, fresnelZone: 0.2 },
          { name: "Link 2-3", attenuationDb: isFallen ? -17.8 : -2.1, fresnelZone: 0.3 },
          { name: "Link 3-1", attenuationDb: isFallen ? -19.4 : -3.8, fresnelZone: 0.1 },
        ],
        fallAlarm,
      },
      overlay: { title, subtitle, badgeText, badgeColor, showSummaryCards: false },
    };
  }

  // Act 5: 2550 - 3000 (Concluzie Tehnica & Sinteza)
  const p = (frame - 2550) / 450;
  // Camera slowly pulls back and elevates into majestic perspective
  const camX = THREE.MathUtils.lerp(3.2, 4.8, smoothstep(0, 0.8, p));
  const camY = THREE.MathUtils.lerp(3.0, 5.2, smoothstep(0, 0.8, p));
  const camZ = THREE.MathUtils.lerp(3.2, 4.8, smoothstep(0, 0.8, p));

  const showSummaryCards = frame >= 2650;

  return {
    frame,
    act: 5,
    actProgress: p,
    camera: { pos: [camX, camY, camZ], target: [0, 0.5, 0] },
    cctv: { opacity: 0, coneOpacity: 0, showBanSign: false },
    hardware: { esp32Opacity: 1, ubertoothOpacity: 1, harpStringsOpacity: 0.6, fresnelShellOpacity: 0.2 },
    human: { visible: true, pos: [0.1, 0.18, 0.0], rotX: Math.PI / 2, isFallen: true, waterGlowColor: "#00f0ff" },
    telemetry: {
      posX: 0.1,
      posZ: 0.0,
      velocity: 0,
      dopplerHz: 0.2,
      stateLabel: "SISTEM ACTIV",
      links: [
        { name: "Link 1-2", attenuationDb: -18.2, fresnelZone: 0.2 },
        { name: "Link 2-3", attenuationDb: -17.8, fresnelZone: 0.3 },
        { name: "Link 3-1", attenuationDb: -19.4, fresnelZone: 0.1 },
      ],
      fallAlarm: false,
    },
    overlay: {
      title: "WI-FI CSI FRESNEL CARTOGRAPHY & FALL DETECTION",
      subtitle: "Lucrare de Licență • Hardware < 50€ • 100% Intimitate Protejată",
      badgeText: "PROIECT DE LICENȚĂ VALIDAT",
      badgeColor: "#00f0ff",
      showSummaryCards,
    },
  };
}
