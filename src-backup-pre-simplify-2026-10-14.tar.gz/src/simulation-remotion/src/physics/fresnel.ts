// Deterministic physics engine for Wi-Fi CSI Fresnel zone & fall detection
export interface Vector3D {
  x: number;
  y: number;
  z: number;
}

export interface NodeConfig {
  id: number;
  label: string;
  pos: Vector3D;
  color: string;
}

export const NODES: NodeConfig[] = [
  { id: 1, label: "ESP32 #1", pos: { x: -2.0, y: 1.2, z: 2.0 }, color: "#00f0ff" },
  { id: 2, label: "ESP32 #2", pos: { x: -2.0, y: 1.2, z: -2.0 }, color: "#00ff88" },
  { id: 3, label: "ESP32 #3", pos: { x: 2.0, y: 1.2, z: -2.0 }, color: "#ffb700" },
];

export const LAMBDA = 0.1231; // 2.4 GHz wavelength in meters (12.31 cm)

export interface SimulationState {
  frame: number;
  humanPos: Vector3D;
  humanRotationX: number;
  isFallen: boolean;
  fallAlarm: boolean;
  velocity: number;
  dopplerHz: number;
  csiLinks: {
    linkName: string;
    attenuationDb: number;
    fresnelZone: number;
  }[];
  estimatedX: number;
  estimatedZ: number;
}

// Strictly deterministic human position based on frame (0 to 450)
export function getHumanState(frame: number): { pos: Vector3D; rotX: number; isFallen: boolean; fallAlarm: boolean } {
  // Phase 1: 0 - 90 (Standing idle near (1.8, 1.8))
  if (frame < 90) {
    return {
      pos: { x: 1.8, y: 0.9, z: 1.8 },
      rotX: 0,
      isFallen: false,
      fallAlarm: false,
    };
  }

  // Phase 2: 90 - 270 (Walking towards center (-0.2, 0.0))
  if (frame < 270) {
    const t = (frame - 90) / 180; // 0 to 1
    // Smooth parametric curve
    const x = 1.8 - 2.0 * Math.sin(t * Math.PI * 0.5);
    const z = 1.8 - 1.8 * t;
    const bobbing = Math.sin(frame * 0.3) * 0.04;
    return {
      pos: { x, y: 0.9 + bobbing, z },
      rotX: 0,
      isFallen: false,
      fallAlarm: false,
    };
  }

  // Phase 3: 270 - 285 (Rapid Fall impact in ~15 frames = 500ms)
  if (frame < 285) {
    const t = (frame - 270) / 15; // 0 to 1
    const startY = 0.9;
    const endY = 0.18; // on the ground
    const y = startY - (startY - endY) * (t * t); // accelerated downwards
    const rotX = (Math.PI / 2) * t; // rotates 90 degrees forward
    return {
      pos: { x: -0.2 + t * 0.3, y, z: 0.0 },
      rotX,
      isFallen: true,
      fallAlarm: false,
    };
  }

  // Phase 4: 285 - 450 (Immobile on floor, Alarm ACTIVE)
  return {
    pos: { x: 0.1, y: 0.18, z: 0.0 },
    rotX: Math.PI / 2,
    isFallen: true,
    fallAlarm: frame >= 295, // Alarm triggers 10 frames after impact confirmation
  };
}

export function computeSimulationState(frame: number): SimulationState {
  const current = getHumanState(frame);
  const prev = getHumanState(Math.max(0, frame - 1));

  // Compute speed (m/s) assuming 30 fps (dt = 1/30 s)
  const dx = current.pos.x - prev.pos.x;
  const dy = current.pos.y - prev.pos.y;
  const dz = current.pos.z - prev.pos.z;
  const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
  const velocity = dist * 30; // m/s
  const dopplerHz = (2 * velocity) / LAMBDA;

  // Compute CSI metrics for the 3 links
  const links = [
    { name: "Link 1-2", tx: NODES[0].pos, rx: NODES[1].pos },
    { name: "Link 2-3", tx: NODES[1].pos, rx: NODES[2].pos },
    { name: "Link 3-1", tx: NODES[2].pos, rx: NODES[0].pos },
  ];

  const csiLinks = links.map((link) => {
    const directD = Math.hypot(link.tx.x - link.rx.x, link.tx.z - link.rx.z);
    const d1 = Math.hypot(link.tx.x - current.pos.x, link.tx.z - current.pos.z);
    const d2 = Math.hypot(link.rx.x - current.pos.x, link.rx.z - current.pos.z);
    const deltaD = d1 + d2 - directD;
    const fresnelZone = deltaD / (LAMBDA / 2);

    // Realistic knife-edge attenuation model: sharp dip near 0 deltaD
    let atten = 0;
    if (deltaD < 0.25) {
      atten = 18.5 * Math.exp(-(deltaD * deltaD) / 0.03); // 15 - 20 dB drop when blocking LOS
    } else {
      // Diffraction fringes
      atten = 4.0 * Math.cos((2 * Math.PI * deltaD) / LAMBDA) * Math.exp(-deltaD * 0.8);
    }

    if (current.isFallen) {
      // When body is on floor, height drops below antenna plane (1.2m)
      atten *= 0.35;
    }

    return {
      linkName: link.name,
      attenuationDb: Number(atten.toFixed(1)),
      fresnelZone: Number(fresnelZone.toFixed(2)),
    };
  });

  return {
    frame,
    humanPos: current.pos,
    humanRotationX: current.rotX,
    isFallen: current.isFallen,
    fallAlarm: current.fallAlarm,
    velocity: Number(velocity.toFixed(2)),
    dopplerHz: Number(dopplerHz.toFixed(1)),
    csiLinks,
    estimatedX: Number(current.pos.x.toFixed(2)),
    estimatedZ: Number(current.pos.z.toFixed(2)),
  };
}
