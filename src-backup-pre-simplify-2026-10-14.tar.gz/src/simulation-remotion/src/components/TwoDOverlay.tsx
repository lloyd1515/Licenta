import React from "react";
import { TimelineState } from "../physics/timeline";
import { SummaryCards } from "./SummaryCards";

interface TwoDOverlayProps {
  timeline: TimelineState;
}

export const TwoDOverlay: React.FC<TwoDOverlayProps> = ({ timeline }) => {
  const { overlay, telemetry, frame, act } = timeline;
  const alarmPulse = Math.sin(frame * 0.4) * 0.3 + 0.7;

  return (
    <div
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        pointerEvents: "none",
        fontFamily: "'Inter', -apple-system, sans-serif",
        color: "#ffffff",
        overflow: "hidden",
      }}
    >
      {/* Red Alert Vignette when fall detected */}
      {telemetry.fallAlarm && (
        <div
          style={{
            position: "absolute",
            inset: 0,
            boxShadow: `inset 0 0 140px rgba(255, 0, 50, ${0.45 * alarmPulse})`,
            border: `6px solid rgba(255, 0, 50, ${0.85 * alarmPulse})`,
            transition: "all 0.08s ease-out",
          }}
        />
      )}

      {/* Top Header Title Card */}
      <div
        style={{
          position: "absolute",
          top: 28,
          left: 36,
          display: "flex",
          alignItems: "center",
          gap: 16,
          background: "rgba(10, 16, 29, 0.88)",
          padding: "14px 24px",
          borderRadius: 14,
          border: "1px solid rgba(0, 240, 255, 0.3)",
          backdropFilter: "blur(12px)",
          maxWidth: 960,
          boxShadow: "0 8px 32px rgba(0,0,0,0.5)",
        }}
      >
        <div
          style={{
            width: 12,
            height: 12,
            borderRadius: "50%",
            backgroundColor: telemetry.fallAlarm ? "#ff0033" : "#00f0ff",
            boxShadow: `0 0 12px ${telemetry.fallAlarm ? "#ff0033" : "#00f0ff"}`,
            flexShrink: 0,
          }}
        />
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <span style={{ fontSize: 20, fontWeight: 800, letterSpacing: -0.5 }}>
              {overlay.title}
            </span>
            {overlay.badgeText && (
              <span
                style={{
                  fontSize: 11,
                  fontWeight: 700,
                  padding: "3px 8px",
                  borderRadius: 6,
                  backgroundColor: `${overlay.badgeColor || "#00f0ff"}22`,
                  color: overlay.badgeColor || "#00f0ff",
                  border: `1px solid ${overlay.badgeColor || "#00f0ff"}55`,
                  textTransform: "uppercase",
                }}
              >
                {overlay.badgeText}
              </span>
            )}
          </div>
          <div style={{ fontSize: 13, color: "#9bb0cb", marginTop: 4 }}>
            {overlay.subtitle}
          </div>
        </div>
      </div>

      {/* Top Right: Real-time Telemetry Card (Active in Acts 2 - 5) */}
      {act >= 2 && !overlay.showSummaryCards && (
        <div
          style={{
            position: "absolute",
            top: 28,
            right: 36,
            background: "rgba(10, 16, 29, 0.88)",
            padding: "16px 20px",
            borderRadius: 14,
            border: "1px solid rgba(255, 255, 255, 0.12)",
            backdropFilter: "blur(12px)",
            minWidth: 260,
            boxShadow: "0 8px 32px rgba(0,0,0,0.5)",
          }}
        >
          <div
            style={{
              fontSize: 11,
              color: "#00f0ff",
              fontWeight: 700,
              letterSpacing: 1.2,
              textTransform: "uppercase",
            }}
          >
            TELEMETRIE RADAR 2D
          </div>

          <div style={{ marginTop: 12, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <div style={{ fontSize: 11, color: "#8ca0ba" }}>Poziție (X, Z)</div>
              <div style={{ fontSize: 17, fontWeight: 700, color: "#ffffff" }}>
                {telemetry.posX.toFixed(2)}m, {telemetry.posZ.toFixed(2)}m
              </div>
            </div>
            <div>
              <div style={{ fontSize: 11, color: "#8ca0ba" }}>Viteză (v)</div>
              <div
                style={{
                  fontSize: 17,
                  fontWeight: 700,
                  color: telemetry.velocity > 2 ? "#ff5500" : "#ffffff",
                }}
              >
                {telemetry.velocity.toFixed(2)} m/s
              </div>
            </div>
            <div>
              <div style={{ fontSize: 11, color: "#8ca0ba" }}>Doppler Shift</div>
              <div
                style={{
                  fontSize: 17,
                  fontWeight: 700,
                  color: telemetry.dopplerHz > 30 ? "#ff2a55" : "#00ff88",
                }}
              >
                {telemetry.dopplerHz.toFixed(1)} Hz
              </div>
            </div>
            <div>
              <div style={{ fontSize: 11, color: "#8ca0ba" }}>Stare Persoană</div>
              <div
                style={{
                  fontSize: 14,
                  fontWeight: 700,
                  color: telemetry.fallAlarm ? "#ff0033" : "#00f0ff",
                }}
              >
                {telemetry.stateLabel}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Left: CSI Amplitude HUD for 3 Links (Active in Acts 2 - 4) */}
      {act >= 2 && !overlay.showSummaryCards && (
        <div
          style={{
            position: "absolute",
            bottom: 36,
            left: 36,
            background: "rgba(10, 16, 29, 0.88)",
            padding: "16px 20px",
            borderRadius: 14,
            border: "1px solid rgba(255, 255, 255, 0.12)",
            backdropFilter: "blur(12px)",
            width: 380,
            boxShadow: "0 8px 32px rgba(0,0,0,0.5)",
          }}
        >
          <div
            style={{
              fontSize: 11,
              color: "#00f0ff",
              fontWeight: 700,
              letterSpacing: 1.2,
              textTransform: "uppercase",
            }}
          >
            ANVELOPĂ CSI PE 52 SUBPURTĂTOARE OFDM
          </div>

          <div style={{ marginTop: 12, display: "flex", flexDirection: "column", gap: 10 }}>
            {telemetry.links.map((link) => {
              const barPercent = Math.min(
                100,
                Math.max(8, (Math.abs(link.attenuationDb) / 20) * 100)
              );
              const isCritical = Math.abs(link.attenuationDb) > 10;
              return (
                <div key={link.name}>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      fontSize: 12,
                      marginBottom: 4,
                    }}
                  >
                    <span style={{ color: "#d0d9e5" }}>{link.name}</span>
                    <span
                      style={{
                        color: isCritical ? "#ff2a55" : "#00ff88",
                        fontWeight: 600,
                      }}
                    >
                      {link.attenuationDb > 0
                        ? `-${link.attenuationDb} dB`
                        : `+${Math.abs(link.attenuationDb)} dB`}
                    </span>
                  </div>
                  <div
                    style={{
                      width: "100%",
                      height: 8,
                      background: "#1a2639",
                      borderRadius: 4,
                      overflow: "hidden",
                    }}
                  >
                    <div
                      style={{
                        width: `${barPercent}%`,
                        height: "100%",
                        background: isCritical
                          ? "linear-gradient(90deg, #ff5500, #ff0033)"
                          : "linear-gradient(90deg, #00f0ff, #00ff88)",
                        borderRadius: 4,
                        transition: "width 0.05s ease-out",
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div
            style={{
              fontSize: 11,
              color: "#61758f",
              marginTop: 10,
              display: "flex",
              justifyContent: "space-between",
            }}
          >
            <span>Frecvență eșantionare: 500 Hz</span>
            <span>Zonă Fresnel: λ/2 = 6.15 cm</span>
          </div>
        </div>
      )}

      {/* Center Alarm Banner when Fall is confirmed in Act 4 */}
      {telemetry.fallAlarm && (
        <div
          style={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            background: "rgba(220, 0, 40, 0.94)",
            border: "2px solid #ffffff",
            borderRadius: 16,
            padding: "24px 48px",
            textAlign: "center",
            boxShadow: "0 0 70px rgba(255, 0, 50, 0.85)",
          }}
        >
          <div style={{ fontSize: 36, fontWeight: 900, letterSpacing: -1, color: "#ffffff" }}>
            🚨 ALERTA: CĂDERE DETECTATĂ
          </div>
          <div style={{ fontSize: 16, fontWeight: 500, color: "#ffe0e5", marginTop: 8 }}>
            Colaps simultan CSI pe 3 legături • Vârf Doppler {telemetry.dopplerHz.toFixed(1)} Hz • Imobilitate Sol
          </div>
        </div>
      )}

      {/* Act 5: Summary Metric Cards */}
      <SummaryCards show={overlay.showSummaryCards} />
    </div>
  );
};
