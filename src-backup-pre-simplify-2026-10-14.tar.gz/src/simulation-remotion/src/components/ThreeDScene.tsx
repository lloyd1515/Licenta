import React, { useMemo } from "react";
import { ThreeCanvas } from "@remotion/three";
import { useVideoConfig } from "remotion";
import * as THREE from "three";
import { useThree } from "@react-three/fiber";
import { NODES } from "../physics/fresnel";
import { TimelineState } from "../physics/timeline";
import { CCTVCamera } from "./CCTVCamera";
import { HarpStrings } from "./HarpStrings";

interface ThreeDSceneProps {
  timeline: TimelineState;
}

const SceneContent: React.FC<ThreeDSceneProps> = ({ timeline }) => {
  const { camera } = useThree();

  React.useLayoutEffect(() => {
    camera.position.set(
      timeline.camera.pos[0],
      timeline.camera.pos[1],
      timeline.camera.pos[2]
    );
    camera.lookAt(
      timeline.camera.target[0],
      timeline.camera.target[1],
      timeline.camera.target[2]
    );
    camera.updateProjectionMatrix();
  }, [camera, timeline.camera.pos, timeline.camera.target]);

  const linkPairs = useMemo(
    () => [
      { start: NODES[0].pos, end: NODES[1].pos, color: "#00f0ff" },
      { start: NODES[1].pos, end: NODES[2].pos, color: "#00ff88" },
      { start: NODES[2].pos, end: NODES[0].pos, color: "#ffb700" },
    ],
    []
  );

  return (
    <>
      {/* Lighting */}
      <ambientLight intensity={0.4} />
      <directionalLight position={[5, 10, 5]} intensity={1.2} />
      <pointLight position={[0, 4, 0]} intensity={2.0} color="#00f0ff" distance={15} />

      {/* Act 1 CCTV Camera on Wall */}
      <CCTVCamera
        opacity={timeline.cctv.opacity}
        coneOpacity={timeline.cctv.coneOpacity}
        showBanSign={timeline.cctv.showBanSign}
      />

      {/* Sci-Fi Floor Grid */}
      <gridHelper args={[10, 20, "#00f0ff", "#152238"]} position={[0, 0, 0]} />

      {/* Room boundary plane */}
      <mesh position={[0, 0, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[6, 6]} />
        <meshStandardMaterial
          color="#0a101d"
          transparent
          opacity={0.8}
          roughness={0.4}
          metalness={0.8}
        />
      </mesh>

      {/* 3x ESP32 Node Beacons */}
      {timeline.hardware.esp32Opacity > 0.01 &&
        NODES.map((node, i) => (
          <group
            key={node.id}
            position={[node.pos.x, node.pos.y, node.pos.z]}
          >
            {/* Base module box */}
            <mesh>
              <boxGeometry args={[0.25, 0.15, 0.25]} />
              <meshStandardMaterial
                color="#0d1b2a"
                roughness={0.2}
                metalness={0.9}
                transparent
                opacity={timeline.hardware.esp32Opacity}
              />
            </mesh>
            {/* Glowing Antenna */}
            <mesh position={[0, 0.18, 0]}>
              <cylinderGeometry args={[0.02, 0.02, 0.22, 12]} />
              <meshBasicMaterial
                color={node.color}
                transparent
                opacity={timeline.hardware.esp32Opacity}
              />
            </mesh>
            {/* Pulsing ring */}
            <mesh position={[0, -0.06, 0]} rotation={[-Math.PI / 2, 0, 0]}>
              <ringGeometry
                args={[
                  0.2,
                  0.28 + (Math.sin((timeline.frame + i * 20) * 0.15) * 0.05 + 0.05),
                  32,
                ]}
              />
              <meshBasicMaterial
                color={node.color}
                transparent
                opacity={timeline.hardware.esp32Opacity * 0.6}
                side={THREE.DoubleSide}
              />
            </mesh>
            <pointLight
              color={node.color}
              intensity={1.5 * timeline.hardware.esp32Opacity}
              distance={3}
            />
          </group>
        ))}

      {/* Ubertooth One Sentinel Beacon on Side */}
      {timeline.hardware.ubertoothOpacity > 0.01 && (
        <group position={[2.6, 0.12, 2.0]}>
          <mesh>
            <boxGeometry args={[0.3, 0.1, 0.18]} />
            <meshStandardMaterial
              color="#1a1c22"
              metalness={0.9}
              transparent
              opacity={timeline.hardware.ubertoothOpacity}
            />
          </mesh>
          {/* External duck antenna */}
          <mesh position={[0.12, 0.2, 0]} rotation={[0, 0, -0.2]}>
            <cylinderGeometry args={[0.015, 0.015, 0.35, 8]} />
            <meshBasicMaterial
              color="#ffb700"
              transparent
              opacity={timeline.hardware.ubertoothOpacity}
            />
          </mesh>
          {/* Spectrum scanning ring */}
          <mesh position={[0, 0.05, 0]} rotation={[-Math.PI / 2, 0, timeline.frame * 0.05]}>
            <ringGeometry args={[0.3, 0.36, 24]} />
            <meshBasicMaterial
              color="#ffb700"
              transparent
              opacity={timeline.hardware.ubertoothOpacity * 0.5}
              side={THREE.DoubleSide}
            />
          </mesh>
        </group>
      )}

      {/* 52 Subcarrier Harp Strings */}
      <HarpStrings
        opacity={timeline.hardware.harpStringsOpacity}
        frame={timeline.frame}
        humanPos={timeline.human.pos}
        isFallen={timeline.human.isFallen}
      />

      {/* Fresnel Ellipsoid Shells */}
      {timeline.hardware.fresnelShellOpacity > 0.01 &&
        linkPairs.map((pair, idx) => {
          const vStart = new THREE.Vector3(pair.start.x, pair.start.y, pair.start.z);
          const vEnd = new THREE.Vector3(pair.end.x, pair.end.y, pair.end.z);
          const mid = new THREE.Vector3().addVectors(vStart, vEnd).multiplyScalar(0.5);
          const length = vStart.distanceTo(vEnd);
          const dir = new THREE.Vector3().subVectors(vEnd, vStart).normalize();
          const orientation = new THREE.Quaternion().setFromUnitVectors(
            new THREE.Vector3(0, 1, 0),
            dir
          );

          const linkMetric = timeline.telemetry.links[idx];
          const isBlocked = Math.abs(linkMetric.attenuationDb) > 8;

          return (
            <group key={idx} position={mid} quaternion={orientation}>
              <mesh>
                <cylinderGeometry args={[0.38, 0.38, length * 0.95, 24, 1, true]} />
                <meshStandardMaterial
                  color={isBlocked ? "#ff2a55" : pair.color}
                  transparent
                  opacity={timeline.hardware.fresnelShellOpacity * (isBlocked ? 0.9 : 0.4)}
                  wireframe={true}
                />
              </mesh>
            </group>
          );
        })}

      {/* Human Body Model (3D Mannequin) */}
      {timeline.human.visible && (
        <group
          position={[timeline.human.pos[0], timeline.human.pos[1], timeline.human.pos[2]]}
          rotation={[timeline.human.rotX, 0, 0]}
        >
          {/* Head */}
          <mesh position={[0, 0.55, 0]}>
            <sphereGeometry args={[0.13, 16, 16]} />
            <meshStandardMaterial
              color={timeline.telemetry.fallAlarm ? "#ff0033" : "#00f0ff"}
              emissive={timeline.telemetry.fallAlarm ? "#ff0033" : "#003355"}
              emissiveIntensity={timeline.telemetry.fallAlarm ? 0.8 : 0.3}
              roughness={0.2}
            />
          </mesh>
          {/* Torso */}
          <mesh position={[0, 0.15, 0]}>
            <capsuleGeometry args={[0.18, 0.45, 8, 16]} />
            <meshStandardMaterial
              color={timeline.telemetry.fallAlarm ? "#ff2a55" : "#1a2c42"}
              roughness={0.3}
              metalness={0.7}
            />
          </mesh>
          {/* Dielectric Center / Body Water Glow Ring */}
          <mesh position={[0, 0.12, 0]} rotation={[-Math.PI / 2, 0, 0]}>
            <ringGeometry args={[0.22, 0.27, 24]} />
            <meshBasicMaterial
              color={timeline.human.waterGlowColor}
              transparent
              opacity={0.8}
              side={THREE.DoubleSide}
            />
          </mesh>
          {/* Fall Impact Glow on ground */}
          {timeline.human.isFallen && (
            <mesh position={[0, -0.1, 0]} rotation={[-Math.PI / 2, 0, 0]}>
              <ringGeometry
                args={[
                  0.3,
                  0.8 + Math.sin(timeline.frame * 0.2) * 0.1,
                  32,
                ]}
              />
              <meshBasicMaterial
                color="#ff0033"
                transparent
                opacity={0.6}
                side={THREE.DoubleSide}
              />
            </mesh>
          )}
        </group>
      )}
    </>
  );
};

export const ThreeDScene: React.FC<ThreeDSceneProps> = ({ timeline }) => {
  const { width, height } = useVideoConfig();

  return (
    <ThreeCanvas
      width={width}
      height={height}
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
      }}
      camera={{
        fov: 45,
        position: timeline.camera.pos,
        near: 0.1,
        far: 100,
      }}
    >
      <SceneContent timeline={timeline} />
    </ThreeCanvas>
  );
};
