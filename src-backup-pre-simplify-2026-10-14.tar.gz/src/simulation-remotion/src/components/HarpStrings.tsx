import React, { useMemo } from "react";
import * as THREE from "three";
import { NODES } from "../physics/fresnel";

interface HarpStringsProps {
  opacity: number;
  frame: number;
  humanPos: [number, number, number];
  isFallen: boolean;
}

export const HarpStrings: React.FC<HarpStringsProps> = ({ opacity, frame, humanPos, isFallen }) => {
  if (opacity <= 0.01) return null;

  // 3 Link definitions connecting the 3 nodes in triangle
  const links = useMemo(
    () => [
      { start: NODES[0].pos, end: NODES[1].pos, baseColor: "#00f0ff" },
      { start: NODES[1].pos, end: NODES[2].pos, baseColor: "#00ff88" },
      { start: NODES[2].pos, end: NODES[0].pos, baseColor: "#ffb700" },
    ],
    []
  );

  // We sample 18 representative subcarriers per link (total 54 strings for 60fps performance)
  const subcarrierIndices = useMemo(() => Array.from({ length: 18 }, (_, i) => i - 9), []);

  return (
    <group>
      {links.map((link, linkIdx) => {
        const vStart = new THREE.Vector3(link.start.x, link.start.y, link.start.z);
        const vEnd = new THREE.Vector3(link.end.x, link.end.y, link.end.z);
        const mid = new THREE.Vector3().addVectors(vStart, vEnd).multiplyScalar(0.5);
        const length = vStart.distanceTo(vEnd);
        const dir = new THREE.Vector3().subVectors(vEnd, vStart).normalize();
        const orientation = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir);

        // Distance from human to this link
        const humanV = new THREE.Vector3(humanPos[0], humanPos[1], humanPos[2]);
        const distToMid = humanV.distanceTo(mid);
        const isPerturbed = distToMid < 1.6;

        return (
          <group key={linkIdx} position={mid} quaternion={orientation}>
            {subcarrierIndices.map((k) => {
              // Spacing spread along orthogonal axis (like a harp fan)
              const offsetAngle = (k / 9) * 0.18; // slightly fanned out
              const wavePhase = (frame * 0.2 + k * 0.5 + linkIdx * 2.0);
              const waveAmp = isPerturbed ? 0.08 : 0.02;
              const vibration = Math.sin(wavePhase) * waveAmp;

              // Color shift when perturbed by human or fall
              let stringColor = link.baseColor;
              if (isFallen) {
                stringColor = "#ff0033";
              } else if (isPerturbed) {
                stringColor = "#ffaa00";
              }

              return (
                <mesh
                  key={k}
                  position={[vibration + offsetAngle * 0.5, 0, offsetAngle]}
                >
                  <cylinderGeometry args={[0.005, 0.005, length * 0.98, 8]} />
                  <meshBasicMaterial
                    color={stringColor}
                    transparent
                    opacity={opacity * (isPerturbed ? 0.85 : 0.45)}
                  />
                </mesh>
              );
            })}
          </group>
        );
      })}
    </group>
  );
};
