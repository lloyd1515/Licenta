/*
 * main.c - Firmware ESP32 CSI Node pentru Lucrarea de Licență
 * Rol: Captură promiscuă CSI (52 subpurtătoare OFDM) + Emisie pachete broadcast TDM
 * Compatibil cu ESP-IDF v5.x
 */

#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/ringbuf.h"
#include "esp_system.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "esp_timer.h"
#include "driver/uart.h"

#define TAG "CSI_NODE"

// Configurare ID nod curent (1, 2 sau 3)
#define CONFIG_NODE_ID 3
#define WIFI_CHANNEL 6
#define UART_PORT_NUM UART_NUM_0
#define UART_BAUD_RATE 921600

// Structura binară compactă trimisă prin UART către PC
typedef struct __attribute__((packed)) {
    uint16_t magic;         // 0xA55A pentru sincronizare cadru
    uint8_t  node_id;       // ID-ul nodului receptor
    int8_t   rssi;          // Putere semnal receptionat (dBm)
    uint32_t timestamp_us;  // Timestamp intern microsecunde
    uint16_t seq_num;       // Numar secventa pachet
    int8_t   csi_data[128]; // 64 subpurtatoare x 2 (I si Q, int8)
} csi_packet_t;

static RingbufHandle_t s_csi_ringbuf = NULL;
static uint16_t s_seq_counter = 0;

// Callback hardware declansat la receptia fiecarui pachet 802.11
void IRAM_ATTR wifi_csi_rx_cb(void *ctx, wifi_csi_info_t *info) {
    if (!info || !info->buf || info->len == 0) return;

    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    csi_packet_t pkt;
    memset(&pkt, 0, sizeof(pkt));
    pkt.magic = 0xA55A;
    pkt.node_id = CONFIG_NODE_ID;
    pkt.rssi = info->rx_ctrl.rssi;
    pkt.timestamp_us = (uint32_t)esp_timer_get_time();
    pkt.seq_num = s_seq_counter++;
    
    // Copiere I/Q raw buffer (pana la 128 bytes)
    size_t copy_len = info->len > 128 ? 128 : info->len;
    memcpy(pkt.csi_data, info->buf, copy_len);

    xRingbufferSendFromISR(s_csi_ringbuf, &pkt, sizeof(pkt), &xHigherPriorityTaskWoken);
    if (xHigherPriorityTaskWoken) {
        portYIELD_FROM_ISR();
    }
}

// Task consumator care citeste din RingBuffer si face streaming pe UART
static void csi_uart_tx_task(void *pvParameters) {
    size_t item_size;
    while (1) {
        csi_packet_t *pkt = (csi_packet_t *)xRingbufferReceive(s_csi_ringbuf, &item_size, portMAX_DELAY);
        if (pkt != NULL) {
            uart_write_bytes(UART_PORT_NUM, (const char *)pkt, sizeof(csi_packet_t));
            vRingbufferReturnItem(s_csi_ringbuf, (void *)pkt);
        }
    }
}

// Task de emisie pachete broadcast pentru stimularea CSI pe celelalte noduri
static void packet_injection_task(void *pvParameters) {
    // Cadru 802.11 Probe Request broadcast (Management)
    uint8_t packet[64] = {
        0x40, 0x00, 0x00, 0x00,                         // Frame Control: Probe Request
        0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,             // Destination MAC: Broadcast
        0x24, 0x0A, 0xC4, 0x00, 0x00, CONFIG_NODE_ID,  // Source MAC (contine ID nod)
        0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,             // BSSID
        0x00, 0x00                                      // Sequence control
    };

    while (1) {
        esp_wifi_80211_tx(WIFI_IF_STA, packet, sizeof(packet), false);
        vTaskDelay(1);
    }
}

void app_main(void) {
    ESP_ERROR_CHECK(nvs_flash_init());
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());

    // Configurare UART la 921600 baud pentru streaming de mare viteza
    uart_config_t uart_config = {
        .baud_rate = UART_BAUD_RATE,
        .data_bits = UART_DATA_8_BITS,
        .parity    = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };
    ESP_ERROR_CHECK(uart_param_config(UART_PORT_NUM, &uart_config));
    ESP_ERROR_CHECK(uart_driver_install(UART_PORT_NUM, 4096, 0, 0, NULL, 0));

    // Initializare RingBuffer (16 KB)
    s_csi_ringbuf = xRingbufferCreate(16 * 1024, RINGBUF_TYPE_NOSPLIT);

    // Initializare Wi-Fi in mod promiscut
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    ESP_ERROR_CHECK(esp_wifi_set_storage(WIFI_STORAGE_RAM));
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_start());
    ESP_ERROR_CHECK(esp_wifi_set_channel(WIFI_CHANNEL, WIFI_SECOND_CHAN_NONE));

    // Configurare filtru promiscuu complet (Management + Data)
    wifi_promiscuous_filter_t filter = {
        .filter_mask = WIFI_PROMIS_FILTER_MASK_ALL
    };
    ESP_ERROR_CHECK(esp_wifi_set_promiscuous_filter(&filter));
    ESP_ERROR_CHECK(esp_wifi_set_promiscuous(true));

    // Activare CSI
    wifi_csi_config_t csi_config = {
        .lltf_en = true,
        .htltf_en = true,
        .stbc_htltf2_en = true,
        .ltf_merge_en = true,
        .channel_filter_en = false,
        .manu_scale = false,
        .shift = false,
    };
    ESP_ERROR_CHECK(esp_wifi_set_csi_config(&csi_config));
    ESP_ERROR_CHECK(esp_wifi_set_csi_rx_cb(&wifi_csi_rx_cb, NULL));
    ESP_ERROR_CHECK(esp_wifi_set_csi(true));

    ESP_LOGI(TAG, "Nodul ESP32 #%d initializat cu succes pe Canalul %d!", CONFIG_NODE_ID, WIFI_CHANNEL);

    // Lansare task-uri pe nuclee diferite (Core 0 pentru Wi-Fi/TX, Core 1 pentru UART streaming)
    xTaskCreatePinnedToCore(csi_uart_tx_task, "csi_uart_tx", 4096, NULL, 10, NULL, 1);
    xTaskCreatePinnedToCore(packet_injection_task, "pkt_inject", 2048, NULL, 5, NULL, 0);
}
