"""
run_simulation.py
=================
Script principal de executie a laboratorului DSP CSI:
1. Simuleaza date sintetice fizice (mers + cadere rapida + imobilitate)
2. Aplica filtrele Hampel, Butterworth si PCA
3. Ruleaza detectorul analitic de cadere (FSM)
4. Calculeaza traiectoria 2D a pasilor prin intersectia elipselor
5. Salveaza 4 grafice de inalta rezolutie in `dsp_lab/plots/`
"""

import os
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse

from synthetic_gen import generate_ground_truth, simulate_csi_dataset, NODES, LINKS
from filters import (clean_csi_amplitude, butterworth_bandpass, 
                     compute_pca_first_component, compute_doppler_spectrogram)
from fall_detector import FallDetectorFSM
from localization import track_trajectory

# Configurare stil estetic grafice (Stil academic Dark/Cyberpunk)
plt.style.use('dark_background')
plt.rcParams['font.sans-serif'] = 'DejaVu Sans'
plt.rcParams['axes.edgecolor'] = '#334455'
plt.rcParams['axes.linewidth'] = 1.2
plt.rcParams['grid.color'] = '#223344'
plt.rcParams['grid.linestyle'] = '--'
plt.rcParams['grid.alpha'] = 0.5

PLOTS_DIR = os.path.join(os.path.dirname(__file__), "plots")
os.makedirs(PLOTS_DIR, exist_ok=True)

def main():
    print("=" * 70)
    print("   LABORATOR SIMULARE DSP & DETECTIE CADERI WI-FI CSI (TEMA 5)    ")
    print("=" * 70)
    
    # 1. Generare date
    print("\n[1/5] Generare scenariu fizic sintetic (20s @ 250 Hz)...")
    gt = generate_ground_truth(duration=20.0, fs=250.0)
    data = simulate_csi_dataset(gt, snr_db=22.0, add_outliers=True)
    t = data["time"]
    
    # 2. Pipeline DSP pe toate cele 3 legaturi
    print("[2/5] Aplicare pipeline DSP (Hampel -> Butterworth -> PCA)...")
    clean_amps = {}
    filtered_amps = {}
    pc1_signals = {}
    
    for _, _, link_name in LINKS:
        raw_csi = data[link_name]
        # Hampel
        clean = clean_csi_amplitude(raw_csi)
        clean_amps[link_name] = clean
        # Butterworth 0.2 - 12.0 Hz
        filtered = butterworth_bandpass(clean, lowcut=0.2, highcut=12.0, fs=250.0)
        filtered_amps[link_name] = filtered
        # PCA PC1
        pc1 = compute_pca_first_component(filtered)
        pc1_signals[link_name] = pc1

    # 3. Analiza Doppler STFT pe semnal de bandă largă (păstrează frecvențele înalte de impact)
    print("[3/5] Calcul spectrograma STFT micro-Doppler...")
    stft_times, stft_freqs, doppler_power = compute_doppler_spectrogram(
        clean_amps["Link 1-2"][:, 10], fs=250.0, nperseg=64, noverlap=56
    )
    
    # 4. FSM Detecie Cadere
    print("[4/5] Rulare automat cu stari finite (FSM) pentru detectia caderii...")
    detector = FallDetectorFSM(fs=250.0)
    fall_res = detector.analyze(t, pc1_signals, stft_freqs, stft_times, doppler_power)
    
    latency_sec = fall_res.alarm_timestamp - (gt.fall_impact_idx / 250.0)
    print(f"      -> Alarma declansata: {fall_res.alarm_triggered}")
    print(f"      -> Moment impact fizic: {gt.fall_impact_idx / 250.0:.2f} s")
    print(f"      -> Timestamp alarma: {fall_res.alarm_timestamp:.2f} s")
    print(f"      -> Latenta totala de decizie (inclusiv confirmare imobilitate): {latency_sec:.2f} s")
    print(f"      -> Colaps simultan 3 legaturi: {fall_res.simultaneous_collapse_detected}")
    
    # 5. Localizare 2D
    print("[5/5] Reconstructie traiectorie 2D cartografica...")
    est_x, est_y, rmse = track_trajectory(data, pc1_signals, LINKS, NODES, downsample_factor=10)
    print(f"      -> Eroare medie patratica de localizare (RMSE): {rmse:.3f} metri")
    
    print("\n[+] Generare si exportare grafice de inalta rezolutie...")
    
    # --- FIGURA 1: RAW VS FILTERED CSI ---
    fig, axes = plt.subplots(3, 1, figsize=(12, 8), sharex=True)
    fig.patch.set_facecolor('#0d1117')
    
    # Subpurtatoare brute cu zgomot si spike-uri LNA
    raw_sample = np.abs(data["Link 1-2"])
    axes[0].plot(t, raw_sample[:, ::5], alpha=0.4, linewidth=0.8)
    axes[0].set_title("1. Amplitudine CSI Brută pe Subpurtătoare (Include Spike-uri LNA & Zgomot)", color="#00f0ff", fontsize=11)
    axes[0].set_ylabel("Amplitudine (L1-2)")
    axes[0].grid(True)
    
    # Dupa filtru Hampel
    axes[1].plot(t, clean_amps["Link 1-2"][:, ::5], alpha=0.5, linewidth=0.8)
    axes[1].set_title("2. Amplitudine după Filtru Hampel (Outlier-uri LNA Eliminate)", color="#00ff88", fontsize=11)
    axes[1].set_ylabel("Amplitudine Hampel")
    axes[1].grid(True)
    
    # Semnale PC1 pe toate cele 3 legaturi (Butterworth + PCA)
    colors = {"Link 1-2": "#00f0ff", "Link 2-3": "#00ff88", "Link 3-1": "#ffb700"}
    for lname in LINKS:
        name = lname[2]
        axes[2].plot(t, pc1_signals[name], label=name, color=colors[name], linewidth=1.5)
    axes[2].axvline(10.0, color="#ff2a55", linestyle="--", linewidth=1.8, label="Impact Cădere (t=10s)")
    axes[2].set_title("3. Semnal PC1 Filtrat pe Cele 3 Legături (Colaps Simultana la Cădere)", color="#ffb700", fontsize=11)
    axes[2].set_xlabel("Timp (secunde)")
    axes[2].set_ylabel("Magnitudine PC1")
    axes[2].legend(loc="upper right", framealpha=0.8)
    axes[2].grid(True)
    
    plt.tight_layout()
    f1_path = os.path.join(PLOTS_DIR, "1_raw_vs_filtered_csi.png")
    plt.savefig(f1_path, dpi=200, facecolor=fig.get_facecolor())
    plt.close()
    print(f"      -> Salvat: {f1_path}")
    
    # --- FIGURA 2: DOPPLER SPECTROGRAM ---
    fig, ax = plt.subplots(figsize=(11, 5))
    fig.patch.set_facecolor('#0d1117')
    
    pcm = ax.pcolormesh(stft_times, stft_freqs, doppler_power, 
                         shading='gouraud', cmap='plasma', vmin=-25, vmax=15)
    cbar = fig.colorbar(pcm, ax=ax, label="Putere Doppler (dB)")
    cbar.ax.yaxis.label.set_color('white')
    cbar.ax.tick_params(colors='white')
    
    ax.axvline(10.0, color="#00ff88", linestyle="--", linewidth=1.8, label="Impact Cădere")
    ax.axhline(35.0, color="#ff2a55", linestyle=":", linewidth=1.5, label="Prag Critic Cădere (35 Hz)")
    
    # Adnotari
    ax.text(5.5, 20.0, "Mers Normal\n(10 - 22 Hz)", color="white", fontsize=10, 
            bbox=dict(boxstyle="round", facecolor="#1e222d", alpha=0.8))
    ax.text(10.2, 50.0, "VÂRF DOPPLER CĂDERE\n(> 45 Hz, < 400 ms)", color="#ff5555", fontsize=10, weight="bold",
            bbox=dict(boxstyle="round", facecolor="#2d1e22", alpha=0.8))
    ax.text(14.0, 8.0, "Imobilitate la Sol\n(~0 Hz)", color="#00f0ff", fontsize=10,
            bbox=dict(boxstyle="round", facecolor="#1e222d", alpha=0.8))
            
    ax.set_ylim(0, 70)
    ax.set_title("Spectrogramă Micro-Doppler STFT: Mers Normal vs Impact Cădere vs Imobilitate", color="#00f0ff", fontsize=12)
    ax.set_xlabel("Timp (secunde)")
    ax.set_ylabel("Deplasare Doppler (Hz)")
    ax.legend(loc="upper right", framealpha=0.8)
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    f2_path = os.path.join(PLOTS_DIR, "2_doppler_spectrogram.png")
    plt.savefig(f2_path, dpi=200, facecolor=fig.get_facecolor())
    plt.close()
    print(f"      -> Salvat: {f2_path}")
    
    # --- FIGURA 3: TRAJECTORY & 2D FRESNEL CARTOGRAPHY ---
    fig, ax = plt.subplots(figsize=(8, 8))
    fig.patch.set_facecolor('#0d1117')
    
    # Desenare noduri ESP32
    for nid, pos in NODES.items():
        ax.scatter(pos[0], pos[1], s=180, color="#00f0ff", edgecolors="white", linewidth=1.5, zorder=5)
        ax.text(pos[0], pos[1] + 0.25, f"ESP32 Nod {nid}", color="#00f0ff", fontsize=10, weight="bold", ha="center")
        
    # Linii directe LOS intre noduri
    for tx_id, rx_id, _ in LINKS:
        p1, p2 = NODES[tx_id], NODES[rx_id]
        ax.plot([p1[0], p2[0]], [p1[1], p2[1]], color="#334466", linestyle="-", linewidth=2.0, alpha=0.6)
        
    # Traiectorie reala vs estimata
    ax.plot(gt.pos_x, gt.pos_y, color="#ffffff", linestyle="--", linewidth=1.8, label="Traiectorie Reală (Ground Truth)")
    ax.scatter(est_x, est_y, color="#ffaa00", s=25, alpha=0.7, label=f"Estimare Fresnel (RMSE = {rmse:.2f} m)")
    
    # Punct impact cadere
    ax.scatter(0.1, 0.0, s=250, color="#ff0033", marker="X", edgecolors="white", linewidth=2, zorder=6, label="Locație Cădere Sol (0.1, 0.0)")
    
    ax.set_xlim(-3.0, 3.0)
    ax.set_ylim(-3.0, 3.0)
    ax.set_aspect('equal')
    ax.set_title(f"Cartografiere Radio Pasivă 2D (Triunghi 3x ESP32)\nEroare Medie: {rmse*100:.1f} cm", color="#00ff88", fontsize=12)
    ax.set_xlabel("Coordonata X (metri)")
    ax.set_ylabel("Coordonata Y (metri)")
    ax.legend(loc="lower left", framealpha=0.8)
    ax.grid(True)
    
    plt.tight_layout()
    f3_path = os.path.join(PLOTS_DIR, "3_trajectory_cartography.png")
    plt.savefig(f3_path, dpi=200, facecolor=fig.get_facecolor())
    plt.close()
    print(f"      -> Salvat: {f3_path}")
    
    # --- FIGURA 4: FSM DECISION TELEMETRY ---
    fig, axes = plt.subplots(2, 1, figsize=(12, 6), sharex=True)
    fig.patch.set_facecolor('#0d1117')
    
    # Derivata anvelopei
    for lname in LINKS:
        name = lname[2]
        deriv = np.abs(np.gradient(pc1_signals[name], 1.0 / 250.0))
        axes[0].plot(t, deriv, label=f"|dA/dt| {name}", color=colors[name], linewidth=1.2)
    axes[0].axhline(1.2, color="#ff2a55", linestyle="--", linewidth=1.5, label="Prag Derivată Impact (1.2)")
    axes[0].axvline(10.0, color="#ff0033", linestyle=":", linewidth=1.5)
    axes[0].set_title("Viteza de Scădere a Anvelopei pe Fiecare Legătură (|dA/dt|)", color="#00f0ff", fontsize=11)
    axes[0].set_ylabel("Derivată Instantanee")
    axes[0].legend(loc="upper right", framealpha=0.8)
    axes[0].grid(True)
    
    # Tranzitia starilor FSM
    state_names = ["0: CALM", "1: MERS", "2: IMPACT", "3: VERIF_IMOBIL", "4: ALARMĂ ACTIVĂ"]
    axes[1].step(t, fall_res.fsm_states, where='post', color="#ff0033", linewidth=2.0)
    axes[1].set_yticks(range(5))
    axes[1].set_yticklabels(state_names)
    axes[1].axvline(fall_res.alarm_timestamp, color="#00ff88", linestyle="-", linewidth=2.0, 
                     label=f"Alarmă Confirmată (t = {fall_res.alarm_timestamp:.2f} s)")
    axes[1].set_title("Evoluția Stărilor Automatului FSM de Decizie", color="#00ff88", fontsize=11)
    axes[1].set_xlabel("Timp (secunde)")
    axes[1].set_ylabel("Stare FSM")
    axes[1].legend(loc="lower right", framealpha=0.8)
    axes[1].grid(True)
    
    plt.tight_layout()
    f4_path = os.path.join(PLOTS_DIR, "4_fsm_decision_telemetry.png")
    plt.savefig(f4_path, dpi=200, facecolor=fig.get_facecolor())
    plt.close()
    print(f"      -> Salvat: {f4_path}")
    
    print("\n" + "=" * 70)
    print("   TOATE CELE 4 GRAFICE GENERATE CU SUCCES IN dsp_lab/plots/   ")
    print("=" * 70)

if __name__ == "__main__":
    main()
