"""
capture_serial.py
=================
Script de captură sincronă UART pe 3 porturi seriale ESP32 (921600 baud).
Citește pachetele binare cu header 0xA55A, extrage datele CSI pe 52 de subpurtătoare
și salvează datele în format NumPy (.npz) pentru procesare în `dsp_lab/run_simulation.py`.
"""

import sys
import time
import struct
import argparse
import threading
import numpy as np
import serial

PACKET_MAGIC = 0xA55A
PACKET_SIZE = 138  # 2(magic) + 1(id) + 1(rssi) + 4(ts) + 2(seq) + 128(csi)

class SerialNodeReader(threading.Thread):
    def __init__(self, port: str, baud: int = 921600):
        super().__init__()
        self.port = port
        self.baud = baud
        self.running = True
        self.packets = []
        self.ser = None

    def run(self):
        try:
            self.ser = serial.Serial(self.port, self.baud, timeout=0.1)
            print(f"[+] Conectat la {self.port} @ {self.baud} baud")
        except Exception as e:
            print(f"[!] Eroare conectare la {self.port}: {e}")
            return

        buf = bytearray()
        while self.running:
            raw = self.ser.read(256)
            if raw:
                buf.extend(raw)
                while len(buf) >= PACKET_SIZE:
                    # Căutare header magic 0xA55A
                    if buf[0] == 0x5A and buf[1] == 0xA5:  # Little-endian 0xA55A
                        pkt_bytes = buf[:PACKET_SIZE]
                        buf = buf[PACKET_SIZE:]
                        
                        # Decodare antet
                        magic, node_id, rssi, ts_us, seq = struct.unpack("<HBbIH", pkt_bytes[:10])
                        # 64 subpurtătoare x 2 (I și Q)
                        iq_data = np.frombuffer(pkt_bytes[10:138], dtype=np.int8)
                        
                        # Conversie în numere complexe (I + j*Q)
                        i_vals = iq_data[0::2]
                        q_vals = iq_data[1::2]
                        complex_csi = i_vals + 1j * q_vals
                        
                        # Decupare 52 subpurtătoare active (eliminare pilot DC și margini nule)
                        # În canal 20 MHz HT20: index subpurtătoare [-26..-1, 1..26]
                        csi_52 = np.concatenate([complex_csi[6:32], complex_csi[33:59]])
                        
                        self.packets.append({
                            "timestamp_s": ts_us * 1e-6,
                            "node_id": node_id,
                            "rssi": rssi,
                            "seq": seq,
                            "csi": csi_52
                        })
                    else:
                        buf.pop(0)

        if self.ser and self.ser.is_open:
            self.ser.close()

    def stop(self):
        self.running = False

def main():
    parser = argparse.ArgumentParser(description="Captură date CSI reale de pe 3 noduri ESP32")
    parser.add_argument("--p1", default="/dev/ttyUSB0", help="Port nod 1")
    parser.add_argument("--p2", default="/dev/ttyUSB1", help="Port nod 2")
    parser.add_argument("--p3", default=None, help="Port nod 3 (optional, daca e in priza)")
    parser.add_argument("--duration", type=float, default=20.0, help="Durata capturii în secunde")
    parser.add_argument("--out", default="dsp_lab/capture_real.npz", help="Fișier salvare .npz")
    args = parser.parse_args()

    print(f"[*] Lansare captură serială pe {args.duration} secunde...")
    readers = []
    if args.p1 and args.p1.lower() != "none":
        readers.append(SerialNodeReader(args.p1))
    if args.p2 and args.p2.lower() != "none":
        readers.append(SerialNodeReader(args.p2))
    if args.p3 and args.p3.lower() != "none":
        readers.append(SerialNodeReader(args.p3))

    for r in readers:
        r.start()

    try:
        time.sleep(args.duration)
    except KeyboardInterrupt:
        print("\n[!] Oprire forțată de utilizator.")

    for r in readers:
        r.stop()
        r.join()

    total_pkts = sum(len(r.packets) for r in readers)
    print(f"[+] Captură finalizată! Total pachete recepționate: {total_pkts}")

    save_dict = {f"p{i+1}": r.packets for i, r in enumerate(readers)}
    np.savez_compressed(args.out, **save_dict)
    print(f"[+] Date salvate în: {args.out}")

if __name__ == "__main__":
    main()
