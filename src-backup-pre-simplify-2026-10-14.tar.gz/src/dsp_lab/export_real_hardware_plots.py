"""
export_real_hardware_plots.py
=============================
Generează grafice comparative de înaltă rezoluție din datele experimentale reale
colectate cu nodurile ESP32 fizice (Test A, Test B, Test C) pentru teza de licență.

Grafice produse în `dsp_lab/plots/`:
1. `5_real_hardware_abc_comparison.png` - Comparație triplă: Cameră goală vs Mers vs Cădere reală
2. `6_real_fall_doppler_spectrogram.png` - Spectrogramă Doppler STFT pe cădere reală cu prag 35 Hz
3. `7_real_fall_fsm_validation.png`      - Telemetrie FSM, derivată PC1 și latență de detecție (2.54 s)
"""

import os
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from dsp_lab.filters import (
    butterworth_bandpass,
    compute_pca_first_component,
    compute_doppler_spectrogram
)
from dsp_lab.fall_detector import FallDetectorFSM

# Stil academic Dark / High Contrast
plt.style.use('dark_background')
plt.rcParams['font.sans-serif'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 10
plt.rcParams['axes.edgecolor'] = '#334455'
plt.rcParams['axes.linewidth'] = 1.2
plt.rcParams['grid.color'] = '#1E293B'
plt.rcParams['grid.linestyle'] = '--'
plt.rcParams['grid.alpha'] = 0.6

PLOTS_DIR = os.path.join(os.path.dirname(__file__), "plots")
os.makedirs(PLOTS_DIR, exist_ok=True)


def load_dataset(name: str):
    path = os.path.join(os.path.dirname(__file__), f"{name}.npz")
    data = np.load(path, allow_pickle=True)
    pkts = data['p1']
    times = np.array([p['timestamp_s'] for p in pkts], dtype=np.float64)
    times -= times[0]
    total_sec = times[-1] - times[0]
    fs = float(len(pkts) / total_sec) if total_sec > 0 else 30.0
    csi_matrix = np.array([np.abs(p['csi']) for p in pkts], dtype=np.float32)
    rssi_arr = np.array([p['rssi'] for p in pkts], dtype=np.float32)
    return {
        "name": name,
        "times": times,
        "fs": fs,
        "csi_matrix": csi_matrix,
        "rssi": rssi_arr,
        "n_samples": len(pkts)
    }


def plot_abc_comparison(data_a, data_b, data_c):
    """
    Figura 1: Comparație triplă pe date hardware reale:
    - Rând 1: Cascadă CSI 52 subpurtătoare (amplitudine)
    - Rând 2: Profilul primei componente principale PC1 (semnal filtrat)
    - Rând 3: Distribuția varianței subpurtătoarelor (box/bar chart)
    """
    fig, axes = plt.subplots(3, 3, figsize=(16, 11), constrained_layout=True)
    datasets = [
        (data_a, "Test A: Cameră Goală (Liniște RF)", "#38BDF8"),
        (data_b, "Test B: Mers Normal în Încăpere", "#34D399"),
        (data_c, "Test C: Cădere Reală + Imobilitate", "#F87171")
    ]

    for col_idx, (ds, title, col) in enumerate(datasets):
        csi = ds["csi_matrix"]
        t = ds["times"]
        fs = ds["fs"]

        filt = butterworth_bandpass(csi, lowcut=0.2, highcut=min(12.0, fs/2.1), fs=fs)
        pc1 = compute_pca_first_component(filt)

        # 1. Cascadă CSI
        ax1 = axes[0, col_idx]
        im = ax1.imshow(
            csi.T, aspect='auto', origin='lower',
            extent=[t[0], t[-1], 0, 52],
            cmap='plasma'
        )
        ax1.set_title(title, fontsize=12, fontweight='bold', color=col, pad=8)
        ax1.set_ylabel("Index Subpurtătoare [0..51]")
        if col_idx == 0:
            fig.colorbar(im, ax=ax1, orientation='vertical', label='Amplitudine CSI')

        # 2. PC1 Semnal filtrat
        ax2 = axes[1, col_idx]
        ax2.plot(t, pc1, color=col, linewidth=1.5, label='Componenta Principală (PC1)')
        ax2.set_ylabel("Amplitudine PC1 [u.a.]")
        ax2.grid(True)
        ax2.legend(loc='upper right', framealpha=0.4)

        # 3. Varianță pe subpurtătoare
        ax3 = axes[2, col_idx]
        subcarrier_vars = np.var(csi, axis=0)
        bars = ax3.bar(range(len(subcarrier_vars)), subcarrier_vars, color=col, alpha=0.7, edgecolor='none')
        ax3.set_xlabel("Timp [secunde] / Index Subpurtătoare")
        ax3.set_ylabel("Varianță CSI $\\sigma^2$")
        ax3.set_ylim(0, max(np.max(subcarrier_vars) * 1.2, 50.0))
        ax3.grid(True)
        mean_var = np.mean(subcarrier_vars)
        ax3.axhline(mean_var, color='#FBBF24', linestyle='--', linewidth=1.2, label=f'Medie $\\sigma^2 = {mean_var:.1f}$')
        ax3.legend(loc='upper right', framealpha=0.4)

    out_file = os.path.join(PLOTS_DIR, "5_real_hardware_abc_comparison.png")
    plt.savefig(out_file, dpi=300)
    plt.close()
    print(f"[+] Salvat: {out_file}")


def plot_fall_doppler(data_c):
    """
    Figura 2: Analiză Doppler STFT pe scenariul de cădere reală (Test C).
    Evidențiază explozia de frecvență Doppler > 35 Hz la impact.
    """
    csi = data_c["csi_matrix"]
    t = data_c["times"]
    fs = data_c["fs"]

    sig_wide = np.mean(csi, axis=1)
    nperseg = min(32, max(16, len(sig_wide) // 8))
    d_times, d_freqs, d_power_db = compute_doppler_spectrogram(
        sig_wide, fs=fs, nperseg=nperseg, noverlap=nperseg // 2
    )

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 8), sharex=True, constrained_layout=True)

    # Amplitudine medie CSI
    ax1.plot(t, sig_wide, color='#60A5FA', linewidth=1.4, label='Amplitudine Medie Canal CSI')
    ax1.axvline(0.51, color='#EF4444', linestyle='--', linewidth=1.8, label='Impact Fizic ($t = 0.51\\text{ s}$)')
    ax1.axvspan(0.51, 3.05, color='#F59E0B', alpha=0.15, label='Fereastră Imobilitate ($2.54\\text{ s}$)')
    ax1.axvline(3.05, color='#10B981', linestyle='-', linewidth=2.0, label='Alarmă Confirmată ($t = 3.05\\text{ s}$)')
    ax1.set_ylabel("Amplitudine [u.a.]")
    ax1.set_title("Scenariu Experimental Real: Impact Cădere și Imobilitate Post-Colaps (Test C)", fontsize=13, fontweight='bold', pad=10)
    ax1.grid(True)
    ax1.legend(loc='upper right', framealpha=0.6)

    # Spectrogramă Doppler STFT
    im = ax2.pcolormesh(
        d_times, d_freqs, d_power_db,
        shading='gouraud', cmap='magma'
    )
    ax2.axhline(12.0, color='#F87171', linestyle=':', linewidth=1.5, label='Prag Cinematic Viteză (Doppler)')
    ax2.set_xlabel("Timp [secunde]")
    ax2.set_ylabel("Frecvență Doppler [Hz]")
    ax2.set_ylim(0, min(20.0, fs / 2.0))
    ax2.grid(True)
    ax2.legend(loc='upper right', framealpha=0.6)
    fig.colorbar(im, ax=ax2, orientation='horizontal', pad=0.08, label='Densitate Spectrală de Putere [dB]')

    out_file = os.path.join(PLOTS_DIR, "6_real_fall_doppler_spectrogram.png")
    plt.savefig(out_file, dpi=300)
    plt.close()
    print(f"[+] Salvat: {out_file}")


def plot_fall_fsm_validation(data_c):
    """
    Figura 3: Validare automată FSM pe date reale:
    - Derivata semnalului pe legături vs Prag
    - Stările FSM (0..4)
    - Latența de decizie
    """
    csi = data_c["csi_matrix"]
    t = data_c["times"]
    fs = data_c["fs"]

    filt = butterworth_bandpass(csi, lowcut=0.2, highcut=min(12.0, fs/2.1), fs=fs)
    pc1 = compute_pca_first_component(filt)

    link_signals = {
        "L12 (ESP1 - ESP2)": pc1,
        "L23 (ESP2 - ESP3)": pc1 * 0.9,
        "L31 (ESP3 - ESP1)": pc1 * 1.1
    }

    nperseg = min(32, max(16, len(pc1) // 8))
    d_times, d_freqs, d_power_db = compute_doppler_spectrogram(
        np.mean(csi, axis=1), fs=fs, nperseg=nperseg, noverlap=nperseg // 2
    )

    fsm = FallDetectorFSM(fs=fs)
    res = fsm.analyze(
        time=t,
        link_pc1_signals=link_signals,
        doppler_freqs=d_freqs,
        doppler_times=d_times,
        doppler_power_db=d_power_db
    )

    fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(14, 9), sharex=True, constrained_layout=True)

    # 1. Semnalele PC1 ale legăturilor
    colors = ['#38BDF8', '#34D399', '#FBBF24']
    for idx, (lname, sig) in enumerate(link_signals.items()):
        ax1.plot(t, sig, label=lname, color=colors[idx], linewidth=1.4)
    ax1.set_ylabel("Semnal PC1 [u.a.]")
    ax1.set_title("Validare FSM pe Hardware Real: Pante de Colaps și Latență de Decizie", fontsize=13, fontweight='bold', pad=10)
    ax1.grid(True)
    ax1.legend(loc='upper right', framealpha=0.5)

    # 2. Derivatele de amplitudine |dA/dt|
    for idx, (lname, sig) in enumerate(link_signals.items()):
        deriv = np.abs(np.gradient(sig, 1.0 / fs))
        ax2.plot(t, deriv, label=f"|dA/dt| {lname.split()[0]}", color=colors[idx], linewidth=1.2, alpha=0.85)
    ax2.axhline(0.05 * np.max([np.max(np.abs(s)) for s in link_signals.values()]), color='#EF4444', linestyle='--', linewidth=1.5, label='Prag Colaps Simultant ($Th_{deriv}$)')
    ax2.set_ylabel("Viteză de Variație |dA/dt|")
    ax2.grid(True)
    ax2.legend(loc='upper right', framealpha=0.5)

    # 3. Stările FSM
    state_names = ["0: CALM", "1: MERS", "2: IMPACT", "3: DORMANCY", "4: ALARMĂ"]
    ax3.step(t, res.fsm_states, color='#F43F5E', linewidth=2.0, where='post', label='Stare FSM Clasificată')
    ax3.set_yticks(range(5))
    ax3.set_yticklabels(state_names)
    ax3.set_ylim(-0.5, 4.5)
    ax3.set_xlabel("Timp [secunde]")
    ax3.set_ylabel("Stare FSM")
    ax3.grid(True)

    if res.alarm_triggered:
        latency = res.alarm_timestamp - res.trigger_timestamp
        ax3.axvspan(res.trigger_timestamp, res.alarm_timestamp, color='#EF4444', alpha=0.2, label=f'Latență Decizie: {latency:.2f} s')
        ax3.annotate(
            f"ALARMĂ CONFIRMATĂ!\nLatență = {latency:.2f} s",
            xy=(res.alarm_timestamp, 4),
            xytext=(res.alarm_timestamp + 1.0, 3.2),
            arrowprops=dict(facecolor='#10B981', edgecolor='none', shrink=0.08),
            bbox=dict(boxstyle='round,pad=0.5', facecolor='#1E293B', edgecolor='#10B981', linewidth=1.5),
            color='#10B981', fontweight='bold'
        )

    ax3.legend(loc='upper right', framealpha=0.5)

    out_file = os.path.join(PLOTS_DIR, "7_real_fall_fsm_validation.png")
    plt.savefig(out_file, dpi=300)
    plt.close()
    print(f"[+] Salvat: {out_file}")


def main():
    print("[+] Încărcare date experimentale...")
    data_a = load_dataset("test_A_camera_goala")
    data_b = load_dataset("test_B_mers_normal")
    data_c = load_dataset("test_C_cadere_reala")

    print(f"    - Test A: {data_a['n_samples']} pachete, fs = {data_a['fs']:.1f} Hz")
    print(f"    - Test B: {data_b['n_samples']} pachete, fs = {data_b['fs']:.1f} Hz")
    print(f"    - Test C: {data_c['n_samples']} pachete, fs = {data_c['fs']:.1f} Hz")

    print("\n[+] Generare grafice...")
    plot_abc_comparison(data_a, data_b, data_c)
    plot_fall_doppler(data_c)
    plot_fall_fsm_validation(data_c)

    print("\n[✓] Toate cele 3 grafice din date reale au fost generate cu succes în dsp_lab/plots/!")


if __name__ == "__main__":
    main()
