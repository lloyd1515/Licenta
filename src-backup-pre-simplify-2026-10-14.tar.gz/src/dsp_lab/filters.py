"""
filters.py
==========
Pipeline DSP pentru conditionarea semnalului CSI brut ESP32:
- Filtru Hampel adaptiv (eliminare spike-uri comutare LNA)
- Filtru Butterworth trece-banda IIR (0.2 - 10.0 Hz)
- PCA (Principal Component Analysis) pe cele 52 de subpurtatoare
- Spectrograma STFT pentru extragerea semnaturii micro-Doppler a caderii
"""

import numpy as np
from scipy import signal
from typing import Tuple

def hampel_filter_1d(x: np.ndarray, window_size: int = 7, n_sigmas: float = 3.0) -> np.ndarray:
    """
    Filtru Hampel pentru detectarea si inlocuirea outlier-ilor cu mediana locala.
    Foloseste Median Absolute Deviation (MAD).
    """
    n = len(x)
    y = x.copy()
    k = 1.4826 # Factor de scalare pentru distributie normala
    
    half_w = window_size // 2
    for i in range(half_w, n - half_w):
        window = x[i - half_w : i + half_w + 1]
        med = np.median(window)
        mad = k * np.median(np.abs(window - med)) + 1e-6
        if np.abs(x[i] - med) > n_sigmas * mad:
            y[i] = med
            
    return y

def clean_csi_amplitude(csi_matrix: np.ndarray) -> np.ndarray:
    """
    Aplica filtrul Hampel pe fiecare din cele 52 de subpurtatoare pentru matricea de amplitudini.
    Input: csi_matrix [n_samples, 52] complex sau modul
    Output: clean_amp [n_samples, 52]
    """
    amp = np.abs(csi_matrix)
    clean_amp = np.zeros_like(amp)
    for k in range(amp.shape[1]):
        clean_amp[:, k] = hampel_filter_1d(amp[:, k], window_size=7, n_sigmas=3.0)
    return clean_amp

def sanitize_subcarriers(csi_matrix: np.ndarray, min_var: float = 0.05, max_var: float = 350.0) -> np.ndarray:
    """
    Selectează subpurtătoarele active OFDM valide conform Hernandez & Bulut (2021).
    Elimină subpurtătoarele nule/invalide (var < 0.05) și cele de gardă cu zgomot extrem (var > 350).
    """
    amp = np.abs(csi_matrix)
    sub_vars = np.var(amp, axis=0)
    valid_mask = (sub_vars >= min_var) & (sub_vars <= max_var)
    if not np.any(valid_mask):
        return amp
    return amp[:, valid_mask]

def butterworth_bandpass(data: np.ndarray, lowcut: float = 0.2, highcut: float = 12.0, 
                         fs: float = 250.0, order: int = 4) -> np.ndarray:
    """
    Filtru Butterworth IIR trece-banda (ordinul 4).
    Elimina componenta continua (pereti/mobilier fix) si zgomotul de inalta frecventa.
    """
    nyquist = 0.5 * fs
    low = lowcut / nyquist
    high = highcut / nyquist
    b, a = signal.butter(order, [low, high], btype='band')
    
    # Filtrare zero-phase pe fiecare subpurtatoare
    if data.ndim == 1:
        return signal.filtfilt(b, a, data)
    
    filtered = np.zeros_like(data)
    for k in range(data.shape[1]):
        filtered[:, k] = signal.filtfilt(b, a, data[:, k])
    return filtered

def compute_pca_first_component(filtered_amp: np.ndarray) -> np.ndarray:
    """
    Extrage prima componenta principala (PC1) din cele 52 de subpurtatoare.
    Maximizeaza raportul semnal-zgomot (SNR) al miscarii umane dinamice.
    """
    # Centrare date
    mean_centered = filtered_amp - np.mean(filtered_amp, axis=0)
    cov_matrix = np.cov(mean_centered, rowvar=False)
    
    # Autovalori si autovectori
    eigvals, eigvecs = np.linalg.eigh(cov_matrix)
    # Primul vector propriu (corespunzator celei mai mari autovalori)
    first_pc = eigvecs[:, -1]
    
    pc1_signal = np.dot(mean_centered, first_pc)
    return pc1_signal

def compute_doppler_spectrogram(signal_1d: np.ndarray, fs: float = 250.0, 
                                nperseg: int = 64, noverlap: int = 56) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Calculează STFT (Short-Time Fourier Transform) pentru analiza timp-frecvență.
    Folosește semnalul de bandă largă (fără filtrare trece-jos de 12 Hz) pentru a păstra
    vitezele Doppler mari (>40 Hz) specifice căderilor.
    Output: (times, frequencies, spectrogram_power_db)
    """
    # Eliminare offset DC
    sig = signal_1d - np.mean(signal_1d)
    f, t, Zxx = signal.stft(sig, fs=fs, window='hann', 
                            nperseg=nperseg, noverlap=noverlap, return_onesided=True)
    power_db = 10 * np.log10(np.abs(Zxx) ** 2 + 1e-6)
    return t, f, power_db
