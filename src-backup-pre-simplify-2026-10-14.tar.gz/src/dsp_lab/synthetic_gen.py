"""
synthetic_gen.py
================
Simulator realist pentru matrice CSI pe 52 subpurtatoare Wi-Fi 802.11n (2.4 GHz)
pentru 3 noduri ESP32 si scenariu de deplasare 2D + cadere la sol.
"""

import numpy as np
from dataclasses import dataclass
from typing import Dict, Tuple

# Constante Fizice
C = 3.0e8                  # Viteza luminii (m/s)
FC = 2.437e9               # Frecventa centrala Canal 6 (Hz)
SUBCARRIER_SPACING = 312.5e3 # Spatiere subpurtatoare OFDM (Hz)
NUM_SUBCARRIERS = 52       # Subpurtatoare active [-26..-1, 1..26]

# Indici subpurtatoare conform 802.11n HT20
SUBCARRIER_INDICES = np.array([i for i in range(-26, 27) if i != 0])
SUBCARRIER_FREQS = FC + SUBCARRIER_INDICES * SUBCARRIER_SPACING
SUBCARRIER_LAMBDAS = C / SUBCARRIER_FREQS

# Coordonate noduri ESP32 in camera 5x5m (metri)
NODES = {
    1: np.array([-2.0, 1.2]),
    2: np.array([2.0, 1.2]),
    3: np.array([0.0, -2.0])
}

LINKS = [
    (1, 2, "Link 1-2"),
    (2, 3, "Link 2-3"),
    (3, 1, "Link 3-1")
]

@dataclass
class GroundTruth:
    time: np.ndarray
    pos_x: np.ndarray
    pos_y: np.ndarray  # In plan orizontal (X, Y)
    height_z: np.ndarray # Inaltimea centrului de masa (m)
    velocity: np.ndarray
    is_fallen: np.ndarray
    fall_impact_idx: int

def generate_ground_truth(duration: float = 20.0, fs: float = 250.0) -> GroundTruth:
    """
    Genereaza traiectoria fizica a subiectului:
    0-3s:   Stationar (linie de baza, respiratie)
    3-10s:  Mers pe diagonala (1.0 m/s) intersectand zonele Fresnel
    10-10.4s: Cadere violenta accelerata (<400 ms) de la 1.7m la sol 0.2m
    10.4-20s: Imobilitate la sol (victima inconstienta)
    """
    n_samples = int(duration * fs)
    t = np.linspace(0, duration, n_samples)
    
    x = np.zeros(n_samples)
    y = np.zeros(n_samples)
    z = np.ones(n_samples) * 1.7 # Inaltime normala
    vel = np.zeros(n_samples)
    is_fallen = np.zeros(n_samples, dtype=bool)
    
    # 0-3s: Stationar la (1.8, 1.8)
    idx_walk_start = int(3.0 * fs)
    idx_fall_start = int(10.0 * fs)
    idx_fall_end = int(10.35 * fs) # 350 ms cadere
    
    x[:idx_walk_start] = 1.8
    y[:idx_walk_start] = 1.8
    
    # 3-10s: Mers de la (1.8, 1.8) catre (0.1, 0.0)
    walk_samples = idx_fall_start - idx_walk_start
    walk_t = np.linspace(0, 1, walk_samples)
    
    # Traiectorie lina cu pas fiziologic
    x[idx_walk_start:idx_fall_start] = 1.8 - 1.7 * walk_t
    y[idx_walk_start:idx_fall_start] = 1.8 - 1.8 * walk_t
    z[idx_walk_start:idx_fall_start] = 1.7 + 0.04 * np.sin(2 * np.pi * 2.0 * t[idx_walk_start:idx_fall_start])
    vel[idx_walk_start:idx_fall_start] = 0.95
    
    # 10-10.35s: Cadere rapida
    fall_samples = idx_fall_end - idx_fall_start
    fall_tau = np.linspace(0, 1, fall_samples)
    
    x[idx_fall_start:idx_fall_end] = 0.1
    y[idx_fall_start:idx_fall_end] = 0.0
    # Prabusire accelerata z(t) = h0 - 0.5 * g_eff * t^2
    z[idx_fall_start:idx_fall_end] = 1.7 - 1.5 * (fall_tau ** 2)
    vel[idx_fall_start:idx_fall_end] = 2.8 * fall_tau
    is_fallen[idx_fall_start:idx_fall_end] = True
    
    # 10.35-20s: La sol
    x[idx_fall_end:] = 0.1
    y[idx_fall_end:] = 0.0
    z[idx_fall_end:] = 0.2 # Culcat la pamant
    vel[idx_fall_end:] = 0.0
    is_fallen[idx_fall_end:] = True
    
    return GroundTruth(
        time=t,
        pos_x=x,
        pos_y=y,
        height_z=z,
        velocity=vel,
        is_fallen=is_fallen,
        fall_impact_idx=idx_fall_start
    )

def simulate_csi_dataset(gt: GroundTruth, snr_db: float = 25.0, add_outliers: bool = True) -> Dict[str, np.ndarray]:
    """
    Calculeaza matricele CSI H[t, k] pentru toate cele 3 legaturi radio.
    Include componenta LOS statica, reflexia difractata pe corpul dielectric,
    zgomot AWGN si spike-uri LNA specifice ESP32.
    """
    n_samples = len(gt.time)
    dataset = {
        "time": gt.time,
        "ground_truth": gt,
        "nodes": NODES
    }
    
    for tx_id, rx_id, link_name in LINKS:
        tx_pos = NODES[tx_id]
        rx_pos = NODES[rx_id]
        direct_dist = np.linalg.norm(rx_pos - tx_pos)
        
        # Matrice CSI complexa: [n_samples, 52]
        H = np.zeros((n_samples, NUM_SUBCARRIERS), dtype=complex)
        
        # 1. Componenta statica (LOS + reflexii din pereti)
        static_attenuation = 1.0 / (direct_dist ** 1.8)
        H_static = static_attenuation * np.exp(-1j * 2 * np.pi * direct_dist / SUBCARRIER_LAMBDAS)
        
        # 2. Componenta dinamica de la corpul uman (cilindru dielectric)
        for i in range(n_samples):
            p = np.array([gt.pos_x[i], gt.pos_y[i]])
            d_tx = np.linalg.norm(p - tx_pos)
            d_rx = np.linalg.norm(p - rx_pos)
            total_refl_path = d_tx + d_rx
            extra_path = total_refl_path - direct_dist
            
            # Sectiune transversala de imprastiere (RCS) depinde de pozitia corpului si inaltime
            # In picioare: RCS mare pe inaltime z=1.7m
            # Cazut la sol: ocluzie masiva pe baza camerei (taie toate lobii inferiori)
            if gt.is_fallen[i]:
                # Colaps simultan masiv de putere (-18 dB la sol)
                rcs = 0.85
                phase_jitter = 0.05
            else:
                # Ocluzie spatiala normala functie de distanta la elipsa Fresnel
                fresnel_radius = 0.5 * np.sqrt(0.123 * direct_dist)
                dist_to_center_line = extra_path
                rcs = 0.35 * np.exp(-dist_to_center_line / (fresnel_radius * 1.5))
                phase_jitter = 0.0
            
            # Faza indusa de propagare
            phase = -2 * np.pi * total_refl_path / SUBCARRIER_LAMBDAS
            dynamic_component = rcs * np.exp(1j * phase)
            
            # Doppler din viteza verticala / orizontala la cadere
            if gt.velocity[i] > 1.5:
                doppler_shift = 2 * np.pi * (2 * gt.velocity[i] / 0.123) * gt.time[i]
                dynamic_component *= np.exp(1j * doppler_shift)
            
            H[i, :] = H_static + dynamic_component
        
        # 3. Adaugare zgomot termic Gaussian (AWGN)
        sig_power = np.mean(np.abs(H) ** 2)
        noise_power = sig_power / (10 ** (snr_db / 10.0))
        noise = (np.random.randn(*H.shape) + 1j * np.random.randn(*H.shape)) * np.sqrt(noise_power / 2)
        H += noise
        
        # 4. Spike-uri LNA specifice receptorului Wi-Fi ESP32 (outliers aleatoare)
        if add_outliers:
            outlier_indices = np.random.choice(n_samples, size=int(n_samples * 0.008), replace=False)
            H[outlier_indices, :] *= np.random.uniform(1.8, 3.2, size=(len(outlier_indices), 1))
            
        dataset[link_name] = H
        
    return dataset

if __name__ == "__main__":
    print("[+] Generare scenariu fizic sintetic...")
    gt = generate_ground_truth(duration=20.0, fs=250.0)
    data = simulate_csi_dataset(gt)
    print(f"[+] Succes! Generat 3 legaturi x {len(gt.time)} esantioane x 52 subpurtatoare.")
