"""
Sistem Inteligent de Monitorizare Ambientală Wi-Fi CSI — Licență UTCN
Main Window Application Interface (PyQt6)
"""

import sys
import time
import os
from typing import Optional, Dict, Any

from PyQt6.QtCore import (
    Qt, QTimer, pyqtSignal, pyqtSlot
)
from PyQt6.QtGui import (
    QColor, QFont
)
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QSplitter, QLabel, QPushButton, QComboBox, QFrame,
    QStatusBar
)

from gui.backend_engine import CSIDataEngine
from gui.widgets import RoomMapWidget, DopplerWidget, WaterfallWidget, TelemetryWidget

DARK_STYLESHEET = """
QMainWindow {
    background-color: #0B0F19;
}

QWidget {
    color: #E2E8F0;
    font-family: 'Segoe UI', 'Inter', -apple-system, sans-serif;
    font-size: 13px;
}

QFrame#PanelFrame {
    background-color: #111827;
    border: 1px solid #1E293B;
    border-radius: 8px;
}

QFrame#PanelHeader {
    background-color: #1F2937;
    border-top-left-radius: 8px;
    border-top-right-radius: 8px;
    border-bottom: 1px solid #374151;
    padding: 6px 12px;
}

QLabel#PanelTitle {
    font-weight: 700;
    font-size: 12px;
    letter-spacing: 0.8px;
    color: #38BDF8;
    text-transform: uppercase;
}

QFrame#TopBar {
    background-color: #0F172A;
    border-bottom: 1px solid #1E293B;
    padding: 8px 16px;
}

QLabel#AppTitle {
    font-size: 16px;
    font-weight: 800;
    color: #F8FAFC;
    letter-spacing: 0.5px;
}

QLabel#AppSubtitle {
    font-size: 11px;
    font-weight: 500;
    color: #06B6D4;
}

QLabel#Badge {
    padding: 4px 10px;
    border-radius: 6px;
    font-weight: 700;
    font-size: 11px;
    letter-spacing: 0.5px;
}

QLabel#MetricBadge {
    background-color: #111827;
    color: #38BDF8;
    border: 1px solid #1E293B;
    font-family: 'JetBrains Mono', 'Fira Code', 'Consolas', monospace;
    font-size: 12px;
    font-weight: 600;
    padding: 4px 10px;
    border-radius: 6px;
}

QComboBox {
    background-color: #1E293B;
    border: 1px solid #334155;
    border-radius: 6px;
    padding: 5px 12px;
    color: #F8FAFC;
    font-weight: 600;
    min-width: 140px;
}

QPushButton#ToggleLive {
    background-color: #1E293B;
    border: 1px solid #334155;
    border-radius: 6px;
    color: #94A3B8;
    font-weight: 700;
    padding: 6px 14px;
}

QPushButton#ToggleLive:checked {
    background-color: rgba(16, 185, 129, 0.2);
    border: 1px solid #10B981;
    color: #10B981;
}

QPushButton#ToggleReplay {
    background-color: #1E293B;
    border: 1px solid #334155;
    border-radius: 6px;
    color: #94A3B8;
    font-weight: 700;
    padding: 6px 14px;
}

QPushButton#ToggleReplay:checked {
    background-color: rgba(6, 182, 212, 0.2);
    border: 1px solid #06B6D4;
    color: #06B6D4;
}

QFrame#AlertBanner {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #991B1B, stop:0.5 #DC2626, stop:1 #991B1B);
    border: 2px solid #EF4444;
    border-radius: 8px;
    margin: 4px 8px 8px 8px;
    padding: 8px 16px;
}

QLabel#AlertText {
    color: #FFFFFF;
    font-size: 14px;
    font-weight: 800;
    letter-spacing: 0.6px;
}

QPushButton#AlertResetButton {
    background-color: #7F1D1D;
    color: #FFFFFF;
    border: 2px solid #FCA5A5;
    border-radius: 6px;
    font-weight: 800;
    padding: 6px 18px;
    text-transform: uppercase;
    font-size: 12px;
}

QPushButton#AlertResetButton:hover {
    background-color: #991B1B;
    border-color: #FFFFFF;
}

QSplitter::handle {
    background-color: #1E293B;
    width: 3px;
    height: 3px;
}

QStatusBar {
    background-color: #0B0F19;
    border-top: 1px solid #1E293B;
    color: #64748B;
    font-size: 11px;
}
"""


class MainWindow(QMainWindow):
    """
    Main application window hosting real-time CSI RF sensing pipeline,
    Fresnel 2D room map, Doppler signature, subcarrier waterfall, and fall FSM alarm.
    """

    def __init__(self, engine: Optional[CSIDataEngine] = None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Sistem Inteligent de Monitorizare Ambientală Wi-Fi CSI — Licență UTCN")
        self.resize(1600, 950)
        self.setMinimumSize(1200, 750)
        self.setStyleSheet(DARK_STYLESHEET)

        self.engine = engine if engine is not None else CSIDataEngine(parent=self)

        self._last_frame_ts = time.time()
        self._frame_count = 0
        self._alarm_muted = False

        self._init_top_bar()
        self._init_central_panels()
        self._init_alert_banner()
        self._init_status_bar()
        self._init_layout()
        self._connect_signals()

        self._fps_timer = QTimer(self)
        self._fps_timer.setInterval(1000)
        self._fps_timer.timeout.connect(self._recalculate_fps)
        self._fps_timer.start()

    def _init_top_bar(self):
        self.top_bar = QFrame(self)
        self.top_bar.setObjectName("TopBar")
        top_layout = QHBoxLayout(self.top_bar)
        top_layout.setContentsMargins(16, 8, 16, 8)
        top_layout.setSpacing(14)

        title_box = QVBoxLayout()
        title_box.setSpacing(2)
        self.lbl_title = QLabel("Sistem Inteligent de Monitorizare Ambientală Wi-Fi CSI", self.top_bar)
        self.lbl_title.setObjectName("AppTitle")
        self.lbl_subtitle = QLabel("Licență Calculatoare UTCN • Modul Multi-Link Fresnel & Detecție Căderi", self.top_bar)
        self.lbl_subtitle.setObjectName("AppSubtitle")
        title_box.addWidget(self.lbl_title)
        title_box.addWidget(self.lbl_subtitle)
        top_layout.addLayout(title_box)

        top_layout.addStretch(1)

        self.lbl_status = QLabel("● DECONECTAT", self.top_bar)
        self.lbl_status.setObjectName("Badge")
        self.lbl_status.setStyleSheet("background-color: #1E293B; color: #94A3B8; border: 1px solid #334155; padding: 5px 12px; border-radius: 6px; font-weight: 700;")
        top_layout.addWidget(self.lbl_status)

        self.lbl_fps = QLabel("FPS: --", self.top_bar)
        self.lbl_fps.setObjectName("MetricBadge")
        top_layout.addWidget(self.lbl_fps)

        self.combo_ports = QComboBox(self.top_bar)
        self.combo_ports.addItems(["/dev/ttyUSB1", "/dev/ttyUSB0", "/dev/ttyUSB2", "COM3"])
        top_layout.addWidget(self.combo_ports)

        self.btn_live = QPushButton("Live USB", self.top_bar)
        self.btn_live.setObjectName("ToggleLive")
        self.btn_live.setCheckable(True)
        top_layout.addWidget(self.btn_live)

        self.btn_replay = QPushButton("Replay Salvare (Test C)", self.top_bar)
        self.btn_replay.setObjectName("ToggleReplay")
        self.btn_replay.setCheckable(True)
        top_layout.addWidget(self.btn_replay)

    def _wrap_panel(self, title: str, widget: QWidget) -> QFrame:
        frame = QFrame(self)
        frame.setObjectName("PanelFrame")
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        header = QFrame(frame)
        header.setObjectName("PanelHeader")
        h_layout = QHBoxLayout(header)
        h_layout.setContentsMargins(12, 6, 12, 6)
        
        lbl = QLabel(title, header)
        lbl.setObjectName("PanelTitle")
        h_layout.addWidget(lbl)
        h_layout.addStretch()

        layout.addWidget(header)
        layout.addWidget(widget, 1)
        return frame

    def _init_central_panels(self):
        self.room_map_widget = RoomMapWidget(self)
        self.doppler_widget = DopplerWidget(self)
        self.waterfall_widget = WaterfallWidget(self)
        self.telemetry_widget = TelemetryWidget(self)

        self.panel_room_map = self._wrap_panel("HARTĂ DE PROPAGARE RF & POZIȚIONARE 2D (ZONE FRESNEL)", self.room_map_widget)
        self.panel_doppler = self._wrap_panel("SEMNĂTURĂ DOPPLER & DINAMICĂ VITEZĂ IMPACT", self.doppler_widget)
        self.panel_waterfall = self._wrap_panel("PROFIL SPECTRAL CSI (52 SUBPURTĂTOARE HT20)", self.waterfall_widget)
        self.panel_telemetry = self._wrap_panel("TELEMETRIE SISTEM & FSM MONITORIZARE CĂDERE", self.telemetry_widget)

    def _init_alert_banner(self):
        self.alert_banner = QFrame(self)
        self.alert_banner.setObjectName("AlertBanner")
        banner_layout = QHBoxLayout(self.alert_banner)
        banner_layout.setContentsMargins(16, 8, 16, 8)
        banner_layout.setSpacing(16)

        self.lbl_alert_msg = QLabel(
            "⚠️ ALERTĂ DE CĂDERE DETECTATĂ! PERSOANĂ LA SOL — LATENȚĂ: 2.60 s — CONFIRMARE IMOBILITATE ACTIVĂ",
            self.alert_banner
        )
        self.lbl_alert_msg.setObjectName("AlertText")
        banner_layout.addWidget(self.lbl_alert_msg, 1)

        self.btn_reset_alert = QPushButton("Resetează Alarmă", self.alert_banner)
        self.btn_reset_alert.setObjectName("AlertResetButton")
        self.btn_reset_alert.clicked.connect(self.reset_alarm)
        banner_layout.addWidget(self.btn_reset_alert)

        self.alert_banner.hide()

    def _init_status_bar(self):
        self.status_bar = QStatusBar(self)
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Sistem gata. Selectați modul Live USB sau Replay Salvare.")

    def _init_layout(self):
        main_widget = QWidget(self)
        self.setCentralWidget(main_widget)
        root_layout = QVBoxLayout(main_widget)
        root_layout.setContentsMargins(8, 8, 8, 8)
        root_layout.setSpacing(8)

        root_layout.addWidget(self.top_bar)

        self.main_splitter = QSplitter(Qt.Orientation.Horizontal, main_widget)

        left_container = QWidget(self.main_splitter)
        left_layout = QVBoxLayout(left_container)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(8)
        left_splitter = QSplitter(Qt.Orientation.Vertical, left_container)
        left_splitter.addWidget(self.panel_room_map)
        left_splitter.addWidget(self.panel_doppler)
        left_splitter.setStretchFactor(0, 6)
        left_splitter.setStretchFactor(1, 4)
        left_layout.addWidget(left_splitter)
        self.main_splitter.addWidget(left_container)

        right_container = QWidget(self.main_splitter)
        right_layout = QVBoxLayout(right_container)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(8)
        right_splitter = QSplitter(Qt.Orientation.Vertical, right_container)
        right_splitter.addWidget(self.panel_waterfall)
        right_splitter.addWidget(self.panel_telemetry)
        right_splitter.setStretchFactor(0, 6)
        right_splitter.setStretchFactor(1, 4)
        right_layout.addWidget(right_splitter)
        self.main_splitter.addWidget(right_container)

        self.main_splitter.setStretchFactor(0, 5)
        self.main_splitter.setStretchFactor(1, 5)

        root_layout.addWidget(self.main_splitter, 1)
        root_layout.addWidget(self.alert_banner)

    def _connect_signals(self):
        self.btn_live.clicked.connect(self._on_live_toggle)
        self.btn_replay.clicked.connect(self._on_replay_toggle)

        if hasattr(self.engine, "sig_frame_ready"):
            self.engine.sig_frame_ready.connect(self.on_frame_received)
        if hasattr(self.engine, "sig_status"):
            self.engine.sig_status.connect(lambda s: self.status_bar.showMessage(s))

    @pyqtSlot(bool)
    def _on_live_toggle(self, checked: bool):
        if checked:
            self.btn_replay.setChecked(False)
            port = self.combo_ports.currentText()
            self.engine.port = port
            self.engine.set_replay_mode(False)
            if not self.engine.isRunning():
                self.engine.start()
            self.update_connection_status(f"LIVE USB ({port})", True)
            self.status_bar.showMessage(f"Conectat la nod hardware pe port {port} (921600 baud)...")
        else:
            self.engine.stop()
            self.update_connection_status("DECONECTAT", False)
            self.status_bar.showMessage("Captura live a fost oprită.")

    @pyqtSlot(bool)
    def _on_replay_toggle(self, checked: bool):
        if checked:
            self.btn_live.setChecked(False)
            self.engine.set_replay_mode(True)
            if not self.engine.isRunning():
                self.engine.start()
            self.update_connection_status("REPLAY (TEST C)", True)
            self.status_bar.showMessage("Se rulează replay din salvarea Test C (Scenariu Cădere + Mers)...")
        else:
            self.engine.stop()
            self.update_connection_status("DECONECTAT", False)
            self.status_bar.showMessage("Replay-ul a fost oprit.")

    @pyqtSlot(dict)
    def on_frame_received(self, frame_data: Dict[str, Any]):
        self._frame_count += 1

        self.room_map_widget.update_data(frame_data)
        self.doppler_widget.update_data(frame_data)
        self.waterfall_widget.update_data(frame_data)
        self.telemetry_widget.update_data(frame_data)

        is_alarm = frame_data.get("alarm_active", False) or frame_data.get("fsm_state") == 4
        if is_alarm:
            if not self._alarm_muted:
                self.on_fall_alert_triggered(2.54)
        else:
            self._alarm_muted = False

    @pyqtSlot(float)
    def on_fall_alert_triggered(self, latency_sec: float):
        self.lbl_alert_msg.setText(
            f"⚠️ ALERTĂ DE CĂDERE DETECTATĂ! PERSOANĂ LA SOL — LATENȚĂ: {latency_sec:.2f} s — CONFIRMARE IMOBILITATE ACTIVĂ"
        )
        self.alert_banner.show()
        self.status_bar.showMessage(f"ALARMĂ CRITICĂ: Cădere confirmată cu latență de {latency_sec:.2f} s!")

    @pyqtSlot()
    def reset_alarm(self):
        self._alarm_muted = True
        self.alert_banner.hide()
        self.telemetry_widget.reset_alarm()
        if hasattr(self.engine, 'reset_alarm'):
            self.engine.reset_alarm()
        self.status_bar.showMessage("Alarma de cădere a fost resetată manual de utilizator.")

    @pyqtSlot(str, bool)
    def update_connection_status(self, text: str, is_connected: bool):
        if not is_connected:
            self.lbl_status.setText("● DECONECTAT")
            self.lbl_status.setStyleSheet("background-color: #1E293B; color: #94A3B8; border: 1px solid #334155; padding: 5px 12px; border-radius: 6px; font-weight: 700;")
        elif "REPLAY" in text.upper():
            self.lbl_status.setText(f"● {text.upper()}")
            self.lbl_status.setStyleSheet("background-color: rgba(6, 182, 212, 0.2); color: #06B6D4; border: 1px solid #0891B2; padding: 5px 12px; border-radius: 6px; font-weight: 700;")
        else:
            self.lbl_status.setText(f"● {text.upper()}")
            self.lbl_status.setStyleSheet("background-color: rgba(16, 185, 129, 0.2); color: #10B981; border: 1px solid #059669; padding: 5px 12px; border-radius: 6px; font-weight: 700;")

    def _recalculate_fps(self):
        now = time.time()
        elapsed = now - self._last_frame_ts
        if elapsed >= 1.0:
            fps = self._frame_count / elapsed
            self.lbl_fps.setText(f"FPS: {fps:.1f}")
            self._frame_count = 0
            self._last_frame_ts = now

    def closeEvent(self, event):
        self.engine.stop()
        event.accept()
