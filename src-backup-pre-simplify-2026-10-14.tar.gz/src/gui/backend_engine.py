"""
backend_engine.py
=================
Real-time Wi-Fi CSI telemetry backend engine for PyQt6 desktop application.
Supports dual ESP32 serial streams (921600 baud, 138-byte packets, 0xA55A header)
with automated seamless fallback to offline replay mode (test_C_cadere_reala.npz).
Integrates DSP filters (Hampel, Butterworth, PCA) and analytical FallDetectorFSM.
"""

import os
import sys
import time
import struct
import numpy as np
from typing import Optional, Dict, Any

from PyQt6.QtCore import QThread, pyqtSignal, QMutex, QMutexLocker

# Ensure workspace root in sys.path for dsp_lab imports
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(CURRENT_DIR)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

try:
    from dsp_lab.filters import (
        hampel_filter_1d,
        clean_csi_amplitude,
        butterworth_bandpass,
        compute_pca_first_component,
        compute_doppler_spectrogram,
        sanitize_subcarriers
    )
    from dsp_lab.fall_detector import FallDetectorFSM, FallDetectionResult
except ImportError as err:
    print(f"[CSIDataEngine] Warning importing dsp_lab modules: {err}")

try:
    import serial
except ImportError:
    serial = None


class CSIDataEngine(QThread):
    """
    QThread engine streaming processed Wi-Fi CSI telemetry frames at 30-60 FPS.
    """
    sig_frame_ready = pyqtSignal(dict)
    sig_status = pyqtSignal(str)
    sig_error = pyqtSignal(str)

    HEADER_MAGIC_LE = 0x5AA5  # 0xA55A in little-endian uint16
    HEADER_MAGIC_BE = 0xA55A  # Big-endian match
    PACKET_SIZE = 138         # 10 bytes header + 128 bytes CSI (64 I/Q pairs)

    def __init__(
        self,
        port: Optional[str] = None,
        baudrate: int = 921600,
        replay_mode: bool = False,
        replay_file: Optional[str] = None,
        target_fps: float = 50.0,
        parent=None
    ):
        super().__init__(parent)
        self.port = port
        self.baudrate = baudrate
        self.replay_mode = replay_mode
        self.target_fps = target_fps
        self.frame_interval = 1.0 / max(10.0, target_fps)
        
        self.replay_file = replay_file or os.path.join(
            PROJECT_ROOT, "dsp_lab", "test_C_cadere_reala.npz"
        )

        self._running = False
        self._mutex = QMutex()

        # DSP & state estimation buffers
        self.fs = 250.0
        self.fsm = FallDetectorFSM(fs=self.fs)
        self.rolling_amp_buffer = []  # Rolling [52] amplitudes
        self.rolling_buffer_size = 128
        self.posture_height = 1.75
        self.person_x = 0.0
        self.person_y = 0.0
        self.target_vx = 0.0
        self.target_vy = 0.0

        # Live tracking state & multi-node metrics
        self.node_variances = {1: 0.1, 2: 0.1, 3: 0.1}
        self.last_pc1_val = 0.0
        self.last_pc1_time = time.time()
        self.live_state = 0  # 0: CALM, 1: WALKING, 2: IMPACT, 3: DORMANCY, 4: ALARM
        self.impact_time = 0.0
        self.dormancy_start = 0.0
        self.alarm_active = False
        self.calm_counter = 0
        self.live_doppler = 2.0
        self.calib_samples = 0
        self.baseline_var = 2.0

        # Replay cache
        self._replay_data: Optional[Dict[str, Any]] = None

    def reset_alarm(self):
        """Resets alarm and returns live FSM to calm."""
        with QMutexLocker(self._mutex):
            self.alarm_active = False
            self.live_state = 0
            self.posture_height = 1.75
            self.impact_time = 0.0
            self.dormancy_start = 0.0

    def stop(self):
        """Stops thread gracefully."""
        with QMutexLocker(self._mutex):
            self._running = False
        self.wait(1500)

    def set_replay_mode(self, enabled: bool):
        """Toggle replay mode dynamically."""
        with QMutexLocker(self._mutex):
            self.replay_mode = enabled

    def run(self):
        """Thread worker main loop."""
        with QMutexLocker(self._mutex):
            self._running = True

        # Check if hardware serial ports can be opened
        serial_devs = []
        if not self.replay_mode:
            serial_devs = self._try_open_serials()
            if not serial_devs:
                self.sig_status.emit(
                    "[CSIDataEngine] Hardware ports unavailable. Falling back to Replay Mode."
                )
                self.replay_mode = True

        if self.replay_mode:
            self._run_replay_loop()
        else:
            self._run_serial_loop(serial_devs)

    # -------------------------------------------------------------------------
    # Hardware Serial Interface
    # -------------------------------------------------------------------------
    def _try_open_serials(self) -> list:
        if serial is None:
            return []

        candidates = []
        if self.port and os.path.exists(self.port):
            candidates.append(self.port)
        for def_port in ["/dev/ttyUSB1", "/dev/ttyUSB0", "/dev/ttyUSB2"]:
            if def_port not in candidates and os.path.exists(def_port):
                candidates.append(def_port)

        opened = []
        for port_name in candidates:
            try:
                ser = serial.Serial(port_name, baudrate=self.baudrate, timeout=0.05)
                ser.dtr = False
                ser.rts = False
                opened.append((port_name, ser))
                self.sig_status.emit(f"[CSIDataEngine] Connected hardware port {port_name} @ {self.baudrate}")
            except Exception as e:
                self.sig_error.emit(f"Failed opening {port_name}: {e}")
        return opened

    def _parse_packet(self, raw_bytes: bytes) -> Optional[Dict[str, Any]]:
        """Parses a 138-byte ESP32 CSI packet with 0xA55A magic."""
        if len(raw_bytes) != self.PACKET_SIZE:
            return None

        magic, node_id, rssi, ts_raw, seq = struct.unpack('<H B b I H', raw_bytes[0:10])
        if magic != self.HEADER_MAGIC_LE and magic != self.HEADER_MAGIC_BE:
            return None

        payload = raw_bytes[10:138]  # 128 bytes = 64 subcarriers * 2 (I, Q)
        iq = np.frombuffer(payload, dtype=np.int8).astype(np.float32)
        i_comp = iq[0::2]
        q_comp = iq[1::2]
        amp_64 = np.sqrt(i_comp**2 + q_comp**2)

        # Extract 52 OFDM subcarriers: [-26..-1, 1..26]
        if len(amp_64) >= 64:
            csi_52 = np.concatenate([amp_64[6:32], amp_64[33:59]])
        else:
            csi_52 = amp_64[:52] if len(amp_64) >= 52 else np.pad(amp_64, (0, 52 - len(amp_64)))

        return {
            "timestamp": ts_raw / 1e6 if ts_raw > 1e9 else float(ts_raw),
            "node_id": int(node_id),
            "rssi": float(rssi),
            "csi_raw_52": csi_52
        }

    def _run_serial_loop(self, serial_devs: list):
        """Reads stream from all connected serial ports concurrently, parses frames, emits at target FPS."""
        buffers = {port_name: bytearray() for port_name, _ in serial_devs}
        last_emit_time = time.time()
        last_parsed = None

        while True:
            with QMutexLocker(self._mutex):
                if not self._running:
                    break

            try:
                for port_name, ser in serial_devs:
                    try:
                        waiting = ser.in_waiting
                        if waiting > 0:
                            chunk = ser.read(waiting)
                            buf = buffers[port_name]
                            buf.extend(chunk)

                            while len(buf) >= self.PACKET_SIZE:
                                magic_pos = -1
                                for idx in range(len(buf) - 1):
                                    val = (buf[idx + 1] << 8) | buf[idx]
                                    if val == self.HEADER_MAGIC_LE or val == self.HEADER_MAGIC_BE:
                                        magic_pos = idx
                                        break

                                if magic_pos == -1:
                                    buf = buf[-1:]
                                    buffers[port_name] = buf
                                    break

                                if magic_pos > 0:
                                    del buf[:magic_pos]

                                if len(buf) < self.PACKET_SIZE:
                                    break

                                pkt_bytes = bytes(buf[:self.PACKET_SIZE])
                                del buf[:self.PACKET_SIZE]

                                parsed = self._parse_packet(pkt_bytes)
                                if parsed:
                                    last_parsed = parsed
                    except Exception:
                        pass

                now = time.time()
                if last_parsed and (now - last_emit_time >= self.frame_interval):
                    telemetry = self._process_rolling_frame(last_parsed)
                    self.sig_frame_ready.emit(telemetry)
                    last_emit_time = now

                time.sleep(0.002)

            except Exception as err:
                self.sig_error.emit(f"Serial stream error: {err}")
                break

        for _, ser in serial_devs:
            try:
                ser.close()
            except Exception:
                pass

    # -------------------------------------------------------------------------
    # Replay Interface
    # -------------------------------------------------------------------------
    def _load_replay_dataset(self) -> Dict[str, Any]:
        """Loads and precomputes FSM analysis on test_C_cadere_reala.npz."""
        if self._replay_data is not None:
            return self._replay_data

        if not os.path.exists(self.replay_file):
            raise FileNotFoundError(f"Replay file not found: {self.replay_file}")

        data = np.load(self.replay_file, allow_pickle=True)
        # Extract packets from dense node
        p1 = data['p1']
        p2 = data['p2']
        pkts = p1 if len(p1) > len(p2) else p2

        n_samples = len(pkts)
        time_arr = np.array([p['timestamp_s'] for p in pkts], dtype=np.float64)
        time_arr -= time_arr[0]
        total_duration = time_arr[-1] - time_arr[0]
        actual_fs = float(n_samples / total_duration) if total_duration > 0 else self.fs

        csi_matrix_52 = np.array([np.abs(p['csi']) for p in pkts], dtype=np.float32)
        sanitized = sanitize_subcarriers(csi_matrix_52)
        filt_amp = butterworth_bandpass(sanitized, lowcut=0.2, highcut=min(12.0, actual_fs/2.1), fs=actual_fs)
        pc1 = compute_pca_first_component(filt_amp)

        link_signals = {
            "L12": pc1,
            "L23": pc1 * 0.9,
            "L31": pc1 * 1.1
        }

        # Doppler spectrogram
        sig_wide = np.mean(csi_matrix_52, axis=1)
        nperseg = min(32, max(16, len(pc1) // 8))
        d_times, d_freqs, d_power_db = compute_doppler_spectrogram(
            sig_wide, fs=actual_fs, nperseg=nperseg, noverlap=nperseg // 2
        )

        # Analytical FSM detection
        replay_fsm = FallDetectorFSM(fs=actual_fs)
        fsm_res = replay_fsm.analyze(
            time=time_arr,
            link_pc1_signals=link_signals,
            doppler_freqs=d_freqs,
            doppler_times=d_times,
            doppler_power_db=d_power_db
        )

        self._replay_data = {
            "time": time_arr,
            "link_signals": link_signals,
            "fsm_states": fsm_res.fsm_states,
            "alarm_triggered": fsm_res.alarm_triggered,
            "alarm_timestamp": fsm_res.alarm_timestamp,
            "trigger_timestamp": fsm_res.trigger_timestamp,
            "csi_matrix_52": csi_matrix_52,
            "d_freqs": d_freqs,
            "d_times": d_times,
            "d_power_db": d_power_db,
            "n_samples": n_samples,
            "actual_fs": actual_fs
        }
        return self._replay_data

    def _run_replay_loop(self):
        """Streams dataset smoothly in a loop at target FPS."""
        dataset = self._load_replay_dataset()
        n_samples = dataset["n_samples"]
        time_arr = dataset["time"]
        fsm_states = dataset["fsm_states"]
        link_signals = dataset["link_signals"]
        csi_matrix_52 = dataset["csi_matrix_52"]
        alarm_ts = dataset["alarm_timestamp"]

        actual_fs = dataset.get("actual_fs", self.fs)
        step_samples = max(1, int(round(actual_fs / self.target_fps)))
        sample_idx = 0
        last_clock = time.time()

        smooth_height = 1.75
        pos_x = 0.0
        pos_y = 0.0

        while True:
            with QMutexLocker(self._mutex):
                if not self._running:
                    break

            t_val = float(time_arr[sample_idx])
            state = int(fsm_states[sample_idx])

            # Posture height calculation (1.75m -> 0.15m)
            if state == 0:     # CALM
                target_height = 1.75 + 0.02 * np.sin(t_val * 1.5)
            elif state == 1:   # WALKING
                target_height = 1.70 + 0.05 * np.sin(t_val * 9.0)
            elif state == 2:   # IMPACT
                target_height = 0.55
            elif state == 3:   # DORMANCY
                target_height = 0.18
            else:              # ALARM
                target_height = 0.15

            smooth_height += 0.22 * (target_height - smooth_height)

            # Link activity
            l12_val = abs(float(link_signals["L12"][sample_idx]))
            l23_val = abs(float(link_signals["L23"][sample_idx]))
            l31_val = abs(float(link_signals["L31"][sample_idx]))

            links_activity = {
                "L12": float(np.clip(l12_val / 50.0, 0.05, 1.0)),
                "L23": float(np.clip(l23_val / 50.0, 0.05, 1.0)),
                "L31": float(np.clip(l31_val / 50.0, 0.05, 1.0))
            }

            vx = 0.0
            vy = 0.0
            # 2D Position tracking in room coordinates (-2m to 2m)
            if state == 0:
                pos_x = 0.0
                pos_y = 0.0
            elif state == 1:
                pos_x = 0.8 * np.sin(t_val * 0.8)
                pos_y = 0.6 * np.cos(t_val * 0.8)
                vx = 0.8 * 0.8 * np.cos(t_val * 0.8)
                vy = -0.6 * 0.8 * np.sin(t_val * 0.8)
            elif state in (2, 3, 4):
                pos_x = 0.2
                pos_y = -0.1

            # Doppler frequency
            if state == 2:
                doppler_max = 48.5
            elif state == 1:
                doppler_max = 18.2 + 3.0 * np.sin(t_val * 4.0)
            else:
                doppler_max = 1.8

            frame_telemetry = {
                "timestamp": t_val,
                "node_id": 1 + (sample_idx % 3),
                "rssi": -42.0 - 5.0 * links_activity["L12"],
                "csi_raw_52": csi_matrix_52[sample_idx],
                "pc1": float(link_signals["L12"][sample_idx]),
                "doppler_max": float(doppler_max),
                "posture_height": float(smooth_height),
                "fsm_state": state,
                "person_x": float(pos_x),
                "person_y": float(pos_y),
                "target_vx": float(vx),
                "target_vy": float(vy),
                "alarm_active": bool(state == 4 or (alarm_ts > 0 and t_val >= alarm_ts)),
                "links_activity": links_activity
            }

            self.sig_frame_ready.emit(frame_telemetry)

            sample_idx += step_samples
            if sample_idx >= n_samples:
                sample_idx = 0

            now = time.time()
            sleep_needed = self.frame_interval - (now - last_clock)
            if sleep_needed > 0.001:
                time.sleep(sleep_needed)
            last_clock = time.time()

    # -------------------------------------------------------------------------
    # Rolling Frame Processing
    # -------------------------------------------------------------------------
    def _process_rolling_frame(self, parsed: Dict[str, Any]) -> Dict[str, Any]:
        """Computes rolling DSP metrics, real-time Doppler, kinematics, and stateful FSM from hardware packet."""
        csi_52 = parsed["csi_raw_52"]
        node_id = parsed["node_id"]
        now = time.time()

        self.rolling_amp_buffer.append(csi_52)
        if len(self.rolling_amp_buffer) > self.rolling_buffer_size:
            self.rolling_amp_buffer.pop(0)

        buf = np.array(self.rolling_amp_buffer)
        pc1_val = 0.0
        # Discard dead zero channels (21-30) and pilot outliers per Hernandez & Bulut (2021)
        clean_buf = sanitize_subcarriers(buf) if len(buf) >= 8 else buf
        var_sub = float(np.mean(np.var(clean_buf, axis=0))) if len(clean_buf) >= 8 else 0.1

        if len(clean_buf) >= 16:
            centered = clean_buf - np.mean(clean_buf, axis=0)
            cov = np.cov(centered, rowvar=False)
            eigvals, eigvecs = np.linalg.eigh(cov)
            pc1_vec = eigvecs[:, -1]
            pc1_val = float(np.dot(centered[-1], pc1_vec))

        dt = max(0.01, now - self.last_pc1_time)
        d_pc1 = (pc1_val - self.last_pc1_val) / dt
        self.last_pc1_val = pc1_val
        self.last_pc1_time = now

        # Dynamic baseline calibration during initial frames
        if self.calib_samples < 50:
            self.calib_samples += 1
            self.baseline_var = 0.95 * self.baseline_var + 0.05 * var_sub

        # Update per-node variance / perturbation metric
        if node_id in self.node_variances:
            self.node_variances[node_id] = 0.8 * self.node_variances[node_id] + 0.2 * var_sub
        else:
            self.node_variances[node_id] = var_sub

        v1 = self.node_variances.get(1, 0.1)
        v2 = self.node_variances.get(2, 0.1)
        mean_activity = (v1 + v2) / 2.0

        # Doppler velocity estimation (Hz)
        raw_doppler = min(58.0, max(1.5, abs(d_pc1) * 0.9 + var_sub * 2.5))
        self.live_doppler = 0.75 * self.live_doppler + 0.25 * raw_doppler

        # 2D Kinematic Position Estimation in Room Space (-2.5 .. 2.5m)
        diff_nodes = (v2 - v1) / max(0.2, (v1 + v2))
        target_x = float(np.clip(diff_nodes * 1.6, -1.6, 1.6))
        target_y = float(np.clip(0.8 - (var_sub * 0.15), -0.8, 1.2))

        # Smooth position and velocity vectors
        new_px = self.person_x + 0.18 * (target_x - self.person_x)
        new_py = self.person_y + 0.18 * (target_y - self.person_y)
        self.target_vx = (new_px - self.person_x) / dt
        self.target_vy = (new_py - self.person_y) / dt
        self.person_x = new_px
        self.person_y = new_py

        # Analytical Fall Detector FSM transitions:
        # States: 0=CALM, 1=WALKING, 2=IMPACT, 3=DORMANCY, 4=ALARM
        if self.alarm_active:
            # Person is confirmed fallen
            self.live_state = 4
            self.posture_height = 0.15
            # If large active movement persists for > 1.5s after alarm, user got back up
            if var_sub > 15.0 and self.live_doppler > 14.0:
                self.calm_counter += 1
                if self.calm_counter > 35:
                    self.alarm_active = False
                    self.live_state = 1
                    self.calm_counter = 0
            else:
                self.calm_counter = 0

        elif self.live_state in (0, 1):
            # Check for sudden violent impact: high Doppler peak (>32 Hz) or sharp PC1 derivative drop
            is_impact = (self.live_doppler >= 32.0) or (abs(d_pc1) > 28.0) or (var_sub > 22.0 and d_pc1 < -18.0)
            is_walking = (var_sub > max(2.5, self.baseline_var * 1.8)) or (abs(pc1_val) > 4.5)
            if is_impact:
                self.live_state = 2  # IMPACT DETECTED
                self.impact_time = now
                self.dormancy_start = now
                self.posture_height = 0.55
                self.calm_counter = 0
            elif is_walking:
                self.live_state = 1  # WALKING
                self.calm_counter = 0
                step_osc = 0.04 * np.sin(now * 8.0)
                self.posture_height = 1.70 + float(step_osc)
            else:
                self.calm_counter += 1
                if self.calm_counter > 15:
                    self.live_state = 0  # CALM
                    self.posture_height = 1.75
                    # Drift avatar slowly toward center in calm
                    self.person_x *= 0.96
                    self.person_y *= 0.96

        elif self.live_state == 2:
            # Impact detected -> Transition immediately to dormancy verification
            self.live_state = 3
            self.dormancy_start = now
            self.posture_height = 0.22

        elif self.live_state == 3:
            # Post-impact dormancy check (immobility on the floor)
            dormant_elapsed = now - self.dormancy_start
            self.posture_height = max(0.16, self.posture_height - 0.02)

            if var_sub < 8.0 and self.live_doppler < 15.0:
                # Still motionless on the ground
                if dormant_elapsed >= 2.0:  # 2.0 seconds confirmed dormancy
                    self.live_state = 4     # TRIGGER ALARM
                    self.alarm_active = True
                    self.posture_height = 0.15
            else:
                # Active movement immediately after impact -> recovered or stumble
                if dormant_elapsed < 1.0:
                    self.live_state = 1
                    self.posture_height = 1.70

        # Activity levels on Fresnel mesh links (0.05 .. 1.0)
        l12_act = float(np.clip(mean_activity / 12.0, 0.05, 1.0))
        l23_act = float(np.clip(v2 / 12.0, 0.05, 1.0))
        l31_act = float(np.clip(v1 / 12.0, 0.05, 1.0))

        active_nodes_count = sum(1 for v in self.node_variances.values() if v > 0.05)
        link_status_hint = "Mesh Active (3 Nodes)" if active_nodes_count >= 3 else "1 Link Active: 1D Range (Connect Node 3 for 2D Fix)"

        return {
            "timestamp": parsed["timestamp"],
            "node_id": node_id,
            "rssi": parsed["rssi"],
            "csi_raw_52": csi_52,
            "pc1": pc1_val,
            "doppler_max": float(self.live_doppler),
            "posture_height": float(self.posture_height),
            "fsm_state": int(self.live_state),
            "person_x": float(self.person_x),
            "person_y": float(self.person_y),
            "target_vx": float(self.target_vx),
            "target_vy": float(self.target_vy),
            "alarm_active": bool(self.alarm_active),
            "link_status_hint": link_status_hint,
            "links_activity": {
                "L12": l12_act,
                "L23": l23_act,
                "L31": l31_act
            }
        }


# =============================================================================
# Self-Test Execution
# =============================================================================
if __name__ == '__main__':
    from PyQt6.QtCore import QCoreApplication

    print("=========================================================")
    print("[CSIDataEngine] Starting 3-Second Verification Self-Test")
    print("=========================================================")

    app = QCoreApplication(sys.argv)
    engine = CSIDataEngine(replay_mode=True, target_fps=50.0)

    received_frames = []

    def on_frame(data: dict):
        received_frames.append(data)
        count = len(received_frames)
        if count % 25 == 0:
            print(
                f"  Frame #{count:03d} | t={data['timestamp']:.2f}s | "
                f"FSM={data['fsm_state']} | Height={data['posture_height']:.2f}m | "
                f"Pos=({data['person_x']:.2f}, {data['person_y']:.2f}) | "
                f"Alarm={data['alarm_active']} | Subcarriers={len(data['csi_raw_52'])}"
            )

    engine.sig_frame_ready.connect(on_frame)
    engine.start()

    start_time = time.time()
    while time.time() - start_time < 3.0:
        app.processEvents()
        time.sleep(0.01)

    engine.stop()
    print("---------------------------------------------------------")
    print(f"[Self-Test] Total Frames Collected: {len(received_frames)}")

    assert len(received_frames) >= 40, f"Expected >= 40 frames in 3s, got {len(received_frames)}"
    sample = received_frames[-1]

    required_keys = [
        "timestamp", "node_id", "rssi", "csi_raw_52", "pc1",
        "doppler_max", "posture_height", "fsm_state", "person_x",
        "person_y", "alarm_active", "links_activity"
    ]
    for key in required_keys:
        assert key in sample, f"Missing telemetry key: '{key}'"

    assert len(sample["csi_raw_52"]) == 52, f"csi_raw_52 must have 52 elements, got {len(sample['csi_raw_52'])}"
    assert isinstance(sample["links_activity"], dict), "links_activity must be dict"
    assert "L12" in sample["links_activity"], "links_activity missing 'L12'"

    print("[Self-Test] PASS: All telemetry fields and rates verified.")
    print("=========================================================")
