"""
Licență UTCN - Wi-Fi CSI Human Sensing & Fall Detection System
Modul GUI: Widgets de Vizualizare Timp Real (PyQt6 + pyqtgraph)
Fișier: /home/vlads4r4/dev/Licenta/gui/widgets.py

Componente:
1. RoomMapWidget - Harta 2D a încăperii (-2.5m .. 2.5m) cu 3 noduri ESP32,
   elipsoide Fresnel dinamice și avatar uman (mers / cădere).
2. WaterfallWidget - Cascadă spectrală CSI (52 subpurtătoare, buffer 100 cadre).
3. DopplerWidget - Spectru Doppler (0-60 Hz) cu prag critic de cădere (35 Hz).
4. TelemetryWidget - Postură verticală CoM (0-1.8m), FSM State Pill (0..4), latență și rată pachete.
"""

import sys
import math
import collections
import numpy as np

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame,
    QGridLayout, QSizePolicy, QApplication, QMainWindow
)
from PyQt6.QtCore import Qt, QTimer, QRectF, QPointF
from PyQt6.QtGui import (
    QPainter, QPen, QBrush, QColor, QFont, QRadialGradient,
    QLinearGradient
)

import pyqtgraph as pg

# Configure pyqtgraph global visual style
pg.setConfigOptions(antialias=True)
pg.setConfigOption('background', '#0b0f19')
pg.setConfigOption('foreground', '#9ca3af')


class RoomMapWidget(QWidget):
    """
    Harta 2D a camerei (-2.5m .. 2.5m).
    Randare:
    - 3 noduri ESP32 la pozițiile:
      Nod 1: (-1.5, 1.0)
      Nod 2: (1.5, 1.0)
      Nod 3: (0.0, -1.5)
    - Elipsoide Fresnel confocale (Zona 1 & 2) între noduri, pulsând dinamic.
    - Avatar uman:
      * Stare CALM / MERS (0, 1): capsulă/cerc verde strălucitor + vector viteză.
      * Stare IMPACT / VERIFICARE / ALARMĂ (2, 3, 4): figură orizontală roșie
        pulsantă pe sol + banner 'CĂDERE DETECTATĂ / PERSOANĂ LA SOL'.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(380, 380)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        # Coordonate noduri ESP32 (metri)
        self.nodes = {
            1: (-1.5, 1.0),
            2: (1.5, 1.0),
            3: (0.0, -1.5)
        }
        self.links = [(1, 2), (2, 3), (3, 1)]

        # Stare țintă umană
        self.target_x = 0.0
        self.target_y = 0.0
        self.target_vx = 0.0
        self.target_vy = 0.0
        self.fsm_state = 0  # 0: CALM, 1: MERS, 2: IMPACT, 3: VERIF, 4: ALARMĂ

        # Nivel de activitate radio pe fiecare legătură (0.0 .. 1.0)
        self.links_activity = {
            (1, 2): 0.1,
            (2, 3): 0.1,
            (3, 1): 0.1
        }

        # Parametri animație puls
        self.pulse_phase = 0.0
        self.anim_timer = QTimer(self)
        self.anim_timer.timeout.connect(self._on_anim_tick)
        self.anim_timer.start(40)  # ~25 FPS pentru puls lin

    def _on_anim_tick(self):
        self.pulse_phase = (self.pulse_phase + 0.12) % (2.0 * math.pi)
        self.update()

    def update_data(self, data_dict: dict):
        """Actualizează poziția, starea și activitatea din fluxul CSI."""
        if not isinstance(data_dict, dict):
            return

        self.target_x = float(data_dict.get('person_x', data_dict.get('target_x', self.target_x)))
        self.target_y = float(data_dict.get('person_y', data_dict.get('target_y', self.target_y)))
        self.target_vx = float(data_dict.get('target_vx', 0.0))
        self.target_vy = float(data_dict.get('target_vy', 0.0))
        self.fsm_state = int(data_dict.get('fsm_state', self.fsm_state))

        if 'links_activity' in data_dict and isinstance(data_dict['links_activity'], dict):
            act_in = data_dict['links_activity']
            if 'L12' in act_in:
                self.links_activity[(1, 2)] = float(act_in['L12'])
            if 'L23' in act_in:
                self.links_activity[(2, 3)] = float(act_in['L23'])
            if 'L31' in act_in:
                self.links_activity[(3, 1)] = float(act_in['L31'])
            for k, v in act_in.items():
                if k in self.links_activity:
                    self.links_activity[k] = float(v)

        self.update()

    def _get_geometry(self):
        """Calculează caroiajul pătrat centrat în widget."""
        w = self.width()
        h = self.height()
        margin = 35.0
        side = max(100.0, min(w, h) - 2.0 * margin)
        ox = (w - side) / 2.0
        oy = (h - side) / 2.0
        scale = side / 5.0  # 5 metri lățime cameră (-2.5 .. 2.5)
        return ox, oy, side, scale

    def world_to_screen(self, x: float, y: float) -> QPointF:
        """Convertește coordonate cameră (-2.5..2.5) în pixeli ecran."""
        ox, oy, side, scale = self._get_geometry()
        sx = ox + (x - (-2.5)) * scale
        sy = oy + (2.5 - y) * scale  # Y inversat ecran
        return QPointF(sx, sy)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setRenderHint(QPainter.RenderHint.TextAntialiasing)

        ox, oy, side, scale = self._get_geometry()

        # 1. Fundal și chenar cameră
        painter.fillRect(self.rect(), QColor('#080d1a'))
        room_rect = QRectF(ox, oy, side, side)
        painter.setBrush(QBrush(QColor('#0b0f19')))
        painter.setPen(QPen(QColor('#1e293b'), 2.0))
        painter.drawRect(room_rect)

        # 2. Grilă carteziană (-2.5 .. 2.5 m)
        grid_pen = QPen(QColor('#151e32'), 1.0, Qt.PenStyle.DashLine)
        axis_pen = QPen(QColor('#334155'), 1.5, Qt.PenStyle.SolidLine)
        font_axis = QFont("Monospace", 8)
        painter.setFont(font_axis)

        for m in range(-2, 3):
            # Linii verticale
            p_top = self.world_to_screen(m, 2.5)
            p_bot = self.world_to_screen(m, -2.5)
            painter.setPen(axis_pen if m == 0 else grid_pen)
            painter.drawLine(p_top, p_bot)

            # Linii orizontale
            p_left = self.world_to_screen(-2.5, m)
            p_right = self.world_to_screen(2.5, m)
            painter.setPen(axis_pen if m == 0 else grid_pen)
            painter.drawLine(p_left, p_right)

            # Etichete axe
            painter.setPen(QColor('#64748b'))
            painter.drawText(int(p_bot.x() - 12), int(p_bot.y() + 15), f"{m:+d}m")
            painter.drawText(int(ox - 30), int(p_left.y() + 4), f"{m:+d}m")

        # 3. Elipsoide Fresnel între noduri
        wavelength = 0.1231  # 2.437 GHz (Canalul 6)
        for (i, j) in self.links:
            p1_w = self.nodes[i]
            p2_w = self.nodes[j]
            act = self.links_activity.get((i, j), 0.1)

            # Geometrie elipsă
            dx = p2_w[0] - p1_w[0]
            dy = p2_w[1] - p1_w[1]
            dist = math.hypot(dx, dy)
            mid_x = (p1_w[0] + p2_w[0]) / 2.0
            mid_y = (p1_w[1] + p2_w[1]) / 2.0

            # Raza 1st Fresnel: a = (D + lambda/2)/2, b = sqrt(lambda * D / 4)
            a_fresnel_1 = (dist + wavelength / 2.0) / 2.0
            b_fresnel_1 = 0.5 * math.sqrt(wavelength * dist + (wavelength ** 2) / 4.0)

            # Pixeli
            a_px = a_fresnel_1 * scale
            b_px = b_fresnel_1 * scale
            center_px = self.world_to_screen(mid_x, mid_y)
            p1_px = self.world_to_screen(p1_w[0], p1_w[1])
            p2_px = self.world_to_screen(p2_w[0], p2_w[1])

            angle_rad = math.atan2(p2_px.y() - p1_px.y(), p2_px.x() - p1_px.x())
            angle_deg = math.degrees(angle_rad)

            # Puls dinamic
            pulse = 0.5 + 0.5 * math.sin(self.pulse_phase + float(i))
            base_alpha = int(35 + 180 * act * pulse)
            base_alpha = max(20, min(230, base_alpha))

            painter.save()
            painter.translate(center_px)
            painter.rotate(angle_deg)

            # Linie directă LoS
            painter.setPen(QPen(QColor(6, 182, 212, int(40 + 80 * act)), 1.2, Qt.PenStyle.DashLine))
            painter.drawLine(QPointF(-dist * scale / 2.0, 0), QPointF(dist * scale / 2.0, 0))

            # Halou exterior Zona 1
            painter.setBrush(QBrush(QColor(6, 182, 212, int(base_alpha * 0.18))))
            painter.setPen(QPen(QColor(6, 182, 212, base_alpha), 1.8))
            painter.drawEllipse(QRectF(-a_px, -b_px, 2.0 * a_px, 2.0 * b_px))

            # Zona 2 mai discretă
            a2_px = ((dist + wavelength) / 2.0) * scale
            b2_px = (0.5 * math.sqrt(2.0 * wavelength * dist)) * scale
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.setPen(QPen(QColor(56, 189, 248, int(base_alpha * 0.4)), 1.0, Qt.PenStyle.DotLine))
            painter.drawEllipse(QRectF(-a2_px, -b2_px, 2.0 * a2_px, 2.0 * b2_px))

            painter.restore()

        # 4. Noduri ESP32
        for nid, (nx, ny) in self.nodes.items():
            np_px = self.world_to_screen(nx, ny)

            # Inel exterior de emisie
            ring_r = 14.0 + 3.0 * math.sin(self.pulse_phase + nid)
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.setPen(QPen(QColor(56, 189, 248, 120), 1.5))
            painter.drawEllipse(np_px, ring_r, ring_r)

            # Corp nod
            painter.setBrush(QBrush(QColor('#0284c7')))
            painter.setPen(QPen(QColor('#e0f2fe'), 2.0))
            painter.drawEllipse(np_px, 8.0, 8.0)

            # Etichetă nod
            painter.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
            painter.setPen(QColor('#f8fafc'))
            painter.drawText(int(np_px.x() + 12), int(np_px.y() + 4), f"ESP32 #{nid}")

        # 5. Avatar Uman
        target_px = self.world_to_screen(self.target_x, self.target_y)
        is_fall = (self.fsm_state in [2, 3, 4])

        if not is_fall:
            # === STARE MERS / CALM ===
            glow_grad = QRadialGradient(target_px, 30.0, target_px)
            glow_grad.setColorAt(0.0, QColor(34, 197, 94, 160))
            glow_grad.setColorAt(0.5, QColor(34, 197, 94, 60))
            glow_grad.setColorAt(1.0, QColor(34, 197, 94, 0))
            painter.setBrush(QBrush(glow_grad))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(target_px, 28.0, 28.0)

            painter.setBrush(QBrush(QColor('#22c55e')))
            painter.setPen(QPen(QColor('#ffffff'), 2.0))
            painter.drawEllipse(target_px, 9.0, 9.0)

            speed = math.hypot(self.target_vx, self.target_vy)
            if speed > 0.05:
                dir_x = self.target_vx / speed
                dir_y = -self.target_vy / speed
                arr_len = min(50.0, max(18.0, speed * 26.0))
                tip = QPointF(target_px.x() + dir_x * arr_len, target_px.y() + dir_y * arr_len)

                painter.setPen(QPen(QColor('#4ade80'), 2.5, Qt.PenStyle.SolidLine))
                painter.drawLine(target_px, tip)

                ang = math.atan2(dir_y, dir_x)
                h_len = 8.0
                p_a = QPointF(tip.x() - h_len * math.cos(ang - 0.5), tip.y() - h_len * math.sin(ang - 0.5))
                p_b = QPointF(tip.x() - h_len * math.cos(ang + 0.5), tip.y() - h_len * math.sin(ang + 0.5))
                painter.drawLine(tip, p_a)
                painter.drawLine(tip, p_b)

            lbl = f"OM ({self.target_x:+.2f}, {self.target_y:+.2f})"
            painter.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
            painter.setPen(QColor('#86efac'))
            painter.drawText(int(target_px.x() - 35), int(target_px.y() + 24), lbl)

        else:
            # === STARE IMPACT / ALARMĂ CĂDERE ===
            for wave_idx in range(2):
                shock_r = (int(self.pulse_phase * 18 + wave_idx * 20) % 46) + 12
                shock_alpha = max(0, int(220 - shock_r * 4.2))
                painter.setPen(QPen(QColor(239, 68, 68, shock_alpha), 2.0))
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawEllipse(target_px, float(shock_r), float(shock_r))

            box_w = 60.0
            box_h = 20.0
            flat_rect = QRectF(target_px.x() - box_w / 2.0, target_px.y() - box_h / 2.0, box_w, box_h)

            flash_on = (int(self.pulse_phase * 4) % 2 == 0)
            fill_col = QColor('#dc2626') if flash_on else QColor('#7f1d1d')

            painter.setBrush(QBrush(fill_col))
            painter.setPen(QPen(QColor('#fca5a5'), 2.2))
            painter.drawRoundedRect(flat_rect, 6.0, 6.0)

            head_pt = QPointF(target_px.x() - 19.0, target_px.y())
            painter.setBrush(QBrush(QColor('#ffffff')))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(head_pt, 4.5, 4.5)

            banner_w = 230.0
            banner_h = 24.0
            banner_rect = QRectF(target_px.x() - banner_w / 2.0, target_px.y() - 38.0, banner_w, banner_h)
            painter.setBrush(QBrush(QColor(153, 27, 27, 230)))
            painter.setPen(QPen(QColor('#ef4444'), 1.8))
            painter.drawRoundedRect(banner_rect, 4.0, 4.0)

            painter.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
            painter.setPen(QColor('#fef08a'))
            painter.drawText(banner_rect, Qt.AlignmentFlag.AlignCenter, "⚠ CĂDERE DETECTATĂ / PERSOANĂ LA SOL")

        # 6. Titlu colț stânga-sus
        painter.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
        painter.setPen(QColor('#94a3b8'))
        painter.drawText(int(ox + 8), int(oy + 18), "HARTĂ CAMERĂ 2D - ZONE FRESNEL & POZIȚIE")


class WaterfallWidget(QWidget):
    """
    Cascadă spectrală CSI pentru cele 52 de subpurtătoare active OFDM.
    Menține un buffer circular de 100 de cadre folosind pyqtgraph.ImageItem.
    """

    def __init__(self, parent=None, n_subcarriers=52, n_frames=100):
        super().__init__(parent)
        self.n_subcarriers = n_subcarriers
        self.n_frames = n_frames

        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)

        self.buffer = np.zeros((self.n_frames, self.n_subcarriers), dtype=np.float32)

        self.plot_widget = pg.PlotWidget()
        self.plot_widget.setTitle("Cascadă Amplitudine CSI (52 Subpurtătoare)", color='#9ca3af', size='10pt')
        self.plot_widget.setLabel('bottom', "Index Subpurtătoare OFDM", units="[-26 .. 26]")
        self.plot_widget.setLabel('left', "Istoric Timp", units="Cadre")
        self.plot_widget.showGrid(x=True, y=True, alpha=0.2)

        self.image_item = pg.ImageItem()
        self.plot_widget.addItem(self.image_item)

        try:
            cmap = pg.colormap.get('plasma')
        except Exception:
            try:
                cmap = pg.colormap.get('viridis')
            except Exception:
                cmap = None

        if cmap is not None:
            try:
                self.image_item.setColorMap(cmap)
            except Exception:
                lut = cmap.getLookupTable(0.0, 1.0, 256)
                self.image_item.setLookupTable(lut)

        self.image_item.setRect(QRectF(-26, 0, 52, self.n_frames))
        self.plot_widget.setXRange(-26, 26, padding=0.01)
        self.plot_widget.setYRange(0, self.n_frames, padding=0.01)

        self.layout.addWidget(self.plot_widget)

    def update_data(self, data_dict: dict):
        if not isinstance(data_dict, dict):
            return

        csi_frame = data_dict.get('csi_raw_52', data_dict.get('csi_matrix', data_dict.get('subcarriers')))
        if csi_frame is None:
            return

        csi_arr = np.asarray(csi_frame, dtype=np.float32)

        if csi_arr.ndim == 1:
            if len(csi_arr) < self.n_subcarriers:
                csi_arr = np.pad(csi_arr, (0, self.n_subcarriers - len(csi_arr)), mode='edge')
            else:
                csi_arr = csi_arr[:self.n_subcarriers]

            self.buffer[:-1] = self.buffer[1:]
            self.buffer[-1] = csi_arr
        elif csi_arr.ndim == 2:
            n_new = min(len(csi_arr), self.n_frames)
            self.buffer[:-n_new] = self.buffer[n_new:]
            self.buffer[-n_new:] = csi_arr[-n_new:, :self.n_subcarriers]

        self.image_item.setImage(self.buffer.T, autoLevels=False, levels=(0.0, 35.0))


class DopplerWidget(QWidget):
    """
    Grafic în timp real pentru deplasarea Doppler (0 - 60 Hz).
    Include linie punctată roșie la pragul de cădere de 35 Hz.
    """

    def __init__(self, parent=None, max_points=120):
        super().__init__(parent)
        self.max_points = max_points
        self.doppler_history = collections.deque(maxlen=self.max_points)
        for _ in range(self.max_points):
            self.doppler_history.append(0.0)

        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(4)

        self.lbl_speed = QLabel("Doppler: 0.0 Hz | Viteză Corp: 0.00 m/s [CALM]")
        self.lbl_speed.setStyleSheet("""
            QLabel {
                color: #38bdf8;
                font-family: 'Segoe UI', Monospace;
                font-size: 12px;
                font-weight: bold;
                background-color: #0b0f19;
                border: 1px solid #1e293b;
                border-radius: 5px;
                padding: 4px 8px;
            }
        """)
        self.layout.addWidget(self.lbl_speed)

        self.plot_widget = pg.PlotWidget()
        self.plot_widget.setTitle("Spectru Doppler Live (0 - 60 Hz)", color='#9ca3af', size='10pt')
        self.plot_widget.setLabel('bottom', "Cadre")
        self.plot_widget.setLabel('left', "Frecvență Doppler", units="Hz")
        self.plot_widget.setYRange(0, 65, padding=0.02)
        self.plot_widget.setXRange(0, self.max_points, padding=0.01)
        self.plot_widget.showGrid(x=True, y=True, alpha=0.25)

        self.thresh_line = pg.InfiniteLine(
            pos=35.0,
            angle=0,
            pen=pg.mkPen(color='#ef4444', width=2.2, style=Qt.PenStyle.DashLine),
            label="Prag Cădere (35 Hz)",
            labelOpts={'position': 0.85, 'color': '#ef4444', 'fill': (35, 10, 10, 210)}
        )
        self.plot_widget.addItem(self.thresh_line)

        self.curve = self.plot_widget.plot(
            pen=pg.mkPen(color='#06b6d4', width=2.5)
        )

        self.layout.addWidget(self.plot_widget)

    def update_data(self, data_dict: dict):
        if not isinstance(data_dict, dict):
            return

        doppler_freq = float(data_dict.get('doppler_max', data_dict.get('doppler_freq', 0.0)))
        speed = float(data_dict.get('speed', doppler_freq * 0.06155))

        self.doppler_history.append(doppler_freq)
        self.curve.setData(list(self.doppler_history))

        if doppler_freq >= 35.0:
            self.curve.setPen(pg.mkPen(color='#ef4444', width=3.0))
            self.lbl_speed.setText(f"⚠ IMPACT! Doppler: {doppler_freq:.1f} Hz | Viteză: {speed:.2f} m/s [CRITIC]")
            self.lbl_speed.setStyleSheet("""
                QLabel {
                    color: #fca5a5;
                    font-family: 'Segoe UI', Monospace;
                    font-size: 12px;
                    font-weight: bold;
                    background-color: #450a0a;
                    border: 1px solid #dc2626;
                    border-radius: 5px;
                    padding: 4px 8px;
                }
            """)
        else:
            self.curve.setPen(pg.mkPen(color='#06b6d4', width=2.5))
            state_desc = "MERS" if doppler_freq > 10.0 else "CALM"
            self.lbl_speed.setText(f"Doppler: {doppler_freq:.1f} Hz | Viteză: {speed:.2f} m/s [{state_desc}]")
            self.lbl_speed.setStyleSheet("""
                QLabel {
                    color: #38bdf8;
                    font-family: 'Segoe UI', Monospace;
                    font-size: 12px;
                    font-weight: bold;
                    background-color: #0b0f19;
                    border: 1px solid #1e293b;
                    border-radius: 5px;
                    padding: 4px 8px;
                }
            """)


class PostureGaugeWidget(QWidget):
    """Termometru vertical de postură corporală (0m - 1.8m)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(85, 200)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)
        self.height_m = 1.75

    def set_height(self, h: float):
        self.height_m = max(0.0, min(1.8, float(h)))
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        w = self.width()
        h = self.height()

        bar_x = 12.0
        bar_w = 26.0
        top_y = 20.0
        bot_y = h - 25.0
        bar_h = bot_y - top_y

        bg_rect = QRectF(bar_x, top_y, bar_w, bar_h)
        painter.setBrush(QBrush(QColor('#0f172a')))
        painter.setPen(QPen(QColor('#334155'), 1.5))
        painter.drawRoundedRect(bg_rect, 6.0, 6.0)

        frac = self.height_m / 1.8
        fill_h = frac * bar_h
        fill_y = bot_y - fill_h
        fill_rect = QRectF(bar_x + 2, fill_y, bar_w - 4, fill_h)

        if self.height_m < 0.5:
            fill_color = QColor('#dc2626')
        elif self.height_m < 1.0:
            fill_color = QColor('#f59e0b')
        else:
            fill_color = QColor('#10b981')

        painter.setBrush(QBrush(fill_color))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawRoundedRect(fill_rect, 4.0, 4.0)

        ticks = [
            (1.8, "1.8m (Picioare)"),
            (1.2, "1.2m"),
            (0.8, "0.8m (Așezat)"),
            (0.4, "0.4m (Sol)"),
            (0.0, "0.0m")
        ]
        painter.setFont(QFont("Segoe UI", 7))
        painter.setPen(QColor('#94a3b8'))

        for val, label in ticks:
            tick_y = bot_y - (val / 1.8) * bar_h
            painter.drawLine(QPointF(bar_x + bar_w, tick_y), QPointF(bar_x + bar_w + 4, tick_y))
            painter.drawText(int(bar_x + bar_w + 8), int(tick_y + 3), label)

        painter.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
        painter.setPen(fill_color)
        painter.drawText(int(bar_x - 4), int(h - 6), f"{self.height_m:.2f} m")


class TelemetryWidget(QWidget):
    """Panou integrat de telemetrie de sistem."""

    FSM_STYLES = {
        0: {"name": "0: CALM / INACTIV", "bg": "#334155", "fg": "#f1f5f9", "border": "#64748b"},
        1: {"name": "1: MERS / ACTIVITATE", "bg": "#1d4ed8", "fg": "#ffffff", "border": "#3b82f6"},
        2: {"name": "2: IMPACT DETECTAT", "bg": "#ea580c", "fg": "#ffffff", "border": "#f97316"},
        3: {"name": "3: VERIFICARE IMOBILITATE", "bg": "#ca8a04", "fg": "#ffffff", "border": "#eab308"},
        4: {"name": "4: ALARMĂ CĂDERE!", "bg": "#dc2626", "fg": "#ffffff", "border": "#ef4444"}
    }

    def __init__(self, parent=None):
        super().__init__(parent)
        self.current_state = 0
        self.flash_state = False

        self.flash_timer = QTimer(self)
        self.flash_timer.timeout.connect(self._toggle_flash)
        self.flash_timer.start(250)

        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(10, 8, 10, 8)
        main_layout.setSpacing(14)

        self.posture_gauge = PostureGaugeWidget(self)
        main_layout.addWidget(self.posture_gauge)

        right_panel = QVBoxLayout()
        right_panel.setSpacing(10)

        lbl_sec = QLabel("STARE FSM & TELEMETRIE CSI")
        lbl_sec.setStyleSheet("color: #94a3b8; font-weight: bold; font-size: 11px;")
        right_panel.addWidget(lbl_sec)

        self.fsm_badge = QLabel("0: CALM / INACTIV")
        self.fsm_badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.fsm_badge.setFixedHeight(44)
        self._apply_fsm_style(0)
        right_panel.addWidget(self.fsm_badge)

        grid = QGridLayout()
        grid.setSpacing(8)

        self.card_latency = self._create_card("Latență Procesare", "2.60 s", "#38bdf8")
        self.card_rate = self._create_card("Putere RSSI", "-42 dBm", "#34d399")
        self.card_links = self._create_card("Link-uri Active", "3 / 3 Mesh", "#a78bfa")
        self.card_pc1 = self._create_card("Energie PC1", "0.00", "#fbbf24")

        grid.addWidget(self.card_latency['frame'], 0, 0)
        grid.addWidget(self.card_rate['frame'], 0, 1)
        grid.addWidget(self.card_links['frame'], 1, 0)
        grid.addWidget(self.card_pc1['frame'], 1, 1)

        right_panel.addLayout(grid)
        right_panel.addStretch(1)

        main_layout.addLayout(right_panel, stretch=1)

    def _create_card(self, title: str, value: str, val_color: str) -> dict:
        frame = QFrame()
        frame.setStyleSheet("""
            QFrame {
                background-color: #0b0f19;
                border: 1px solid #1e293b;
                border-radius: 6px;
                padding: 6px;
            }
        """)
        lay = QVBoxLayout(frame)
        lay.setContentsMargins(6, 4, 6, 4)
        lay.setSpacing(2)

        lbl_t = QLabel(title)
        lbl_t.setStyleSheet("color: #64748b; font-size: 9px; font-weight: bold;")

        lbl_v = QLabel(value)
        lbl_v.setStyleSheet(f"color: {val_color}; font-size: 13px; font-weight: bold; font-family: Monospace;")

        lay.addWidget(lbl_t)
        lay.addWidget(lbl_v)
        return {'frame': frame, 'val': lbl_v}

    def _apply_fsm_style(self, state: int):
        st = self.FSM_STYLES.get(state, self.FSM_STYLES[0])
        bg = st['bg']
        if state == 4 and self.flash_state:
            bg = "#7f1d1d"

        self.fsm_badge.setText(st['name'])
        self.fsm_badge.setStyleSheet(f"""
            QLabel {{
                background-color: {bg};
                color: {st['fg']};
                border: 2px solid {st['border']};
                border-radius: 8px;
                font-size: 13px;
                font-weight: bold;
                padding: 6px;
            }}
        """)

    def _toggle_flash(self):
        if self.current_state == 4:
            self.flash_state = not self.flash_state
            self._apply_fsm_style(4)

    def reset_alarm(self):
        self.current_state = 0
        self._apply_fsm_style(0)

    def update_data(self, data_dict: dict):
        if not isinstance(data_dict, dict):
            return

        h_val = data_dict.get('posture_height', data_dict.get('height'))
        if h_val is not None:
            self.posture_gauge.set_height(float(h_val))

        state = int(data_dict.get('fsm_state', self.current_state))
        if state != self.current_state:
            self.current_state = state
            self.flash_state = False
            self._apply_fsm_style(state)

        if 'rssi' in data_dict:
            self.card_rate['val'].setText(f"{float(data_dict['rssi']):.1f} dBm")
        if 'pc1' in data_dict:
            self.card_pc1['val'].setText(f"{float(data_dict['pc1']):.2f}")
        if 'links_activity' in data_dict and isinstance(data_dict['links_activity'], dict):
            n_active = sum(1 for v in data_dict['links_activity'].values() if v > 0.1)
            self.card_links['val'].setText(f"{n_active} / 3 Mesh")
        if state in (2, 3, 4):
            self.card_latency['val'].setText(f"{data_dict.get('latency', 2.54):.2f} s")
        else:
            self.card_latency['val'].setText("--")


__all__ = [
    'RoomMapWidget',
    'WaterfallWidget',
    'DopplerWidget',
    'PostureGaugeWidget',
    'TelemetryWidget'
]
