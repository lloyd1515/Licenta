#!/usr/bin/env python3
"""
Sistem Inteligent de Monitorizare Ambientală Wi-Fi CSI — Licență UTCN
Punctul de Intrare Principal (Application Entry Point)

Rulare:
    .venv/bin/python gui/app.py --replay
    .venv/bin/python gui/app.py --live --port /dev/ttyUSB1
    .venv/bin/python gui/app.py --test
"""

import sys
import os
import signal
import argparse
import time

# Ensure project root in sys.path
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(CURRENT_DIR)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

def parse_args():
    parser = argparse.ArgumentParser(
        description="Sistem Inteligent de Monitorizare Ambientală Wi-Fi CSI — Desktop App (PyQt6)"
    )
    parser.add_argument(
        "--replay",
        nargs="?",
        const="DEFAULT",
        default=None,
        help="Rulează în mod Replay. Opțional specifică calea către fișierul .npz (implicit: dsp_lab/test_C_cadere_reala.npz)",
    )
    parser.add_argument(
        "--live",
        action="store_true",
        help="Pornește automat achiziția Live USB la lansare",
    )
    parser.add_argument(
        "--port",
        type=str,
        default="/dev/ttyUSB1",
        help="Port serial principal pentru nodul ESP32 (implicit: /dev/ttyUSB1)",
    )
    parser.add_argument(
        "--baud",
        type=int,
        default=921600,
        help="Baudrate port serial ESP32 (implicit: 921600)",
    )
    parser.add_argument(
        "--fps",
        type=float,
        default=50.0,
        help="Frecvență țintă redare cadre (implicit: 50.0 FPS)",
    )
    parser.add_argument(
        "--offscreen",
        action="store_true",
        help="Rulează fără interfață grafică fizică (headless / platform offscreen)",
    )
    parser.add_argument(
        "--test",
        action="store_true",
        help="Rulează un test automat complet de integrare (smoke test) timp de 3 secunde și iese cu cod 0",
    )
    return parser.parse_args()


def run_smoke_test(args):
    """
    Test automat de integrare fără GUI fizic.
    Verifică: instanțiere engine, conectare semnale, recepție cadre,
    procesare DSP, detecție FSM și închidere curată.
    """
    print("[SMOKE-TEST] Inițializare mediu offscreen pentru testare automată...")
    os.environ["QT_QPA_PLATFORM"] = "offscreen"

    from PyQt6.QtWidgets import QApplication
    from PyQt6.QtCore import QTimer
    from gui.backend_engine import CSIDataEngine
    from gui.main_window import MainWindow

    app = QApplication(["--platform", "offscreen"])

    replay_path = None
    if args.replay and args.replay != "DEFAULT":
        replay_path = args.replay
    else:
        replay_path = os.path.join(PROJECT_ROOT, "dsp_lab", "test_C_cadere_reala.npz")

    if not os.path.exists(replay_path):
        print(f"[SMOKE-TEST] EȘEC: Fișierul de test {replay_path} nu există!")
        sys.exit(1)

    print(f"[SMOKE-TEST] Fișier replay selectat: {replay_path}")
    engine = CSIDataEngine(
        port=args.port,
        baudrate=args.baud,
        replay_mode=True,
        replay_file=replay_path,
        target_fps=args.fps,
    )

    window = MainWindow(engine=engine)
    window.show()

    frame_count = 0
    alarm_triggered = False

    def on_frame(data):
        nonlocal frame_count, alarm_triggered
        frame_count += 1
        if data.get("alarm_active", False) or data.get("fsm_state") == 4:
            alarm_triggered = True

    engine.sig_frame_ready.connect(on_frame)

    print("[SMOKE-TEST] Pornire engine...")
    engine.start()

    # Rulează bucla Qt pentru 3 secunde
    start_time = time.time()
    test_duration = 3.0

    timer = QTimer()
    timer.setInterval(50)

    def check_progress():
        elapsed = time.time() - start_time
        if elapsed >= test_duration:
            timer.stop()
            engine.stop()
            window.close()
            app.quit()

    timer.timeout.connect(check_progress)
    timer.start()

    app.exec()

    print(f"[SMOKE-TEST] Rezultate: {frame_count} cadre procesate în {test_duration} secunde.")
    print(f"[SMOKE-TEST] Alarmă cădere declanșată: {alarm_triggered}")

    if frame_count < 30:
        print("[SMOKE-TEST] EȘEC: Prea puține cadre procesate!")
        sys.exit(1)

    print("[SMOKE-TEST] SUCCES: Toate componentele GUI, Engine și FSM funcționează perfect!")
    sys.exit(0)


def main():
    args = parse_args()

    if args.test:
        run_smoke_test(args)
        return

    if args.offscreen:
        os.environ["QT_QPA_PLATFORM"] = "offscreen"

    from PyQt6.QtWidgets import QApplication
    from PyQt6.QtCore import QTimer
    from gui.backend_engine import CSIDataEngine
    from gui.main_window import MainWindow

    # Permite întreruperea prin Ctrl+C
    signal.signal(signal.SIGINT, signal.SIG_DFL)

    app = QApplication(sys.argv)
    app.setApplicationName("Wi-Fi CSI Sensing & Fall Detection")
    app.setOrganizationName("UTCN")

    # Periodic timer to allow Python signal handling (SIGINT)
    sig_timer = QTimer()
    sig_timer.setInterval(200)
    sig_timer.timeout.connect(lambda: None)
    sig_timer.start()

    # Configurare replay path dacă a fost cerut
    replay_path = None
    if args.replay:
        if args.replay != "DEFAULT":
            replay_path = args.replay
        else:
            replay_path = os.path.join(PROJECT_ROOT, "dsp_lab", "test_C_cadere_reala.npz")

    is_replay = bool(args.replay)
    is_live = bool(args.live) and not is_replay

    engine = CSIDataEngine(
        port=args.port,
        baudrate=args.baud,
        replay_mode=is_replay,
        replay_file=replay_path,
        target_fps=args.fps,
    )

    window = MainWindow(engine=engine)

    # Actualizare selecție port în interfață dacă e custom
    idx = window.combo_ports.findText(args.port)
    if idx >= 0:
        window.combo_ports.setCurrentIndex(idx)
    else:
        window.combo_ports.insertItem(0, args.port)
        window.combo_ports.setCurrentIndex(0)

    # Dacă s-a cerut explicit live sau replay din CLI, declanșăm butonul corespunzător
    if is_replay:
        window.btn_replay.setChecked(True)
        window._on_replay_toggle(True)
    elif is_live:
        window.btn_live.setChecked(True)
        window._on_live_toggle(True)

    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
